package org.testng.internal.annotations;

public interface IBeforeGroups extends IBaseBeforeAfter {

}
