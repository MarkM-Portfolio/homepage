-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 65
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 65 FOR HP
------------------------------------------------

--{include.hp-fixup65.sql}

------------------------------------------------
-- INCLUDE FIX UP 65 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------
-- 1) ADD COLUMN TO THE EMD_EMAIL_PREFS TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS ADD REPLYTO_ENABLED NUMBER(5,0) DEFAULT 1 NOT NULL;

COMMIT;

-----------------------------------------------------------------------------------------------
-- 2) ADD COLUMNS TO THE EMD_TRANCHE TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE ADD (
	IS_LOCKED_DAILY NUMBER(5,0) DEFAULT 0 NOT NULL,
	IS_LOCKED_WEEKLY NUMBER(5,0) DEFAULT 0 NOT NULL,
	LAST_STARTED_DAILY TIMESTAMP,
	LAST_STARTED_WEEKLY TIMESTAMP,
	LAST_EXEC_TIME_DAILY_MIN  NUMBER(10 ,0),
	LAST_EXEC_TIME_WEEKLY_MIN  NUMBER(10 ,0),
	LAST_RUNNER_DAILY VARCHAR2(256),
	LAST_RUNNER_WEEKLY VARCHAR2(256)
);

COMMIT;

---------------------------------------------------------------------------------
-- 3) MODIFY QUARANTINE TABLE
---------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE ADD STATUS NUMBER(5,0) DEFAULT 0 NOT NULL;

COMMIT;

--------------------------------------------------------------------------------
-- 4) RENAMING TABLES
--------------------------------------------------------------------------------
DROP VIEW HOMEPAGE.NR_FOLLOWED_STORIES;

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT CK_CAT1_TYPE;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_STORIES RENAME TO NR_RESPONSES_READERS;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CONSTRAINT CK_CAT1_TYPE CHECK (CATEGORY_TYPE = 1);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT CK_CAT2_TYPE;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_STORIES RENAME TO NR_PROFILES_READERS;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CONSTRAINT CK_CAT2_TYPE CHECK (CATEGORY_TYPE = 2);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT CK_CAT3_TYPE;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_STORIES RENAME TO NR_COMMUNITIES_READERS;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CONSTRAINT CK_CAT3_TYPE CHECK (CATEGORY_TYPE = 3);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT CK_CAT4_TYPE;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_STORIES RENAME TO NR_ACTIVITIES_READERS;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CONSTRAINT CK_CAT4_TYPE CHECK (CATEGORY_TYPE = 4);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT CK_CAT5_TYPE;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_STORIES RENAME TO NR_BLOGS_READERS;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CONSTRAINT CK_CAT5_TYPE CHECK (CATEGORY_TYPE = 5);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT CK_CAT6_TYPE;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_STORIES RENAME TO NR_BOOKMARKS_READERS;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CONSTRAINT CK_CAT6_TYPE CHECK (CATEGORY_TYPE = 6);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT CK_CAT7_TYPE;
ALTER TABLE 	HOMEPAGE.NR_FILES_STORIES RENAME TO NR_FILES_READERS;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CONSTRAINT CK_CAT7_TYPE CHECK (CATEGORY_TYPE = 7);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT CK_CAT8_TYPE;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_STORIES RENAME TO NR_FORUMS_READERS;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CONSTRAINT CK_CAT8_TYPE CHECK (CATEGORY_TYPE = 8);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT CK_CAT9_TYPE;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_STORIES RENAME TO NR_WIKIS_READERS;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CONSTRAINT CK_CAT9_TYPE CHECK (CATEGORY_TYPE = 9);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT CK_CAT10_TYPE;
ALTER TABLE 	HOMEPAGE.NR_TAGS_STORIES RENAME TO NR_TAGS_READERS;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CONSTRAINT CK_CAT10_TYPE CHECK (CATEGORY_TYPE = 10);

COMMIT;

ALTER TABLE  HOMEPAGE.NR_RESPONSES_READERS ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_PROFILES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_COMMUNITIES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_ACTIVITIES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_BLOGS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_BOOKMARKS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_FILES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_FORUMS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_WIKIS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_TAGS_READERS  ENABLE ROW MOVEMENT;

COMMIT;

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE CATEGORIES READERS TABLE
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
);

COMMIT;


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESPONSES_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_PROFILES_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMMUNITIES_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ACTIVITIES_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_BLOGS_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_BOOKMARKS_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FILES_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FORUMS_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_WIKIS_READERS TO HOMEPAGEUSER_ROLE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_TAGS_READERS TO HOMEPAGEUSER_ROLE;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORIES_READERS TO HOMEPAGEUSER_ROLE;
  	


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 65 FOR SEARCH
------------------------------------------------

--{include.search-fixup65.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 65
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 65 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 64;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 65
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
