-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 67
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 67 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- Adding column to trace the LAST_ACTIONABLE_VISIT
---------------------------------------------------------
ALTER TABLE HOMEPAGE.HP_UI
	ADD LAST_ACTIONABLE_VISIT DATETIME;
GO	

UPDATE HOMEPAGE.HP_UI SET LAST_ACTIONABLE_VISIT = CURRENT_TIMESTAMP;
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 67 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- UPDATING SOURCE_TYPE TABLE
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
	ADD IS_ENABLE NUMERIC(5,0);

GO
	
UPDATE HOMEPAGE.NR_SOURCE_TYPE SET IS_ENABLE = 1;

GO


----------------------------------------------------------------------
-- [START] INDEX CLEANUP
----------------------------------------------------------------------

-----------------------------------------------
-- FIXING INDEXES ON COMM_STORIES TABLE
-----------------------------------------------
DROP INDEX  NR_COMM_STORIES_COM_ID ON HOMEPAGE.NR_COMM_STORIES;

CREATE INDEX NR_COMM_STORIES_CDATE
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, CREATION_DATE ASC); 

CREATE INDEX NR_COM_STORY_ID			ON	HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, STORY_ID);

GO

-- DROPPING UNUSED INDEXES FOR READERS TABLES
DROP INDEX  RESPONSES_STORIES_CIDX 		ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX  PROFILES_STORIES_CIDX		ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX  COMMUNITIES_STORIES_CIDX	ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX  ACTIVITIES_STORIES_CIDX		ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX  BLOGS_STORIES_CIDX			ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX  BOOKMARKS_STORIES_CIDX		ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX  FILES_STORIES_CIDX			ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX  FORUMS_STORIES_CIDX			ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX  WIKIS_STORIES_CIDX			ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX  TAGS_STORIES_CIDX			ON HOMEPAGE.NR_TAGS_READERS;

-- ADDING INDEXES used to retrieve the evidence and delete records
CREATE INDEX NR_RESP_READER_STORY 		ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID); 
CREATE INDEX NR_PRO_READER_STORY 		ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_COM_READER_STORY 		ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_ACT_READER_STORY 		ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_BLG_READER_STORY 		ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_BOOK_READER_STORY 		ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_FILES_READER_STORY 		ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_FORUMS_READER_STORY 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_WIKIS_READER_STORY 		ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_TAGS_READER_STORY 		ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID);



GO

-- DROPPING UNUSED INDEXES FOR ENTRIES TABLES
DROP INDEX  NR_ENTRIES_ACT_SRC		ON HOMEPAGE.NR_ENTRIES_ACT;
DROP INDEX  NR_ENTRIES_BLG_SRC 		ON HOMEPAGE.NR_ENTRIES_BLG;
DROP INDEX  NR_ENTRIES_COM_SRC 		ON HOMEPAGE.NR_ENTRIES_COM;
DROP INDEX  NR_ENTRIES_WIK_SRC 		ON HOMEPAGE.NR_ENTRIES_WIK;
DROP INDEX  NR_ENTRIES_PRF_SRC 		ON HOMEPAGE.NR_ENTRIES_PRF;
DROP INDEX  NR_ENTRIES_HP_SRC 		ON HOMEPAGE.NR_ENTRIES_HP;
DROP INDEX  NR_ENTRIES_DGR_SRC 		ON HOMEPAGE.NR_ENTRIES_DGR;
DROP INDEX  NR_ENTRIES_FILE_SRC 	ON HOMEPAGE.NR_ENTRIES_FILE;
DROP INDEX  NR_ENTRIES_FRM_SRC 		ON HOMEPAGE.NR_ENTRIES_FRM;

-- DROPPING UNUSED INDEXES FOR STORIES TABLES
DROP INDEX  NR_SRC_STORIES_ACT_SIDX 	ON HOMEPAGE.NR_SRC_STORIES_ACT;
DROP INDEX  NR_SRC_STORIES_BLG_SIDX		ON HOMEPAGE.NR_SRC_STORIES_BLG;
DROP INDEX  NR_SRC_STORIES_COM_SIDX		ON HOMEPAGE.NR_SRC_STORIES_COM;
DROP INDEX  NR_SRC_STORIES_WIK_SIDX		ON HOMEPAGE.NR_SRC_STORIES_WIK;
DROP INDEX  NR_SRC_STORIES_PRF_SIDX		ON HOMEPAGE.NR_SRC_STORIES_PRF;
DROP INDEX  NR_SRC_STORIES_HP_SIDX		ON HOMEPAGE.NR_SRC_STORIES_HP;
DROP INDEX  NR_SRC_STORIES_DGR_SIDX		ON HOMEPAGE.NR_SRC_STORIES_DGR;
DROP INDEX  NR_SRC_STORIES_FILE_SIDX	ON HOMEPAGE.NR_SRC_STORIES_FILE;
DROP INDEX  NR_SRC_STORIES_FRM_SIDX		ON HOMEPAGE.NR_SRC_STORIES_FRM;




----------------------------------------------------------------------
-- [END] INDEX CLEANUP
----------------------------------------------------------------------

---------------------------------------------------------
-- [START] EMD INIT DATA
---------------------------------------------------------
UPDATE HOMEPAGE.EMD_TRANCHE	SET 	
		IS_LOCKED = 0,
		IS_LOCKED_DAILY = 0,
		IS_LOCKED_WEEKLY = 0;
---------------------------------------------------------
-- [END] EMD INIT DATA
---------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_STORIES TABLES 
--------------------------------------------------------
-- Adding to story table:
-- i) MESSAGE
-- ii) EVENT_TIME
--- iii) VERB
--------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)

GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128);


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128);


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)
	

GO	
--------------------------------------------------------
-- [END] UPDATING NR_STORIES TABLES
--------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_ENTRIES TABLES ADDING
--------------------------------------------------------
--  FIRST: we need to move it do a bigger table space
-- i) Adding preview URL
-- ii) Adding status update column
-- iii) Adding JSON_META_DATA column
-- iv) Event time
--------------------------------------------------------
------------------------------------------------------------------------------------
-- CREATING NEW TABLES (Those new tables will also have the new required fields)
-- Which are: MESSAGE, PREVIEW_IMAGE_URL, JSON_META_DATA
--	MESSAGE VARCHAR2(4000),
--	PREVIEW_IMAGE_URL VARCHAR2(2048),
--	JSON_META_DATA VARCHAR2(4000),
--	EVENT_TIME TIMESTAMP,
------------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME		
GO		

--------------------------------------------------------
-- [END] UPDATING NR_ENTRIES TABLES
--------------------------------------------------------


---------------------------------------------
-- Adding VERB and USE_IN_ROLLUP columns to the readers tables
---------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME
	

GO

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME
	
GO

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_FILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME	

GO

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_TAGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

-----------------------------------------------------------
-- ADDING A NR_STATUS_UPDATE_READER
-----------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories (we don't need to add source here as they already exist)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('status_update_x8b0bx51af2ddef2cd', 11, '%status_update', 'status_update');

--------------------------------------------------------------------------
-- 11) HOMEPAGE.NR_STATUS_UPDATE_READERS
--------------------------------------------------------------------------	
CREATE TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
   	CONSTRAINT  CK_CAT11_TYPE
    			CHECK
    			(CATEGORY_TYPE = 11)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS 
    ADD CONSTRAINT PK_SU_READERS PRIMARY KEY(FOLLOWED_STORY_ID);

CREATE INDEX SU_STORIES_IDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX SU_STORIES_SIDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (STORY_ID);

CREATE INDEX SU_STORIES_ITEM_ID
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ITEM_ID);

CREATE INDEX SU_STORIES_READER_STORY
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID);	

GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STATUS_UPDATE_READERS TO HOMEPAGEUSER

---------------------------------------------------------
-- [START] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------
----------------------------------------------------------
-- Adding ACTIVITY_META_DATA to NR_STORIES_CONTENT table
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD ACTIVITY_META_DATA VARCHAR(MAX);
GO
----------------------------------------------------------

---------------------------------------------------------------------------------
-- INSERTING THIRD PARTY CATEGORIES AND SOURCES
---------------------------------------------------------------------------------
-- Adding a new category (used from UI rendering) and source (used a source of stories from component)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('ext_9cax4cc4x8b0bx51af2ddef2cd', 12, '%external', 'external');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC, IS_ENABLE)
VALUES ('ext_____fdfdc9cax80bx51af2', 100, '%external', 'external', 0);

---------------------------------------------------------
-- 12) ADDING A NR_EXTERNAL_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_EXTERNAL_READERS (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
   	CONSTRAINT  CK_CAT12_TYPE
    			CHECK
    			(CATEGORY_TYPE = 12)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS 
    ADD CONSTRAINT PK_EXT_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);
    
CREATE INDEX EXT_STORIES_IDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX EXT_STORIES_SIDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (STORY_ID);

CREATE INDEX EXT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_EXTERNAL_READERS (ITEM_ID);

CREATE INDEX EXT_STORIES_READER_STORY
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID);    

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_EXTERNAL_READERS TO HOMEPAGEUSER

--------------------------------------------------------------
-- ADDING A NR_ENTRIES_EXTERNAL TABLE
--------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	ITEM_ATOM_URL nvarchar(2048),
	MESSAGE nvarchar(4000),
	PREVIEW_IMAGE_URL nvarchar(2048),
	JSON_META_DATA nvarchar(4000),
	EVENT_TIME DATETIME,
	CONSTRAINT   	CK_ENT_SRC10_TYPE
    				CHECK
    				(SOURCE_TYPE = 10)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL 
    ADD CONSTRAINT PK_EXT_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_EXT_CONT
    ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CONTAINER_ID);
    
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ENTRIES_EXTERNAL  TO HOMEPAGEUSER

----------------------------------------------------
-- ADDING A NR_SRC_STORIES_EXTERNAL TABLE
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_CORRELATION_ID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	MESSAGE nvarchar(4000),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),	
	CONSTRAINT   	CK_SRC100_TYPE
    				CHECK
    				(SOURCE_TYPE >= 100)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
    ADD CONSTRAINT PK_EXT_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
  	ADD CONSTRAINT FK_ENTRY_ID_EXT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_EXTERNAL (ENTRY_ID);    

CREATE INDEX SRC_STORIES_EXT_DATE
	ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CREATION_DATE DESC);

CREATE INDEX SRC_EXT_CONTAINER_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CONTAINER_ID);

CREATE INDEX SRC_EXT_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ITEM_CORRELATION_ID);
    
CREATE INDEX SRC_STORIES_EXT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ENTRY_ID);  

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL TO HOMEPAGEUSER

---------------------------------------------------------
-- [END] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------


---------------------------------------------------------
-- [START] ACTIONABLE
---------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_saved_stories_4cc4x8b0bx', 13, '%actionable_saved_stories', 'actionable_saved_stories');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_directed_notification_bx', 14, '%actionable_directed_notification', 'actionable_directed_notification');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_todo_______cax4cc4x8b0bx', 15, '%actionable_todo', 'actionable_todo');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_action_required__4x8b0bx', 16, '%actionable_action_required', 'actionable_action_required');

GO


---------------------------------------------------------
-- ADDING NR_ACTIONABLE_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_READERS (
	ACTIONABLE_READER_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
	NOTE_TEXT nvarchar(4000),
	NOTE_UPDATE_DATE DATETIME,
	CONSTRAINT   	CK_CAT_ACTION_TYPE
    				CHECK
    				(CATEGORY_TYPE >= 13 AND CATEGORY_TYPE <= 16)	
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS 
    ADD CONSTRAINT PK_ACTION_STORIES PRIMARY KEY (ACTIONABLE_READER_ID);
    
CREATE INDEX ACTION_READER_STORIES_IDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX ACTION_READER_SIDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (STORY_ID);

CREATE INDEX ACTION_READER_ITEM_ID
    ON HOMEPAGE.NR_ACTIONABLE_READERS (ITEM_ID);

CREATE UNIQUE INDEX ACTION_READER_STORY
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, STORY_ID);    

    
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ACTIONABLE_READERS TO HOMEPAGEUSER

GO

---------------------------------------------------------
-- ADDING NR_ACTIONABLE_STORIES TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_STORIES (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	MESSAGE nvarchar(4000),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	CONSTRAINT   	CK_SRC_ACTION_TYPE
    				CHECK
    				(SOURCE_TYPE >= 1 AND SOURCE_TYPE <= 10 )
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_STORIES
    ADD CONSTRAINT PK_ACTION_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX ACTION_CONTAINER_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (CONTAINER_ID);

CREATE INDEX ACTION_ITEM_CORR_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ITEM_CORRELATION_ID);

CREATE INDEX ACTION_ACT_ENTRYID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ENTRY_ID);    


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ACTIONABLE_STORIES TO HOMEPAGEUSER
GO
	
---------------------------------------------------------
-- [END] ACTIONABLE
---------------------------------------------------------

DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;
GO
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);
GO


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORIES_READERS TO HOMEPAGEUSER
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 67 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

----------------------------------------
--  SR_GLOBAL_SAND_PROPS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS(
	GSP_ID			NVARCHAR(36) NOT NULL,
	GSP_NAME		NVARCHAR(36) NOT NULL,
	GSP_VALUE		NVARCHAR(36) NOT NULL,
	GSP_TYPE        NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
	ADD CONSTRAINT PK_GSP_ID PRIMARY KEY (GSP_ID)
GO

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
	ADD CONSTRAINT UNIQUE_GSP_NAME UNIQUE (GSP_NAME)
GO
	
ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS		
	ADD CONSTRAINT GSP_TYPE_CHECK
	CHECK (GSP_TYPE >=0 AND GSP_TYPE < 4);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_GLOBAL_SAND_PROPS TO HOMEPAGEUSER
GO
--END 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 67
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 67 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 66;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 67
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

