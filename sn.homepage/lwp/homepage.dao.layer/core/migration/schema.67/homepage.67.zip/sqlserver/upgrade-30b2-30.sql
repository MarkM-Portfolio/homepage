-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE
GO

BEGIN TRANSACTION
GO


------------------------------------------------
-- INCLUDE UPGRADE-30b2-30 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 51
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------
-- 1) HOMEPAGE.EMD_EMAIL_PREFS
-----------------------------------------
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    DROP CONSTRAINT UNIQUE_PREFS;

CREATE UNIQUE INDEX EMD_EMAIL_PREFS_PER
    ON HOMEPAGE.EMD_EMAIL_PREFS (PERSON_ID);

------------------------------------------------
-- 2) NR_NEWS_SAVED
------------------------------------------------
CREATE INDEX SAVED_ITEM_ID
    ON HOMEPAGE.NR_NEWS_SAVED (ITEM_ID);

CREATE INDEX SAVED_STORY_ID
    ON HOMEPAGE.NR_NEWS_SAVED (NEWS_STORY_ID);

------------------------------------------------
-- 3) NR_NEWS_DISCOVERY
------------------------------------------------
CREATE INDEX DISCOVERY_ITEM_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_ID);

CREATE INDEX DISCOVERY_STORY_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (NEWS_STORY_ID);

CREATE INDEX DISCOVERY_CONTAINER_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CONTAINER_ID);

------------------------------------------------
-- 4) NR_NEWS_STATUS_COMMENT
------------------------------------------------
CREATE INDEX STATUS_COMMENT_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_ID);

----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_STORIES
----------------------------------------------------------------------
CREATE INDEX STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_STORIES (CONTAINER_ID);

CREATE INDEX STORIES_ITEM_ID
    ON HOMEPAGE.NR_STORIES (ITEM_ID);

CREATE INDEX STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_STORIES (ITEM_CORRELATION_ID);

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE INDEX COMM_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMM_STORIES (ITEM_ID);

------------------------------------------------
-- 7) NR_STORIES_CONTENT
------------------------------------------------
CREATE INDEX STORIES_CONTENT_STORY
    ON HOMEPAGE.NR_STORIES_CONTENT (STORY_ID);

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_COMM_PERSON_STORIES 
----------------------------------------------------------------------
CREATE INDEX COMM_PERSON_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 1 NR_RESPONSES_STORIES
--------------------------------------------------------------------------
CREATE INDEX RESPONSES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_RESPONSES_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 2 NR_PROFILES_STORIES
--------------------------------------------------------------------------
CREATE INDEX PROFILES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_PROFILES_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 3 NR_COMMUNITIES_STORIES
--------------------------------------------------------------------------
CREATE INDEX COMMUNITIES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 4 NR_ACTIVITIES_STORIES
--------------------------------------------------------------------------
CREATE INDEX ACTIVITIES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 5 NR_BLOGS_STORIES
--------------------------------------------------------------------------
CREATE INDEX BLOGS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_BLOGS_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 6 NR_BOOKMARKS_STORIES
--------------------------------------------------------------------------
CREATE INDEX BOOKMARKS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 7 NR_FILES_STORIES
--------------------------------------------------------------------------
CREATE INDEX FILES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_FILES_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 8 NR_FORUMS_STORIES
--------------------------------------------------------------------------
CREATE INDEX FORUMS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_FORUMS_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 9 NR_WIKIS_STORIES
--------------------------------------------------------------------------
CREATE INDEX WIKIS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_WIKIS_STORIES (ITEM_ID);

--------------------------------------------------------------------------
-- 10 NR_TAGS_STORIES
--------------------------------------------------------------------------
CREATE INDEX TAGS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_TAGS_STORIES (ITEM_ID);
    
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 52
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ALTER COLUMN N_USERS NUMERIC(10,0);

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE UNIQUE INDEX NR_STORIES_ER_UUID
	ON HOMEPAGE.NR_STORIES(EVENT_RECORD_UUID);
GO

DROP INDEX NR_STORIES_CREAT_IS_COM ON HOMEPAGE.NR_STORIES;
GO

CREATE INDEX NR_STORIES_DATE
	ON HOMEPAGE.NR_STORIES(CREATION_DATE DESC);
GO	

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 54
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- STATUS_UPDATES tables

-- HOMEPAGE.NR_NEWS_STATUS_NETWORK
-- HOMEPAGE.NR_NEWS_STATUS_COMMENT
-- HOMEPAGE.NR_NEWS_STATUS_CONTENT

CREATE INDEX NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE ASC);
   
GO

CREATE INDEX NR_STATUS_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (CREATION_DATE ASC);

GO

-- NR_STORIES_CONTENT table
CREATE INDEX NR_STORIES_CONTENT_DATE
    ON HOMEPAGE.NR_STORIES_CONTENT (CREATION_DATE ASC);

GO

-- FOLLOWED STORIES tableS

--HOMEPAGE.NR_RESPONSES_STORIES 
--HOMEPAGE.NR_PROFILES_STORIES
--HOMEPAGE.NR_COMMUNITIES_STORIES
--HOMEPAGE.NR_ACTIVITIES_STORIES
--HOMEPAGE.NR_BLOGS_STORIES
--HOMEPAGE.NR_BOOKMARKS_STORIES
--HOMEPAGE.NR_FILES_STORIES
--HOMEPAGE.NR_FORUMS_STORIES
--HOMEPAGE.NR_WIKIS_STORIES
--HOMEPAGE.NR_TAGS_STORIES

CREATE INDEX NR_RESPONSES_STORIES_DATE
    ON HOMEPAGE.NR_RESPONSES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_COMMUNITIES_STORIES_DATE
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_ACTIVITIES_STORIES_DATE
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_BLOGS_STORIES_DATE
    ON HOMEPAGE.NR_BLOGS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_BOOKMARKS_STORIES_DATE
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_FILES_STORIES_DATE
    ON HOMEPAGE.NR_FILES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_FORUMS_STORIES_DATE
    ON HOMEPAGE.NR_FORUMS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_WIKIS_STORIES_DATE
    ON HOMEPAGE.NR_WIKIS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_TAGS_STORIES_DATE
    ON HOMEPAGE.NR_TAGS_STORIES (CREATION_DATE ASC);

GO

-- HOMEPAGE.NR_COMM_PERSON_STORIES
CREATE INDEX NR_COMM_PERSON_STORIES_DATE
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC);

GO

-- HOMEPAGE.NR_COMM_STORIES
CREATE INDEX NR_COMM_STORIES_DATE
    ON HOMEPAGE.NR_COMM_STORIES (CREATION_DATE ASC);

GO    


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE INDEX NR_SC_UDATE
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (UPDATE_DATE ASC);  
   
GO

CREATE INDEX NR_NEWS_DISCOVERY_ITEM_C
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_CORRELATION_ID);
   
GO

-- SPR #RSTR8A5Q7R
-- Slow query on Homepage nr_news_status_network table: Oracle
CREATE INDEX NR_NEWS_SN_READER_IDX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID);

GO

--SPR #MAKN8A8DXJ SVT: 
--Homepage News Feed (Filter Responses and People) is very slow
CREATE INDEX NR_EVENT_READER 
	ON HOMEPAGE.NR_NEWS_SAVED (READER_ID,EVENT_RECORD_UUID);
GO	

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE UPGRADE-30b2-30  FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
GO

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
GO

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
GO

DELETE FROM HOMEPAGE.SR_FACET_DOCS;
GO

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
GO

DELETE FROM HOMEPAGE.SR_STATS;
GO

DELETE FROM HOMEPAGE.SR_STRING_STATS;
GO

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
GO

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 55
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------ START FIX FOR PMAN89HG7Z ------ 

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/15 0,2-23 * * ?',INTERVAL='0 1/15 0,2-23 * * ?' WHERE TASK_NAME='15min-search-indexing-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/20 0,2-23 * * ?',INTERVAL='0 1/20 0,2-23 * * ?' WHERE TASK_NAME='20min-file-retrieval-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 5 1 * * ?',INTERVAL='0 0 1 * * ?' WHERE TASK_NAME='nightly-sand-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 35 1 * * ?',INTERVAL='0 30 1 * * ?' WHERE TASK_NAME='nightly-optimize-task';


------ END FIX FOR PMAN89HG7Z ------ 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- CLEAR SCHEDULERS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- NEWS

DELETE FROM HOMEPAGE.NR_SCHEDULER_TASK;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_TREG;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMGR;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMPR;
GO




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 56
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 56 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 50;


--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;