-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 45 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Update PERSON table SAND_OPT SMALLINT DEFAULT 1	NOT NULL
ALTER TABLE HOMEPAGE.PERSON
    ADD SAND_OPT NUMBER(5,0) DEFAULT 1;

UPDATE HOMEPAGE.PERSON SET SAND_OPT = 1;

COMMIT;

-- 2) Drop IS_ACTIVE from PERSON table
ALTER TABLE HOMEPAGE.PERSON
    DROP COLUMN IS_ACTIVE;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 45 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Adding the new resource bookmark for EMD:
INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('bookmarks_0f1xc9cax4cc4x8cdb0bx51f2d', 14, '%bookmarks', 'bookmarks');

-- 2) move stories to the new tables:

----------------------------------------------------------------------------------
-- NR_COMM_PERSON_FOLLOW
----------------------------------------------------------------------------------

-- INSERT 1 RECORD FOR EACH PERSON
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (COMM_PERSON_FOLLOW_ID, PERSON_ID, PERSON_COMMUNITY_ID)
    SELECT  MAX(COMM_FOLLOW_ID) COMM_PERSON_FOLLOW_ID,
            PERSON_ID PERSON_ID,         
            PERSON_ID PERSON_COMMUNITY_ID
    FROM    HOMEPAGE.NR_COMM_FOLLOW NR_COMM_FOLLOW
    GROUP BY PERSON_ID;

COMMIT;

-- RENAME TO AVOID PK CONFLICTS
UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW SET COMM_PERSON_FOLLOW_ID = SUBSTR(COMM_PERSON_FOLLOW_ID,1,18) || SUBSTR(PERSON_ID,1,18);

COMMIT;

-- INSERT THE OLD EXISTING RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (COMM_PERSON_FOLLOW_ID, PERSON_ID, PERSON_COMMUNITY_ID)
    SELECT  COMM_FOLLOW_ID COMM_PERSON_FOLLOW_ID,
            PERSON_ID PERSON_ID,         
            COMMUNITY_ID PERSON_COMMUNITY_ID
    FROM HOMEPAGE.NR_COMM_FOLLOW NR_COMM_FOLLOW;

COMMIT;

----------------------------------------------------------------------------------
-- NR_COMM_PERSON_FOLLOW
----------------------------------------------------------------------------------

-- COPYING BACK THE OLD NR_COMM_STORIES
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (COMM_PER_STORY_ID, COMM_PER_READER_ID, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, CATEGORY_TYPE, CREATION_DATE, SOURCE, STORY_ID)
    SELECT  NR_COMM_STORIES.COMM_STORY_ID COMM_PER_STORY_ID,
            NR_COMM_STORIES.COMMUNITY_ID COMM_PER_READER_ID, 
            NR_COMM_STORIES.CONTAINER_ID CONTAINER_ID, 
            NR_COMM_STORIES.ITEM_ID ITEM_ID, 
            NR_COMM_STORIES.RESOURCE_TYPE RESOURCE_TYPE, 
            2 CATEGORY_TYPE, 
            NR_COMM_STORIES.CREATION_DATE CREATION_DATE, 
            'communities' SOURCE, 
            NR_COMM_STORIES.STORY_ID STORY_ID
    FROM HOMEPAGE.NR_COMM_STORIES NR_COMM_STORIES;

COMMIT;

-- COPYING BACK THE OLD NR_FOLLOWED_STORIES
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (COMM_PER_STORY_ID, COMM_PER_READER_ID, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, CATEGORY_TYPE, CREATION_DATE, SOURCE, STORY_ID)
    SELECT  NR_FOLLOWED_STORIES.FOLLOWED_STORY_ID COMM_PER_STORY_ID,
            NR_FOLLOWED_STORIES.READER_ID COMM_PER_READER_ID, 
            NR_FOLLOWED_STORIES.CONTAINER_ID CONTAINER_ID, 
            NR_FOLLOWED_STORIES.ITEM_ID ITEM_ID, 
            NR_FOLLOWED_STORIES.RESOURCE_TYPE RESOURCE_TYPE, 
            NR_FOLLOWED_STORIES.CATEGORY_TYPE CATEGORY_TYPE,  
            NR_FOLLOWED_STORIES.CREATION_DATE CREATION_DATE, 
            NR_FOLLOWED_STORIES.SOURCE SOURCE, 
            NR_FOLLOWED_STORIES.STORY_ID STORY_ID
    FROM HOMEPAGE.NR_FOLLOWED_STORIES NR_FOLLOWED_STORIES;

COMMIT;      
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 45 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEX_MANAGEMENT
----------------------------------------

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
ADD INDEXER NUMBER(5,0) DEFAULT 1 NOT NULL
MODIFY NODE_ID VARCHAR2(256);

----------------------------------------
--  HOMEPAGE.SR_RESUME_TOKENS
----------------------------------------

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
MODIFY NODE_ID VARCHAR2(256);

----------------------------------------
--  SR_LOTUSCONNECTIONS*
----------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 45
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 45 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 44;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
