-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE 
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--HOMEPAGE

UPDATE STATISTICS HOMEPAGE.HOMEPAGE_SCHEMA;
GO

UPDATE STATISTICS HOMEPAGE.PERSON;
GO

UPDATE STATISTICS HOMEPAGE.LOGINNAME;
GO

UPDATE STATISTICS HOMEPAGE.PREREQ;
GO

UPDATE STATISTICS HOMEPAGE.WIDGET;
GO

UPDATE STATISTICS HOMEPAGE.HP_UI;
GO

UPDATE STATISTICS HOMEPAGE.HP_TAB;
GO

UPDATE STATISTICS HOMEPAGE.HP_TAB_INST;
GO

UPDATE STATISTICS HOMEPAGE.HP_WIDGET_INST;
GO

UPDATE STATISTICS HOMEPAGE.HP_WIDGET_TAB;
GO

UPDATE STATISTICS HOMEPAGE.NT_NOTIFICATION;
GO

UPDATE STATISTICS HOMEPAGE.NT_NOTIFICATION_RECIPIENT;
GO

UPDATE STATISTICS HOMEPAGE.MT_METRIC_STAT;
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--NEWS

UPDATE STATISTICS HOMEPAGE.NR_SOURCE;
GO

UPDATE STATISTICS HOMEPAGE.NR_SUBSCRIPTION;
GO

UPDATE STATISTICS HOMEPAGE.NR_NEWS_RECORDS;
GO

UPDATE STATISTICS HOMEPAGE.NR_TEMPLATE;
GO

UPDATE STATISTICS  HOMEPAGE.NR_SCHEDULER_LMGR;
GO

UPDATE STATISTICS  HOMEPAGE.NR_SCHEDULER_LMPR;
GO

UPDATE STATISTICS  HOMEPAGE.NR_SCHEDULER_TASK;
GO

UPDATE STATISTICS  HOMEPAGE.NR_SCHEDULER_TREG;
GO

UPDATE STATISTICS  HOMEPAGE.NR_CATEGORY_TYPE;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_SAVED;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_DISCOVERY;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_STATUS_CONTENT;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_STATUS_COMMENT;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NEWS_STATUS_NETWORK;
GO

UPDATE STATISTICS  HOMEPAGE.NR_NETWORK;	
GO
UPDATE STATISTICS  HOMEPAGE.NR_STORIES_CONTENT;
GO
UPDATE STATISTICS  HOMEPAGE.NR_ORGPERSON_STORIES;
GO
UPDATE STATISTICS  HOMEPAGE.NR_COMM_STORIES;
GO

UPDATE STATISTICS  HOMEPAGE.NR_STORIES;
GO
UPDATE STATISTICS  HOMEPAGE.NR_ORGPERSON_FOLLOW;
GO
UPDATE STATISTICS  HOMEPAGE.NR_COMM_FOLLOW;
GO
UPDATE STATISTICS  HOMEPAGE.NR_FOLLOWS;	
GO
UPDATE STATISTICS  HOMEPAGE.NR_RESOURCE;
GO
UPDATE STATISTICS  HOMEPAGE.NR_RESOURCE_TYPE;	
GO
UPDATE STATISTICS  HOMEPAGE.NR_COMM_PERSON_FOLLOW;
GO
UPDATE STATISTICS  HOMEPAGE.NR_COMM_PERSON_STORIES;	
GO

UPDATE STATISTICS HOMEPAGE.EMD_FREQUENCY_TYPE;
GO
UPDATE STATISTICS HOMEPAGE.EMD_RESOURCE_PREF;
GO
UPDATE STATISTICS HOMEPAGE.EMD_TRANCHE;
GO
UPDATE STATISTICS HOMEPAGE.EMD_TRANCHE_INFO;
GO
UPDATE STATISTICS HOMEPAGE.EMD_EMAIL_PREFS;
GO

UPDATE STATISTICS HOMEPAGE.NR_RESPONSES_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_PROFILES_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_COMMUNITIES_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_ACTIVITIES_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_BLOGS_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_BOOKMARKS_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_FILES_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_FORUMS_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_WIKIS_STORIES;
GO
UPDATE STATISTICS HOMEPAGE.NR_TAGS_STORIES;
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- SEARCH

UPDATE STATISTICS HOMEPAGE.SR_INDEX_MANAGEMENT
GO

UPDATE STATISTICS HOMEPAGE.SR_RESUME_TOKENS
GO

UPDATE STATISTICS HOMEPAGE.SR_INDEX_DOCS
GO

UPDATE STATISTICS HOMEPAGE.SR_FACET_DOCS
GO

UPDATE STATISTICS  HOMEPAGE.SR_BACKUPTASKDEF
GO

UPDATE STATISTICS  HOMEPAGE.SR_BACKUPTASKDEF
GO

UPDATE STATISTICS  HOMEPAGE.SR_FILECONTENTTASKDEF
GO

UPDATE STATISTICS  HOMEPAGE.SR_INDEXINGTASKDEF
GO

UPDATE STATISTICS  HOMEPAGE.SR_OPTIMIZETASKDEF
GO

UPDATE STATISTICS  HOMEPAGE.SR_TASKDEF
GO

UPDATE STATISTICS HOMEPAGE.SR_FEEDBACK 
GO

UPDATE STATISTICS HOMEPAGE.SR_FEEDBACK_CONTEXT

GO

UPDATE STATISTICS HOMEPAGE.SR_FEEDBACK_PARAMETERS

GO

UPDATE STATISTICS HOMEPAGE.SR_STATS

GO

UPDATE STATISTICS HOMEPAGE.SR_STRING_STATS

GO

UPDATE STATISTICS HOMEPAGE.SR_NUMBER_STATS
GO

UPDATE STATISTICS HOMEPAGE.SR_TIMER_STATS
GO

UPDATE STATISTICS  HOMEPAGE.SR_FILESCONTENT
GO

UPDATE STATISTICS  HOMEPAGE.SR_MIGTASKDEFINFO
GO

UPDATE STATISTICS  HOMEPAGE.LOTUSCONNECTIONSLMGR
GO

UPDATE STATISTICS  HOMEPAGE.LOTUSCONNECTIONSLMPR
GO

UPDATE STATISTICS  HOMEPAGE.LOTUSCONNECTIONSTASK
GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------
