-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 46
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 46 FOR HP
------------------------------------------------

-- {include.hp-fixup46.sql}

------------------------------------------------
-- INCLUDE FIX UP 46 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------------------------------
-- 1) ENFORCE A UNIQUE FIELD ON READER_ID, STORY_ID TO AVOID THE USE OF DISTINCT
------------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT COMM_PER_READER_ID, STORY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
-- GROUP BY COMM_PER_READER_ID, STORY_ID
-- HAVING count(*) > 1

-- CREATE A TEMP DUP TABLE
CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID nvarchar(36) NOT NULL,
	COMM_PER_READER_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PER_STORY_ID, 
            T2.COMM_PER_READER_ID, 
            T2.CONTAINER_ID, 
            T2.ITEM_ID, 
            T2.RESOURCE_TYPE, 
            T2.CATEGORY_TYPE, 
            T2.CREATION_DATE, 
            T2.SOURCE, 
            T2.STORY_ID
    FROM (
            SELECT  COMM_PER_READER_ID, STORY_ID, MAX(COMM_PER_STORY_ID) COMM_PER_STORY_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
            GROUP BY COMM_PER_READER_ID, STORY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_STORIES T2
    WHERE T1.COMM_PER_STORY_ID = T2.COMM_PER_STORY_ID;

GO

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES
    WHERE COMM_PER_STORY_ID IN (
    SELECT  NR_COMM_PERSON_STORIES.COMM_PER_STORY_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES,  HOMEPAGE.TMP_COMM_PERSON_STORIES TMP_COMM_PERSON_STORIES
    WHERE   NR_COMM_PERSON_STORIES.COMM_PER_READER_ID = TMP_COMM_PERSON_STORIES.COMM_PER_READER_ID AND
            NR_COMM_PERSON_STORIES.STORY_ID = TMP_COMM_PERSON_STORIES.STORY_ID
);

GO

-- CREATE THE UNIQUE CONSTRAINTS
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT UNIQUE_COMM_PERSON UNIQUE (COMM_PER_READER_ID, STORY_ID);

GO

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    SELECT  COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            CATEGORY_TYPE, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_STORIES;

GO

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES;

GO

--reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;

------------------------------------------------------------------------------------
-- 2) REMOVE NOT NULL CONSTRAINTS FROM EMD_EMAIL_PREFS
------------------------------------------------------------------------------------
-- SEND_DIRECTED
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN SEND_DIRECTED NUMERIC(5,0);

-- LANG
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN LANG nvarchar(36);

-- USE_TEXT_EMAIL
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN USE_TEXT_EMAIL NUMERIC(5,0);

--reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 3) NR_COMM_FOLLOW 
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_COMM UNIQUE (PERSON_ID, COMMUNITY_ID);

--reorg table HOMEPAGE.NR_COMM_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 4) NR_COMM_PERSON_FOLLOW
-----------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT PERSON_ID, PERSON_COMMUNITY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW
-- GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
-- HAVING count(*) > 1

CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	PERSON_COMMUNITY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID, 
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PERSON_FOLLOW_ID, 
            T2.PERSON_ID, 
            T2.PERSON_COMMUNITY_ID
    FROM (
            SELECT  PERSON_ID, PERSON_COMMUNITY_ID, MAX(COMM_PERSON_FOLLOW_ID) COMM_PERSON_FOLLOW_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW COMM_PERSON_FOLLOW
            GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_FOLLOW T2
    WHERE T1.COMM_PERSON_FOLLOW_ID = T2.COMM_PERSON_FOLLOW_ID;

GO

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_FOLLOW
    WHERE   COMM_PERSON_FOLLOW_ID IN (
    SELECT  NR_COMM_PERSON_FOLLOW.COMM_PERSON_FOLLOW_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW,  HOMEPAGE.TMP_COMM_PERSON_FOLLOW TMP_COMM_PERSON_FOLLOW
    WHERE   NR_COMM_PERSON_FOLLOW.PERSON_ID = TMP_COMM_PERSON_FOLLOW.PERSON_ID AND
            NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = TMP_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID
);

GO

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_P_COMM UNIQUE (PERSON_ID, PERSON_COMMUNITY_ID);

GO

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID,
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    SELECT  COMM_PERSON_FOLLOW_ID, 
            PERSON_ID, 
            PERSON_COMMUNITY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

GO

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

GO

--reorg table HOMEPAGE.NR_COMM_PERSON_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 5) ADDING NR_NEWS_DISCOVERY_CREAT_IS_COM
-----------------------------------------------------------------------------------
CREATE INDEX NR_NEWS_DISCOVERY_CREAT_IS_COM
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, IS_COMMUNITY_STORY);

GO

-----------------------------------------------------------------------------------
-- 6) ADDING TO NR_NEWS_STATUS_NETWORK 
-- CREATION_DATE
-- ACTOR_UUID
-- TARGET_SUBJECT_ID
-- ITEM_URL
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD ACTOR_UUID nvarchar(36);
    
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD CREATION_DATE DATETIME;    

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD TARGET_SUBJECT_ID nvarchar(36);

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD ITEM_URL  nvarchar(2048);
    
-- reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;

GO

-- ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT SET ACTOR_UUID = (
    SELECT DISTINCT(ACTOR_UUID)
    FROM (
        SELECT  ACTOR_UUID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

GO

-- CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  SET CREATION_DATE = (
    SELECT DISTINCT(CREATION_DATE)
    FROM (
        SELECT  CREATION_DATE, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

GO

-- ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT SET ACTOR_UUID = (
    SELECT DISTINCT(ACTOR_UUID)
    FROM (
        SELECT  ACTOR_UUID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

GO

-- CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  SET CREATION_DATE = (
    SELECT DISTINCT(CREATION_DATE)
    FROM (
        SELECT  CREATION_DATE, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

GO

CREATE INDEX NR_NEWS_SC_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (ITEM_ID);

CREATE INDEX NR_NEWS_SC_CD
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (CREATION_DATE ASC);

GO

-- reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;

------------------------------------------------------------------------
-- 7) DROPPING UN-USED INDEXES FROM NR_FOLLOWED_STORIES TABLE
------------------------------------------------------------------------
DROP INDEX NR_FOLLOWED_STORIES_READER
	ON HOMEPAGE.NR_FOLLOWED_STORIES;

DROP INDEX NR_FS_READER_CONT
	ON HOMEPAGE.NR_FOLLOWED_STORIES ;

DROP INDEX NR_FOLLOWED_STORIES_STORY_ID
	ON HOMEPAGE.NR_FOLLOWED_STORIES;

GO    
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 46 FOR SEARCH
------------------------------------------------

-- {include.search-fixup46.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 46
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 46 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 45;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 46
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
