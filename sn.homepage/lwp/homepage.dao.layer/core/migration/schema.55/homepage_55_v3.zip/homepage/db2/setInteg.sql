-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- to create a new baseline
connect to HOMEPAGE;


-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE
-----------------------------------------------------------------------------------------------------------
 
set integrity for HOMEPAGE.HOMEPAGE_SCHEMA immediate checked;
set integrity for HOMEPAGE.PERSON immediate checked;
set integrity for HOMEPAGE.LOGINNAME immediate checked;
set integrity for HOMEPAGE.HP_UI immediate checked;
set integrity for HOMEPAGE.HP_TAB immediate checked;
set integrity for HOMEPAGE.HP_TAB_INST immediate checked;
set integrity for HOMEPAGE.WIDGET immediate checked;
set integrity for HOMEPAGE.HP_WIDGET_TAB immediate checked;
set integrity for HOMEPAGE.HP_WIDGET_INST immediate checked;
set integrity for HOMEPAGE.PREREQ immediate checked;
set integrity for HOMEPAGE.NT_NOTIFICATION immediate checked;
set integrity for HOMEPAGE.NT_NOTIFICATION_RECIPIENT immediate checked;
set integrity for HOMEPAGE.MT_METRIC_STAT immediate checked;

-----------------------------------------------------------------------------------------------------------
-- START NEWS
-----------------------------------------------------------------------------------------------------------

set integrity for HOMEPAGE.NR_SOURCE immediate checked;
set integrity for HOMEPAGE.NR_SUBSCRIPTION immediate checked;
set integrity for HOMEPAGE.NR_NEWS_RECORDS immediate checked;

set integrity for HOMEPAGE.NR_SCHEDULER_TASK immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_TREG immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_LMGR immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_LMPR immediate checked;

set integrity for HOMEPAGE.NR_TEMPLATE immediate checked;
set integrity for HOMEPAGE.NR_CATEGORY_TYPE immediate checked;
set integrity for HOMEPAGE.NR_NEWS_SAVED immediate checked;
set integrity for HOMEPAGE.NR_NEWS_DISCOVERY immediate checked;

set integrity for HOMEPAGE.NR_NETWORK immediate checked;
set integrity for HOMEPAGE.NR_NEWS_STATUS_NETWORK immediate checked;
set integrity for HOMEPAGE.NR_NEWS_STATUS_COMMENT immediate checked;
set integrity for HOMEPAGE.NR_NEWS_STATUS_CONTENT immediate checked;
set integrity for HOMEPAGE.NR_NEWS_COMMENT_CONTENT immediate checked;


set integrity for HOMEPAGE.NR_RESOURCE_TYPE immediate checked;
set integrity for HOMEPAGE.NR_RESOURCE immediate checked;
set integrity for HOMEPAGE.NR_FOLLOWS immediate checked;
set integrity for HOMEPAGE.NR_COMM_FOLLOW immediate checked;
set integrity for HOMEPAGE.NR_ORGPERSON_FOLLOW immediate checked;

set integrity for HOMEPAGE.NR_STORIES immediate checked;
set integrity for HOMEPAGE.NR_COMM_STORIES immediate checked;
set integrity for HOMEPAGE.NR_ORGPERSON_STORIES immediate checked;
set integrity for HOMEPAGE.NR_STORIES_CONTENT immediate checked;

set integrity for HOMEPAGE.NR_COMM_PERSON_FOLLOW immediate checked;
set integrity for HOMEPAGE.NR_COMM_PERSON_STORIES immediate checked;

set integrity for HOMEPAGE.NR_RESPONSES_STORIES immediate checked;
set integrity for HOMEPAGE.NR_PROFILES_STORIES immediate checked;
set integrity for HOMEPAGE.NR_COMMUNITIES_STORIES immediate checked;
set integrity for HOMEPAGE.NR_ACTIVITIES_STORIES immediate checked;
set integrity for HOMEPAGE.NR_BLOGS_STORIES immediate checked;
set integrity for HOMEPAGE.NR_BOOKMARKS_STORIES immediate checked;
set integrity for HOMEPAGE.NR_FILES_STORIES immediate checked;
set integrity for HOMEPAGE.NR_FORUMS_STORIES immediate checked;
set integrity for HOMEPAGE.NR_WIKIS_STORIES immediate checked;
set integrity for HOMEPAGE.NR_TAGS_STORIES immediate checked;

set integrity for HOMEPAGE.EMD_TRANCHE immediate checked;
set integrity for HOMEPAGE.EMD_TRANCHE_INFO immediate checked;
set integrity for HOMEPAGE.EMD_FREQUENCY_TYPE immediate checked;
set integrity for HOMEPAGE.EMD_EMAIL_PREFS immediate checked;
set integrity for HOMEPAGE.EMD_RESOURCE_PREF immediate checked; 

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------

set integrity for HOMEPAGE.SR_TASKDEF immediate checked;
set integrity for HOMEPAGE.SR_INDEXINGTASKDEF immediate checked;
set integrity for HOMEPAGE.SR_OPTIMIZETASKDEF immediate checked;
set integrity for HOMEPAGE.SR_FILESCONTENT immediate checked;

set integrity for HOMEPAGE.SR_BACKUPTASKDEF immediate checked;
set integrity for HOMEPAGE.SR_SANDTASKDEF immediate checked;
set integrity for HOMEPAGE.SR_FILECONTENTTASKDEF immediate checked;

set integrity for HOMEPAGE.SR_MIGTASKDEFINFO immediate checked;
set integrity for HOMEPAGE.SR_INDEX_MANAGEMENT immediate checked;
set integrity for HOMEPAGE.SR_RESUME_TOKENS immediate checked;

set integrity for HOMEPAGE.SR_INDEX_DOCS immediate checked;
set integrity for HOMEPAGE.SR_FACET_DOCS immediate checked;

set integrity for HOMEPAGE.SR_FEEDBACK immediate checked;
set integrity for HOMEPAGE.SR_FEEDBACK_CONTEXT immediate checked;
set integrity for HOMEPAGE.SR_FEEDBACK_PARAMETERS immediate checked;
set integrity for HOMEPAGE.SR_STATS immediate checked;
set integrity for HOMEPAGE.SR_STRING_STATS immediate checked;
set integrity for HOMEPAGE.SR_NUMBER_STATS immediate checked;
set integrity for HOMEPAGE.SR_TIMER_STATS immediate checked;
 
set integrity for HOMEPAGE.LOTUSCONNECTIONSTASK immediate checked;
set integrity for HOMEPAGE.LOTUSCONNECTIONSTREG immediate checked;
set integrity for HOMEPAGE.LOTUSCONNECTIONSLMGR immediate checked;
set integrity for HOMEPAGE.LOTUSCONNECTIONSLMPR immediate checked;

COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;