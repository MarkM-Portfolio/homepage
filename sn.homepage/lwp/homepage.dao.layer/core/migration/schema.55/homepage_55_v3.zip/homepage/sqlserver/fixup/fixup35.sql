-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 35 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------
-- 9 MIGRATION FOR NT_NOTIFICATION TABLES
-----------------------------------------------------

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT SET IS_DELETED = 0;
GO

-- create temp view
CREATE VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT AS (
    select      NT_NOTIFICATION.NOTIFICATION_ID, COUNT(NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID) AS RECIPIENT_COUNT
    from        HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, 
                HOMEPAGE.NT_NOTIFICATION_RECIPIENT NT_NOTIFICATION_RECIPIENT
    where       NT_NOTIFICATION.NOTIFICATION_ID = NT_NOTIFICATION_RECIPIENT.NOTIFICATION_ID
    group by    NT_NOTIFICATION.NOTIFICATION_ID
)
GO


CREATE VIEW HOMEPAGE.TEMP_FIND_RECIPIENT AS (
    select NOTIFICATION_ID, MAX(RECIPIENT_EXID) RECIPIENT_EXID
    from HOMEPAGE.NT_NOTIFICATION_RECIPIENT  NT_NOTIFICATION_RECIPIENT
    GROUP BY NOTIFICATION_ID
)
GO


-- create TEMP_NOTIFICATION table
CREATE TABLE HOMEPAGE.TEMP_NOTIFICATION (
	  NOTIFICATION_ID nvarchar(36) NOT NULL,
	  NOTIFICATION_SOURCE nvarchar(36) NOT NULL,
	  NOTIFICATION_TYPE nvarchar(256) NOT NULL,
	  DATETIME_STAMP DATETIME NOT NULL,
	  SENDER_EXID nvarchar(36) NOT NULL,
	  SUBJECT nvarchar(256),
	  MESSAGE nvarchar(2048),
	  CONTAINER_NAME nvarchar(256),
	  CONTAINER_URL nvarchar(2048),
	  ITEM_NAME nvarchar(256),
	  ITEM_URL nvarchar(2048),
	  FIRST_RECIPIENT_EXID nvarchar(36),
	  NUM_RECIPIENTS NUMERIC(5,0),
	  IS_DELETED NUMERIC(5,0),
	  PRIMARY_ACTION_URL nvarchar(2048),
	  SECONDARY_ACTION_URL nvarchar(2048)	  
) ON [PRIMARY]
GO

-- copying temp the results to TEMP_NOTIFICATION
INSERT INTO HOMEPAGE.TEMP_NOTIFICATION (    NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )    
SELECT  NT_NOTIFICATION.NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        TEMP_FIND_RECIPIENT.RECIPIENT_EXID , TEMP_COUNT_RECIPIENT.RECIPIENT_COUNT, 0, '',''
FROM    HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, HOMEPAGE.TEMP_COUNT_RECIPIENT TEMP_COUNT_RECIPIENT, HOMEPAGE.TEMP_FIND_RECIPIENT TEMP_FIND_RECIPIENT
WHERE   NT_NOTIFICATION.NOTIFICATION_ID = TEMP_COUNT_RECIPIENT.NOTIFICATION_ID AND
        NT_NOTIFICATION.NOTIFICATION_ID = TEMP_FIND_RECIPIENT.NOTIFICATION_ID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT DROP CONSTRAINT FK_RECIP_NOTIF;

DELETE FROM HOMEPAGE.NT_NOTIFICATION;

INSERT INTO HOMEPAGE.NT_NOTIFICATION (    	NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )
SELECT  NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
FROM    HOMEPAGE.TEMP_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
	ADD CONSTRAINT FK_RECIP_NOTIF FOREIGN KEY (NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_NOTIFICATION (NOTIFICATION_ID)
	ON DELETE CASCADE;

-- drop temps stuff
DROP TABLE HOMEPAGE.TEMP_NOTIFICATION;

DROP VIEW HOMEPAGE.TEMP_FIND_RECIPIENT;

DROP VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 33 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING RESOURCE TYPE
----------------------------------------------------------------------

------------
--- START INSERT NR_RESOURCE_TYPE
------------ 

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('activity_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%activity', 'activity');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('blog________0f1xc9cax4cc4x8b0bx51af2', 3, '%blog', 'blog');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('community____f1xc9cax4cc4x8b0bx51af2', 4, '%community', 'community');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_change_ds1xc9cax4cc4x8b0bx51af2', 5, '%file_change', 'file_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_comment_df1xc9cax4cc4x8b0bx5af2', 6, '%file_comment', 'file_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_collection_fdfca4cc4x8b0bx51af2', 7, '%file_collection', 'file_collection');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_topic_fdfdxc9cax4cc4xb0bx51af2', 8, '%forum_topic', 'forum_topic');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_0fdsfdsf1xc9cax4cc4xb0bxd51af2', 9, '%forum', 'forum');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('person_0f1xc9cax4cc4xb0bx51af2def2cd', 10, '%person', 'person');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_change_fdfdc9cax8b0bx51af2', 11, '%wiki_page_change', 'wiki_page_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_comment_0cax4c4x8b0bx51af2', 12, '%wiki_page_comment', 'wiki_page_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('tag_0f1xc9cax4cc4x8cdb0bx51f2ddef2cd', 13, '%tag', 'tag');

------------
--- END INSERT NR_RESOURCE_TYPE
------------

----------------------------------------------------------------------
-- 2) CHANGE FROM THE USE OF RESOURCE_TYPE_ID to USE RESOURCE_TYPE AND ADDING ITEM_ID TO NR_COMM_STORIES
----------------------------------------------------------------------

-- a) NR_FOLLOWED_STORIES
DROP TABLE HOMEPAGE.NR_FOLLOWED_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWED_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWED_STORIES (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36), -- I don't think we need SOURCE_ID here, this should be in the SOURCE table?
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL, -- ???? what is this ??
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT PK_F_STORY_ID PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO HOMEPAGEUSER  

-- b) NR_COMM_STORIES
DROP TABLE HOMEPAGE.NR_COMM_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_STORIES (
	COMM_STORY_ID nvarchar(36) NOT NULL,
	COMMUNITY_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT PK_F_CSTORY_ID PRIMARY KEY(COMM_STORY_ID);

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT FK_COMM_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO HOMEPAGEUSER

-- c) NR_ORGPERSON_STORIES
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_STORIES (
	ORGPERSON_STORY_ID nvarchar(36) NOT NULL,
	ORGANIZATION_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT PK_ORGP_STORY_ID PRIMARY KEY(ORGPERSON_STORY_ID);

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT FK_ORGP_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO HOMEPAGEUSER

------------------------------------------------------
-- 3) REMOVING THE IS_ACTIVE FLAG and REDO the VIEW
------------------------------------------------------
--ALTER TABLE HOMEPAGE.PERSON DROP COLUMN IS_ACTIVE;

------------------------------------------------------
-- 4) ADDING FK TO THE NR_RESOURCE for CATEGORY_TYPE AND - RESOURCE TYPE
------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT FK_RES_RES_TYPE FOREIGN KEY (RESOURCE_TYPE)
	REFERENCES HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE);
	
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT FK_RES_CAT_TYPE FOREIGN KEY (CATEGORY_TYPE)
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE);
	
------------------------------------------------------
-- 5) ADDING NR_NETWORK TABLE TO MANAGE PEOPLE IN YOUR NETWORK
------------------------------------------------------

----------------------------------------------------------------------
-- HOMEPAGE.NR_NETWORK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NETWORK (
	NETWORK_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	COLLEAGUE_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT PK_NETWORK_ID PRIMARY KEY(NETWORK_ID);

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT FK_NTW_PERS_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT FK_NTW_COLL_ID FOREIGN KEY (COLLEAGUE_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NETWORK  TO HOMEPAGEUSER	
	
------------------------------------------------------
-- 6) REMOVING OLD EMAIL DIGEST TABLES
------------------------------------------------------
DROP TABLE HOMEPAGE.EMD_JOBS_STATS;
DROP TABLE HOMEPAGE.EMD_JOBS;
DROP TABLE HOMEPAGE.EMD_RECIPIENTS;

------------------------------------------------------
-- 7) ADDING NEW EMAIL DIGEST TABLES
------------------------------------------------------

-----------------------------------------
-- HOMEPAGE.EMD_FREQUENCY_TYPE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_FREQUENCY_TYPE (
	FREQUENCY_TYPE_ID nvarchar(36) NOT NULL,
	FREQUENCY_TYPE_NAME nvarchar(36) NOT NULL, 
	FREQUENCY_TYPE NUMERIC(5,0) NOT NULL,
	FREQUENCY_TYPE_DESC nvarchar(256) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE 
  	ADD CONSTRAINT PK_FRQ_TYPE_ID PRIMARY KEY(FREQUENCY_TYPE_ID);

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE
	ADD CONSTRAINT FRQ_TYPE_UNIQUE UNIQUE (FREQUENCY_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_FREQUENCY_TYPE  TO HOMEPAGEUSER 	

-----------------------------------------
-- HOMEPAGE.EMD_RESOURCE_PREF
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_RESOURCE_PREF (
	RESOURCE_PREF_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	FREQUENCY_TYPE NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF 
  	ADD CONSTRAINT PK_RES_PREF_ID PRIMARY KEY(RESOURCE_PREF_ID);

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT FK_RES_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT FK_RES_FRQ_TYPE FOREIGN KEY (FREQUENCY_TYPE)
	REFERENCES HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_RESOURCE_PREF  TO HOMEPAGEUSER  	 	

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE (
	TRANCHE_ID nvarchar(36) NOT NULL,
	SEQ_NUMBER NUMERIC(5,0) NOT NULL,
	LAST_PROCESSED_DAILY DATETIME,
	LAST_PROCESSED_WEEKLY DATETIME,
	IS_LOCKED NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
  	ADD CONSTRAINT PK_TRANCHE_ID PRIMARY KEY(TRANCHE_ID);

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
	ADD CONSTRAINT SEQ_NUMBER_UNIQUE UNIQUE (SEQ_NUMBER);   	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE  TO HOMEPAGEUSER  	

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE_INFO
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE_INFO (
	TRANCHE_INFO_ID nvarchar(36) NOT NULL,
	TRANCHE_ID nvarchar(36) NOT NULL,
	COUNT_PROCESSED_DAILY NUMERIC(5,0),
	COUNT_PROCESSED_WEEKLY NUMERIC(5,0),
	AVG_EXEC_TIME_DAILY_MIN NUMERIC(5,0),
	AVG_EXEC_TIME_WEEKLY_MIN NUMERIC(5,0),
	DOMAIN_AFFINITY nvarchar(2048) NOT NULL,
	N_USERS NUMERIC(5,0)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
  	ADD CONSTRAINT PK_TRC_INFO_ID PRIMARY KEY(TRANCHE_INFO_ID);

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
    ADD CONSTRAINT FK_TRANCHE_ID FOREIGN KEY (TRANCHE_ID)
	REFERENCES HOMEPAGE.EMD_TRANCHE (TRANCHE_ID);	 	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE_INFO  TO HOMEPAGEUSER

-----------------------------------------
-- HOMEPAGE.EMD_EMAIL_PREFS
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_EMAIL_PREFS (
	EMAIL_PREFS_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	SEND_DIRECTED NUMERIC(5,0) NOT NULL,
	TRANCHE_ID nvarchar(36) NOT NULL,
	EMAIL_ADDRESS nvarchar(256) NOT NULL,
	LANG nvarchar(36) NOT NULL,
	USE_TEXT_EMAIL NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
  	ADD CONSTRAINT PK_EMAIL_PREFS_ID PRIMARY KEY(EMAIL_PREFS_ID);

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ADD CONSTRAINT FK_EMD_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_EMAIL_PREFS  TO HOMEPAGEUSER	
	
--------------------------------------
-- 8) INIT EMD_FREQUENCY_TYPE
--------------------------------------

-----------------------------------
-- START EMD_FREQUENCY_TYPE
-----------------------------------	
INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('never_____0fdf1xc9cax4cc4x8b0bx51af2', 1, '%never', 'never');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('immediete_9cax4cc4x8b0bx51af2ddef2cd', 2, '%immediete', 'immediete');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('daily_______0f1xc9cax4cc4x8b0bx51af2', 3, '%daily', 'daily');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('weekly_______f1xc9cax4cc4x8b0bx51af2', 4, '%weekly', 'weekly');  	
-----------------------------------
-- END EMD_FREQUENCY_TYPE
-----------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 33 FOR SEARCH
------------------------------------------------

--{include.search-fixup35.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 35
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 35 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 34;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
