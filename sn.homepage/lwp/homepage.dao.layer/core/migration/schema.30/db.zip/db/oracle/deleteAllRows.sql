-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- REMOVING RECORDS -----------------

DELETE FROM HOMEPAGE.HOMEPAGE_SCHEMA;

DELETE FROM HOMEPAGE.LOGINNAME;

DELETE FROM HOMEPAGE.HP_WIDGET_INST;

DELETE FROM HOMEPAGE.HP_TAB_INST;

DELETE FROM HOMEPAGE.HP_WIDGET_TAB; 

DELETE FROM HOMEPAGE.HP_UI;

DELETE FROM HOMEPAGE.HP_TAB;

DELETE FROM HOMEPAGE.PREREQ;

DELETE FROM HOMEPAGE.WIDGET;

DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

DELETE FROM HOMEPAGE.NT_NOTIFICATION;

DELETE FROM HOMEPAGE.NR_NEWS_RECORDS;

DELETE FROM HOMEPAGE.NR_SUBSCRIPTION;

DELETE FROM HOMEPAGE.NR_SOURCE;

DELETE FROM HOMEPAGE.NR_EVENT_RECORDS;

DELETE FROM HOMEPAGE.NR_TEMPLATE;

DELETE FROM HOMEPAGE.EMD_JOBS_STATS;

DELETE FROM HOMEPAGE.EMD_RECIPIENTS;

DELETE FROM HOMEPAGE.EMD_JOBS;

DELETE FROM HOMEPAGE.SR_INDEXINGTASKDEF;

DELETE FROM HOMEPAGE.SR_OPTIMIZETASKDEF;

DELETE FROM HOMEPAGE.SR_TASKDEF;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;

DELETE FROM HOMEPAGE.SR_MIGTASKDEFINFO;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;

DELETE FROM HOMEPAGE.NR_SCHEDULER_LMGR;

DELETE FROM HOMEPAGE.NR_SCHEDULER_LMPR;

DELETE FROM HOMEPAGE.NR_SCHEDULER_TASK;

DELETE FROM HOMEPAGE.NR_SCHEDULER_TREG;

DELETE FROM HOMEPAGE.PERSON;


COMMIT;

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
