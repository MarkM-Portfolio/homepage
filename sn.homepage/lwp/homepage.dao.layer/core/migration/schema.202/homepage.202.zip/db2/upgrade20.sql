-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

----------------------------------------------------
-- Script to upgrade Home Page database
-- from Beta 1 to Connections 2.0
----------------------------------------------------

CONNECT TO HOMEPAGE;

ALTER TABLE HOMEPAGE.USER_WIDGET_PREF
   ADD SHOW_DISABLED_WIDGETS SMALLINT DEFAULT 0 NOT NULL;
   
UPDATE HOMEPAGE.HOMEPAGE_SCHEMA
   SET   DBSCHEMAVER = 5
   WHERE COMPKEY = 'HOMEPAGE';

COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 

