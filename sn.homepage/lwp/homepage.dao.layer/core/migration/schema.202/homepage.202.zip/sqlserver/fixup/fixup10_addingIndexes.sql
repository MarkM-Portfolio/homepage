-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO 

----------------------------------------------------
-- 1) START ADDING INDEXES FOR HOMEPAGE TABLES
----------------------------------------------------
CREATE INDEX TAB_INST_UI_ID_IDX 
	ON HOMEPAGE.HP_TAB_INST(UI_ID)
GO

CREATE INDEX HP_WIDGET_INST_TAB_INST_ID_IDX
	ON HOMEPAGE.HP_WIDGET_INST(TAB_INST_ID)
GO
----------------------------------------------------
-- END ADDING INDEXES FOR HOMEPAGE TABLES
----------------------------------------------------

-------------------------------------------------------------------
-- 2) START ADDING INDEXES FOR NEWS REPOSITORY 
-------------------------------------------------------------------
-- NEW REPOSITORY INDEXES
CREATE INDEX NR_NEWS_RECORDS_READER_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(READER_ID)
GO	

CREATE INDEX NR_NEWS_RECORDS_ACTOR_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(ACTOR_UUID)
GO	

CREATE INDEX NR_NEWS_RECORDS_SOURCE_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(SOURCE)
GO	

CREATE INDEX NR_NEWS_RECORDS_CONTAINER_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(CONTAINER_ID)
GO
	
CREATE INDEX NR_NEWS_RECORDS_DATE_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(CREATION_DATE DESC)
GO

CREATE INDEX NR_NEWS_RECORDS_EVENT_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS(EVENT_RECORD_UUID)	
GO
-------------------------------------------------------------------
-- END ADDING INDEXES FOR NEWS REPOSITORY 
-------------------------------------------------------------------

COMMIT;