-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

-------------------------------------------------------
-- 1) SEARCH: Make the field STARTBY and INTERVAL nullable
--------------------------------------------------------

CREATE TABLE HOMEPAGE.TMP (
	TMP_TASK_ID VARCHAR2(36) NOT NULL,
	TMP_STARTBY VARCHAR2(256),
	TMP_INTERVAL VARCHAR2(256)
) 
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.TMP
    ADD (CONSTRAINT "PK_TMP" PRIMARY KEY ("TMP_NEWS_RECORDS_ID")
    USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE")

INSERT INTO HOMEPAGE.TMP
(	SELECT SR_TASKDEF.TASK_ID, SR_TASKDEF.STARTBY, SR_TASKDEF.INTERVAL
	FROM HOMEPAGE.SR_TASKDEF SR_TASKDEF
);

ALTER TABLE HOMEPAGE.SR_TASKDEF
DROP COLUMN STARTBY;


ALTER TABLE HOMEPAGE.SR_TASKDEF
ADD  STARTBY VARCHAR2(256);

ALTER TABLE HOMEPAGE.SR_TASKDEF
DROP COLUMN INTERVAL;

ALTER TABLE HOMEPAGE.SR_TASKDEF
ADD  INTERVAL VARCHAR2(256);

-- moving back the data
UPDATE HOMEPAGE.SR_TASKDEF 
SET STARTBY = 	(  	SELECT TMP.TMP_STARTBY FROM HOMEPAGE.TMP TMP
                    WHERE TMP.TMP_TASK_ID = HOMEPAGE.SR_TASKDEF.TASK_ID
           		);

UPDATE HOMEPAGE.SR_TASKDEF 
SET INTERVAL = 	(	SELECT TMP.TMP_INTERVAL FROM HOMEPAGE.TMP TMP
                    WHERE TMP.TMP_TASK_ID = HOMEPAGE.SR_TASKDEF.TASK_ID
           		);

-- dropping the temp table
DROP TABLE HOMEPAGE.TMP;

-------------------------------------------------------
-- 2) SEARCH: Adding the CHECK_SR_TASKDEF check
--------------------------------------------------------
ALTER TABLE HOMEPAGE.SR_TASKDEF
    ADD CONSTRAINT CHECK_SR_TASKDEF
    CHECK ( (STARTBY IS NOT NULL AND INTERVAL IS NOT NULL) OR (STARTBY IS NULL AND INTERVAL IS NULL) );


CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE, 
    T1.ENABLED 					AS  PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID			AS 	PARENT_TASK_ID,
	T3.TASK_NAME 				AS 	PARENT_TASK_NAME,
	T3.INTERVAL					AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 					AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 				AS 	PARENT_TASK_TYPE, 
 	T3.ENABLED 			AS  PARENT_TASK_ENABLED,
	''							AS 	INDEXING_TASK_SERVICES,
	0							AS	INDEXING_TASK_OPTIMIZE,
	''							AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 		AS	OPTIMIZE_TASK_ID,
	T4.OPTIMIZE_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
);

-------------------------------------------------------------------------------
-- Updating the schema version from 17 to 18
-------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 18
WHERE   DBSCHEMAVER = 17;


COMMIT;
--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;