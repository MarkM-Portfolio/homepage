-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 104
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 104 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START HP FIXUP 104 -------------------------------------
---------------------------------------------------------------------------------

--69726: [HP/News104 Schema change] Fix registration URL for SocialMail gadget
UPDATE HOMEPAGE.WIDGET
	SET  	WIDGET_URL = '{connectionsmail}/gadgets/inbox.xml', WIDGET_SECURE_URL = '{connectionsmail}/gadgets/inbox.xml'
	WHERE 	WIDGET_ID = '405a4f26-fa08-4cef-a995-7d90fbe2634f';    
	
---------------------------------------------------------------------------------
------------------------ END HP FIXUP 104 ---------------------------------------
---------------------------------------------------------------------------------
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 104 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 104 -----------------------------------
---------------------------------------------------------------------------------

-- 69579: cannot add more than 32767 comments to a status update
ALTER TABLE HOMEPAGE.BOARD_COMMENTS MODIFY (PUBLISHED_ORDER NUMBER(10,0));
COMMIT;

--70007: [fixup104] HOMEPAGE slow response times while executing the following query on DB2 AIX 
-- SELECT HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID, ..........
DROP INDEX  HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER;
COMMIT;

CREATE INDEX HOMEPAGE.NEWS_STATUS_NET_R_U 
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID, UPDATE_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

--70800: [fixup104] add an index on  RELATED_COMMUNITY_ID
CREATE INDEX HOMEPAGE.NR_STORIES_REL_COMM
	ON HOMEPAGE.NR_STORIES (RELATED_COMMUNITY_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

------------------------------------------------------------------------------------------------------------------
-- [START] 70802: [fixup104] add the column MAX_UPDATE_FOR_READER to READERS and VIEW tables
------------------------------------------------------------------------------------------------------------------


ALTER TABLE  HOMEPAGE.NR_AGGREGATED_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_RESPONSES_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_PROFILES_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_COMMUNITIES_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_ACTIVITIES_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_BLOGS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_BOOKMARKS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_FILES_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_FORUMS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_WIKIS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_TAGS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_STATUS_UPDATE_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_EXTERNAL_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_SAVED_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_ACTIONABLE_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_DISCOVERY_VIEW ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_PROFILES_VIEW ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_NOTIFICATION_SENT_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

ALTER TABLE  HOMEPAGE.NR_TOPICS_READERS ADD MAX_UPDATE_FOR_READER TIMESTAMP;
COMMIT;

------------------------------------------------------------------------------------------------------------------
-- [END] 70802: [fixup104] add the column MAX_UPDATE_FOR_READER to READERS and VIEW tables
------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------
-- [START] 70821: [fixup104] After rally we see we can improve of 90% perf. on querying readers table.
-----------------------------------------------------------------------------------------------------


--  [start indexes] NR_AGGREGATED_READERS
CREATE  INDEX HOMEPAGE.AGGREGATED_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_AGGREGATED_READERS

--  [start indexes] NR_RESPONSES_READERS
CREATE  INDEX HOMEPAGE.RESPONSES_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_RESPONSES_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_RESPONSES_READERS

--  [start indexes] NR_PROFILES_READERS
CREATE  INDEX HOMEPAGE.PROFILES_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_PROFILES_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_PROFILES_READERS

--  [start indexes] NR_COMMUNITIES_READERS
CREATE  INDEX HOMEPAGE.COMM_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_COMMUNITIES_READERS

--  [start indexes] NR_ACTIVITIES_READERS
CREATE  INDEX HOMEPAGE.ACTIVITIES_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_ACTIVITIES_READERS

--  [start indexes] NR_BLOGS_READERS
CREATE  INDEX HOMEPAGE.BLOGS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_BLOGS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_BLOGS_READERS

--  [start indexes] NR_BOOKMARKS_READERS
CREATE  INDEX HOMEPAGE.BOOKMARKS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_BOOKMARKS_READERS

--  [start indexes] NR_FILES_READERS
CREATE  INDEX HOMEPAGE.FILES_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_FILES_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_FILES_READERS

--  [start indexes] NR_FORUMS_READERS
CREATE  INDEX HOMEPAGE.FORUMS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_FORUMS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_FORUMS_READERS

--  [start indexes] NR_WIKIS_READERS
CREATE  INDEX HOMEPAGE.WIKIS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_WIKIS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_WIKIS_READERS

--  [start indexes] NR_TAGS_READERS
CREATE  INDEX HOMEPAGE.TAGS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_TAGS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_TAGS_READERS

--  [start indexes] NR_STATUS_UPDATE_READERS
CREATE  INDEX HOMEPAGE.STATUS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_STATUS_UPDATE_READERS

--  [start indexes] NR_EXTERNAL_READERS
CREATE  INDEX HOMEPAGE.EXTERNAL_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_EXTERNAL_READERS

--  [start indexes] NR_SAVED_READERS
CREATE  INDEX HOMEPAGE.SAVED_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_SAVED_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_SAVED_READERS

--  [start indexes] NR_ACTIONABLE_READERS
CREATE  INDEX HOMEPAGE.ACTIONABLE_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_ACTIONABLE_READERS

--  [start indexes] NR_DISCOVERY_VIEW
CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_DISCOVERY_VIEW

--  [start indexes] NR_PROFILES_VIEW
CREATE  INDEX HOMEPAGE.PROFILES_VIEW_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_PROFILES_VIEW (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_PROFILES_VIEW

--  [start indexes] NR_NOTIFICATION_SENT_READERS
CREATE  INDEX HOMEPAGE.NOTIFICA_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_NOTIFICATION_SENT_READERS

--  [start indexes] NR_NOTIFICATION_RECEIV_READERS
CREATE  INDEX HOMEPAGE.NOT_REC_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_NOTIFICATION_RECEIV_READERS

--  [start indexes] NR_TOPICS_READERS
CREATE  INDEX HOMEPAGE.TOPICS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_TOPICS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

--  [end indexes] NR_TOPICS_READERS

-- 70839: Found as part of defect 70701 - need to set IS_READER_COMM to 1 as part of upgrade scripts
UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW  SET IS_READER_COMM = 1 WHERE NOT EXISTS (
	SELECT 	1
 	FROM  	HOMEPAGE.PERSON PERSON
 	WHERE 	HOMEPAGE.NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = PERSON.PERSON_ID 
);
COMMIT;

-----------------------------------------------------------------------------------------------------
-- [END] 70821: [fixup104] After rally we see we can improve of 90% perf. on querying readers table.
-----------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 104 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 104 FOR SEARCH
------------------------------------------------

--{include.search-fixup104.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 100
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 104 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 103;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 104
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
