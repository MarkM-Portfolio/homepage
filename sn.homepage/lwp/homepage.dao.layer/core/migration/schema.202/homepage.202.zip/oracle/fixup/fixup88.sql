-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 88 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- RENAME REPLYTO COLUMNS - DROP AND CREATE THE TABLES
----------------------------------------------------------------------
    	
DROP TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT;

DROP TABLE HOMEPAGE.NT_REPLYTO; 

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_NOTIFICATION_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36),
	EVENT_NAME VARCHAR2(256) NOT NULL,
	CONTAINER_ID VARCHAR2(256),	
	ITEM_ID VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),	
	CREATION_DATE TIMESTAMP NOT NULL,
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0),
	SOURCE_TYPE NUMBER(5,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD (CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_NOTIFICATION_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO ENABLE ROW MOVEMENT;
    
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID VARCHAR2(36) NOT NULL,
	REPLYTO_NOTIFICATION_ID VARCHAR2(36) NOT NULL,
	PERSON_ID VARCHAR2(36) NOT NULL,	
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	LAST_UPDATE TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD (CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_NOT_ID FOREIGN KEY (REPLYTO_NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_NOTIFICATION_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.REPLYTO_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ID) TABLESPACE "HPNTINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT ENABLE ROW MOVEMENT;

COMMIT;


COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 88 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- FIX CONSTRAINT ON SOURCE_TYPE FOR NR_ENTRIES_EXTERNAL
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL DROP CONSTRAINT CK_ENT_SRC10_TYPE;

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD CONSTRAINT CK_ENT_SRC100_TYPE
    													CHECK
    													(SOURCE_TYPE >= 100);
COMMIT;

-----------------------------------------------
-- ADD ROLLUP_ENTRY_ID FOREIGN KEY TO READER TABLES
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_FILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_TAGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 88 FOR SEARCH
------------------------------------------------

--{include.search-fixup88.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 88
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 88 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 87;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
