-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE 
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--HOMEPAGE

runstats on table HOMEPAGE.HOMEPAGE_SCHEMA with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.PERSON with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.LOGINNAME with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.PREREQ with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.WIDGET with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.HP_UI with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_TAB with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_TAB_INST with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_WIDGET_INST with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_WIDGET_TAB with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.NT_NOTIFICATION with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NT_NOTIFICATION_RECIPIENT with distribution and detailed indexes all allow write access;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--NEWS



runstats on table HOMEPAGE.NR_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SUBSCRIPTION with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_RECORDS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_TEMPLATE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_EVENT_RECORDS with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.EMD_JOBS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.EMD_JOBS_STATS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.EMD_RECIPIENTS with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.NR_SCHEDULER_LMGR with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SCHEDULER_LMPR with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SCHEDULER_TASK with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SCHEDULER_TREG with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.NR_GROUP_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_PERSON_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_CATEGORY_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_TOP_UPDATES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_SAVED with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_DISCOVERY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_WATCHLIST with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STORY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_COMMENT with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.NR_NEWS_COMMENT_CONTENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STATUS_CONTENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STATUS_COMMENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STATUS_NETWORK with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.NR_STORIES_CONTENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_ORGPERSON_STORIES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_COMM_STORIES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOWED_STORIES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_STORIES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_ORGPERSON_FOLLOW with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_COMM_FOLLOW with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOWS with distribution and detailed indexes all allow write access;	
runstats on table HOMEPAGE.NR_RESOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_RESOURCE_TYPE with distribution and detailed indexes all allow write access;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH
runstats on table HOMEPAGE.SR_INDEXINGTASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_OPTIMIZETASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_TASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FILESCONTENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_MIGTASKDEFINFO with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FILECONTENTTASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_INDEX_DOCS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FACET_DOCS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_RESUME_TOKENS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_BACKUPTASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_INDEX_MANAGEMENT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_SANDTASKDEF with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FEEDBACK   with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FEEDBACK_CONTEXT with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_FEEDBACK_PARAMETERS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_STATS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_STRING_STATS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_NUMBER_STATS with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.SR_TIMER_STATS with distribution and detailed indexes all allow write access;

runstats on table HOMEPAGE.LOTUSCONNECTIONSLMGR with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.LOTUSCONNECTIONSLMPR with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.LOTUSCONNECTIONSTASK with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.LOTUSCONNECTIONSTREG with distribution and detailed indexes all allow write access;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------


COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 