-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

----------------------------------------------------
-- Script to upgrade Home Page database
-- from schema version 3 to 4
----------------------------------------------------

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

ALTER TABLE HOMEPAGE.USER_WIDGET_PREF
   ADD SHOW_DISABLED_WIDGETS NUMERIC(5, 0) NOT NULL DEFAULT 0;
GO

UPDATE HOMEPAGE.HOMEPAGE_SCHEMA
   SET   DBSCHEMAVER = 4
   WHERE COMPKEY = 'HOMEPAGE';
GO

COMMIT;
