-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 56 FOR HP
------------------------------------------------

-- {include.hp-fixup56.sql}

------------------------------------------------
-- INCLUDE FIX UP 56 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CREATE INDEX HOMEPAGE.NR_SC_UDATE
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (UPDATE_DATE ASC);
   
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_ITEM_C
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_CORRELATION_ID);
   
COMMIT;

-- SPR #RSTR8A5Q7R
-- Slow query on Homepage nr_news_status_network table: Oracle
CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_IDX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID);

COMMIT;

--SPR #MAKN8A8DXJ SVT: 
--Homepage News Feed (Filter Responses and People) is very slow
CREATE INDEX HOMEPAGE.NR_EVENT_READER 
	ON HOMEPAGE.NR_NEWS_SAVED (READER_ID,EVENT_RECORD_UUID);

COMMIT;

reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_DISCOVERY;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_NETWORK;
reorg indexes all for table HOMEPAGE.NR_NEWS_SAVED;

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 56 FOR SEARCH
------------------------------------------------

--{include.search-fixup56.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 56
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 56 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 55;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
