-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- *****************************************************************  

----------------------------------------------------
-- Script to upgrade Home Page database
-- from schema version 3 to 4
----------------------------------------------------

ALTER TABLE "HOMEPAGE"."USER_WIDGET_PREF"
   ADD SHOW_DISABLED_WIDGETS NUMBER(1) DEFAULT 0 NOT NULL;
   
UPDATE "HOMEPAGE"."HOMEPAGE_SCHEMA"
   SET   DBSCHEMAVER = 4
   WHERE COMPKEY = 'HOMEPAGE';

COMMIT;

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
