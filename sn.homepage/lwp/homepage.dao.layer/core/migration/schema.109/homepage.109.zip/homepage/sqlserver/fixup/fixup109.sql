-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 109 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.OH2P_CLIENTCFG;
GO

CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID nvarchar(128) NOT NULL, 
	CLIENTID nvarchar(256) NOT NULL, 
	CLIENTSECRET nvarchar(256), 
	DISPLAYNAME nvarchar(256) NOT NULL, 
	REDIRECTURI nvarchar(2048), 
	ENABLED NUMERIC(5,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID);

GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 109 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 109 -----------------------------------
---------------------------------------------------------------------------------

CREATE  INDEX DISCOVERY_VIEW_ACT_CD_VIS_IDX  
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ACTOR_UUID, CREATION_DATE DESC, IS_VISIBLE); 
GO
    

DROP INDEX STORIES_CONTAINER_URL_IDX ON HOMEPAGE.NR_STORIES;
GO
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 109 -------------------------------------
---------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK ALTER COLUMN BRIEF_DESC nvarchar(4000);
GO

CREATE INDEX NR_STATUS_UPDATE_IX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID, UPDATE_DATE ASC, CREATION_DATE ASC, ITEM_ID, ACTOR_UUID);
GO


--76074: Fixup109.sql - add indexes based on performance and dev activities
DROP INDEX NR_SL_UD_DELTED_IX ON HOMEPAGE.NR_AS_SEEDLIST;
GO

DROP INDEX NR_SL_UD_VISIBLE_IX ON HOMEPAGE.NR_AS_SEEDLIST;
GO

DROP INDEX NR_AS_SEEDLIST_IDX ON HOMEPAGE.NR_AS_SEEDLIST;
GO

CREATE INDEX NR_SL_UD_STR
	ON HOMEPAGE.NR_AS_SEEDLIST (UPDATE_DATE ASC, STORY_ID);
GO

-- Index for deletion service
DROP INDEX COMM_READERS_DEL_SERV_IX ON HOMEPAGE.NR_COMMUNITIES_READERS;
GO

DROP INDEX DISCOVERY_VIEW_DEL_SERV_IX ON HOMEPAGE.NR_DISCOVERY_VIEW;
GO

DROP INDEX PROFILES_VIEW_DEL_SERV_IX ON HOMEPAGE.NR_PROFILES_VIEW;
GO

CREATE  INDEX COMM_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (CREATION_DATE DESC, IS_BROADCAST); 
GO

CREATE  INDEX DISCOVERY_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (CREATION_DATE DESC, IS_BROADCAST); 
GO

CREATE  INDEX PROFILES_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE DESC, IS_BROADCAST); 
GO

---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 102 FOR SEARCH
------------------------------------------------

--{include.search-fixup109.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 109
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 109 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 108;
------------------------------------------------------------------------------------------------

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

COMMIT
