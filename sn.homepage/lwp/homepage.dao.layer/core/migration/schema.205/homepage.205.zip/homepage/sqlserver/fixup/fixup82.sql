-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 82
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 82 FOR HP
------------------------------------------------

--{include.hp-fixup82.sql}

------------------------------------------------
-- INCLUDE FIX UP 82 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_ENTRIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_ACT (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
    ADD CONSTRAINT PK_ACT_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_ACT_CONT
    ON HOMEPAGE.NR_ENTRIES_ACT (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_ACT_SRC
    ON HOMEPAGE.NR_ENTRIES_ACT (SOURCE_TYPE);

GO

----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_ENTRIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_BLG (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
    ADD CONSTRAINT PK_BLG_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_BLG_CONT
    ON HOMEPAGE.NR_ENTRIES_BLG (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_BLG_SRC
    ON HOMEPAGE.NR_ENTRIES_BLG (SOURCE_TYPE);
    

GO

----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_ENTRIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_COM (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
    ADD CONSTRAINT PK_COM_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_COM_CONT
    ON HOMEPAGE.NR_ENTRIES_COM (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_COM_SRC
    ON HOMEPAGE.NR_ENTRIES_COM (SOURCE_TYPE);

GO

----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_ENTRIES_WIK
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_WIK (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
    ADD CONSTRAINT PK_WIK_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_WIK_CONT
    ON HOMEPAGE.NR_ENTRIES_WIK (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_WIK_SRC
    ON HOMEPAGE.NR_ENTRIES_WIK (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_ENTRIES_PRF
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_PRF (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
    ADD CONSTRAINT PK_PRF_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_PRF_CONT
    ON HOMEPAGE.NR_ENTRIES_PRF (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_PRF_SRC
    ON HOMEPAGE.NR_ENTRIES_PRF (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_ENTRIES_HP
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_HP (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
    ADD CONSTRAINT PK_HP_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_HP_CONT
    ON HOMEPAGE.NR_ENTRIES_HP (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_HP_SRC
    ON HOMEPAGE.NR_ENTRIES_HP (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_ENTRIES_DGR
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_DGR (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
) ON [PRIMARY]
GO 


ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
    ADD CONSTRAINT PK_DGR_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_DGR_CONT
    ON HOMEPAGE.NR_ENTRIES_DGR (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_DGR_SRC
    ON HOMEPAGE.NR_ENTRIES_DGR (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_ENTRIES_FILE
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FILE (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
    ADD CONSTRAINT PK_FILE_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_FILE_CONT
    ON HOMEPAGE.NR_ENTRIES_FILE (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_FILE_SRC
    ON HOMEPAGE.NR_ENTRIES_FILE (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_ENTRIES_FRM
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FRM (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
    ADD CONSTRAINT PK_FRM_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_FRM_CONT
    ON HOMEPAGE.NR_ENTRIES_FRM (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_FRM_SRC
    ON HOMEPAGE.NR_ENTRIES_FRM (SOURCE_TYPE);


GO

----------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE ADDING TABLE FOR PROFILES STORIES COMMENTS 
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT;

CREATE TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT (
	NEWS_COMMENT_ID nvarchar(36) NOT NULL,
	ACTOR_UUID nvarchar(36) NOT NULL,
	CREATION_DATE DATETIME,
	UPDATE_DATE DATETIME,
	BRIEF_DESC nvarchar(500),
	ENTRY_ID  nvarchar(36),
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	ITEM_ID  nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_URL nvarchar(2048),
	TARGET_SUBJECT_ID nvarchar(36),
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT PK_PRF_COMMENT_ID PRIMARY KEY(NEWS_COMMENT_ID);

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT FK_ENTRY_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
  	
CREATE INDEX PRF_COMMENT_ENTRY_ID
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (ENTRY_ID);

CREATE INDEX NR_NEWS_PRF_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (UPDATE_DATE ASC);



GO

----------------------------------------------------------------
-- DROPPING AND RECREATE NR_RECOMMENDATION - CAN RELATE TO ANY ENTRY TABLE
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_RECOMMENDATION;

CREATE TABLE HOMEPAGE.NR_RECOMMENDATION  (
	RECOMMENDATION_ID nvarchar(36) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(36) NOT NULL, 
	SOURCE_TYPE NUMERIC(5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 
    ADD CONSTRAINT PK_RECOMMENDATION PRIMARY KEY(RECOMMENDATION_ID);

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION
  	ADD CONSTRAINT FK_RECOMMENDER_ID FOREIGN KEY (RECOMMENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);
    
CREATE INDEX NR_REC_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (ENTRY_ID);

CREATE INDEX NR_RECCOMANDER_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID);
    
CREATE UNIQUE INDEX NR_RECOMMENDER_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID, ENTRY_ID);


GO

---------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE HOMEPAGE.NR_ATTACHMENT
---------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ATTACHMENT;

CREATE TABLE HOMEPAGE.NR_ATTACHMENT (
	ATTACHMENT_ID nvarchar(36) NOT NULL,
	ENTRY_ID nvarchar(36) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC(5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 
    ADD CONSTRAINT PK_ATTACHMENT PRIMARY KEY(ATTACHMENT_ID);

CREATE INDEX NR_ATT_ENTRY_ID
    ON HOMEPAGE.NR_ATTACHMENT (ENTRY_ID);    



GO

---------------------------------------------------------------
-- Adding flag for debug purpose on PERSON_COMM table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
	ADD IS_READER_COMM NUMERIC(5,0) DEFAULT 0 NOT NULL;
GO	


UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW  SET IS_READER_COMM = 0;

GO

UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW  SET IS_READER_COMM = 1 WHERE NOT EXISTS (
	SELECT 	1
 	FROM  	HOMEPAGE.PERSON PERSON
 	WHERE 	HOMEPAGE.NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = PERSON.PERSON_ID 
);
		
GO	

---------------------------------------------------------------
-- Adding flag for debug purpose on NR_COMM_PERSON_STORIES table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD IS_STORY_COMM NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET IS_STORY_COMM = 1;

GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES 
SET    IS_STORY_COMM = 0
WHERE  EXISTS ( SELECT 1
                FROM   HOMEPAGE.PERSON
                WHERE  PERSON_ID = COMM_PER_READER_ID );

GO

---------------------------------------------------------------
---------------------------------------------------------------	
-- SEEDLIST AND BOARD TABLES	
---------------------------------------------------------------
---------------------------------------------------------------
--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMERIC (5,0),
	CATEGORY_TYPE NUMERIC (5,0),
	SOURCE nvarchar(36),
	SOURCE_TYPE NUMERIC (5,0),
	STORY_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE DATETIME NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID nvarchar(36),
	N_COMMENTS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_COMMUNITY_STORY NUMERIC (5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMERIC (5,0) DEFAULT 0,
	TARGET_SUBJECT_ID nvarchar(256),
	IS_NETWORK_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	TAGS nvarchar(1024),
	SL_IS_UPDATED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE DATETIME NOT NULL, -- this field is used by the seedlist
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID);

CREATE INDEX NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC);
  
CREATE INDEX NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC);

GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID nvarchar(36) NOT NULL,
	IS_READER_COMM NUMERIC (5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID);

CREATE INDEX NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);

GO

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	ITEM_ID nvarchar(47),
	ITEM_CORRELATION_ID nvarchar(47),
	ITEM_URL nvarchar(2048),	
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID);   

GO

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC (5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID);     
	
GO

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID nvarchar(47) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(47) NOT NULL,
	SOURCE_TYPE NUMERIC (5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID);
    
CREATE UNIQUE INDEX BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID);

GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 60 FOR SEARCH
------------------------------------------------

--{include.search-fixup82.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 82
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 82 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 81;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 82
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

