-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

runstats on table HOMEPAGE.WIDGET  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_TIMER_STATS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_TASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_STRING_STATS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_STATS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_SANDTASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_RESUME_TOKENS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_OPTIMIZETASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_NUMBER_STATS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_MIGTASKDEFINFO with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_INDEXINGTASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_INDEX_MANAGEMENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_INDEX_DOCS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_GLOBAL_SAND_PROPS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_FILESCONTENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_FILECONTENTTASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_FEEDBACK_PARAMETERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_FEEDBACK_CONTEXT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_FEEDBACK with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.SR_BACKUPTASKDEF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.PREREQ with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.PERSON with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.OH2P_CLIENTCFG with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OH2P_CACHE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.OAUTH2_TOKEN with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.OAUTH2_PROVIDER with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH2_GADGET_BINDING with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH2_CLIENT with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH1_TOKEN with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH1_PROVIDER with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH1_CONTEXT with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.OAUTH1_CLIENT with distribution and detailed indexes all allow write access;
COMMIT; 
runstats on table HOMEPAGE.NT_REPLYTO_RECIPIENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NT_REPLYTO with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NT_NOTIFICATION_RECIPIENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NT_NOTIFICATION with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_WIKIS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_TOPICS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_MENTIONS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_TEMPLATE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_TAGS_READERS with distribution and detailed indexes all allow write access;
COMMIT;

runstats on table HOMEPAGE.NR_STORIES_CONTENT  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_STORIES with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_STATUS_UPDATE_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SOURCE_TYPE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SOURCE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SCHEDULER_TREG with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SCHEDULER_TASK with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SCHEDULER_LMPR with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SCHEDULER_LMGR with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_SAVED_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_RESPONSES_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_RESOURCE_TYPE  with distribution and detailed indexes all allow write access;
COMMIT;	
runstats on table HOMEPAGE.NR_RESOURCE  with distribution and detailed indexes all allow write access;
COMMIT;  
runstats on table HOMEPAGE.NR_PROFILES_VIEW with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_PROFILES_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NOTIFICATION_SENT_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NEWS_STATUS_NETWORK with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NEWS_STATUS_CONTENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NEWS_STATUS_COMMENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NEWS_COMMENT_CONTENT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_NETWORK  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_FORUMS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_FOLLOWS  with distribution and detailed indexes all allow write access;
COMMIT;	
runstats on table HOMEPAGE.NR_FILES_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_EXTERNAL_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_ENTRIES_ARCHIVE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_ENTRIES with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_DISCOVERY_VIEW with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_COMMUNITIES_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_COMM_SETTINGS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_COMM_PERSON_FOLLOW with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_COMM_FOLLOW  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_CATEGORY_TYPE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_BOOKMARKS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_BLOGS_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_AS_SEEDLIST with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_AS_CRAWLER_STATUS  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_AS_CONTENT_INDEX_STATS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_AS_COLLECTION_CONFIG with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_AGGREGATED_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_ACTIVITIES_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.NR_ACTIONABLE_READERS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.MTCONFIG with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.MT_METRIC_STAT with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.LOTUSCONNECTIONSTREG with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.LOTUSCONNECTIONSTASK with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.LOTUSCONNECTIONSLMPR with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.LOTUSCONNECTIONSLMGR with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.LOGINNAME with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.HP_WIDGET_TAB  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.HP_WIDGET_INST  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.HP_UI  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.HP_TAB_INST  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.HP_TAB  with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.EMD_TRANCHE_INFO with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.EMD_TRANCHE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.EMD_RESOURCE_PREF with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.EMD_FREQUENCY_TYPE with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.EMD_EMAIL_PREFS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.DELETED_STORIES_QUEUE with distribution and detailed indexes all allow write access;
COMMIT;  
runstats on table HOMEPAGE.BOARD_MENTIONS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.BOARD_RECOMMENDATIONS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.BOARD_OBJECT_REFERENCE with distribution and detailed indexes all allow write access;
COMMIT;   
runstats on table HOMEPAGE.BOARD_ENTRIES with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.BOARD_CURRENT_STATUS with distribution and detailed indexes all allow write access;
COMMIT;
runstats on table HOMEPAGE.BOARD_COMMENTS with distribution and detailed indexes all allow write access;
COMMIT;   
runstats on table HOMEPAGE.BOARD with distribution and detailed indexes all allow write access;
COMMIT;



--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 