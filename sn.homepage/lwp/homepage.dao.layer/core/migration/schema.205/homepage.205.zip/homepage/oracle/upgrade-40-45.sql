-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++ HOMEPAGE +++++++++++++++++++++++++++++++++++++
-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

------------------------------------------------
-- INCLUDE FIXUP 204 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------
------------------------ START HP FIXUP 204 --------
----------------------------------------------------
-- 80778: Schema changes to enable per-gadget-per-server rules

ALTER TABLE HOMEPAGE.WIDGET 
	ADD SERVER_ACCESS 			CLOB 	LOB (SERVER_ACCESS) STORE AS (TABLESPACE NEWSLOBTABSPACE STORAGE (INITIAL 1M) CHUNK 4000 NOCACHE NOLOGGING)
	ADD ADDITIONAL_FEATURES 	CLOB 	LOB (ADDITIONAL_FEATURES) STORE AS (TABLESPACE NEWSLOBTABSPACE STORAGE (INITIAL 1K) CHUNK 100 NOCACHE NOLOGGING);


COMMIT;


----------------------------------------------------
------------------------ START END FIXUP 204 -------
----------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++ NEWS +++++++++++++++++++++++++++++++++++++++++
-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

------------------------------------------------
-- INCLUDE FIXUP 201 FOR NEWS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 201 -----------------------------------
---------------------------------------------------------------------------------

-- 78715 - New columns on NR_SOURCE_TYPE table.
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
ADD (IS_DIGEST_ENABLED NUMBER(5,0) DEFAULT 0 NOT NULL,
     DEFAULT_DIGEST_FREQUENCY NUMBER(5,0)  DEFAULT 0 NOT NULL,
     IS_DIGEST_LOCKED NUMBER(5,0) DEFAULT 0 NOT NULL);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES
MODIFY (N_COMMENTS NUMBER(10,0),
		N_RECOMMANDATIONS NUMBER(10,0));
COMMIT;
	
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 201 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIXUP 202 FOR NEWS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 202 -----------------------------------
---------------------------------------------------------------------------------

-- 78618: [DB] Add columns in NR_ENTRIES/NR_ENTRIES_ARCHIVE tables to store total number of comments
ALTER TABLE HOMEPAGE.NR_ENTRIES ADD (
	PREV_COMMENT_NUM_REC NUMBER(10 ,0) DEFAULT NULL,
	LAST_COMMENT_NUM_REC NUMBER(10 ,0) DEFAULT NULL
);
COMMIT;


ALTER TABLE HOMEPAGE.NR_ENTRIES_ARCHIVE ADD (
	PREV_COMMENT_NUM_REC NUMBER(10 ,0) DEFAULT NULL,
	LAST_COMMENT_NUM_REC NUMBER(10 ,0) DEFAULT NULL
);
COMMIT;


-- 78857: Remove FK_BRD_ENTRY_ID constraint on BOARD_RECOMMENDATIONS table
ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 	DROP CONSTRAINT FK_BRD_ENTRY_ID;
COMMIT;
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 202 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIXUP 202 FOR NEWS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 203 -----------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- HOMEPAGE.BOARD_MENTIONS
------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_MENTIONS  (
	BOARD_MENTIONS_ID VARCHAR2(36) NOT NULL, --primary key
	ITEM_ID VARCHAR2(256) NOT NULL, 
	PERSON_ID VARCHAR2(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	LABEL VARCHAR2(4000),
	WAS_ITEM_VISIBLE NUMBER(5,0) DEFAULT 0 NOT NULL
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_MENTIONS 
    ADD (CONSTRAINT PK_BRD_MEN_ID PRIMARY KEY(BOARD_MENTIONS_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_MENTIONS
	ADD CONSTRAINT FK_BRD_MEN_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE INDEX HOMEPAGE.BRD_MEN_PER_IDX
	ON HOMEPAGE.BOARD_MENTIONS (PERSON_ID) TABLESPACE "BOARDINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.BRD_MEN_ITEM_IDX
	ON HOMEPAGE.BOARD_MENTIONS (ITEM_ID) TABLESPACE "BOARDINDEXTABSPACE";	
	
ALTER TABLE HOMEPAGE.BOARD_MENTIONS ENABLE ROW MOVEMENT;

COMMIT;

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 203 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIXUP 204 FOR NEWS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 204 -----------------------------------
---------------------------------------------------------------------------------

----------------------------------------------------
-- 22 HOMEPAGE.NR_MENTIONS_READERS
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_MENTIONS_READERS (
	CATEGORY_READER_ID VARCHAR2(36)  DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR2(39) NOT NULL,
	CATEGORY_TYPE NUMBER(5 ,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(256),
	ROLLUP_ENTRY_ID VARCHAR2(256),
	RESOURCE_TYPE NUMBER(5 ,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5 ,0),
	USE_IN_ROLLUP NUMBER(5 ,0),
	IS_NETWORK	NUMBER(5 ,0),
	IS_FOLLOWER	NUMBER(5 ,0),
	EVENT_TIME 	TIMESTAMP,
	IS_STORY_COMM NUMBER(5 ,0),
	IS_BROADCAST NUMBER(5,0),
	ORGANIZATION_ID VARCHAR2(256),
	ACTOR_UUID VARCHAR2(256),
	ROLLUP_AUTHOR_ID VARCHAR2 (256),
	IS_VISIBLE NUMBER(5 ,0) DEFAULT 1 NOT NULL,
	MAX_UPDATE_FOR_READER TIMESTAMP,
		CONSTRAINT   	CK_CAT22_TYPE
    			CHECK
    			(CATEGORY_TYPE = 22)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS
    ADD (CONSTRAINT PK_MEN_READERS PRIMARY KEY(CATEGORY_READER_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS 
	ADD CONSTRAINT FK_MEN_READERS_STR FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);
	
--  [start indexes] NR_MENTIONS_READERS
CREATE  INDEX HOMEPAGE.MENTIONS_READERS_STR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ITEM_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_CD_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID, CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RDR_STR 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, STORY_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RIR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, ROLLUP_ENTRY_ID DESC, CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;


--  [end indexes] NR_MENTIONS_READERS	

ALTER TABLE "HOMEPAGE"."NR_MENTIONS_READERS" ENABLE ROW MOVEMENT;

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('mentions', 22, '%mentions', 'mentions');

--------------------------------------------------------
-- DROPPING UNUSED OLD TABLES
--------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SUBSCRIPTION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_DISCOVERY;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_SAVED;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_RECORDS;
COMMIT;

------------------ 81333: Rename ENTRY_ID to ITEM_ID in BOARD_RECOMMENDATIONS --------
DROP INDEX HOMEPAGE.BRD_REC_STORY_ID;
COMMIT;  
    
DROP INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID;
COMMIT;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	RENAME COLUMN ENTRY_ID TO ITEM_ID;
COMMIT;	

CREATE INDEX HOMEPAGE.BRD_REC_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;    
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_REC_RECOM_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;    
	
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 204 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++ SEARCH +++++++++++++++++++++++++++++++++++++++
-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

------------------------------------------------
-- INCLUDE FIXUP 200 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 74517: Create script that creates DB table that hold document type labels

----------------------------------------
--  SR_ECM_DOCUMENT_TYPE_LABELS
----------------------------------------


CREATE TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_LABELS(
	LABEL_ID VARCHAR2(36) NOT NULL,
	LABEL_NAME VARCHAR2(256) NOT NULL,	
	DOCUMENT_TYPES CLOB NOT NULL,
	UPDATE_TIME  TIMESTAMP NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_LABELS
         ADD (CONSTRAINT "PK_LABEL_ID" PRIMARY KEY ("LABEL_ID")
         USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_LABELS
    ADD CONSTRAINT UNIQUE_LABEL_NAME UNIQUE ("LABEL_NAME");


--END 74517: Create script that creates DB table that hold document type labels

--START Task 78083 Prepare DB table for storing post filtering service.
----------------------------------------
--  SR_POST_FILTERING_SERVICE
----------------------------------------

CREATE TABLE HOMEPAGE.SR_POST_FILTERING_SERVICE(
    PFS_ID VARCHAR2(36) NOT NULL,
    SERVICE_NAME VARCHAR2(36) NOT NULL,
    URL VARCHAR2(2048) NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.SR_POST_FILTERING_SERVICE
         ADD (CONSTRAINT "PK_PFS_ID" PRIMARY KEY ("PFS_ID")
         USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");


ALTER TABLE HOMEPAGE.SR_POST_FILTERING_SERVICE
    ADD CONSTRAINT UNIQUE_SERVICE_NAME UNIQUE ("SERVICE_NAME");

--END Task 78083 Prepare DB table for storing post filtering service.
 

--START Defect 77766: Search slow query 
CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_SU_IDX ON  HOMEPAGE.SR_INDEX_DOCS(SERVICE,UPDATE_TIME) TABLESPACE "HOMEPAGEINDEXTABSPACE";
--END Defect 77766: Search slow query 

--START SmartCloud Defect 96370
CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_TAW_IDX ON  HOMEPAGE.SR_INDEX_DOCS(UPDATE_TIME ASC,DOCUMENT_ID ASC,CRAWLING_VERSION ASC) TABLESPACE "HOMEPAGEINDEXTABSPACE";
--END SmartCloud Defect 96370

ALTER TABLE "HOMEPAGE"."SR_INDEX_DOCS" ENABLE ROW MOVEMENT;




---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIXUP 201 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 74517: Create script that creates DB table that hold document type labels

----------------------------------------
--  SR_ECM_DOCUMENT_TYPE_PROPS
----------------------------------------


CREATE TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS(
	PROPERTIES_ID VARCHAR2(36) NOT NULL,
	DOCUMENT_TYPE_ID VARCHAR2(256) NOT NULL,
	LOCALE VARCHAR2(10) NOT NULL,	
	PROPERTIES CLOB NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS
         ADD (CONSTRAINT "PK_PROPERTIES_ID" PRIMARY KEY ("PROPERTIES_ID")
         USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

--END 74517: Create script that creates DB table that hold document type labels

--START Defect 80084: Rename IS_CURRENT Field to STATUS.

DROP INDEX  HOMEPAGE.SR_FILESCONTENT_IS_CURRENT_IDX;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	RENAME COLUMN IS_CURRENT TO STATUS;

CREATE INDEX "HOMEPAGE"."SR_FILESCONTENT_STATUS_IDX" 
	ON HOMEPAGE.SR_FILESCONTENT(STATUS) TABLESPACE "HOMEPAGEINDEXTABSPACE"; 
 
--END Defect 80084: Rename IS_CURRENT Field to STATUS.
         
         

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 204
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 204 , RELEASEVER = '4.5.0.0'
WHERE   DBSCHEMAVER = 110;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;


--------------------------------------
-- DISCONNECT
--------------------------------------

DISCONNECT ALL;

QUIT;