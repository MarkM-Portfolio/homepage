-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

 
--------------------------------------
-- CONNECT TO HOMEPAGE
--------------------------------------
USE HOMEPAGE 
GO

BEGIN TRANSACTION
GO
-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--HOMEPAGE

-- Insert the panel tab page widget
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.widgetx4a43x82aaxb00187218631' , '%panel.widget' , 2 , 0, 1);

-- Insert the panel tab page update
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.updatex4a43x82aaxb00187218631' , '%panel.update' , 1 , 0, 1);
 
-- Insert the panel tab page widget
INSERT INTO HOMEPAGE.HP_TAB
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.customx4a43x82aaxb00187218631' , '%panel.custom' , 2 , 1, 1);

-- Insert the panel tab page widget
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.getstartx4a43x82aaxb001872186' , '%panel.getstart' , 1 , 0, 1);

--
-- Insert special non-UI panels needed for gadgets
--

-- hidden pane for gadgets
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_noui.gadgetpanx11e1b0c40800200c9a66' , '%panel.gadgets' , 1 , 0, 1);

-- hidden pane for EE gadgets
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_noui.embeddedxx11e1b0c40800200c9a66' , '%panel.embedxp' , 1 , 0, 1);

-- hidden pane for sharebox gadgets
INSERT INTO HOMEPAGE.HP_TAB 
                  (TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES            ('_noui.share_diax11e1b0c40800200c9a66' , '%panel.sharedialog' , 1 , 0, 1);

 
-- Beginning Dogear widgets 

-- Dogear Original Widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('dogear46x0a77x4a43x82aaxb00187218631', '%widget.dogear.name', '%widget.dogear.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'DOGEAR', 1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('7b1a60f1xc9cax4cc4x8b0bx51af2ddef2cd', 'dogear', 'dogear46x0a77x4a43x82aaxb00187218631');

-- Dogear MyBookmarks widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('dembk46x0a77x4a43x82aaxb00187218631', '%widget.dogear.personal.name', '%widget.dogear.personal.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'DOGEAR', 0,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('7c1a34f1xc9cax4cc4x8b0bx51af2ddef2cd', 'dogear', 'dembk46x0a77x4a43x82aaxb00187218631');

-- Dogear PopularBookmarks widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('depbk46x0a77x4a43x82aaxb00187218631', '%widget.dogear.popular.name', '%widget.dogear.popular.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'DOGEAR', 0,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('7w1a60f1xc9cax4cc4x8b0bx51af2ddef2cd', 'dogear', 'depbk46x0a77x4a43x82aaxb00187218631');

-- Dogear RecentBookmarks widget - opened by default
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('derbk46x0a77x4a43x82aaxb00187218631',  '%widget.dogear.recent.name', '%widget.dogear.recent.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'DOGEAR', 0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('7t1a60f1xc9cax4cc4x8b0bx51af2ddef2cd', 'dogear', 'derbk46x0a77x4a43x82aaxb00187218631');

-- Dogear WatchList widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('dewl46x0a77x4a43x82aaxb00187218631', '%widget.dogear.watchlist.name', '%widget.dogear.watchlist.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'DOGEAR',  0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('7m1a60f1xc9cax4cc4x8b0bx51af2ddef2cd', 'dogear', 'dewl46x0a77x4a43x82aaxb00187218631');

-- End Dogear widgets



-- Beginning Activities widgets

-- Activities Original Widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('activitixa187x491dxa4bfx2e1261d0b6ec', '%widget.activities.name', '%widget.activities.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'ACTIVITIES', 1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('fab0b9ccx9ffex4574xbf4ax10e389b5b4e3', 'activities', 'activitixa187x491dxa4bfx2e1261d0b6ec');

-- Activities MyActivities widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('myactxa187x491dxa4bfx2e1261d0b6ec', '%widget.activities.personal.name', '%widget.activities.personal.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'ACTIVITIES', 0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('fab0b9ccx9ffex4874xbf4ax10e389b5b4e3', 'activities', 'myactxa187x491dxa4bfx2e1261d0b6ec');

-- Activities PublicActivities widget - opened by default
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('pubactxa187x491dxa4bfx2e1261d0b6ec',  '%widget.activities.public.name', '%widget.activities.public.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'ACTIVITIES', 0,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('fab0v9ccx9ffex4523xbf4ax10e389b5b4e3', 'activities', 'pubactxa187x491dxa4bfx2e1261d0b6ec');

-- Sidebar Activities TODO widget - in update page
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('activities-sidebar7x4229x8',  '%widget.activities.sidebar.todo.name', '%widget.activities.sidebar.todo.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'ACTIVITIES', 1,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconActivities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('fab0z9ccx9ffex4523xbf4ax10e389b5b4e3', 'activities', 'activities-sidebar7x4229x8');

-- End Activities widgets

-- Beginning Communities widgets

-- Communities Original Widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('communitxe7c4x4e08xab54x80e7a4eb8933', '%widget.communities.name', '%widget.communities.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'COMMUNITIES', 1,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('73de8824x9317x4195x90c0x696c1b6da4ff', 'communities', 'communitxe7c4x4e08xab54x80e7a4eb8933');

-- Communities MyCommunities widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('mycommunxe7c4x4e08xab54x80e7a4eb8933',  '%widget.communities.personal.name', '%widget.communities.personal.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'COMMUNITIES', 0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('73de6624x9317x4195x90c0x696c1b6da4ff', 'communities', 'mycommunxe7c4x4e08xab54x80e7a4eb8933');

-- Communities PublicCommunities widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID,  WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('pubcommuxe7c4x4e08xab54x80e7a4eb8933',  '%widget.communities.public.name', '%widget.communities.public.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'COMMUNITIES', 0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('73de8824x9677y4195x90c0x696c1b6da4ff', 'communities', 'pubcommuxe7c4x4e08xab54x80e7a4eb8933');

-- End Communities widgets




-- Beginning Blogs widget

INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID,  WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('blogs448xcd34x4565x9469x9c34fcefe48c', '%widget.blogs.name', '%widget.blogs.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBlogs16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'BLOGS', 1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconBlogs16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('ac8ce708x3f95x4357xa3c9xc8673baab246', 'blogs', 'blogs448xcd34x4565x9469x9c34fcefe48c');

-- End Blogs widget




-- Beginning Profiles widgets

-- Profiles Original Widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID,  WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('profilesxaac7x4229x87bbx9a1c3551c591', '%widget.profiles.name', '%widget.profiles.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'PROFILES', 1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('4a848b83x7621x4ad0x807ex2aa4373360bd', 'profiles', 'profilesxaac7x4229x87bbx9a1c3551c591');

-- Profiles MyProfile widget - opened by default
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID,  WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('myprofisxaac7x4229x87bbx9a1c3551c591', '%widget.profiles.personal.name', '%widget.profiles.personal.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'PROFILES', 0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('4a848b83x7451x4ad0x807ex2aa4373360bd', 'profiles', 'myprofisxaac7x4229x87bbx9a1c3551c591');

-- Profiles ColleagueProfile widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('colprofsxaac7x4229x87bbx9a1c3551c591', '%widget.profiles.colleagues.name', '%widget.profiles.colleagues.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'PROFILES',  0,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconProfiles16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('4a848b83x7891x4aw0x807ex2aa4373360bd', 'profiles', 'colprofsxaac7x4229x87bbx9a1c3551c591');

-- End Profiles widgets



-- Beginning Wiki Widget

-- My Wiky widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED,  WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('mywikiz1xaac7x4229x87BBx91ac3551c591', '%widget.mywiki.name', '%widget.mywiki.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'WIKI',  0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('4a848b83x7621x4awk5020ex2aa4373360bd', 'wikis', 'mywikiz1xaac7x4229x87BBx91ac3551c591');

-- Popular Wiki
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED,  WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('pop-wiki1xaac7x4229x87BBx91ac3551c5', '%widget.popwiki.name', '%widget.popwiki.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png', 1, 1, 1,  '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'WIKI',  0,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('4a848b8997620ojaw08d20ex2o4837336r8j', 'wikis', 'pop-wiki1xaac7x4229x87BBx91ac3551c5');

-- Latest wiki
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('latest-wiki5jz1xaac7x4229x87BBx91ac', '%widget.latestwiki.name', '%widget.latestwiki.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png', 1, 1, 1,  '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'WIKI',  1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconWikis16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('45thpb899762998dw08ee96x20of33o0Ur8j', 'wikis', 'latest-wiki5jz1xaac7x4229x87BBx91ac');


-- My Files widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('myFilesPb86locI7vRV4yY1KKawZvE8Qul88', '%widget.files.name', '%widget.files.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml','${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconFiles16.png', 1, 1, 1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'FILES',  1, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconFiles16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('U9PdeKPWtviSGv2QP57ZRady4RHYBPyXCL9a','files','myFilesPb86locI7vRV4yY1KKawZvE8Qul88');

-- Files shared with me widget
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY,  WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET)
VALUES      ('sharedFilesV4fv72LD5NAcGv2nbrex0ExEq', '%widget.sharedfiles.name', '%widget.sharedfiles.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml','${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconFiles16.png', 1, 1, 1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'FILES',  0, 0, '${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconFiles16.png',0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('JlNdbgUL4kAwMEFAEAwlYXQ3YBOWnBry4x6Y','files','sharedFilesV4fv72LD5NAcGv2nbrex0ExEq');

-- Sand widget
INSERT INTO HOMEPAGE.WIDGET 
			(WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT,WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_MARKED_CACHABLE, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET) 
VALUES 		('recommend7x4f6hd93kd9','%widget.sand.recommend.name','%widget.sand.recommend.desc','${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png',1,1,1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg','SAND',1,0,0,'${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png',0);

INSERT INTO HOMEPAGE.PREREQ 
			(PREREQ_ID,APP_ID,WIDGET_ID) 
VALUES 		('9t1a20f1xc4cax6cc4x8b0bx51af2ddef2cd','sand','recommend7x4f6hd93kd9');


--Community Event Widget

INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET, WIDGET_POLICY_FLAGS, PROXY_POLICY, SHARE_ORDER)
VALUES      ('commuevtxe7c4x4e08xab54x80e7a4eb8933', '%widget.communities.event.name', '%widget.communities.event.desc', '${COMMON_CONTEXT_ROOT}/web/lconn.calendar/CalendarGadget.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', 1, 1, 1, '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 'COMMUNITIES', 1,  0, '${COMMON_CONTEXT_ROOT}/web/lconn.calendar/CalendarGadget.xml', '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png',1, 39,'intranet_access', -1);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('73de6654x9317x4195x90c0x696c1b6da4ff', 'communities', 'commuevtxe7c4x4e08xab54x80e7a4eb8933');

--
-- CONN MAIL
--
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MARKED_CACHABLE, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET, WIDGET_POLICY_FLAGS, PROXY_POLICY, SHARE_ORDER)
VALUES      ('405a4f26-fa08-4cef-a995-7d90fbe2634f','%widget.connmail.name','%widget.connmail.desc','{connectionsmail}/gadgets/inbox.xml',NULL,1,1,0,NULL,'CONNECTIONSMAIL',0,0,0,'{connectionsmail}/gadgets/inbox.xml',NULL,1, 43, 'intranet_access', -1);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('0d0a920d-3772-48bf-84e3-069676aea87b', 'connectionsmail', '405a4f26-fa08-4cef-a995-7d90fbe2634f');


--
-- SHARE Microblogging
--
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MARKED_CACHABLE, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET, WIDGET_POLICY_FLAGS, PROXY_POLICY, SHARE_ORDER)
VALUES      ('826e0a39-d231-49bd-a1fa-b1e6e787aaa1','%widget.connshare.microblog.name','%widget.connshare.microblog.desc','${COMMON_CONTEXT_ROOT}/web/lconn.news.microblogging.sharebox/globalMicrobloggingForm.xml',NULL,1,1,0,NULL,'CONNECTIONSSHARE',0,0,0,'${COMMON_CONTEXT_ROOT}/web/lconn.news.microblogging.sharebox/globalMicrobloggingForm.xml',NULL,1,55,'intranet_access', 0);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('0c28301d-40c6-49b9-ab2e-918f58076c0f', 'news', '826e0a39-d231-49bd-a1fa-b1e6e787aaa1');


--
-- SHARE Files
--
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MARKED_CACHABLE, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET, WIDGET_POLICY_FLAGS, PROXY_POLICY, SHARE_ORDER)
VALUES      ('8426c915-6836-4a4b-a3f5-2db0ced9909f','%widget.connshare.files.name','%widget.connshare.files.desc','${COMMON_CONTEXT_ROOT}/web/com.ibm.social.sharebox/UploadFile.xml',NULL,1,1,0,NULL,'CONNECTIONSSHARE',0,0,0,'${COMMON_CONTEXT_ROOT}/web/com.ibm.social.sharebox/UploadFile.xml',NULL,1,39,'intranet_access', 1);

INSERT INTO HOMEPAGE.PREREQ
            (PREREQ_ID, APP_ID, WIDGET_ID)
VALUES      ('37c6cd92-6ef5-43b9-8022-89a051e37e9a','files','8426c915-6836-4a4b-a3f5-2db0ced9909f');


--
-- Connections EE
--
INSERT INTO HOMEPAGE.WIDGET
            (WIDGET_ID, WIDGET_TITLE, WIDGET_TEXT, WIDGET_URL, WIDGET_ICON, WIDGET_ENABLED, WIDGET_SYSTEM, WIDGET_HOMEPAGE_SPECIFIC, WIDGET_PREVIEW_IMAGE, WIDGET_CATEGORY, WIDGET_IS_DEFAULT_OPENED, WIDGET_MARKED_CACHABLE, WIDGET_MULTIPLE_INSTANCES, WIDGET_SECURE_URL, WIDGET_SECURE_ICON, IS_GADGET, WIDGET_POLICY_FLAGS, PROXY_POLICY, SHARE_ORDER)
VALUES      ('aad20aa1-c0fa-48ef-bd05-8abe630c0012','%widget.connee.name','%widget.connee.desc','${COMMON_CONTEXT_ROOT}/web/com.ibm.social.ee/ConnectionsEE.xml',NULL,1,1,0,NULL,'CONNECTIONSEE',0,0,0,'${COMMON_CONTEXT_ROOT}/web/com.ibm.social.ee/ConnectionsEE.xml',NULL,1,7,'intranet_access', -1);



----------------
--- INSERT THE DATA INTO THE WIDGET_TAB TABLE
----------------
-- Dogear Original Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_dogear7x4229x87BBx91ac3551c5', 'dogear46x0a77x4a43x82aaxb00187218631', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Dogear MyBookmarks widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_dembkx7x4229x87BBx91ac3551c5', 'dembk46x0a77x4a43x82aaxb00187218631', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Dogear PopularBookmarks widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_depbkx7x4229x87BBx91ac3551c5', 'depbk46x0a77x4a43x82aaxb00187218631', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Dogear RecentBookmarks widget - opened by default
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_derbkx7x4229x87BBx91ac3551c5', 'derbk46x0a77x4a43x82aaxb00187218631', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Dogear WatchList widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_dewlx7x4229x87BBx91ac3551c5', 'dewl46x0a77x4a43x82aaxb00187218631', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Activities Original Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_activitixa187x491dxa4bfx2e1', 'activitixa187x491dxa4bfx2e1261d0b6ec', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Activities MyActivities widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_myactxa187x491dxa4bfx2e1261', 'myactxa187x491dxa4bfx2e1261d0b6ec', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Activities PublicActivities widget - opened by default
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_pubactxa187x491dxa4bfx2e126', 'pubactxa187x491dxa4bfx2e1261d0b6ec', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Communities Original Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_communitxe7c4x4e08xab54x80e', 'communitxe7c4x4e08xab54x80e7a4eb8933', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Communities MyCommunities widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_mycommunxe7c4x4e08xab54x80e', 'mycommunxe7c4x4e08xab54x80e7a4eb8933', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Communities PublicCommunities widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_pubcommuxe7c4x4e08xab54x80e', 'pubcommuxe7c4x4e08xab54x80e7a4eb8933', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Blogs widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_blogs448xcd34x4565x9469x9c3', 'blogs448xcd34x4565x9469x9c34fcefe48c', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Profiles Original Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_profilesxaac7x4229x87bbx9a1', 'profilesxaac7x4229x87bbx9a1c3551c591', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Profiles MyProfile widget - opened by default
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_myprofisxaac7x4229x87bbx9a1', 'myprofisxaac7x4229x87bbx9a1c3551c591', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Profiles ColleagueProfile widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_colprofsxaac7x4229x87bbx9al', 'colprofsxaac7x4229x87bbx9a1c3551c591', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- My Wiky widget                
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_mywikiz1xaac7x4229x87BBx91a', 'mywikiz1xaac7x4229x87BBx91ac3551c591', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Popular Wiki
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_pop-wiki1xaac7x4229x87BBx91', 'pop-wiki1xaac7x4229x87BBx91ac3551c5', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Latest wiki
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_latest-wiki5jz1xaac7x4229x8', 'latest-wiki5jz1xaac7x4229x87BBx91ac', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Files Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_HXMb14Y53n2XAuLeHgrZI3f1CEGhN', 'myFilesPb86locI7vRV4yY1KKawZvE8Qul88', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Files sharded with me widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('WIDGET_FfQvWEJHX1TBvSCW0PS8ayfbPlZ1k', 'sharedFilesV4fv72LD5NAcGv2nbrex0ExEq', '_panel.widgetx4a43x82aaxb00187218631', 'primary');

-- Sidebar activities widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('UPDATES_activities-sidebar', 'activities-sidebar7x4229x8', '_panel.updatex4a43x82aaxb00187218631', 'primary');

-- Sidebar recommend widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
		(WIDGET_TAB_ID,WIDGET_ID,TAB_ID,TYPE) 
VALUES 	('UPDATES_recommend-sidebar','recommend7x4f6hd93kd9','_panel.updatex4a43x82aaxb00187218631','primary');

--Community Event Widget
INSERT INTO HOMEPAGE.HP_WIDGET_TAB
        (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES  ('UPDATES_communityevent-sidebar', 'commuevtxe7c4x4e08xab54x80e7a4eb8933', '_panel.updatex4a43x82aaxb00187218631', 'primary');


-- CONN MAIL

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('d8361d6b-0021-41de-b562-55ca27a3e954','405a4f26-fa08-4cef-a995-7d90fbe2634f','_noui.gadgetpanx11e1b0c40800200c9a66','primary');

-- SHARE Microblogging

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('825edb79-8b86-45c3-afbb-4891355755b2','826e0a39-d231-49bd-a1fa-b1e6e787aaa1','_noui.gadgetpanx11e1b0c40800200c9a66','primary');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('5394716f-273c-4a0e-9845-5069275ab029','826e0a39-d231-49bd-a1fa-b1e6e787aaa1','_noui.share_diax11e1b0c40800200c9a66','primary');

-- SHARE Files

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('ecd31763-d711-4a57-9e14-eb6b3d71daee','8426c915-6836-4a4b-a3f5-2db0ced9909f', '_noui.gadgetpanx11e1b0c40800200c9a66','primary');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('c1f5196b-4f94-49ec-bc38-f7d8dacc0bb4','8426c915-6836-4a4b-a3f5-2db0ced9909f','_noui.share_diax11e1b0c40800200c9a66','primary');

-- Connections EE

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('985f431a-3c00-4301-a93b-d375181d9814', 'aad20aa1-c0fa-48ef-bd05-8abe630c0012', '_noui.gadgetpanx11e1b0c40800200c9a66','primary');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('8cd18252-ec33-4f8f-97df-b62f3bb49e28','aad20aa1-c0fa-48ef-bd05-8abe630c0012','_noui.embeddedxx11e1b0c40800200c9a66','primary');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('61532c5f-664f-40c0-bd09-abf337b43312','commuevtxe7c4x4e08xab54x80e7a4eb8933','_noui.gadgetpanx11e1b0c40800200c9a66','primary');


----------------
--- END THE DATA INTO THE WIDGET_TAB TABLE
----------------

---------------------------------------------------------
-- Insert a "fake" user in PERSON table to be used in public stories
---------------------------------------------------------
INSERT INTO HOMEPAGE.PERSON
		(PERSON_ID,DISPLAYNAME,EXID,STATE,MEMBER_TYPE)
VALUES  ('00000000-0000-0000-0000-000000000001','%anyone','00000000-0000-0000-0000-000000000001',0,2);


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- NEWS

------------ 
--- START INSERT TEMPLATES
------------

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actor-Bei35oPldKwZTaR7aAiPFw4L08CyRW','actor', 'actorInternalId', 'profilePhoto', 1); 

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actorProfile-CAsyXgPhQd7N3wSMw7C0IUe','actorProfiles', 'actorInternalId', 'profilePhoto', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('target-Ah3vEOPQZDEpgpwcQ2JNaHFfMnMcG','subject', 'targetSubjectsInternalIds', 'profilePhoto', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEnt-anXIr0xP82OSZnuoYbAZa2M5AsRFr', 'activityEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k','activityEntryWithComment', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-WHHEhu6HTkRWtCQPylcUdSENF4mU', 'activityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-Mg2xRFBLmRqg3Zj7Etrdttiyc6OH','activityContainerNameACL', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actToDo-psOHtvbY4lOJv8jOXJH5YgLoGYP7','toDoEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blog-Itf9INx14G6bbCWRYNRpLhSawJXF8Qs','blogContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogNew-qsgRrfp88AKWys4wcm4gIuZm3T2p','newBlogContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogEntry-ubpjmKeG6Vi8XpQXYKVx3mtCqm','blogEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogComment-92JYbZEOrk0CBLEJHYwkrqPA','blogEntryWithComment', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-Qf0I5rSEaImjaCcds3HYi4SeCGYCDCN','newCommunityContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-new-IduwKhHDNCLdmJFi0G7lwrE86IJ','communityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-topic6V808ijHf9TRgUSUqVVZoSOGg5','topicEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-book-VSWMFF7uZVaE11XRe4Q1ElJIc6','communityBookmarkEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-feed-Ja6XFBT7kyfEJv07Unitc0MsJT','feedEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('dogear-book-DXAWZl1FIGMuMr4Ea4Lejbum','dogearBookmarkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('tags-a7YmLTHTY2FdHKPsHU0wbAZCkgYrkk1','tag', 'contentTags', 'plain', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profileEntry-Vrh9M5YNmxNogF2oERZWyRE','profileLinkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profile-status-HNX0o3AF32cFuPWhtYMjl','profileStatusEntry', 'status', 'plain', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQ0gZl5','wikiContainerName','containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-page-P75oD6oAdgoWCRNt4YYh7hZfuM','wikiEntryPage', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-comment-Ye2xdX8pbYM996pc7je30LI','wikiEntryPageCommented', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('file-bbqZpR6oxvE2sYAXxasKS0EtS1mDg4h','fileEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('collection-7jEWoKkWx8ucNTo6Z7AndhRFh','collectionContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQdfgt5','newWikiContainer','containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('membership-9qgdh66pf82um3c6q1lQdfgt5','newMembers', 'memberAddedInternalIds', 'profilePhoto', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE 
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES ('blogCorrName-2G3abCWRYNRpLhSawJXF6Qd', 'blogCorrelationName', 'correlationName;correlationHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('general-containerffasfh3452yst42465','container','containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('general-item-slkmg9015bxBNKbkHkdf65','item','itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('general-correllation-asdfbe898Bjr95','correlationitem','correlationName;correlationHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('Actor-3913FB2B6B5D4323BFD4DAAC189B8','Actor', 'actorInternalId', 'profilePhoto', 1); 

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('Object-CEDEBA0964F2442EB3E5155493C0','Object', 'asObjectType;asObjectInternalId;asObjectName;asObjectHtmlPath', 'activityObject', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('Target-5EF5EDF61F9F47F692ED1CDFDF86','Target', 'asTargetType;asTargetInternalId;asTargetName;asTargetHtmlPath', 'activityObject', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('repostIcon-oPldKwZTaR7aAiPFw4L08CyRW','repostIcon', 'asRepostIcon', 'repostIcon', 1); 

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('itemAuthor-wPldKwZTaR7aAiPFw4L08CyRW','Author', 'asItemAuthor','profilePhoto', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('itemauthor-wPldKwZTaR7aAiPFw4L08CyRW','author', 'asItemAuthor','profilePhoto',  1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('itemCorrAuthorkla9034jl89vasgf3k5Wfd','correlationItemAuthor', 'correlationItemAuthor','profilePhoto',  1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profileContainervmladkL9DFYU5ADFla9a','profileContainer', 'profileContainer', 'profilePhoto', 1); 

------------
--- END INSERT TEMPLATES
------------

-- INSERTING CATEGORY_TYPE
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%profiles', 'profiles');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('communities_0f1xc9cax4cc4x8b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('activities_0ff1xc9cax4cc4x8b0bx51af2', 4, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('blogs_0ffdsfds1xc9cax4cc4x8b0bx51af2', 5, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('bookmarks_0fdf1xc9cax4cc4x8b0bx51af2', 6, '%bookmarks', 'bookmarks');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('files_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 7, '%files', 'files');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('forums_0fdsfdf1xc9cax4cc4x8b0bx51af2', 8, '%forums', 'forums');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('wikis_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 9, '%wikis', 'wikis');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('tags_0f1xc9cax4cc4x8b0bx51af2ddef2cd', 10, '%tags', 'tags');

-- Adding four new categories for ui rendering of actianable stories (we don't need to add source here as they already exist)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('status_update_x8b0bx51af2ddef2cd', 11, '%status_updates', 'status_updates');

-- Adding a new category (used from UI rendering) and source (used a source of stories from component)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('ext_9cax4cc4x8b0bx51af2ddef2cd', 12, '%external', 'external');

-- Adding four new categories for ui rendering of actianable stories
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('saved_readers', 13, '%saved_readers', 'saved_readers');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_directed_notification_bx', 14, '%actionable_directed_notification', 'actionable_directed_notification');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_todo_______cax4cc4x8b0bx', 15, '%actionable_todo', 'actionable_todo');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_action_required__4x8b0bx', 16, '%actionable_action_required', 'actionable_action_required');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('discovery-view', 17, '%discovery', 'discovery');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles-view', 18, '%profiles-view', 'profiles-view');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('notification-sent', 19, '%notification-sent', 'notification-sent');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('notification-received', 20, '%notification-received', 'notification-received');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('topics', 21, '%topics', 'topics');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('mentions', 22, '%mentions', 'mentions');

------------
--- START INSERT NR_RESOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('activity_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%activity', 'activity');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('blog________0f1xc9cax4cc4x8b0bx51af2', 3, '%blog', 'blog');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('community____f1xc9cax4cc4x8b0bx51af2', 4, '%community', 'community');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_change_ds1xc9cax4cc4x8b0bx51af2', 5, '%file_change', 'file_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_comment_df1xc9cax4cc4x8b0bx5af2', 6, '%file_comment', 'file_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_collection_fdfca4cc4x8b0bx51af2', 7, '%file_collection', 'file_collection');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_topic_fdfdxc9cax4cc4xb0bx51af2', 8, '%forum_topic', 'forum_topic');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_0fdsfdsf1xc9cax4cc4xb0bxd51af2', 9, '%forum', 'forum');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('person_0f1xc9cax4cc4xb0bx51af2def2cd', 10, '%person', 'person');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_change_fdfdc9cax8b0bx51af2', 11, '%wiki_page_change', 'wiki_page_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_comment_0cax4c4x8b0bx51af2', 12, '%wiki_page_comment', 'wiki_page_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('tag_0f1xc9cax4cc4x8cdb0bx51f2ddef2cd', 13, '%tag', 'tag');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('bookmarks_0f1xc9cax4cc4x8cdb0bx51f2d', 14, '%bookmarks', 'bookmarks');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('topics____0f1xc9cax4cc4x8cdb0bx51f2d', 15, '%topics', 'topics');

------------
--- END INSERT NR_RESOURCE_TYPE
------------

-----------------------------------
-- START EMD_FREQUENCY_TYPE
-----------------------------------	
INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('never_____0fdf1xc9cax4cc4x8b0bx51af2', 1, '%never', 'never');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('immediete_9cax4cc4x8b0bx51af2ddef2cd', 2, '%immediete', 'immediete');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('daily_______0f1xc9cax4cc4x8b0bx51af2', 3, '%daily', 'daily');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('weekly_______f1xc9cax4cc4x8b0bx51af2', 4, '%weekly', 'weekly');  	
-----------------------------------
-- END EMD_FREQUENCY_TYPE
-----------------------------------

-------------------------------------------------------------------------
-- START: INIT EMD_TRANCHE
-------------------------------------------------------------------------
-- EMD_TRANCHE 1
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_1_KwZTaR7aAiPFw4L08CyRW', 'tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 2
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_2_KwZTaR7aAiPFw4L08CyRW','tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 3
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_3_KwZTaR7aAiPFw4L08CyRW','tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 4
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 4, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_4_KwZTaR7aAiPFw4L08CyRW','tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 5
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_5_KwZTaR7aAiPFw4L08CyRW','tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 6
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 6, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_6_KwZTaR7aAiPFw4L08CyRW','tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 7
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_7_KwZTaR7aAiPFw4L08CyRW','tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 8
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_8_KwZTaR7aAiPFw4L08CyRW','tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 9
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 9, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_9_KwZTaR7aAiPFw4L08CyRW','tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 10
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_10_wZTaR7aAiPFw4L08CyRW','tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 11
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_11_wZTaR7aAiPFw4L08CyRW','tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 12
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 12, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_12_wZTaR7aAiPFw4L08CyRW','tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 13
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 13, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_13_wZTaR7aAiPFw4L08CyRW','tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 14
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 14, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_14_wZTaR7aAiPFw4L08CyRW','tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 15
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_15_wZTaR7aAiPFw4L08CyRW','tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 16
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 16, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_16_wZTaR7aAiPFw4L08CyRW','tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 17
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 17, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_17_wZTaR7aAiPFw4L08CyRW','tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 18
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 18, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_18_wZTaR7aAiPFw4L08CyRW','tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 19
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 19, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_19_wZTaR7aAiPFw4L08CyRW','tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 20
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED, IS_LOCKED_DAILY, IS_LOCKED_WEEKLY)
VALUES          ('tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0,0,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_20_wZTaR7aAiPFw4L08CyRW','tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);
-------------------------------------------------------------------------
-- END: INIT EMD_TRANCHE
-------------------------------------------------------------------------

------------
--- START INSERT NR_SOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'activities', 'activities', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'blogs', 'blogs', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBlogs16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBlogs16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'communities', 'communities', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconCommunities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'wikis', 'wikis', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconWikis16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconWikis16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'profiles', 'profiles', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconProfiles16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'homepage', 'homepage', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconHome16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconHome16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'dogear', 'dogear', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'files', 'files', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconFiles16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconFiles16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'forums', 'forums', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconForums16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconForums16.png');

------------
--- END INSERT NR_SOURCE_TYPE
------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('6f6ee109-6ad4-4926-afcb-d2a04a0e390d','15min-search-indexing-task','0 10/15 0,2-23 * * ?','0 1/15 0,2-23 * * ?','IndexingTask',1);

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('ea789e87-c262-484b-92f4-d60af4bef3d3','nightly-optimize-task','0 35 1 * * ?','0 30 1 * * ?' ,'OptimizeTask',1);

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('111111-1111-1111-1111-1111111FCRT','20min-file-retrieval-task','0 10/20 0,2-23 * * ?','0 1/20 0,2-23 * * ?','FileContentRetrievalTask',1);

INSERT INTO HOMEPAGE.SR_INDEXINGTASKDEF(INDEXING_TASK_ID,TASK_ID,INDEXING_TASK_SERVICES,INDEXING_TASK_OPTIMIZE)
VALUES('315a416c-78e2-4cf4-bcb2-69eb8d3a2583','6f6ee109-6ad4-4926-afcb-d2a04a0e390d','all_configured',0);

INSERT INTO HOMEPAGE.SR_OPTIMIZETASKDEF(OPTIMIZE_TASK_ID,TASK_ID)
VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fa','ea789e87-c262-484b-92f4-d60af4bef3d3');

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('ea789e87-c262-484b-92f4-d60af4bef3d4','nightly-sand-task','0 5 1 * * ?','0 0 1 * * ?','SaNDTask',1);

INSERT INTO HOMEPAGE.SR_SANDTASKDEF(SAND_TASK_ID,TASK_ID,SAND_TASK_SERVICES)
VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fb','ea789e87-c262-484b-92f4-d60af4bef3d4','evidence-graph-manageremployees-tags-taggedby-communitymembership');

INSERT INTO HOMEPAGE.SR_FILECONTENTTASKDEF(FILECONTENT_TASK_ID,TASK_ID,FILE_CONTENT_TASK_SERVICES,CONTENT_FAILURES_ONLY)
VALUES('111111-1111-1111-1111-1111111FCRT','111111-1111-1111-1111-1111111FCRT','all_configured',0);

-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------


--------------------------------------
-- DISCONNECT
--------------------------------------

COMMIT;
