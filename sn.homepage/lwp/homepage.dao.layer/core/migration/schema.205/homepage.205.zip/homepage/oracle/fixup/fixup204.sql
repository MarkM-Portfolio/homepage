-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 204
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 204 FOR HP
------------------------------------------------

--
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------
------------------------ START HP FIXUP 204 --------
----------------------------------------------------
-- 80778: Schema changes to enable per-gadget-per-server rules

ALTER TABLE HOMEPAGE.WIDGET 
	ADD SERVER_ACCESS 			CLOB 	LOB (SERVER_ACCESS) STORE AS (TABLESPACE NEWSLOBTABSPACE STORAGE (INITIAL 1M) CHUNK 4000 NOCACHE NOLOGGING)
	ADD ADDITIONAL_FEATURES 	CLOB 	LOB (ADDITIONAL_FEATURES) STORE AS (TABLESPACE NEWSLOBTABSPACE STORAGE (INITIAL 1K) CHUNK 100 NOCACHE NOLOGGING);


COMMIT;


----------------------------------------------------
------------------------ START END FIXUP 204 -------
----------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 204 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 204 -----------------------------------
---------------------------------------------------------------------------------

----------------------------------------------------
-- 22 HOMEPAGE.NR_MENTIONS_READERS
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_MENTIONS_READERS (
	CATEGORY_READER_ID VARCHAR2(36)  DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR2(39) NOT NULL,
	CATEGORY_TYPE NUMBER(5 ,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(256),
	ROLLUP_ENTRY_ID VARCHAR2(256),
	RESOURCE_TYPE NUMBER(5 ,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5 ,0),
	USE_IN_ROLLUP NUMBER(5 ,0),
	IS_NETWORK	NUMBER(5 ,0),
	IS_FOLLOWER	NUMBER(5 ,0),
	EVENT_TIME 	TIMESTAMP,
	IS_STORY_COMM NUMBER(5 ,0),
	IS_BROADCAST NUMBER(5,0),
	ORGANIZATION_ID VARCHAR2(256),
	ACTOR_UUID VARCHAR2(256),
	ROLLUP_AUTHOR_ID VARCHAR2 (256),
	IS_VISIBLE NUMBER(5 ,0) DEFAULT 1 NOT NULL,
	MAX_UPDATE_FOR_READER TIMESTAMP,
		CONSTRAINT   	CK_CAT22_TYPE
    			CHECK
    			(CATEGORY_TYPE = 22)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS
    ADD (CONSTRAINT PK_MEN_READERS PRIMARY KEY(CATEGORY_READER_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS 
	ADD CONSTRAINT FK_MEN_READERS_STR FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);
	
--  [start indexes] NR_MENTIONS_READERS
CREATE  INDEX HOMEPAGE.MENTIONS_READERS_STR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ITEM_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_CD_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID, CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RDR_STR 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, STORY_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RIR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, ROLLUP_ENTRY_ID DESC, CREATION_DATE DESC) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;


--  [end indexes] NR_MENTIONS_READERS	

ALTER TABLE "HOMEPAGE"."NR_MENTIONS_READERS" ENABLE ROW MOVEMENT;

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('mentions', 22, '%mentions', 'mentions');

--------------------------------------------------------
-- DROPPING UNUSED OLD TABLES
--------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SUBSCRIPTION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_DISCOVERY;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_SAVED;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_RECORDS;
COMMIT;

------------------ 81333: Rename ENTRY_ID to ITEM_ID in BOARD_RECOMMENDATIONS --------
DROP INDEX HOMEPAGE.BRD_REC_STORY_ID;
COMMIT;  
    
DROP INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID;
COMMIT;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	RENAME COLUMN ENTRY_ID TO ITEM_ID;
COMMIT;	

CREATE INDEX HOMEPAGE.BRD_REC_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;    
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_REC_RECOM_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;    
	
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 204 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 204 FOR SEARCH
------------------------------------------------

--{include.search-fixup204.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 204
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 204 , RELEASEVER = '4.5.0.0'
WHERE   DBSCHEMAVER = 203;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 204
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
