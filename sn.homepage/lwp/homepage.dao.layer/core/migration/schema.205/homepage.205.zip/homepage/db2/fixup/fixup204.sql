-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 204
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 204 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------
------------------------ START HP FIXUP 204 --------
----------------------------------------------------
-- 80778: Schema changes to enable per-gadget-per-server rules

ALTER TABLE HOMEPAGE.WIDGET
	ADD SERVER_ACCESS CLOB
	ADD ADDITIONAL_FEATURES CLOB;
COMMIT;

REORG TABLE HOMEPAGE.WIDGET ALLOW NO ACCESS;
COMMIT;


----------------------------------------------------
------------------------ START END FIXUP 204 -------
----------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 204 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 204  -----------------------------------
---------------------------------------------------------------------------------

----------------------------------------------------
-- HOMEPAGE.NR_MENTIONS_READERS
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_MENTIONS_READERS (
	CATEGORY_READER_ID VARCHAR(36) DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR(39) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(256),
	ROLLUP_ENTRY_ID VARCHAR(256),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	SOURCE_TYPE SMALLINT,
	USE_IN_ROLLUP SMALLINT,
	IS_NETWORK	SMALLINT,
	IS_FOLLOWER	SMALLINT,
	EVENT_TIME 	TIMESTAMP,
	IS_STORY_COMM SMALLINT,
	IS_BROADCAST SMALLINT,
	ORGANIZATION_ID VARCHAR(256),
	ACTOR_UUID VARCHAR(256),
	IS_VISIBLE SMALLINT DEFAULT 1 NOT NULL,
	ROLLUP_AUTHOR_ID VARCHAR (256),
	MAX_UPDATE_FOR_READER TIMESTAMP,
	CONSTRAINT   	CK_CAT22_TYPE
    			CHECK
    			(CATEGORY_TYPE = 22)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS
    ADD CONSTRAINT PK_MEN_READERS PRIMARY KEY(CATEGORY_READER_ID);

ALTER TABLE HOMEPAGE.NR_MENTIONS_READERS 
	ADD CONSTRAINT FK_MEN_READERS_STR FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID); 
	
--  [start indexes] NR_MENTIONS_READERS
CREATE  INDEX HOMEPAGE.MENTIONS_READERS_STR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ITEM_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_CD_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (STORY_ID, CREATION_DATE DESC); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE, IS_VISIBLE); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RDR_STR 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, STORY_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (CREATION_DATE DESC); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RIR_IX 
 	ON HOMEPAGE.NR_MENTIONS_READERS (READER_ID, IS_VISIBLE, ROLLUP_ENTRY_ID DESC, CREATION_DATE DESC); 
COMMIT;

CREATE  INDEX HOMEPAGE.MENTIONS_READERS_RLL_BRD_VIS 
 	ON HOMEPAGE.NR_MENTIONS_READERS (ROLLUP_AUTHOR_ID, IS_BROADCAST, USE_IN_ROLLUP, IS_VISIBLE); 
COMMIT;


--  [end indexes] NR_MENTIONS_READERS	

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('mentions', 22, '%mentions', 'mentions');

COMMIT;

--------------------------------------------------------
-- DROPPING UNUSED OLD TABLES
--------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SUBSCRIPTION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_DISCOVERY;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_SAVED;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT;
COMMIT;

DROP TABLE HOMEPAGE.NR_ATTACHMENT_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION_301;
COMMIT;

DROP TABLE HOMEPAGE.NR_RECOMMENDATION;
COMMIT;

DROP TABLE HOMEPAGE.NR_NEWS_RECORDS;
COMMIT;

------------------ 81333: Rename ENTRY_ID to ITEM_ID in BOARD_RECOMMENDATIONS --------
DROP INDEX HOMEPAGE.BRD_REC_STORY_ID;
COMMIT;  
    
DROP INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID;
COMMIT;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	RENAME COLUMN ENTRY_ID TO ITEM_ID;
COMMIT;	

CREATE INDEX HOMEPAGE.BRD_REC_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ITEM_ID);
COMMIT;    
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_REC_RECOM_ITEM_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ITEM_ID);
COMMIT;    
	
REORG TABLE HOMEPAGE.BOARD_RECOMMENDATIONS ALLOW NO ACCESS;
COMMIT;
RUNSTATS ON TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  AND INDEXES ALL;
COMMIT;

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 204 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 204 FOR SEARCH
------------------------------------------------

--{include.search-fixup204.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 204
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 204, RELEASEVER = '4.5.0.0' 
WHERE   DBSCHEMAVER = 203; 

------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 204
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
