-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

-- to create a new baseline
connect to HOMEPAGE;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- HOME PAGE
--set integrity for HOMEPAGE.HOMEPAGE_SCHEMA immediate checked;
set integrity for HOMEPAGE.PERSON immediate checked;
set integrity for HOMEPAGE.LOGINNAME immediate checked;
set integrity for HOMEPAGE.PREREQ immediate checked;
set integrity for HOMEPAGE.WIDGET  immediate checked;
set integrity for HOMEPAGE.MT_METRIC_STAT immediate checked;


set integrity for HOMEPAGE.HP_UI  immediate checked;
set integrity for HOMEPAGE.HP_TAB  immediate checked;
set integrity for HOMEPAGE.HP_TAB_INST  immediate checked;
set integrity for HOMEPAGE.HP_WIDGET_INST  immediate checked;
set integrity for HOMEPAGE.HP_WIDGET_TAB  immediate checked;

set integrity for HOMEPAGE.NT_NOTIFICATION immediate checked;
set integrity for HOMEPAGE.NT_NOTIFICATION_RECIPIENT immediate checked;

set integrity for HOMEPAGE.NT_REPLYTO immediate checked;
set integrity for HOMEPAGE.NT_REPLYTO_RECIPIENT immediate checked;
set integrity for HOMEPAGE.OH2P_CACHE immediate checked;
set integrity for HOMEPAGE.OH2P_CLIENTCFG immediate checked; 
set integrity for HOMEPAGE.MTCONFIG immediate checked;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE GRANTS FOR NEWS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- NEWS REPOSITORY
set integrity for HOMEPAGE.NR_SOURCE immediate checked;
set integrity for HOMEPAGE.NR_TEMPLATE immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_SCHEDULER_LMGR immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_LMPR immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_TASK immediate checked;
set integrity for HOMEPAGE.NR_SCHEDULER_TREG immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_CATEGORY_TYPE immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_NEWS_STATUS_NETWORK immediate checked;
set integrity for HOMEPAGE.NR_NEWS_STATUS_COMMENT immediate checked;
set integrity for HOMEPAGE.NR_NEWS_STATUS_CONTENT immediate checked;
set integrity for HOMEPAGE.NR_NEWS_COMMENT_CONTENT immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_RESOURCE_TYPE  immediate checked;	
set integrity for HOMEPAGE.NR_RESOURCE  immediate checked;  
set integrity for HOMEPAGE.NR_FOLLOWS  immediate checked;	
set integrity for HOMEPAGE.NR_COMM_FOLLOW  immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_STORIES_CONTENT  immediate checked;
set integrity for HOMEPAGE.NR_NETWORK  immediate checked;
set integrity for HOMEPAGE.NR_COMM_PERSON_FOLLOW immediate checked;
set integrity for HOMEPAGE.NR_AGGREGATED_READERS immediate checked;
COMMIT;

set integrity for HOMEPAGE.EMD_FREQUENCY_TYPE immediate checked;
set integrity for HOMEPAGE.EMD_RESOURCE_PREF immediate checked;
set integrity for HOMEPAGE.EMD_TRANCHE immediate checked;
set integrity for HOMEPAGE.EMD_TRANCHE_INFO immediate checked;
set integrity for HOMEPAGE.EMD_EMAIL_PREFS immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_RESPONSES_READERS immediate checked;
set integrity for HOMEPAGE.NR_PROFILES_READERS immediate checked;
set integrity for HOMEPAGE.NR_COMMUNITIES_READERS immediate checked;
set integrity for HOMEPAGE.NR_ACTIVITIES_READERS immediate checked;
set integrity for HOMEPAGE.NR_BLOGS_READERS immediate checked;
set integrity for HOMEPAGE.NR_BOOKMARKS_READERS immediate checked;
set integrity for HOMEPAGE.NR_FILES_READERS immediate checked;
set integrity for HOMEPAGE.NR_FORUMS_READERS immediate checked;
set integrity for HOMEPAGE.NR_WIKIS_READERS immediate checked;
set integrity for HOMEPAGE.NR_TAGS_READERS immediate checked;
set integrity for HOMEPAGE.NR_STATUS_UPDATE_READERS immediate checked;
set integrity for HOMEPAGE.NR_EXTERNAL_READERS immediate checked;
COMMIT;


set integrity for HOMEPAGE.NR_SOURCE_TYPE immediate checked;
COMMIT;

-- BOARD USE CASE
set integrity for HOMEPAGE.BOARD_ENTRIES immediate checked;
set integrity for HOMEPAGE.BOARD_COMMENTS immediate checked;   
set integrity for HOMEPAGE.BOARD_OBJECT_REFERENCE immediate checked;   
set integrity for HOMEPAGE.BOARD_RECOMMENDATIONS immediate checked;
set integrity for HOMEPAGE.BOARD_CURRENT_STATUS immediate checked;

set integrity for HOMEPAGE.DELETED_STORIES_QUEUE immediate checked;  
COMMIT;

set integrity for HOMEPAGE.NR_COMM_SETTINGS immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_SAVED_READERS immediate checked;
set integrity for HOMEPAGE.NR_ACTIONABLE_READERS immediate checked;
set integrity for HOMEPAGE.NR_DISCOVERY_VIEW immediate checked;
set integrity for HOMEPAGE.NR_PROFILES_VIEW immediate checked;
set integrity for HOMEPAGE.NR_NOTIFICATION_SENT_READERS immediate checked;
set integrity for HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS immediate checked;
set integrity for HOMEPAGE.NR_TOPICS_READERS immediate checked;
COMMIT;

set integrity for HOMEPAGE.BOARD immediate checked;

set integrity for HOMEPAGE.NR_ENTRIES immediate checked;
set integrity for HOMEPAGE.NR_ENTRIES_ARCHIVE immediate checked;
set integrity for HOMEPAGE.NR_STORIES immediate checked;
COMMIT;

set integrity for HOMEPAGE.OAUTH1_TOKEN immediate checked; 
set integrity for HOMEPAGE.OAUTH1_PROVIDER immediate checked; 
set integrity for HOMEPAGE.OAUTH1_CLIENT immediate checked; 
set integrity for HOMEPAGE.OAUTH1_CONTEXT immediate checked; 
set integrity for HOMEPAGE.OAUTH2_PROVIDER immediate checked; 
set integrity for HOMEPAGE.OAUTH2_CLIENT immediate checked; 
set integrity for HOMEPAGE.OAUTH2_GADGET_BINDING immediate checked; 
set integrity for HOMEPAGE.OAUTH2_TOKEN immediate checked;
COMMIT;

set integrity for HOMEPAGE.NR_AS_SEEDLIST immediate checked;
set integrity for HOMEPAGE.NR_AS_COLLECTION_CONFIG immediate checked;
set integrity for HOMEPAGE.NR_AS_CRAWLER_STATUS  immediate checked;
set integrity for HOMEPAGE.NR_AS_CONTENT_INDEX_STATS immediate checked;
COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- SEARCH
set integrity for HOMEPAGE.SR_TASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_OPTIMIZETASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_INDEXINGTASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_FILESCONTENT immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_MIGTASKDEFINFO immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_FILECONTENTTASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_INDEX_DOCS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_RESUME_TOKENS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_BACKUPTASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_INDEX_MANAGEMENT immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_SANDTASKDEF immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_FEEDBACK immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_FEEDBACK_CONTEXT immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_FEEDBACK_PARAMETERS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_STATS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_STRING_STATS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_NUMBER_STATS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_TIMER_STATS immediate checked;
COMMIT;

set integrity for HOMEPAGE.SR_GLOBAL_SAND_PROPS immediate checked;
COMMIT;

set integrity for HOMEPAGE.LOTUSCONNECTIONSLMGR immediate checked;
COMMIT;

set integrity for HOMEPAGE.LOTUSCONNECTIONSLMPR immediate checked;
COMMIT;

set integrity for HOMEPAGE.LOTUSCONNECTIONSTASK immediate checked;
COMMIT;

set integrity for HOMEPAGE.LOTUSCONNECTIONSTREG immediate checked;
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------------------------

COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;