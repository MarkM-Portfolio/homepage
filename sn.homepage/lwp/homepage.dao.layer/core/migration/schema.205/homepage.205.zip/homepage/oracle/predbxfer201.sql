-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

-- CONSTRAINTS KEYS

ALTER TABLE "HOMEPAGE"."PREREQ" DROP CONSTRAINT "FK_PREREQ_WIDGET";

ALTER TABLE "HOMEPAGE"."USER_WIDGET_PREF" DROP CONSTRAINT "FK_WIDGET_ID";

ALTER TABLE "HOMEPAGE"."USER_WIDGET_PREF" DROP CONSTRAINT "FK_USER_ID";

ALTER TABLE "HOMEPAGE"."LOGINNAME" DROP CONSTRAINT "FK_PERSON_ID";

DROP INDEX "HOMEPAGE"."USERID_WIDGET_UNIQUE";

COMMIT;

QUIT;