-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 44 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 ----------------------------------------------------------------------
-- HOMEPAGE.MT_METRICS 
----------------------------------------------------------------------

CREATE TABLE HOMEPAGE.MT_METRIC_STAT  (
      METRIC_STAT_ID VARCHAR2(36) NOT NULL,
      RECORDED_ON TIMESTAMP NOT NULL,
      METRIC_TYPE NUMBER(5,0) NOT NULL,
      METRIC_DESC VARCHAR2(36) NOT NULL,
      RES_BUNDLE_KEY VARCHAR2(144) NOT NULL,
      COUNT_LAST_24_H NUMBER(19 ,0),
      COUNT_LAST_7_D NUMBER(19 ,0),
      COUNT_LAST_1_M NUMBER(19 ,0),
      TOP_STATS VARCHAR2(512),
      TOT_STAT NUMBER(19 ,0),
      AVG_TOT_STAT NUMBER(19 ,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.MT_METRIC_STAT 
    ADD (CONSTRAINT PK_METRIC_STAT_ID PRIMARY KEY(METRIC_STAT_ID) USING INDEX TABLESPACE "HPNTINDEXTABSPACE");

CREATE INDEX HOMEPAGE.MT_METRICS_IDX
    ON HOMEPAGE.MT_METRIC_STAT (RECORDED_ON ASC, METRIC_TYPE) TABLESPACE "HPNTINDEXTABSPACE";
    
ALTER TABLE HOMEPAGE.MT_METRIC_STAT ENABLE ROW MOVEMENT;     
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.MT_METRIC_STAT TO HOMEPAGEUSER_ROLE;


-------------------------------------------------
-- FIXING NT_NOTIFICATION TABLE
-------------------------------------------------

-- 1 NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID
DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID IS NULL;
COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
	MODIFY RECIPIENT_ID NOT NULL;

COMMIT;

-- 2 NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID
DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID IS NULL;
COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	MODIFY FIRST_RECIPIENT_ID NOT NULL;
	
-- 3 NT_NOTIFICATION WHERE SENDER_ID
DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE SENDER_ID IS NULL;
COMMIT;
	
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	MODIFY SENDER_ID NOT NULL;

COMMIT;	

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 44 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- SPR #XJFN85ZEAN
-- Brief Description:*   [dbupgrade & dbcompare] Homepage: error in the db compare log on Oracle
DROP INDEX "HOMEPAGE"."NR_SCHEDULER_TASK_IDX1 ";

CREATE INDEX HOMEPAGE.NR_SCHEDULER_TASK_IDX1
	ON HOMEPAGE."NR_SCHEDULER_TASK" ("TASKID", "OWNERTOKEN") TABLESPACE "NEWSINDEXTABSPACE";
	
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------	


-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                              
--                                                                                                                       
--                                                                   
-- Copyright IBM Corp. 2007, 2008  All Rights Reserved.              
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or       
-- disclosure restricted by GSA ADP Schedule Contract with           
-- IBM Corp.                                                         
--                                                                   
-- ***************************************************************** 

-- 5724-S68

--------------------------------------------------------------
-- FIXING DB INCONSISTENCES
--------------------------------------------------------------

-- 1) NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    MODIFY R_META_TEMPLATE NULL;
    
-- 2) EMD_EMAIL_PREFS
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    MODIFY EMAIL_ADDRESS NULL;

-- 3) NR_STORIES_CONTENT
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    MODIFY CONTENT NULL;

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    ADD STORY_ID VARCHAR2(36);
    
-- 4) NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    ADD IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET IS_COMMUNITY_STORY = 0;

------------------------------------------------------------------
-- FIXING TEMPLATE ISSUES
------------------------------------------------------------------
UPDATE HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING = 'itemName;itemHtmlPath' 
WHERE TEMPLATE_ID = 'actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k';

INSERT INTO HOMEPAGE.NR_TEMPLATE values ('blogCorrName-2G3abCWRYNRpLhSawJXF6Qd', 'blogCorrelationName', 'link', 'correlationName;correlationHtmlPath', 1);

-----------------------------------------------------------------
-- ADDING TABLES TO SUPPORT THE NEWS FFED
-----------------------------------------------------------------

------------------------------
-- NR_COMM_PERSON_FOLLOW
------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID VARCHAR2(36) NOT NULL,
	PERSON_ID VARCHAR2(36) NOT NULL,
	PERSON_COMMUNITY_ID VARCHAR2(36) NOT NULL
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD (CONSTRAINT "PK_COMM_PER_ID" PRIMARY KEY("COMM_PERSON_FOLLOW_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT "FK_COMM_PER_PER_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

CREATE INDEX HOMEPAGE.NR_COMM_PER_FOLLOW_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_ID)  TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_COMM_FOLLOW_COM_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_COMMUNITY_ID)  TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW ENABLE ROW MOVEMENT;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_FOLLOW TO HOMEPAGEUSER_ROLE;


----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_PERSON_STORIES 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR2(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD (CONSTRAINT "PK_COMPER_STORY_ID" PRIMARY KEY("COMM_PER_STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT "FK_FCP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_READER
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC, COMM_PER_READER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (STORY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES ENABLE ROW MOVEMENT;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_STORIES TO HOMEPAGEUSER_ROLE;
      
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 44 FOR SEARCH
------------------------------------------------

--{include.search-fixup44.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 44
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 44 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 43;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
