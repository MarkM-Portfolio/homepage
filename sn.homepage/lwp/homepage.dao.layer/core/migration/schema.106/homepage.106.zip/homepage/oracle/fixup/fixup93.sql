-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 93
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 93 FOR HP
------------------------------------------------

--{include.hp-fixup93.sql}

------------------------------------------------
-- INCLUDE FIX UP 93 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------
-- [START] RECREATING NR_CATEGORIES_READERS VIEW
---------------------------------------------------------
DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;

COMMIT;

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_PROFILES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_BLOGS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_FILES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_FORUMS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_WIKIS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_TAGS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS  		ENABLE ROW MOVEMENT;

COMMIT;
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);

COMMIT;

---------------------------------------------------------
-- [END] RECREATING NR_CATEGORIES_READERS VIEW
---------------------------------------------------------

-----------------------------------------------------
-- 1) ADDING INDEXES 
-----------------------------------------------------
CREATE INDEX HOMEPAGE.BRD_SL_UPDATED_DEL 
	ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC, SL_IS_DELETED) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

CREATE INDEX HOMEPAGE.BRD_CURRENT_STATUS 
	ON HOMEPAGE.BOARD_CURRENT_STATUS (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;	

CREATE INDEX HOMEPAGE.BRD_RECOMMENDER_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

----------------------------------------------------
-- 2) ADDING A MISSING FK TO BOARD_RECOMMENDATIONS: FK_BRD_RECOMMENDER AND 
----------------------------------------------------
ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	ADD CONSTRAINT FK_BRD_RECOMMENDER FOREIGN KEY (RECOMMENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

COMMIT;		    

----------------------------------------------------------
-- 3) Adding an ORGANISATION_ID
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE ADD ORGANIZATION_ID VARCHAR2(36);    

UPDATE HOMEPAGE.NR_SOURCE_TYPE SET ORGANIZATION_ID = 'default';

COMMIT;

----------------------------------------------------------
-- 4) Change the CATEGORY_TYPE INFO FOR PROFILE VIEW
----------------------------------------------------------
UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%profiles-view', CATEGORY_TYPE_DESC = 'profiles-view' WHERE CATEGORY_TYPE = 18;

----------------------------------------------------------
-- 5) CREATING AN INDEX FOR ALL THE READERS TABLE INCLUDING ALSO THE SOURCE_TYPE
-- THIS INDEX IS USED FOR THIRD FILTER LEVEL
----------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_AGG_READERS 
	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.PROFILES_STORIES_SRC_IDX
	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.COMMUNITIES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.ACTIVITIES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.BLOGS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.BOOKMARKS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.FILES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_FILES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.FORUMS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.WIKIS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.TAGS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.SU_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

-- they already have indexed the SOURCE_TYPE those tables
--NR_RESPONSES_READERS
--NR_EXTERNAL_READERS
--NR_ACTIONABLE_READERS

COMMIT;

-------------------------------------------------------------------------------------------
-- 6) Adding IS_LAST_COMMENT_PUBLIC and IS_PREV_COMMENT_PUBLIC to  NR_ENTRIES_XXX tables
-------------------------------------------------------------------------------------------

--1) NR_ENTRIES_ACT 
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);

COMMIT;

----reorg table HOMEPAGE.NR_ENTRIES_ACT;

COMMIT;

--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_BLG;

COMMIT;

--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_COM;

COMMIT;

--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_WIK;

COMMIT;

--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_PRF;

COMMIT;

--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_HP;

COMMIT;

--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_DGR;

COMMIT;

--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_FILE;

COMMIT;

--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_FRM;

COMMIT;

--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD ( 
	IS_LAST_COMMENT_PUBLIC NUMBER(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMBER(5,0)
);
	
COMMIT;

--reorg table HOMEPAGE.NR_ENTRIES_EXTERNAL;

COMMIT;





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 93 FOR SEARCH
------------------------------------------------

--{include.search-fixup92.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 93
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 93 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 92;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 93
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
