-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 100 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START HP FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.OH2P_CACHE (
	LOOKUPKEY nvarchar(256) NOT NULL, 
	UNIQUEID nvarchar(128) NOT NULL, 
	COMPONENTID nvarchar(256) NOT NULL, 
	TYPE nvarchar(64) NOT NULL, 
	SUBTYPE nvarchar(64), 
	CREATEDAT NUMERIC(19,0), 
	LIFETIME NUMERIC(10,0), 
	EXPIRES NUMERIC(19,0), 
	TOKENSTRING nvarchar(2048) NOT NULL, 
	CLIENTID nvarchar(64) NOT NULL, 
	USERNAME nvarchar(64) NOT NULL, 
	SCOPE nvarchar(512) NOT NULL, 
	REDIRECTURI nvarchar(2048), 
	STATEID nvarchar(64) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH2P_CACHE 
	ADD CONSTRAINT PK_LOOKUPKEY PRIMARY KEY (LOOKUPKEY);

CREATE INDEX OH2P_CACHE_EXPIRES ON HOMEPAGE.OH2P_CACHE (EXPIRES ASC);

GO


CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID nvarchar(256) NOT NULL, 
	CLIENTID nvarchar(256) NOT NULL, 
	CLIENTSECRET nvarchar(256), 
	DISPLAYNAME nvarchar(256) NOT NULL, 
	REDIRECTURI nvarchar(2048), 
	ENABLED NUMERIC(5,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID);

GO



ALTER TABLE HOMEPAGE.HP_UI ADD WELCOME_NOTE NUMERIC(5,0) DEFAULT 1;

GO


-- Update Dogear widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml'
WHERE WIDGET_ID='dogear46x0a77x4a43x82aaxb00187218631';

-- Update My Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml'
WHERE WIDGET_ID='dembk46x0a77x4a43x82aaxb00187218631';

-- Update Popular Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml'
WHERE WIDGET_ID='depbk46x0a77x4a43x82aaxb00187218631';

-- Update Recent Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml'
WHERE WIDGET_ID='derbk46x0a77x4a43x82aaxb00187218631';

-- Update Watchlist widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml'
WHERE WIDGET_ID='dewl46x0a77x4a43x82aaxb00187218631';

-- Update Activities Original widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml'
WHERE WIDGET_ID='activitixa187x491dxa4bfx2e1261d0b6ec';

-- Update MyActivities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml'
WHERE WIDGET_ID='myactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Public Activities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml'
WHERE WIDGET_ID='pubactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Sidebar Activities ToDo Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml'
WHERE WIDGET_ID='activities-sidebar7x4229x8';

-- Update Communities Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml'
WHERE WIDGET_ID='communitxe7c4x4e08xab54x80e7a4eb8933';

-- Update MyCommunities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml'
WHERE WIDGET_ID='mycommunxe7c4x4e08xab54x80e7a4eb8933';

-- Update Public Communities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml'
WHERE WIDGET_ID='pubcommuxe7c4x4e08xab54x80e7a4eb8933';

-- Update Blogs widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml'
WHERE WIDGET_ID='blogs448xcd34x4565x9469x9c34fcefe48c';

-- Update Profiles Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml'
WHERE WIDGET_ID='profilesxaac7x4229x87bbx9a1c3551c591';

-- Update MyProfile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml'
WHERE WIDGET_ID='myprofisxaac7x4229x87bbx9a1c3551c591';

-- Update Colleague Profile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml'
WHERE WIDGET_ID='colprofsxaac7x4229x87bbx9a1c3551c591';

-- Update MyWiki widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml'
WHERE WIDGET_ID='mywikiz1xaac7x4229x87BBx91ac3551c591';

-- Update Popular Wiki Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml'
WHERE WIDGET_ID='pop-wiki1xaac7x4229x87BBx91ac3551c5';

-- Update Latest Wiki Widget 
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml'
WHERE WIDGET_ID='latest-wiki5jz1xaac7x4229x87BBx91ac';

-- Update MyFiles widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml'
WHERE WIDGET_ID='myFilesPb86locI7vRV4yY1KKawZvE8Qul88';

-- Update Files shared with me Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml'
WHERE WIDGET_ID='sharedFilesV4fv72LD5NAcGv2nbrex0ExEq';

-- Update Sand widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml'
WHERE WIDGET_ID='recommend7x4f6hd93kd9';

GO


---------------------------------------------------------------------------------
------------------------ END HP FIXUP 100 ---------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 100 -----------------------------------
---------------------------------------------------------------------------------



------------------------------------------------------------------------------
-- INSERT DATA INTO NR_TEMPLATE TABLE
------------------------------------------------------------------------------

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('repostIcon-oPldKwZTaR7aAiPFw4L08CyRW','repostIcon', 'asRepostIcon', 'repostIcon', 1); 

GO



------------------------------------------------------------------------------
-- ADD INDEXES TO NR_STORIES TABLE
------------------------------------------------------------------------------

CREATE INDEX STORIES_CONTAINER_URL_IDX ON 
	HOMEPAGE.NR_STORIES (CONTAINER_URL ASC);

CREATE INDEX STORIES_EVENT_ITEM_ACTOR_IDX ON
	HOMEPAGE.NR_STORIES (EVENT_NAME, ITEM_ID, ACTOR_UUID);
GO

------------------------------------------------------------------------------------------------
-- [START] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------

--------------------------------------------------------------
-- Make the existing index on ITEM_CORRELATION_ID to a clustered index
--------------------------------------------------------------
DROP INDEX NR_NEWS_SC_ITEM_COR ON HOMEPAGE.NR_NEWS_STATUS_COMMENT;

GO


ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	DROP CONSTRAINT FK_C_COMMENT_ID;
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT 
	DROP CONSTRAINT PK_NEWS_COMMENT_ID;

GO

CREATE CLUSTERED INDEX CL_STATUS_COMMENT_IDX ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_CORRELATION_ID);
 
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT
  	ADD CONSTRAINT PK_NEWS_COMMENT_ID PRIMARY KEY(NEWS_STATUS_COMMENT_ID);
GO

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT FK_C_COMMENT_ID FOREIGN KEY (NEWS_STATUS_COMMENT_ID)
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT(NEWS_STATUS_COMMENT_ID);

GO

-----------------------------------------------------------------------------
-- DROP AND RECREATE THE INDEXES USING UPDATE_DATE INSTEAD OF CREATION_DATE
-----------------------------------------------------------------------------
DROP INDEX NR_NEWS_SN_READER_FOLL ON HOMEPAGE.NR_NEWS_STATUS_NETWORK;
GO

CREATE INDEX NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_FOLLOW_NEWS);
GO

DROP INDEX NR_NEWS_SN_READER_NETW ON HOMEPAGE.NR_NEWS_STATUS_NETWORK;
GO

CREATE INDEX NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_NETWORK_NEWS);
GO

DROP INDEX NR_NEWS_STATUS_NETWORK_READER ON HOMEPAGE.NR_NEWS_STATUS_NETWORK;
GO

CREATE INDEX NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID);
GO

DROP INDEX NR_STATUS_NETWORK_DATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK;
GO

CREATE INDEX NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE ASC);
GO

------------------------------------------------------------------------------------------------
-- [END] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------
-- ADD WIDGET_ID to the BOARD table
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.BOARD ADD WIDGET_ID nvarchar(36);

GO


------------------------------------------------------------------------------
-- ADD MODERATION FLAGS TO THE ENTRIES TABLE
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_ENTRIES ADD 
	IS_LAST_COMMENT_VISIBLE NUMERIC(5,0) DEFAULT 1,
	IS_PREV_COMMENT_VISIBLE NUMERIC(5,0) DEFAULT 1;
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_ARCHIVE ADD 
	IS_LAST_COMMENT_VISIBLE NUMERIC(5) DEFAULT 1,
	IS_PREV_COMMENT_VISIBLE NUMERIC(5,0) DEFAULT 1;
GO


------------------------------------------------------------------------------
-- MOVE COLUMNS BETWEEN NR_STORY AND NR_STORIES_CONTENT TABLES
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT ADD 
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED NUMERIC(5,0),
	ITEM_BRIEF_DESC nvarchar(4000),
	ITEM_CORRELATION_BRIEF_DESC nvarchar(4000);

GO


ALTER TABLE HOMEPAGE.NR_STORIES DROP COLUMN 
	ACTIVITY_META_DATA_1,
	ACTIVITY_META_DATA_2,
	IS_META_DATA_TRUNCATED;
GO

ALTER TABLE HOMEPAGE.NR_STORIES ADD RELATED_COMMUNITY_ID nvarchar(36);

GO



------------------------------------------------------------------------------
-- ADD INDEX ON ROLLUP_ENTRY_ID TO ALL READER TABLES
------------------------------------------------------------------------------

CREATE  INDEX AGGREGATED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX RESPONSES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX PROFILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX COMM_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX ACTIVITIES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX BLOGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX BOOKMARKS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX FILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FILES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX FORUMS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX WIKIS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX TAGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX STATUS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX EXTERNAL_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX ACTIONABLE_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX DISCOVERY_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX PROFILES_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX NOTIFICA_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX NOT_REC_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX SAVED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

CREATE  INDEX TOPICS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
GO

------------------------------------------------------------------------------
-- ADD AS_CONTENT_INDEX_STATS TABLE
------------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS (
	STAT_ID nvarchar(36) NOT NULL,
	STAT_NAME nvarchar(2048),
	STAT_VALUE varbinary(MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS
  	ADD CONSTRAINT NR_CONTENTSTATS_PK PRIMARY KEY(STAT_ID);

GO

------------------------------------------------------------------------------
-- DB schema consistency with event model [START]
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT ADD 
	ITEM_TAGS nvarchar(1024),
	ITEM_CORRELATION_TAGS nvarchar(1024);
GO

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [start]

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID < '0..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '0..f' AND STORIES.STORY_ID < '1..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '1..f' AND STORIES.STORY_ID < '2..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '2..f' AND STORIES.STORY_ID < '3..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '3..f' AND STORIES.STORY_ID < '4..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '4..f' AND STORIES.STORY_ID < '5..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '5..f' AND STORIES.STORY_ID < '6..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '6..f' AND STORIES.STORY_ID < '7..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '7..f' AND STORIES.STORY_ID < '8..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '8..f' AND STORIES.STORY_ID < '9..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= '9..f' AND STORIES.STORY_ID < 'a..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'a..f' AND STORIES.STORY_ID < 'b..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'b..f' AND STORIES.STORY_ID < 'c..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'c..f' AND STORIES.STORY_ID < 'd..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'd..f' AND STORIES.STORY_ID < 'e..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'e..f' AND STORIES.STORY_ID < 'f..f';

GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT
SET NR_STORIES_CONTENT.ITEM_TAGS = STORIES.ITEM_TAGS
FROM HOMEPAGE.NR_STORIES STORIES INNER JOIN HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT ON STORIES.STORY_ID = STORIES_CONTENT.STORY_ID
AND STORIES.STORY_ID >= 'f..f';

GO

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [end]


ALTER TABLE HOMEPAGE.NR_STORIES DROP COLUMN
	ITEM_TAGS,
	ITEM_AUTHOR_DISPLAYNAME;
GO

ALTER TABLE HOMEPAGE.NR_STORIES ADD 
	ITEM_CORRELATION_SCOPE NUMERIC(5,0),
	ITEM_CORRELATION_UPDATE_DATE DATETIME,
	ITEM_CORRELATION_URL nvarchar(2048);
GO

------------------------------------------------------------------------------
-- DB schema consistency with event model [END]
------------------------------------------------------------------------------

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


CREATE INDEX SR_FEEDBACK_PERSON_ID_IDX 
	ON HOMEPAGE.SR_FEEDBACK(PERSON_ID)
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT DROP COLUMN CONTENT
GO

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT
GO

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT 
ADD OUT_OF_SYNC NUMERIC(5,0) DEFAULT 0 NOT NULL
GO

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 100
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 100 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 99;
------------------------------------------------------------------------------------------------

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

COMMIT
