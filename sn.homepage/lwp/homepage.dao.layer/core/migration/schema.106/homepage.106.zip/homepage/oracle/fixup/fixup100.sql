-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 100 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START HP FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------


CREATE TABLE HOMEPAGE.OH2P_CACHE (
	LOOKUPKEY VARCHAR2(256) NOT NULL, 
	UNIQUEID VARCHAR2(128) NOT NULL, 
	COMPONENTID VARCHAR2(256) NOT NULL, 
	TYPE VARCHAR2(64) NOT NULL, 
	SUBTYPE VARCHAR2(64), 
	CREATEDAT NUMBER(19), 
	LIFETIME NUMBER(10), 
	EXPIRES NUMBER(19), 
	TOKENSTRING VARCHAR2(2048) NOT NULL, 
	CLIENTID VARCHAR2(64) NOT NULL, 
	USERNAME VARCHAR2(64) NOT NULL, 
	SCOPE VARCHAR2(512) NOT NULL, 
	REDIRECTURI VARCHAR2(2048), 
	STATEID VARCHAR2(64) NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CACHE 
	ADD CONSTRAINT PK_LOOKUPKEY PRIMARY KEY (LOOKUPKEY) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE";

CREATE INDEX OH2P_CACHE_EXPIRES ON HOMEPAGE.OH2P_CACHE (EXPIRES ASC) TABLESPACE "HOMEPAGEINDEXTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CACHE ENABLE ROW MOVEMENT;

COMMIT;


CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID VARCHAR2(256) NOT NULL, 
	CLIENTID VARCHAR2(256) NOT NULL, 
	CLIENTSECRET VARCHAR2(256), 
	DISPLAYNAME VARCHAR2(256) NOT NULL, 
	REDIRECTURI VARCHAR2(2048), 
	ENABLED NUMBER(5)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG ENABLE ROW MOVEMENT;

COMMIT;



ALTER TABLE HOMEPAGE.HP_UI ADD WELCOME_NOTE NUMBER(5) DEFAULT 1;

ALTER TABLE HOMEPAGE.HP_UI ENABLE ROW MOVEMENT;

COMMIT;


-- Update Dogear widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml'
WHERE WIDGET_ID='dogear46x0a77x4a43x82aaxb00187218631';

-- Update My Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml'
WHERE WIDGET_ID='dembk46x0a77x4a43x82aaxb00187218631';

-- Update Popular Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml'
WHERE WIDGET_ID='depbk46x0a77x4a43x82aaxb00187218631';

-- Update Recent Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml'
WHERE WIDGET_ID='derbk46x0a77x4a43x82aaxb00187218631';

-- Update Watchlist widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml'
WHERE WIDGET_ID='dewl46x0a77x4a43x82aaxb00187218631';

-- Update Activities Original widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml'
WHERE WIDGET_ID='activitixa187x491dxa4bfx2e1261d0b6ec';

-- Update MyActivities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml'
WHERE WIDGET_ID='myactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Public Activities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml'
WHERE WIDGET_ID='pubactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Sidebar Activities ToDo Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml'
WHERE WIDGET_ID='activities-sidebar7x4229x8';

-- Update Communities Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml'
WHERE WIDGET_ID='communitxe7c4x4e08xab54x80e7a4eb8933';

-- Update MyCommunities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml'
WHERE WIDGET_ID='mycommunxe7c4x4e08xab54x80e7a4eb8933';

-- Update Public Communities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml'
WHERE WIDGET_ID='pubcommuxe7c4x4e08xab54x80e7a4eb8933';

-- Update Blogs widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml'
WHERE WIDGET_ID='blogs448xcd34x4565x9469x9c34fcefe48c';

-- Update Profiles Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml'
WHERE WIDGET_ID='profilesxaac7x4229x87bbx9a1c3551c591';

-- Update MyProfile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml'
WHERE WIDGET_ID='myprofisxaac7x4229x87bbx9a1c3551c591';

-- Update Colleague Profile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml'
WHERE WIDGET_ID='colprofsxaac7x4229x87bbx9a1c3551c591';

-- Update MyWiki widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml'
WHERE WIDGET_ID='mywikiz1xaac7x4229x87BBx91ac3551c591';

-- Update Popular Wiki Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml'
WHERE WIDGET_ID='pop-wiki1xaac7x4229x87BBx91ac3551c5';

-- Update Latest Wiki Widget 
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml'
WHERE WIDGET_ID='latest-wiki5jz1xaac7x4229x87BBx91ac';

-- Update MyFiles widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml'
WHERE WIDGET_ID='myFilesPb86locI7vRV4yY1KKawZvE8Qul88';

-- Update Files shared with me Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml'
WHERE WIDGET_ID='sharedFilesV4fv72LD5NAcGv2nbrex0ExEq';

-- Update Sand widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml'
WHERE WIDGET_ID='recommend7x4f6hd93kd9';

COMMIT;

---------------------------------------------------------------------------------
------------------------ END HP FIXUP 100 ---------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 100 -----------------------------------
---------------------------------------------------------------------------------


------------------------------------------------------------------------------
-- INSERT DATA INTO NR_TEMPLATE TABLE
------------------------------------------------------------------------------

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('repostIcon-oPldKwZTaR7aAiPFw4L08CyRW','repostIcon', 'asRepostIcon', 'repostIcon', 1); 

COMMIT;



------------------------------------------------------------------------------
-- ADD INDEXES TO NR_STORIES TABLE
------------------------------------------------------------------------------

CREATE INDEX HOMEPAGE.STORIES_CONTAINER_URL_IDX ON 
	HOMEPAGE.NR_STORIES (CONTAINER_URL ASC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.STORIES_EVENT_ITEM_ACTOR_IDX ON
	HOMEPAGE.NR_STORIES (EVENT_NAME, ITEM_ID, ACTOR_UUID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

------------------------------------------------------------------------------------------------
-- [START] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------

--------------------------------------------------------------
-- Make the existing index on ITEM_CORRELATION_ID to a clustered index
--------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_NEWS_SC_ITEM_COR;
COMMIT;

CREATE CLUSTER 
	HOMEPAGE.CL_STATUS_COMMENT_IDX (ITEM_CORRELATION_ID VARCHAR2(36)) INDEX TABLESPACE "NEWSINDEXTABSPACE";
 
COMMIT;


-----------------------------------------------------------------------------
-- DROP AND RECREATE THE INDEXES USING UPDATE_DATE INSTEAD OF CREATION_DATE
-----------------------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_NEWS_SN_READER_FOLL;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_FOLLOW_NEWS) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

DROP INDEX HOMEPAGE.NR_NEWS_SN_READER_NETW;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_NETWORK_NEWS) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

DROP INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

DROP INDEX HOMEPAGE.NR_STATUS_NETWORK_DATE;
COMMIT;

CREATE INDEX HOMEPAGE.NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE ASC) TABLESPACE "NEWSINDEXTABSPACE";
COMMIT;

------------------------------------------------------------------------------------------------
-- [END] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------
-- ADD WIDGET_ID to the BOARD table
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.BOARD ADD WIDGET_ID VARCHAR2(36);

ALTER TABLE HOMEPAGE.BOARD ENABLE ROW MOVEMENT;

COMMIT;


------------------------------------------------------------------------------
-- ADD MODERATION FLAGS TO THE ENTRIES TABLE
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_ENTRIES ADD ( 
	IS_LAST_COMMENT_VISIBLE NUMBER(5) DEFAULT 1,
	IS_PREV_COMMENT_VISIBLE NUMBER(5) DEFAULT 1
);

ALTER TABLE HOMEPAGE.NR_ENTRIES ENABLE ROW MOVEMENT;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_ARCHIVE ADD ( 
	IS_LAST_COMMENT_VISIBLE NUMBER(5) DEFAULT 1,
	IS_PREV_COMMENT_VISIBLE NUMBER(5) DEFAULT 1
);

ALTER TABLE HOMEPAGE.NR_ENTRIES_ARCHIVE ENABLE ROW MOVEMENT;

COMMIT;


------------------------------------------------------------------------------
-- MOVE COLUMNS BETWEEN NR_STORY AND NR_STORIES_CONTENT TABLES
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT ADD (
	ACTIVITY_META_DATA_1 RAW(2000),
	ACTIVITY_META_DATA_2 RAW(2000),
	IS_META_DATA_TRUNCATED NUMBER(5,0),
	ITEM_BRIEF_DESC VARCHAR2(4000),
	ITEM_CORRELATION_BRIEF_DESC VARCHAR2(4000)
);

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT ENABLE ROW MOVEMENT;

COMMIT;


ALTER TABLE HOMEPAGE.NR_STORIES DROP (
	ACTIVITY_META_DATA_1,
	ACTIVITY_META_DATA_2,
	IS_META_DATA_TRUNCATED
);

ALTER TABLE HOMEPAGE.NR_STORIES ADD RELATED_COMMUNITY_ID VARCHAR2(36);

ALTER TABLE HOMEPAGE.NR_STORIES ENABLE ROW MOVEMENT;

COMMIT;



------------------------------------------------------------------------------
-- ADD INDEX ON ROLLUP_ENTRY_ID TO ALL READER TABLES
------------------------------------------------------------------------------

CREATE  INDEX HOMEPAGE.AGGREGATED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.RESPONSES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.COMM_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.ACTIVITIES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.BLOGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.BOOKMARKS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.FILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FILES_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.FORUMS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.WIKIS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.TAGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.STATUS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.EXTERNAL_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.ACTIONABLE_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.NOTIFICA_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.NOT_REC_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.SAVED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.TOPICS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS (ROLLUP_ENTRY_ID, READER_ID) TABLESPACE NEWSINDEXTABSPACE; 
COMMIT;

------------------------------------------------------------------------------
-- ADD AS_CONTENT_INDEX_STATS TABLE
------------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS (
	STAT_ID VARCHAR2(36) NOT NULL,
	STAT_NAME VARCHAR2(2048),
	STAT_VALUE BLOB
)
LOB (STAT_VALUE) STORE AS (TABLESPACE NEWSLOBTABSPACE STORAGE (INITIAL 1M) CHUNK 4000 NOCACHE NOLOGGING) 
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS
  	ADD (CONSTRAINT NR_CONTENTSTATS_PK PRIMARY KEY(STAT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE") ;

ALTER TABLE "HOMEPAGE"."NR_AS_CONTENT_INDEX_STATS" ENABLE ROW MOVEMENT;

COMMIT;

------------------------------------------------------------------------------
-- DB schema consistency with event model [START]
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT ADD (
	ITEM_TAGS VARCHAR2(1024),
	ITEM_CORRELATION_TAGS VARCHAR2(1024)
);

COMMIT;

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [start]

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID < '0..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '0..f' AND STORY_ID < '1..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '1..f' AND STORY_ID < '2..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '2..f' AND STORY_ID < '3..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '3..f' AND STORY_ID < '4..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '4..f' AND STORY_ID < '5..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '5..f' AND STORY_ID < '6..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '6..f' AND STORY_ID < '7..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '7..f' AND STORY_ID < '8..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '8..f' AND STORY_ID < '9..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '9..f' AND STORY_ID < 'a..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'a..f' AND STORY_ID < 'b..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'b..f' AND STORY_ID < 'c..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'c..f' AND STORY_ID < 'd..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'd..f' AND STORY_ID < 'e..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'e..f' AND STORY_ID < 'f..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'f..f';

COMMIT;

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [end]


ALTER TABLE HOMEPAGE.NR_STORIES DROP (
	ITEM_TAGS,
	ITEM_AUTHOR_DISPLAYNAME
);


ALTER TABLE HOMEPAGE.NR_STORIES ADD (
	ITEM_CORRELATION_SCOPE NUMBER(5),
	ITEM_CORRELATION_UPDATE_DATE TIMESTAMP,
	ITEM_CORRELATION_URL VARCHAR2(2048)
);

COMMIT;

------------------------------------------------------------------------------
-- DB schema consistency with event model [END]
------------------------------------------------------------------------------

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------

		
CREATE INDEX "HOMEPAGE"."SR_FEEDBACK_PERSON_IDX" 
		ON  HOMEPAGE.SR_FEEDBACK(PERSON_ID) TABLESPACE "HOMEPAGEINDEXTABSPACE";
COMMIT;		

ALTER TABLE HOMEPAGE.SR_FILESCONTENT DROP COLUMN CONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
ADD OUT_OF_SYNC NUMBER(5, 0) DEFAULT 0 NOT NULL
MODIFY OUT_OF_DATE DEFAULT 0;

COMMIT;

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 100
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 100 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 99;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
