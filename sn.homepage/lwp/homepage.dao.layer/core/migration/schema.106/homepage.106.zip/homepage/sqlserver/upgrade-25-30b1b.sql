-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE
GO

BEGIN TRANSACTION
GO

------------------------------------------------
-- INCLUDE UPGRADE30 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 23;
-- GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START HOMEPAGE ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- PERSON
------------------------------------------------


ALTER TABLE HOMEPAGE.PERSON
	ADD IS_ACTIVE NUMERIC(5,0) DEFAULT 1;
GO

ALTER TABLE HOMEPAGE.PERSON
	ADD USER_MAIL_LOWER nvarchar(256);
GO

UPDATE HOMEPAGE.PERSON SET USER_MAIL_LOWER =  lower(USER_MAIL);
GO

ALTER TABLE HOMEPAGE.PERSON
	ADD DISPLAYNAME_LOWER nvarchar(256);	
GO

UPDATE HOMEPAGE.PERSON SET DISPLAYNAME_LOWER =  lower(DISPLAYNAME);
GO

-- in 2.5 it didn't exist
--DROP VIEW HOMEPAGE.SNCORE_PERSON;
--GO

CREATE INDEX PERSON_USER_MAIL_LWR
    ON HOMEPAGE.PERSON(USER_MAIL_LOWER ASC);
GO

CREATE INDEX PERSON_DISPLAYNAME_LWR
    ON HOMEPAGE.PERSON(DISPLAYNAME_LOWER ASC);
GO

------------------------------------------------
-- SNCORE_PERSON
------------------------------------------------

CREATE VIEW HOMEPAGE.SNCORE_PERSON (SNC_INTERNAL_ID, SNC_IDKEY, SNC_EMAIL_LOWER, SNC_DISPLAY_NAME) 
    AS SELECT PERSON_ID, EXID, USER_MAIL_LOWER, DISPLAYNAME FROM HOMEPAGE.PERSON;		
GO

------------------------------------------------
-- HP_TAB
------------------------------------------------

ALTER TABLE HOMEPAGE.HP_TAB
	ADD ENABLED NUMERIC(5,0) DEFAULT 1;
GO


---------------------------------------------------------------------------------
---------------- END UPDATE HOMEPAGE DATABASE ----------------    
--------------------------------------------------------------


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 30;
-- GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Update HOMEPAGE.PERSON  
ALTER TABLE HOMEPAGE.PERSON
ADD STATE NUMERIC(5,0) DEFAULT 0 NOT NULL;

-- b) update the NT_NOTIFICATION table
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD FIRST_RECIPIENT_EXID nvarchar(36);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD NUM_RECIPIENTS NUMERIC(5,0);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD IS_DELETED NUMERIC(5,0);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD PRIMARY_ACTION_URL nvarchar(2048);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD SECONDARY_ACTION_URL nvarchar(2048);

--c) update NT_RECIPIENTS table
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
ADD IS_DELETED NUMERIC(5,0);

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------
-- 9 MIGRATION FOR NT_NOTIFICATION TABLES
-----------------------------------------------------

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT SET IS_DELETED = 0;
GO

-- create temp view
CREATE VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT AS (
    select      NT_NOTIFICATION.NOTIFICATION_ID, COUNT(NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID) AS RECIPIENT_COUNT
    from        HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, 
                HOMEPAGE.NT_NOTIFICATION_RECIPIENT NT_NOTIFICATION_RECIPIENT
    where       NT_NOTIFICATION.NOTIFICATION_ID = NT_NOTIFICATION_RECIPIENT.NOTIFICATION_ID
    group by    NT_NOTIFICATION.NOTIFICATION_ID
)
GO


CREATE VIEW HOMEPAGE.TEMP_FIND_RECIPIENT AS (
    select NOTIFICATION_ID, MAX(RECIPIENT_EXID) RECIPIENT_EXID
    from HOMEPAGE.NT_NOTIFICATION_RECIPIENT  NT_NOTIFICATION_RECIPIENT
    GROUP BY NOTIFICATION_ID
)
GO


-- create TEMP_NOTIFICATION table
CREATE TABLE HOMEPAGE.TEMP_NOTIFICATION (
	  NOTIFICATION_ID nvarchar(36) NOT NULL,
	  NOTIFICATION_SOURCE nvarchar(36) NOT NULL,
	  NOTIFICATION_TYPE nvarchar(256) NOT NULL,
	  DATETIME_STAMP DATETIME NOT NULL,
	  SENDER_EXID nvarchar(36) NOT NULL,
	  SUBJECT nvarchar(256),
	  MESSAGE nvarchar(2048),
	  CONTAINER_NAME nvarchar(256),
	  CONTAINER_URL nvarchar(2048),
	  ITEM_NAME nvarchar(256),
	  ITEM_URL nvarchar(2048),
	  FIRST_RECIPIENT_EXID nvarchar(36),
	  NUM_RECIPIENTS NUMERIC(5,0),
	  IS_DELETED NUMERIC(5,0),
	  PRIMARY_ACTION_URL nvarchar(2048),
	  SECONDARY_ACTION_URL nvarchar(2048)	  
) ON [PRIMARY]
GO

-- copying temp the results to TEMP_NOTIFICATION
INSERT INTO HOMEPAGE.TEMP_NOTIFICATION (    NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )    
SELECT  NT_NOTIFICATION.NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        TEMP_FIND_RECIPIENT.RECIPIENT_EXID , TEMP_COUNT_RECIPIENT.RECIPIENT_COUNT, 0, '',''
FROM    HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, HOMEPAGE.TEMP_COUNT_RECIPIENT TEMP_COUNT_RECIPIENT, HOMEPAGE.TEMP_FIND_RECIPIENT TEMP_FIND_RECIPIENT
WHERE   NT_NOTIFICATION.NOTIFICATION_ID = TEMP_COUNT_RECIPIENT.NOTIFICATION_ID AND
        NT_NOTIFICATION.NOTIFICATION_ID = TEMP_FIND_RECIPIENT.NOTIFICATION_ID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT DROP CONSTRAINT FK_RECIP_NOTIF;

DELETE FROM HOMEPAGE.NT_NOTIFICATION;

INSERT INTO HOMEPAGE.NT_NOTIFICATION (    	NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )
SELECT  NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
FROM    HOMEPAGE.TEMP_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
	ADD CONSTRAINT FK_RECIP_NOTIF FOREIGN KEY (NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_NOTIFICATION (NOTIFICATION_ID)
	ON DELETE CASCADE;

-- drop temps stuff
DROP TABLE HOMEPAGE.TEMP_NOTIFICATION;

DROP VIEW HOMEPAGE.TEMP_FIND_RECIPIENT;

DROP VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING the new widget - UPDATE activities to do list (review) 
----------------------------------------------------------------------
UPDATE 	HOMEPAGE.WIDGET 
SET 	WIDGET_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml', WIDGET_SECURE_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml'
WHERE 	WIDGET_ID='activities-sidebar7x4229x8';

INSERT INTO HOMEPAGE.WIDGET (WIDGET_ID,WIDGET_TITLE,WIDGET_TEXT,WIDGET_URL,WIDGET_ICON,WIDGET_ENABLED,WIDGET_SYSTEM,WIDGET_HOMEPAGE_SPECIFIC,WIDGET_PREVIEW_IMAGE,WIDGET_CATEGORY,WIDGET_IS_DEFAULT_OPENED,WIDGET_MULTIPLE_INSTANCES,WIDGET_MARKED_CACHABLE,WIDGET_SECURE_URL,WIDGET_SECURE_ICON) VALUES ('recommend7x4f6hd93kd9','%widget.sand.recommend.name','%widget.sand.recommend.desc','web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png',1,0,1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg','SAND',1,0,0,'web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB (WIDGET_TAB_ID,WIDGET_ID,TAB_ID,TYPE) VALUES ('UPDATES_recommend-sidebar','recommend7x4f6hd93kd9','_panel.updatex4a43x82aaxb00187218631','primary');

INSERT INTO HOMEPAGE.PREREQ 
			(PREREQ_ID,APP_ID,WIDGET_ID) 
VALUES 		('9t1a20f1xc4cax6cc4x8b0bx51af2ddef2cd','sand','recommend7x4f6hd93kd9');

----------------------------------------------------------------------
-- 2) ADDING TO THE PERSON TABLE A LAST_UPDATE ATTRIBUTE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.PERSON
	ADD LAST_UPDATE DATETIME;

----------------------------------------------------------------------
-- 3) REFACTORING OF THE NOTIFICATIONS tables 
--		DB script update to store internal IDs for users in notification tables
----------------------------------------------------------------------
------------------------------------  NT_NOTIFICATION -------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD SENDER_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD FIRST_RECIPIENT_ID nvarchar(36);
GO

-- add index (ADDED) - it is new index (we need to remove it after) FIX
CREATE INDEX NT_NOTIFICATION_FP_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(FIRST_RECIPIENT_EXID);
	
-- sender_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET SENDER_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID);

-- first_recipient_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET FIRST_RECIPIENT_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID);

-- drop (REMOVE) the temp index FIX
DROP INDEX NT_NOTIFICATION_FP_INDEX ON HOMEPAGE.NT_NOTIFICATION;

-- sender
DROP INDEX NT_NOTIFICATION_EXID_INDEX ON HOMEPAGE.NT_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN SENDER_EXID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT FK_SENDER_ID FOREIGN KEY (SENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);
	
-- recipient
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN FIRST_RECIPIENT_EXID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT FK_F_RECIPIENT_ID FOREIGN KEY (FIRST_RECIPIENT_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

-- add index
CREATE INDEX NT_NOTIFICATION_EXID_INDEX
	ON HOMEPAGE.NT_NOTIFICATION (SENDER_ID);

------------------ NT_NOTIFICATION_RECIPIENT --------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
ADD RECIPIENT_ID nvarchar(36);
GO

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT    	
SET RECIPIENT_ID = (    SELECT  HOMEPAGE.PERSON.PERSON_ID
                        FROM    HOMEPAGE.PERSON
                        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID);
        
DROP INDEX NT_NOTIF_RECT_EXID_INDEX ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT;        

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
DROP COLUMN RECIPIENT_EXID;

-- add fk
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
    ADD CONSTRAINT FK_RECIPIENT_ID FOREIGN KEY (RECIPIENT_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

-- add index
CREATE INDEX NT_NOT_RECIPIENT_INDEX
	ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT (RECIPIENT_ID);
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 37
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) Insert the panel tab page widget
----------------------------------------------------------------------
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.getstartx4a43x82aaxb001872186' , '%panel.getstart' , 1 , 0, 1);

----------------------------------------------------------------------
-- 2) LAST_NOTIFY_VISIT TIMESTAMP
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.HP_UI
	ADD LAST_NOTIFY_VISIT DATETIME;
GO	

UPDATE HOMEPAGE.HP_UI SET LAST_NOTIFY_VISIT = CURRENT_TIMESTAMP;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 38
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 41
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                              
--                                                                                                                       
--                                                                   
-- Copyright IBM Corp. 2007, 2008  All Rights Reserved.              
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or       
-- disclosure restricted by GSA ADP Schedule Contract with           
-- IBM Corp.                                                         
--                                                                   
-- ***************************************************************** 

-- 5724-S68

-----------------------------------------------------------------------------------
-- PERSON
-----------------------------------------------------------------------------------
-- select * 
-- from HOMEPAGE.PERSON 
-- where LAST_UPDATE > ?
CREATE INDEX PERSON_LAST_UPDATE
    ON HOMEPAGE.PERSON (LAST_UPDATE DESC);

-----------------------------------------------------------------------------------
-- NT_NOTIFICATION
-----------------------------------------------------------------------------------
-- select N.NOTIFICATION_ID, N.NOTIFICATION_SOURCE AS SOURCE, N.NOTIFICATION_TYPE AS TYPE, N.DATETIME_STAMP, P1.PERSON_ID, N.SENDER_ID,
--        N.SUBJECT, N.MESSAGE, N.CONTAINER_NAME, N.CONTAINER_URL, N.ITEM_NAME, N.ITEM_URL, P2.PERSON_ID AS FIRST_RECIPIENT_PERSON_ID,
--         P2.EXID AS FIRST_RECIPIENT_EXID, P2.DISPLAYNAME AS FIRST_RECIPIENT_DISPLAY_NAME, N.NUM_RECIPIENTS
-- from HOMEPAGE.NT_NOTIFICATION N, HOMEPAGE.PERSON P1, HOMEPAGE.PERSON P2 
-- where P1.PERSON_ID = ? AND P2.PERSON_ID = N.FIRST_RECIPIENT_ID AND N.SENDER_ID = P1.PERSON_ID AND N.IS_DELETED = 0 
-- order by N.DATETIME_STAMP DESC
CREATE INDEX NT_NOTIFICATION_IDX
    ON HOMEPAGE.NT_NOTIFICATION (DATETIME_STAMP DESC, FIRST_RECIPIENT_ID, SENDER_ID);

CREATE INDEX NT_FIRST_RECIPIENT_PER
    ON HOMEPAGE.NT_NOTIFICATION (FIRST_RECIPIENT_ID);

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 43
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
UPDATE HOMEPAGE.PERSON SET IS_ACTIVE = 1;

ALTER TABLE HOMEPAGE.PERSON
	ALTER COLUMN IS_ACTIVE NUMERIC(5,0) NOT NULL;

UPDATE HOMEPAGE.HP_TAB SET ENABLED = 1;

-- HOME PAGE
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HOMEPAGE_SCHEMA TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.PERSON TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SNCORE_PERSON TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.LOGINNAME TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.PREREQ TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.WIDGET  TO HOMEPAGEUSER
GO


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_UI  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_TAB  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_TAB_INST  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_WIDGET_INST  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_WIDGET_TAB  TO HOMEPAGEUSER
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NT_NOTIFICATION TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT TO HOMEPAGEUSER
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE30 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- NR_NEWS_RECORDS
------------------------------------------------

ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD ITEM_ID nvarchar(36);
GO


ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD ITEM_CORRELATION_ID nvarchar(36);
GO

---------------------------------------------------------------------------------
------------------------ END NEWS -----------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 23;
-- GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------


---------------------------------------------------------------
-- TO MANAGE PARTECIPATION: IMPLICIT SUBSCRIPTION
---------------------------------------------------------------

------------------------------------------------
-- NR_GROUP_TYPE
------------------------------------------------

CREATE TABLE HOMEPAGE.NR_GROUP_TYPE (
	GROUP_TYPE_ID nvarchar(36) NOT NULL,
	GROUP_TYPE NUMERIC(5,0) NOT NULL,
	GROUP_TYPE_DESC nvarchar(256) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
    ADD CONSTRAINT PK_GROUP_TYPE_ID PRIMARY KEY(GROUP_TYPE_ID);
GO

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
	ADD CONSTRAINT GROUP_TYPE_UNIQUE UNIQUE(GROUP_TYPE);
GO
------------------------------------------------
-- NR_GROUP
------------------------------------------------

CREATE TABLE HOMEPAGE.NR_GROUP (
	GROUP_ID nvarchar(36) NOT NULL,
	GROUP_NAME nvarchar(256) NOT NULL,
	GROUP_TYPE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_GROUP 
    ADD CONSTRAINT PK_GROUP_ID PRIMARY KEY(GROUP_ID);
GO	

ALTER TABLE HOMEPAGE.NR_GROUP
	ADD CONSTRAINT FK_GROUP_TYPE FOREIGN KEY (GROUP_TYPE)
	REFERENCES HOMEPAGE.NR_GROUP_TYPE(GROUP_TYPE);
GO
------------------------------------------------
-- NR_PERSON_SOURCE
------------------------------------------------

CREATE TABLE HOMEPAGE.NR_PERSON_SOURCE (
	PARTICIPATION_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	SOURCE_ID nvarchar(36) NOT NULL,
	GROUP_TYPE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE 
    ADD CONSTRAINT PK_PART_PER_ID PRIMARY KEY(PARTICIPATION_ID);
GO	

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT FK_READER_PER_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);
GO
	
ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT FK_SOURCE_PER_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE(SOURCE_ID);
GO

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT FK_GROUP_TYPE_PER FOREIGN KEY (GROUP_TYPE)
	REFERENCES HOMEPAGE.NR_GROUP_TYPE(GROUP_TYPE);
GO

------------------------------------------------
-- NR_GROUP_SOURCE
------------------------------------------------

CREATE TABLE HOMEPAGE.NR_GROUP_SOURCE (
	PARTICIPATION_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	SOURCE_ID nvarchar(36) NOT NULL,
	GROUP_TYPE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE 
    ADD CONSTRAINT PK_PART_GRP_ID PRIMARY KEY(PARTICIPATION_ID);
GO
	
ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT FK_READER_GRP_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);
GO
	
ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT FK_SOURCE_GRP_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE(SOURCE_ID);
GO
	
ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT FK_GROUP_TYPE_GRP FOREIGN KEY (GROUP_TYPE)
	REFERENCES HOMEPAGE.NR_GROUP_TYPE(GROUP_TYPE);
GO	

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY_TYPE 
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY_TYPE (
	CATEGORY_TYPE_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE_NAME nvarchar(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	CATEGORY_TYPE_DESC nvarchar(256) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
    ADD CONSTRAINT PK_CAT_TYPE_ID	PRIMARY KEY(CATEGORY_TYPE_ID);
GO	

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
	ADD CONSTRAINT CAT_TYPE_UNIQUE UNIQUE(CATEGORY_TYPE);

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY (
	CATEGORY_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	CATEGORY_NAME nvarchar(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_CATEGORY
    ADD CONSTRAINT PK_CATEGORY_ID PRIMARY KEY(CATEGORY_ID);
GO	

ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT FK_C_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);
GO
	
ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT FK_CATEGORY_TYPE FOREIGN KEY (CATEGORY_TYPE)
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE(CATEGORY_TYPE);
GO
--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_SOURCE_WATCHED
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_SOURCE_WATCHED (
	SOURCE_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36) NOT NULL,
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ENTRY_ID nvarchar(36),
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	IS_ACL NUMERIC(5,0) NOT NULL,
	IS_PRIVATE NUMERIC(5,0),
	LAST_UPDATE DATETIME,
	IS_CNAME_RTL NUMERIC(5,0) NOT NULL DEFAULT 0,
	IS_ENAME_RTL NUMERIC(5,0) NOT NULL DEFAULT 0
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SOURCE_WATCHED 
    ADD CONSTRAINT PK_SRC_WATCHED_ID PRIMARY KEY(SOURCE_ID);
GO	
--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- NR_FOLLOW
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	SOURCE_ID nvarchar(36) NOT NULL,
	CATEGORY_ID nvarchar(36) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT PK_FOLLOW_ID PRIMARY KEY(FOLLOW_ID);
GO

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_F_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);
GO	

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_F_SOURCE_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED(SOURCE_ID);
GO	

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_CATEGORY_ID FOREIGN KEY (CATEGORY_ID)
	REFERENCES HOMEPAGE.NR_CATEGORY(CATEGORY_ID);
GO	

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_FOLLOW_GROUP
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_FOLLOW_GROUP (
	FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	SOURCE_ID nvarchar(36) NOT NULL,
	CATEGORY_ID nvarchar(36) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP 
    ADD CONSTRAINT PK_FOLLOW_GRP_ID PRIMARY KEY(FOLLOW_ID);
GO	

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT FK_PERSON_GRP_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);
GO
	

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT FK_FGSOURCE_GRP_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED(SOURCE_ID);

GO	

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT FK_CATEGORY_GRP_ID FOREIGN KEY (CATEGORY_ID)
	REFERENCES HOMEPAGE.NR_CATEGORY(CATEGORY_ID);
GO	

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_TOP_UPDATES
---------------------------------------------------------

-- SCRIPT to simulate a new design for the news table --
CREATE TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES (
	NEWS_RECORDS_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	READER_ID nvarchar(36),
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	-- ENTRY_ID nvarchar(36), -- REMOVED
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	-- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- IS_SAVED NUMERIC(5,0) NOT NULL,
	-- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC nvarchar(512),
	IS_BRIEF_DESC_RTL NUMERIC(5,0) NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	IS_CONTAINER NUMERIC(5,0) NOT NULL DEFAULT 0,
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID nvarchar(36) NOT NULL -- NEW
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES 
    ADD CONSTRAINT PK_TOP_UPDATES_ID PRIMARY KEY(NEWS_RECORDS_ID);

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE..NR_NEWS_SAVED
---------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_SAVED (
	NEWS_RECORDS_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	READER_ID nvarchar(36),
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	-- ENTRY_ID nvarchar(36), -- REMOVED
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	-- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- IS_SAVED NUMERIC(5,0) NOT NULL,
	-- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC nvarchar(512),
	IS_BRIEF_DESC_RTL NUMERIC(5,0) NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	IS_CONTAINER NUMERIC(5,0) NOT NULL DEFAULT 0,
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID nvarchar(36) NOT NULL -- NEW
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED 
    ADD CONSTRAINT PK_SAVED_ID PRIMARY KEY(NEWS_RECORDS_ID);
GO	
---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_DISCOVERY
---------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_DISCOVERY (
	NEWS_RECORDS_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	-- READER_ID nvarchar(36), re remove it because it is a discovery table
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	-- ENTRY_ID nvarchar(36), -- REMOVED
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	-- IS_INBOX NUMERIC(5,0) NOT NULL,
	-- IS_SAVED NUMERIC(5,0) NOT NULL, we cannot save a discovery
	-- IS_TOP_STORY NUMERIC(5,0) NOT NULL, re remove it because it is a discovery table
	-- IS_PUBLIC NUMERIC(5,0) NOT NULL, this is always public
	-- IS_MAILED NUMERIC(5,0) NOT NULL, never used
	-- TIME_STAMP TIMESTAMP NOT NULL, never used
	BRIEF_DESC nvarchar(512),
	IS_BRIEF_DESC_RTL NUMERIC(5,0) NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	-- IS_CONTAINER NUMERIC(5,0) NOT NULL DEFAULT 0,
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID nvarchar(36) NOT NULL -- NEW
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY 
    ADD CONSTRAINT PK_DISCOVERY_ID PRIMARY KEY(NEWS_RECORDS_ID);
GO	
---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_WATCHLIST
---------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_WATCHLIST (
	NEWS_RECORDS_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE_ID nvarchar(36), -- reader_id in this context is replaced by source_id
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	-- ENTRY_ID nvarchar(36), -- REMOVED
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	-- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- IS_SAVED NUMERIC(5,0) NOT NULL,
	-- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC nvarchar(512),
	IS_BRIEF_DESC_RTL NUMERIC(5,0) NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	IS_CONTAINER NUMERIC(5,0) NOT NULL DEFAULT 0,
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID nvarchar(36) NOT NULL -- NEW
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST 
    ADD CONSTRAINT PK_WATCHLIST_ID PRIMARY KEY(NEWS_RECORDS_ID);

---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_STATUS_NETWORK
---------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_RECORDS_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	READER_ID nvarchar(36),
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	-- ENTRY_ID nvarchar(36), -- REMOVED
	ENTRY_NAME nvarchar(256),
	ENTRY_URL nvarchar(2048),
	ENTRY_ATOM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	-- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- IS_SAVED NUMERIC(5,0) NOT NULL,
	-- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC nvarchar(512),
	IS_BRIEF_DESC_RTL NUMERIC(5,0) NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	IS_CONTAINER NUMERIC(5,0) NOT NULL DEFAULT 0,
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID nvarchar(36) NOT NULL -- NEW
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK 
    ADD CONSTRAINT PK_STATUS_ID PRIMARY KEY(NEWS_RECORDS_ID);
GO	

----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
----------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_STORY (
	NEWS_STORY_ID nvarchar(36) NOT NULL,
	CONTENT nvarchar(max) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STORY 
    ADD CONSTRAINT PK_NEWS_STORY_ID PRIMARY KEY(NEWS_STORY_ID);
GO	
----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
-- HOMEPAGE.NR_NEWS_COMMENT
----------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT (
	COMMENT_ID nvarchar(36) NOT NULL,
	NEWS_STORY_ID nvarchar(36) NOT NULL,
	COMMENTS nvarchar(4000) DEFAULT '' NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT 
    ADD CONSTRAINT PK_COMMENT_ID PRIMARY KEY(COMMENT_ID);
GO	

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT
	ADD CONSTRAINT FK_NEWS_STORY_ID FOREIGN KEY (NEWS_STORY_ID)
	REFERENCES HOMEPAGE.NR_NEWS_STORY(NEWS_STORY_ID);
GO	
-- GIVING GRANTS TO THE NEW TABLES --


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_TYPE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_PERSON_SOURCE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_SOURCE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY_TYPE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SOURCE_WATCHED TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW_GROUP TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_TOP_UPDATES TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_SAVED TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_DISCOVERY TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_WATCHLIST TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STORY TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT TO HOMEPAGEUSER
GO

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------

------------------------------------- MIGRATION DATA ---------------------------------


--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_TOP_UPDATES ( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID nvarchar(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW
)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_TOP_STORY = 1 AND READER_ID IS NOT NULL;
GO	
	
--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_SAVED
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_SAVED ( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID nvarchar(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW
)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_SAVED = 1;
GO	

--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_DISCOVERY ( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID nvarchar(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY NUMERIC(5,0) NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC NUMERIC(5,0) NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED NUMERIC(5,0) NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW
)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_PUBLIC = 1 AND READER_ID IS NULL AND IS_CONTAINER=0;
GO

-----------------------------------------------------------------------------------------------------------------
-- WATCHLIST
-----------------------------------------------------------------------------------------------------------------

-- INSERTING CATEGORY_TYPE (profiles and tag)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles_c9cax4cc4x8b0bx51af2ddef2cd', 1, '%profile', 'profiles');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('tags_0f1xc9cax4cc4x8b0bx51af2ddef2cd', 2, '%tag', 'tag');

-- CREATE FOR EACH USERS A DEFAULT CATEGORY FOR EACH CATEGORY TYPE. 
-- THIS TABLE WILL HAVE HAS RESULTS N_USERS X CATEGORY_TYPES RECORDS
INSERT INTO HOMEPAGE.NR_CATEGORY 
    (
        CATEGORY_ID,
        PERSON_ID,
        CATEGORY_NAME,
        CATEGORY_TYPE
    )
    SELECT
        '-' + SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + PERSON.PERSON_ID),2,LEN(PERSON.PERSON_ID)-2) CATEGORY_ID,
        PERSON.PERSON_ID, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE
    FROM HOMEPAGE.PERSON PERSON, HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE;
GO

-- SELECT THE PROFILES SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;
GO

-- SELECT THE TAG SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;
GO

-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) + 
        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) +  
        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' + SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,LEN(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;
GO		

-- CREATE THE RELETIONSHIP FOR TAGS SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) + 
        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) +  
        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' + SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,LEN(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;
GO

-- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
-- INSERTING PROFILES STORIES
-- 1 profile status update
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;
GO		

-- 2 where actor uuid is specified        
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   READER_ID IS NULL AND
        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE_WATCHED.CONTAINER_ID;
GO		

-- INSERTING TAGS STORIES
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;		
GO		

UPDATE 	HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING='collection.name;htmlURL'
WHERE 	TEMPLATE_ID='collection-7jEWoKkWx8ucNTo6Z7AndhRFh';

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 30;
-- GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Missing fk for NR_NEWS_WATCHLIST
ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT FK_F_WSOURCE_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED(SOURCE_ID);
	
-- REMOVING NR_FOLLOW_GROUP table
DROP TABLE HOMEPAGE.NR_FOLLOW_GROUP;

-- REFACTORING THE NR_FOLLOW table; 
DROP TABLE HOMEPAGE.NR_FOLLOW;

-- REMOVING NR_CATEGORY table
DROP TABLE HOMEPAGE.NR_CATEGORY;

------------------------------------------------
-- NR_FOLLOW
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	SOURCE_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOW 
  	ADD CONSTRAINT PK_FOLLOW_ID PRIMARY KEY(FOLLOW_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_F_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_F_SOURCE_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED(SOURCE_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_CATEGORY_TYPE FOREIGN KEY (CATEGORY_TYPE)
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE(CATEGORY_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO HOMEPAGEUSER
GO
	
---- MIGRATE DATA TO THE FOLLOW TABLE
---- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE   
--)
--SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) + 
--        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) +  
--        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		1
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
--        NR_SOURCE.SOURCE = 'profiles';
--GO		
--
--
---- MIGRATE DATA TO THE FOLLOW TABLE
---- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE   
--)
--SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) + 
--        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) +  
--        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--        2
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tag
--        NR_SOURCE.SOURCE = 'tag';
--GO     

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) UPDATE THE TOP UPDATES TABLE. Adding SOURCE_ID and CATEGORY_TYPE attributes
ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD SOURCE_ID nvarchar(36);

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD CATEGORY_TYPE NUMERIC(5,0);
	
-- 2) REMOVE IS_ACL FROM NR_SOURCE TABLE
DROP INDEX NR_SOURCE_IX_UNIQUE ON HOMEPAGE.NR_SOURCE;

DROP INDEX NR_SOURCE_CONTAINER_NAME_IDX ON HOMEPAGE.NR_SOURCE;

ALTER TABLE HOMEPAGE.NR_SOURCE
DROP COLUMN IS_ACL;

CREATE INDEX NR_SOURCE_IX_UNIQUE
	ON HOMEPAGE.NR_SOURCE(SOURCE ASC, CONTAINER_ID ASC, ENTRY_ID ASC);

CREATE INDEX NR_SOURCE_CONTAINER_NAME_IDX
  	ON HOMEPAGE.NR_SOURCE(SOURCE ASC, CONTAINER_NAME ASC, ENTRY_ID ASC);

-- 3) UPDATE THE FK FOR SOURCE_ID AND REMOVE NR_SOURCE_WATCHED
-- NR_NEWS_WATCHLIST
DELETE FROM HOMEPAGE.NR_NEWS_WATCHLIST;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
DROP CONSTRAINT FK_F_WSOURCE_ID;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT FK_F_WSOURCE_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE(SOURCE_ID);

-- 	NR_FOLLOW
DELETE FROM HOMEPAGE.NR_FOLLOW;

ALTER TABLE HOMEPAGE.NR_FOLLOW
DROP CONSTRAINT FK_F_SOURCE_ID;

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_F_SOURCE_ID FOREIGN KEY (SOURCE_ID)
	REFERENCES HOMEPAGE.NR_SOURCE(SOURCE_ID);

DROP TABLE HOMEPAGE.NR_SOURCE_WATCHED;	

-- 4) ADDING THE TABLE TO MANAGE NEWS STATUS NETWORK

DROP TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK;

------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_STATUS_NETWORK_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36),
	ACTOR_UUID nvarchar(36) NOT NULL,
	BRIEF_DESC nvarchar(500),
	ITEM_URL nvarchar(2048),
	ITEM_ID  nvarchar(36),
	EVENT_NAME nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	IS_WALL_POST  NUMERIC(5,0) NOT NULL DEFAULT 0,
	CREATION_DATE DATETIME,
	UPDATE_DATE DATETIME,
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0,
	IS_NETWORK_NEWS NUMERIC(5,0) NOT NULL DEFAULT 0,
	IS_FOLLOW_NEWS NUMERIC(5,0) NOT NULL DEFAULT 0
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK
  	ADD CONSTRAINT PK_NEWS_STATUS_ID PRIMARY KEY(NEWS_STATUS_NETWORK_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO HOMEPAGEUSER  	    

------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT (
	NEWS_STATUS_COMMENT_ID nvarchar(36) NOT NULL,
	ACTOR_UUID nvarchar(36) NOT NULL,
	CREATION_DATE DATETIME,
	BRIEF_DESC nvarchar(500),
	ITEM_ID  nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_URL nvarchar(2048)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT
  	ADD CONSTRAINT PK_NEWS_COMMENT_ID PRIMARY KEY(NEWS_STATUS_COMMENT_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_COMMENT TO HOMEPAGEUSER  	    

------------------------------------------------
-- NR_NEWS_STATUS_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID nvarchar(36) NOT NULL,
	CONTENT varbinary (MAX),
	ITEM_ID  nvarchar(36)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
  	ADD CONSTRAINT PK_S_CONTENT_ID PRIMARY KEY(NEWS_STATUS_CONTENT_ID);    

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO HOMEPAGEUSER 

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID nvarchar(36) NOT NULL,
	CONTENT varbinary (MAX),
	NEWS_STATUS_COMMENT_ID  nvarchar(36)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT PK_C_CONTENT_ID PRIMARY KEY(NEWS_COMMENT_CONTENT_ID);    

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT FK_C_COMMENT_ID FOREIGN KEY (NEWS_STATUS_COMMENT_ID)
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT(NEWS_STATUS_COMMENT_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO HOMEPAGEUSER
	
----------------------------------------------------
----------------------------------------------------
-- MIGRATION
----------------------------------------------------
----------------------------------------------------

---- MIGRATE DATA TO THE FOLLOW TABLE
---- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE    
--)
--SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) + 
--        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) + 
--        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		1
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
--        NR_SOURCE.SOURCE = 'profiles';
--
---- MIGRATE DATA TO THE FOLLOW TABLE
---- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE    
--)
--SELECT  SUBSTRING(NR_SUBSCRIPTION.PERSON_ID,1,10) +
--        SUBSTRING(NR_SOURCE.SOURCE_ID,1,10) +
--        SUBSTRING((SUBSTRING((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME + NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		2
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
--        NR_SOURCE.SOURCE = 'tag';
--
---- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
---- INSERTING PROFILES STORIES
---- 1 profile status update
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
--        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
--        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;
--
---- 2 where actor uuid is specified        
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   READER_ID IS NULL AND
--        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
--        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE.CONTAINER_ID;
--
---- INSERTING TAGS STORIES
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
--        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
--        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
--        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) UPDATE CATEGORY
----------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_FOLLOW DROP CONSTRAINT FK_CATEGORY_TYPE;

UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%tags', CATEGORY_TYPE_DESC='tags', CATEGORY_TYPE=10 WHERE CATEGORY_TYPE = 2;

UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%profiles', CATEGORY_TYPE=2 WHERE CATEGORY_TYPE = 1;

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('communities_0f1xc9cax4cc4x8b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('activities_0ff1xc9cax4cc4x8b0bx51af2', 4, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('blogs_0ffdsfds1xc9cax4cc4x8b0bx51af2', 5, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('bookmarks_0fdf1xc9cax4cc4x8b0bx51af2', 6, '%bookmarks', 'bookmarks');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('files_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 7, '%files', 'files');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('forums_0fdsfdf1xc9cax4cc4x8b0bx51af2', 8, '%forums', 'forums');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('wikis_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 9, '%wikis', 'wikis');

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT FK_CATEGORY_TYPE FOREIGN KEY (CATEGORY_TYPE)
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE(CATEGORY_TYPE);

----------------------------------------------------------------------
-- 2) UPDATE TEMPLATES
----------------------------------------------------------------------
DELETE FROM HOMEPAGE.NR_TEMPLATE;

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actor-Bei35oPldKwZTaR7aAiPFw4L08CyRW','actor', 'actorInternalId', 'profilePhoto', 1); 

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actorProfile-CAsyXgPhQd7N3wSMw7C0IUe','actorProfiles', 'actorInternalId', 'profilePhoto', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('target-Ah3vEOPQZDEpgpwcQ2JNaHFfMnMcG','subject', 'targetSubjectsInternalIds', 'profilePhoto', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEnt-anXIr0xP82OSZnuoYbAZa2M5AsRFr', 'activityEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k','activityEntryWithComment', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-WHHEhu6HTkRWtCQPylcUdSENF4mU', 'activityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-Mg2xRFBLmRqg3Zj7Etrdttiyc6OH','activityContainerNameACL', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actToDo-psOHtvbY4lOJv8jOXJH5YgLoGYP7','toDoEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blog-Itf9INx14G6bbCWRYNRpLhSawJXF8Qs','blogContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogNew-qsgRrfp88AKWys4wcm4gIuZm3T2p','newBlogContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogEntry-ubpjmKeG6Vi8XpQXYKVx3mtCqm','blogEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogComment-92JYbZEOrk0CBLEJHYwkrqPA','blogEntryWithComment', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-Qf0I5rSEaImjaCcds3HYi4SeCGYCDCN','newCommunityContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-new-IduwKhHDNCLdmJFi0G7lwrE86IJ','communityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-topic6V808ijHf9TRgUSUqVVZoSOGg5','topicEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-book-VSWMFF7uZVaE11XRe4Q1ElJIc6','communityBookmarkEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-feed-Ja6XFBT7kyfEJv07Unitc0MsJT','feedEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('dogear-book-DXAWZl1FIGMuMr4Ea4Lejbum','dogearBookmarkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('tags-a7YmLTHTY2FdHKPsHU0wbAZCkgYrkk1','tag', 'contentTags', 'plain', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profileEntry-Vrh9M5YNmxNogF2oERZWyRE','profileLinkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profile-status-HNX0o3AF32cFuPWhtYMjl','profileStatusEntry', 'status', 'plain', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQ0gZl5','wikiContainerName','containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-page-P75oD6oAdgoWCRNt4YYh7hZfuM','wikiEntryPage', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-comment-Ye2xdX8pbYM996pc7je30LI','wikiEntryPageCommented', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('file-bbqZpR6oxvE2sYAXxasKS0EtS1mDg4h','fileEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('collection-7jEWoKkWx8ucNTo6Z7AndhRFh','collectionContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQdfgt5','newWikiContainer','containerName;containerHtmlPath', 'link', 1);

------------------------------------------------
-- NR_RESOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESOURCE_TYPE (
	RESOURCE_TYPE_ID nvarchar(36) NOT NULL,
	RESOURCE_TYPE_NAME nvarchar(36) NOT NULL, -- this is externalized
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	RESOURCE_TYPE_DESC nvarchar(256) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
  	ADD CONSTRAINT PK_RES_TYPE_ID PRIMARY KEY(RESOURCE_TYPE_ID);

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
	ADD CONSTRAINT RES_TYPE_UNIQUE UNIQUE (RESOURCE_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE_TYPE  TO HOMEPAGEUSER	

----------------------------------------------------------------------
-- HOMEPAGE.NR_RESOURCE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESOURCE (
	RESOURCE_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36) NOT NULL,
	CONTAINER_NAME nvarchar(36),
	CONTAINER_URL nvarchar(2048),
	CATEGORY_TYPE NUMERIC(5,0),
	RESOURCE_TYPE NUMERIC(5,0)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_RESOURCE 
    ADD CONSTRAINT PK_RESOURCE_ID PRIMARY KEY(RESOURCE_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE  TO HOMEPAGEUSER  

----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWS 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWS (
	FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	RESOURCE_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOWS 
    ADD CONSTRAINT PK_FOLLOWS_ID PRIMARY KEY(FOLLOW_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOWS
    ADD CONSTRAINT FK_FS_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOWS
    ADD CONSTRAINT FK_FS_RESOURCE_ID FOREIGN KEY (RESOURCE_ID)
	REFERENCES HOMEPAGE.NR_RESOURCE (RESOURCE_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWS  TO HOMEPAGEUSER	

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_FOLLOW 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_FOLLOW (
	COMM_FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	COMMUNITY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT PK_COMM_FOLLOW_ID PRIMARY KEY(COMM_FOLLOW_ID);

ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT FK_COMM_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_FOLLOW  TO HOMEPAGEUSER	  

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_FOLLOW
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW (
	ORGPERSON_FOLLOW_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	ORGANIZATION_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW
    ADD CONSTRAINT PK_ORGP_FOLLOW_ID PRIMARY KEY(ORGPERSON_FOLLOW_ID);

ALTER TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW
    ADD CONSTRAINT FK_ORGP_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_FOLLOW  TO HOMEPAGEUSER

----------------------------------------------------------------------
-- HOMEPAGE.NR_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	RELATED_COMM_UUID nvarchar(36),
	RELATED_COMM_NAME nvarchar(256),
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0 -- NEW
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT PK_STORY_ID PRIMARY KEY(STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO HOMEPAGEUSER

----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWED_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWED_STORIES (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL, 
	ITEM_ID nvarchar(36) NOT NULL, -- I don't think we need SOURCE_ID here, this should be in the SOURCE table?
	RESOURCE_TYPE_ID nvarchar(36) NOT NULL, -- ???? what is this ??
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT PK_F_STORY_ID PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO HOMEPAGEUSER    

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_STORIES (
	COMM_STORY_ID nvarchar(36) NOT NULL,
	COMMUNITY_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	RESOURCE_TYPE_ID nvarchar(36) NOT NULL, -- ???? what is this ??
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT PK_F_CSTORY_ID PRIMARY KEY(COMM_STORY_ID);

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT FK_COMM_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO HOMEPAGEUSER

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_STORIES (
	ORGPERSON_STORY_ID nvarchar(36) NOT NULL,
	ORGANIZATION_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36) NOT NULL,
	RESOURCE_TYPE_ID nvarchar(36) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT PK_ORGP_STORY_ID PRIMARY KEY(ORGPERSON_STORY_ID);

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT FK_ORGP_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO HOMEPAGEUSER

----------------------------------------------------------------------------------
-- 5) Creating the story table where to store the actual content for a story
----------------------------------------------------------------------------------

------------------------------------------------
-- NR_STORIES_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES_CONTENT (
	STORY_CONTENT_ID nvarchar(36) NOT NULL,
	CONTENT varbinary (MAX) NOT NULL,
	CREATION_DATE DATETIME NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
  	ADD CONSTRAINT PK_STORY_CONT_ID PRIMARY KEY(STORY_CONTENT_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES_CONTENT  TO HOMEPAGEUSER


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING RESOURCE TYPE
----------------------------------------------------------------------

------------
--- START INSERT NR_RESOURCE_TYPE
------------ 

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('activity_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%activity', 'activity');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('blog________0f1xc9cax4cc4x8b0bx51af2', 3, '%blog', 'blog');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('community____f1xc9cax4cc4x8b0bx51af2', 4, '%community', 'community');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_change_ds1xc9cax4cc4x8b0bx51af2', 5, '%file_change', 'file_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_comment_df1xc9cax4cc4x8b0bx5af2', 6, '%file_comment', 'file_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_collection_fdfca4cc4x8b0bx51af2', 7, '%file_collection', 'file_collection');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_topic_fdfdxc9cax4cc4xb0bx51af2', 8, '%forum_topic', 'forum_topic');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_0fdsfdsf1xc9cax4cc4xb0bxd51af2', 9, '%forum', 'forum');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('person_0f1xc9cax4cc4xb0bx51af2def2cd', 10, '%person', 'person');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_change_fdfdc9cax8b0bx51af2', 11, '%wiki_page_change', 'wiki_page_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_comment_0cax4c4x8b0bx51af2', 12, '%wiki_page_comment', 'wiki_page_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('tag_0f1xc9cax4cc4x8cdb0bx51f2ddef2cd', 13, '%tag', 'tag');

------------
--- END INSERT NR_RESOURCE_TYPE
------------

----------------------------------------------------------------------
-- 2) CHANGE FROM THE USE OF RESOURCE_TYPE_ID to USE RESOURCE_TYPE AND ADDING ITEM_ID TO NR_COMM_STORIES
----------------------------------------------------------------------

-- a) NR_FOLLOWED_STORIES
DROP TABLE HOMEPAGE.NR_FOLLOWED_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWED_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWED_STORIES (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36), -- I don't think we need SOURCE_ID here, this should be in the SOURCE table?
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL, -- ???? what is this ??
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT PK_F_STORY_ID PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO HOMEPAGEUSER  

-- b) NR_COMM_STORIES
DROP TABLE HOMEPAGE.NR_COMM_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_STORIES (
	COMM_STORY_ID nvarchar(36) NOT NULL,
	COMMUNITY_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT PK_F_CSTORY_ID PRIMARY KEY(COMM_STORY_ID);

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT FK_COMM_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO HOMEPAGEUSER

-- c) NR_ORGPERSON_STORIES
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_STORIES (
	ORGPERSON_STORY_ID nvarchar(36) NOT NULL,
	ORGANIZATION_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(36),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT PK_ORGP_STORY_ID PRIMARY KEY(ORGPERSON_STORY_ID);

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT FK_ORGP_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO HOMEPAGEUSER

------------------------------------------------------
-- 3) REMOVING THE IS_ACTIVE FLAG and REDO the VIEW
------------------------------------------------------
--ALTER TABLE HOMEPAGE.PERSON DROP COLUMN IS_ACTIVE;

------------------------------------------------------
-- 4) ADDING FK TO THE NR_RESOURCE for CATEGORY_TYPE AND - RESOURCE TYPE
------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT FK_RES_RES_TYPE FOREIGN KEY (RESOURCE_TYPE)
	REFERENCES HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE);
	
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT FK_RES_CAT_TYPE FOREIGN KEY (CATEGORY_TYPE)
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE);
	
------------------------------------------------------
-- 5) ADDING NR_NETWORK TABLE TO MANAGE PEOPLE IN YOUR NETWORK
------------------------------------------------------

----------------------------------------------------------------------
-- HOMEPAGE.NR_NETWORK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NETWORK (
	NETWORK_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	COLLEAGUE_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT PK_NETWORK_ID PRIMARY KEY(NETWORK_ID);

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT FK_NTW_PERS_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT FK_NTW_COLL_ID FOREIGN KEY (COLLEAGUE_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NETWORK  TO HOMEPAGEUSER	
	
------------------------------------------------------
-- 6) REMOVING OLD EMAIL DIGEST TABLES
------------------------------------------------------
DROP TABLE HOMEPAGE.EMD_JOBS_STATS;
DROP TABLE HOMEPAGE.EMD_JOBS;
DROP TABLE HOMEPAGE.EMD_RECIPIENTS;

------------------------------------------------------
-- 7) ADDING NEW EMAIL DIGEST TABLES
------------------------------------------------------

-----------------------------------------
-- HOMEPAGE.EMD_FREQUENCY_TYPE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_FREQUENCY_TYPE (
	FREQUENCY_TYPE_ID nvarchar(36) NOT NULL,
	FREQUENCY_TYPE_NAME nvarchar(36) NOT NULL, 
	FREQUENCY_TYPE NUMERIC(5,0) NOT NULL,
	FREQUENCY_TYPE_DESC nvarchar(256) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE 
  	ADD CONSTRAINT PK_FRQ_TYPE_ID PRIMARY KEY(FREQUENCY_TYPE_ID);

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE
	ADD CONSTRAINT FRQ_TYPE_UNIQUE UNIQUE (FREQUENCY_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_FREQUENCY_TYPE  TO HOMEPAGEUSER 	

-----------------------------------------
-- HOMEPAGE.EMD_RESOURCE_PREF
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_RESOURCE_PREF (
	RESOURCE_PREF_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	FREQUENCY_TYPE NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF 
  	ADD CONSTRAINT PK_RES_PREF_ID PRIMARY KEY(RESOURCE_PREF_ID);

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT FK_RES_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT FK_RES_FRQ_TYPE FOREIGN KEY (FREQUENCY_TYPE)
	REFERENCES HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_RESOURCE_PREF  TO HOMEPAGEUSER  	 	

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE (
	TRANCHE_ID nvarchar(36) NOT NULL,
	SEQ_NUMBER NUMERIC(5,0) NOT NULL,
	LAST_PROCESSED_DAILY DATETIME,
	LAST_PROCESSED_WEEKLY DATETIME,
	IS_LOCKED NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
  	ADD CONSTRAINT PK_TRANCHE_ID PRIMARY KEY(TRANCHE_ID);

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
	ADD CONSTRAINT SEQ_NUMBER_UNIQUE UNIQUE (SEQ_NUMBER);   	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE  TO HOMEPAGEUSER  	

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE_INFO
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE_INFO (
	TRANCHE_INFO_ID nvarchar(36) NOT NULL,
	TRANCHE_ID nvarchar(36) NOT NULL,
	COUNT_PROCESSED_DAILY NUMERIC(5,0),
	COUNT_PROCESSED_WEEKLY NUMERIC(5,0),
	AVG_EXEC_TIME_DAILY_MIN NUMERIC(5,0),
	AVG_EXEC_TIME_WEEKLY_MIN NUMERIC(5,0),
	DOMAIN_AFFINITY nvarchar(2048) NOT NULL,
	N_USERS NUMERIC(5,0)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
  	ADD CONSTRAINT PK_TRC_INFO_ID PRIMARY KEY(TRANCHE_INFO_ID);

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
    ADD CONSTRAINT FK_TRANCHE_ID FOREIGN KEY (TRANCHE_ID)
	REFERENCES HOMEPAGE.EMD_TRANCHE (TRANCHE_ID);	 	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE_INFO  TO HOMEPAGEUSER

-----------------------------------------
-- HOMEPAGE.EMD_EMAIL_PREFS
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_EMAIL_PREFS (
	EMAIL_PREFS_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,
	SEND_DIRECTED NUMERIC(5,0) NOT NULL,
	TRANCHE_ID nvarchar(36) NOT NULL,
	EMAIL_ADDRESS nvarchar(256) NOT NULL,
	LANG nvarchar(36) NOT NULL,
	USE_TEXT_EMAIL NUMERIC(5,0) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
  	ADD CONSTRAINT PK_EMAIL_PREFS_ID PRIMARY KEY(EMAIL_PREFS_ID);

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ADD CONSTRAINT FK_EMD_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_EMAIL_PREFS  TO HOMEPAGEUSER	
	
--------------------------------------
-- 8) INIT EMD_FREQUENCY_TYPE
--------------------------------------

-----------------------------------
-- START EMD_FREQUENCY_TYPE
-----------------------------------	
INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('never_____0fdf1xc9cax4cc4x8b0bx51af2', 1, '%never', 'never');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('immediete_9cax4cc4x8b0bx51af2ddef2cd', 2, '%immediete', 'immediete');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('daily_______0f1xc9cax4cc4x8b0bx51af2', 3, '%daily', 'daily');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('weekly_______f1xc9cax4cc4x8b0bx51af2', 4, '%weekly', 'weekly');  	
-----------------------------------
-- END EMD_FREQUENCY_TYPE
-----------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 4) ADDING A UNIQUE CONSTRAINT on EMD_EMAIL_PREFES - PERSON ID
---------------------------------------------------------------------
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
	ADD CONSTRAINT UNIQUE_PREFS UNIQUE (PERSON_ID);

----------------------------------------------------------------------
-- 5) REMOVE NR_NEWS_COMMENT table
----------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_COMMENT;

----------------------------------------------------------------------
-- 6) SET HP_UI.WELCOME MODE  to 1 for all the users 
----------------------------------------------------------------------
UPDATE HOMEPAGE.HP_UI SET WELCOME_MODE = 1;
GO
----------------------------------------------------------------------
-- 7) DROP NOT NULL on NR_STORIES for column R_META_TEMPLATE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP CONSTRAINT FK_F_STORY_ID;
ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP CONSTRAINT FK_COMM_STORY_ID;
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES DROP CONSTRAINT FK_ORGP_STORY_ID;
GO

DROP TABLE HOMEPAGE.NR_STORIES;

CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(36),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) NOT NULL DEFAULT 0 -- NEW
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT PK_STORY_ID PRIMARY KEY(STORY_ID);
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO HOMEPAGEUSER  

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT FK_COMM_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT FK_ORGP_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);    

----------------------------------------------------------------------
-- 8) REMOVE RELATED COMMUNITY COLUMNS FROM DISCOVERY TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_NAME;

----------------------------------------------------------------------
-- 9) REMOVE RELATED COMMUNITY COLUMNS FROM NR_NEWS_SAVED TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_NAME;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 37
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 3) ADDING LAST UPDATE FOR RESORUCE TABLE
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD LAST_UPDATE DATETIME;
GO	

UPDATE HOMEPAGE.NR_RESOURCE SET LAST_UPDATE = CURRENT_TIMESTAMP;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 38
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 0) ADDING UNIQUE CONSTRAINTS FOR NR_FOLLOWS TABLE
----------------------------------------------------------------------
CREATE UNIQUE INDEX NR_FOLLOWS_IDX
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID, PERSON_ID);

----------------------------------------------------------------------
-- 1) REMOVING UN-USED TABLE
----------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_STORY;
DROP TABLE HOMEPAGE.NR_NEWS_WATCHLIST;
DROP TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES;
DROP TABLE HOMEPAGE.NR_FOLLOW;
DROP TABLE HOMEPAGE.NR_GROUP_SOURCE;
DROP TABLE HOMEPAGE.NR_PERSON_SOURCE;
DROP TABLE HOMEPAGE.NR_GROUP;
DROP TABLE HOMEPAGE.NR_GROUP_TYPE;
DROP TABLE HOMEPAGE.NR_EVENT_RECORDS;
-- DROP TABLE HOMEPAGE.NR_NEWS_RECORDS;
-- DROP TABLE HOMEPAGE.NR_SUBSCRIPTION;
-- DROP TABLE HOMEPAGE.NR_SOURCE;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 39
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-------------------------------------------------------------------------------
-- ADDING TEMPLATE
-------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('membership-9qgdh66pf82um3c6q1lQdfgt5','newMembers', 'memberAddedInternalIds', 'profilePhoto', 3);

---------------------------------------------------------------------------------- 
-- PRE FIX SCHEMA 
---------------------------------------------------------------------------------- 
ALTER TABLE HOMEPAGE.NR_RESOURCE 
DROP COLUMN CONTAINER_NAME;

ALTER TABLE HOMEPAGE.NR_RESOURCE 
ADD CONTAINER_NAME nvarchar(256);
GO

----------------------------------------------------------------------------------
-- FIX DUPLICATED RECORDS - ADDING CONSTRAINSTS
----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ALTER COLUMN RESOURCE_TYPE 
    NUMERIC(5,0) NOT NULL;

ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);
GO	

--REORG table HOMEPAGE.NR_RESOURCE USE NEWS4TMPTABSPACE; 

---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 1) START: MIGRATION FOR STATUS UPDATE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- BUILDING RESOURCE TABLE WITH CONTAINER NAME FOR PROFILES 
---------------------------------------------------------------------------------- 
CREATE VIEW HOMEPAGE.PROFILE_SOURCES_NAME AS  ( 
    SELECT  NR_SOURCE.SOURCE_ID     SOURCE_ID, 
            B_CONTAINER_ID          CONTAINER_ID, 
            B_CONTAINER_NAME        CONTAINER_NAME 
    FROM    ( 
                SELECT  TEMP_A.A_CONTAINER_ID B_CONTAINER_ID, MAX(NR_NEWS_RECORDS.CONTAINER_NAME) B_CONTAINER_NAME 
                FROM    (   SELECT  NR_SOURCE.SOURCE_ID, MAX(NR_NEWS_RECORDS.CONTAINER_ID) A_CONTAINER_ID 
                            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
                            WHERE NR_NEWS_RECORDS.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID AND NR_SOURCE.SOURCE = 'profiles' 
                            GROUP BY NR_SOURCE.SOURCE_ID 
                        )   TEMP_A, 
                            HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
                WHERE       NR_NEWS_RECORDS.SOURCE = 'profiles' AND TEMP_A.A_CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
                GROUP BY    TEMP_A.A_CONTAINER_ID 
                ) TEMP_B, 
                HOMEPAGE.NR_SOURCE NR_SOURCE 
    WHERE NR_SOURCE.CONTAINER_ID = TEMP_B.B_CONTAINER_ID 
);
GO

---------
-- START: FIX - create PROFILE_SOURCES_NAME_FILTERED
--------
CREATE VIEW HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE AS (
    SELECT CONTAINER_ID, CONTAINER_NAME, MAX (SOURCE_ID) SOURCE_ID
    FROM HOMEPAGE.PROFILE_SOURCES_NAME
    GROUP BY  CONTAINER_ID, CONTAINER_NAME
);
GO

---------
-- END: FIX
--------  

-- INSERTING PROFILES RESOURCES WITH THE NAME 
INSERT INTO HOMEPAGE.NR_RESOURCE ( 
    RESOURCE_ID, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    CATEGORY_TYPE, 
    RESOURCE_TYPE 
) 
SELECT  SOURCE_ID, 
        'profiles', 
        CONTAINER_ID,  
        CONTAINER_NAME, 
        '' , 
        2 , -- profile type 
        10 -- person 
FROM    HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE; 
GO

---------------------------------------------------------------------------------- 
-- BUILDING NETWORK TABLE FOR STATUS UPDATE 
---------------------------------------------------------------------------------- 
-- FROM the subscription table we SELECT what IS implicit. thIS the USEr network 
CREATE VIEW HOMEPAGE.TMP_NETWORK AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID COLLEAGUE_ID 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 0 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
GO

-- to build the network relationship 
INSERT INTO HOMEPAGE.NR_NETWORK ( 
    NETWORK_ID, 
    PERSON_ID, 
    COLLEAGUE_ID 
) 
SELECT  (SUBSTRING(TMP_NETWORK.PERSON_ID,1,18) + SUBSTRING(TMP_NETWORK.COLLEAGUE_ID,1,18)), TMP_NETWORK.PERSON_ID,  TMP_NETWORK.COLLEAGUE_ID 
FROM    HOMEPAGE.TMP_NETWORK TMP_NETWORK; 
GO

----------------------------------------------------------------------------------------------- 
-- BUILIDING FOLLOWER TABLES FOR PROFILES 
------------------------------------------------------------------------------------------------ 
-- FROM the subscription table we SELECT what IS explicit. thIS the what an USEr IS following 
-- what an USEr IS following 
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 1 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
GO 

INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER; 
GO


--------------------------------------------------------------------------------------------------------------- 
-- A - BUILDING STATUS UPDATE NETWORK + FOLLOWED (NOTe in the pASt who IS in your network IS automated followed) 
--------------------------------------------------------------------------------------------------------------- 
---------------------------------------------------------------- 
-- A-1) insert all the status updates releted to the USEr network 
---------------------------------------------------------------- 
-- profiles.status.updated 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
        NR_NEWS_RECORDS.READER_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
		'MIGRATED' + SUBSTRING(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        1   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated'; 
GO

---------------------------------------------------------------- 
-- A-1b) insert all MY status updates releted to myself 
---------------------------------------------------------------- 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
)
SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
        NR_NEWS_RECORDS.READER_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
		'MIGRATED' + SUBSTRING(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        0   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.PERSON PERSON
WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND IS_PUBLIC = 1 AND
        ACTOR_UUID = PERSON.PERSON_ID;
GO

UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET READER_ID = ACTOR_UUID WHERE READER_ID IS NULL;
GO

---------------------------------------------------------------- 
-- A-1c) insert all MY network updates 
---------------------------------------------------------------- 
-- profiles.status.updated 
-- performing this insertions two times because there is a bidirectional reletionship

-- PERSON - COLLEAGUE
-- COLLEAGUE - PERSON
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT  (   SUBSTRING(NR_NETWORK.PERSON_ID,1,12) + 
            SUBSTRING(NR_NEWS_RECORDS.ACTOR_UUID,1,12) +
            SUBSTRING(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,12)
        ) NEWS_STATUS_NETWORK_ID, 
        NR_NETWORK.PERSON_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
        'MIGRATED' + SUBSTRING(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        0   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,
        HOMEPAGE.NR_NETWORK NR_NETWORK
WHERE   NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND NR_NEWS_RECORDS.READER_ID IS NULL AND 
        NR_NEWS_RECORDS.ACTOR_UUID = NR_NETWORK.COLLEAGUE_ID;

GO

-------------------------------------- 
---- A-2) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created'; 
--GO
--
-------------------------------------- 
---- A-3) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.you' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.READER_ID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.READER_ID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you'; 
--GO
--
-------------------------------------- 
---- A-4) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.their' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.READER_ID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.READER_ID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.their'; 
--GO



--------------------------------------------------------------------------------------------------------------- 
-- B - BUILDING STATUS UPDATE FOLLOWED 
--------------------------------------------------------------------------------------------------------------- 
CREATE VIEW HOMEPAGE.TMP_FOLLOWS_CONTAINER AS ( 
    SELECT  FOLLOW_ID, PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID 
);
GO 



---------------------------------------------------------------- 
-- B-1) insert all the status updates releted to the USEr network 
---------------------------------------------------------------- 
-- profiles.status.updated 
CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS (            
    SELECT  SUBSTRING(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) + SUBSTRING(TMP_FOLLOWS_CONTAINER.PERSON_ID,1,18)  NEWS_STATUS_NETWORK_ID, 
            TMP_FOLLOWS_CONTAINER.PERSON_ID         READER_ID, 
            NR_NEWS_RECORDS.ACTOR_UUID              ACTOR_UUID, 
            NR_NEWS_RECORDS.BRIEF_DESC              BRIEF_DESC, 
            NR_NEWS_RECORDS.ENTRY_URL               ITEM_URL, 
            'MIGRATED' + SUBSTRING(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27)						       	ITEM_ID, 
            NR_NEWS_RECORDS.EVENT_NAME              EVENT_NAME, 
            ''         								TARGET_SUBJECT_ID, -- target subject 
            0                                       IS_WALL_POST, -- IS wall post 
            NR_NEWS_RECORDS.CREATION_DATE           CREATION_DATE, 
            NR_NEWS_RECORDS.CREATION_DATE           UPDATE_DATE, 
            0                                       N_COMMENTS, 
            0                                       IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
            1                                       IS_FOLLOW_NEWS  -- thIS IS just a followed news 
    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
            HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND 
            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
);
GO 

CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
);
GO 
 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT      NEWS_STATUS_NETWORK_ID, 
            READER_ID, 
            ACTOR_UUID, 
            BRIEF_DESC, 
            ITEM_URL, 
            ITEM_ID,
            EVENT_NAME, 
            TARGET_SUBJECT_ID, 
            IS_WALL_POST, 
            CREATION_DATE, 
            UPDATE_DATE, 
            N_COMMENTS, 
            IS_NETWORK_NEWS, 
            IS_FOLLOW_NEWS 
FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
GO


------------------------------------------------------------------ 
---- B-2) INSERT STATUS UPDATE WALLPOST 
------------------------------------------------------------------ 
--DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED;
--GO 
--CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS (            
--    SELECT  SUBSTRING(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) + SUBSTRING(TMP_FOLLOWS_CONTAINER.PERSON_ID,1,18)  NEWS_STATUS_NETWORK_ID, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID         READER_ID, 
--            NR_NEWS_RECORDS.ACTOR_UUID              ACTOR_UUID, 
--            NR_NEWS_RECORDS.BRIEF_DESC              BRIEF_DESC, 
--            NR_NEWS_RECORDS.ENTRY_URL               ITEM_URL, 
--            NR_NEWS_RECORDS.EVENT_RECORD_UUID       ITEM_ID, 
--            NR_NEWS_RECORDS.EVENT_NAME              EVENT_NAME, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID         TARGET_SUBJECT_ID, -- target subject 
--            0                                       IS_WALL_POST, -- IS wall post 
--            NR_NEWS_RECORDS.CREATION_DATE           CREATION_DATE, 
--            NR_NEWS_RECORDS.CREATION_DATE           UPDATE_DATE, 
--            0                                       N_COMMENTS, 
--            0                                       IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
--            1                                       IS_FOLLOW_NEWS  -- thIS IS just a followed news 
--    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
--            HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
--    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created' AND 
--            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
--);
--GO 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED;
--GO 
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--);
--GO
-- 
---- profiles.wallpost.created 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--GO
--
-------------------------------------- 
---- B-3) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.you' 
--DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED;
--GO 
--CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS ( 
--    SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID NEWS_STATUS_NETWORK_ID, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID READER_ID, 
--            NR_NEWS_RECORDS.ACTOR_UUID ACTOR_UUID, 
--            NR_NEWS_RECORDS.BRIEF_DESC BRIEF_DESC, 
--            NR_NEWS_RECORDS.ENTRY_URL ITEM_URL, 
--            NR_NEWS_RECORDS.EVENT_RECORD_UUID ITEM_ID, 
--            NR_NEWS_RECORDS.EVENT_NAME EVENT_NAME, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID TARGET_SUBJECT_ID, -- target subject 
--            1 IS_WALL_POST, -- IS wall post 
--            NR_NEWS_RECORDS.CREATION_DATE CREATION_DATE, 
--            NR_NEWS_RECORDS.CREATION_DATE UPDATE_DATE, 
--            0 N_COMMENTS, 
--            0 IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
--            1 IS_FOLLOW_NEWS  -- thIS IS just a followed news 
--    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
--    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you' AND 
--            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
--);
--GO 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED;
--GO
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--);
--GO 
--
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--GO
--
-------------------------------------- 
---- B-4) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.their' 
--DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED;
--GO
--CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS ( 
--    SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID NEWS_STATUS_NETWORK_ID, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID READER_ID, 
--            NR_NEWS_RECORDS.ACTOR_UUID ACTOR_UUID, 
--            NR_NEWS_RECORDS.BRIEF_DESC BRIEF_DESC, 
--            NR_NEWS_RECORDS.ENTRY_URL ITEM_URL, 
--            NR_NEWS_RECORDS.EVENT_RECORD_UUID ITEM_ID, 
--            NR_NEWS_RECORDS.EVENT_NAME EVENT_NAME, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID TARGET_SUBJECT_ID, -- target subject 
--            1 IS_WALL_POST, -- IS wall post 
--            NR_NEWS_RECORDS.CREATION_DATE CREATION_DATE, 
--            NR_NEWS_RECORDS.CREATION_DATE UPDATE_DATE, 
--            0 N_COMMENTS, 
--            0 IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
--            1 IS_FOLLOW_NEWS  -- thIS IS just a followed news 
--    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
--    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you' AND 
--            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
--);
--GO 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED;
--GO
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--);
--GO 
--
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--GO

DROP VIEW  HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE; 
DROP VIEW  HOMEPAGE.PROFILE_SOURCES_NAME; 
DROP VIEW  HOMEPAGE.TMP_NETWORK; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWS; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWS_CONTAINER; 
DROP VIEW  HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWED_FILTERED;
GO
 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 1) END: MIGRATION FOR STATUS UPDATE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

---------------------------------------------------------------------------------- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
---------------------------------------------------------------------------------- 




---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 2) START: MIGRATION FOR FOLLOWED TAGS *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

-- INSERTING TAG RESOURCES WITH THE NAME 
INSERT INTO HOMEPAGE.NR_RESOURCE ( 
    RESOURCE_ID, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    CATEGORY_TYPE, 
    RESOURCE_TYPE 
) 
SELECT  SOURCE_ID, 
        'tag', 
        CONTAINER_ID,  
        CONTAINER_NAME, 
        '' , 
        10 , -- tags category typw 
        13 -- tag reSOURCE type 
FROM    HOMEPAGE.NR_SOURCE NR_SOURCE 
WHERE   NR_SOURCE.SOURCE = 'tag'; 
GO

-- CREATING THE FOLLOWS RELETIONSHIP FOR TAG 
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) FOLLOWS_ID, 
        PERSON_ID, 
        RESOURCE_ID 
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_RESOURCE NR_RESOURCE 
WHERE   NR_SUBSCRIPTION.IS_ACTIVE = 1 AND NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND 
        NR_RESOURCE.RESOURCE_ID = NR_SUBSCRIPTION.SOURCE_ID AND 
        NR_RESOURCE.CATEGORY_TYPE = 10; 

-- sanitize the SOURCE tag. moving tag to be tags 
update HOMEPAGE.NR_RESOURCE set SOURCE='tags' WHERE SOURCE='tag'; 
GO

---------------------------------------------------- 
-- WORKING ON NR_FOLLOWED_STORIES AND NR_STORIES 
---------------------------------------------------- 

-- creating a VIEW to see all the folloed tags 
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_TAGS AS ( 
    SELECT  PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID AND NR_RESOURCE.CATEGORY_TYPE = 10 
); 
GO

-- create a VIEW to see all the readed stories tags 
CREATE VIEW HOMEPAGE.TMP_READED_TAGS AS ( 
SELECT  SUBSTRING(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) + SUBSTRING(TMP_FOLLOWED_TAGS.PERSON_ID,1,18)              FOLLOWED_STORY_ID, 
        TMP_FOLLOWED_TAGS.PERSON_ID                 READER_ID, 
        10                                          CATEGORY_TYPE, 
        NR_NEWS_RECORDS.SOURCE                      SOURCE, 
        TMP_FOLLOWED_TAGS.CONTAINER_ID              CONTAINER_ID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           ITEM_ID, 
        13                                          RESOURCE_TYPE, 
        NR_NEWS_RECORDS.CREATION_DATE               CREATION_DATE, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           STORY_ID, 
        NR_NEWS_RECORDS.EVENT_NAME                  EVENT_NAME, 
        NR_NEWS_RECORDS.CONTAINER_NAME              CONTAINER_NAME, 
        NR_NEWS_RECORDS.CONTAINER_URL               CONTAINER_URL, 
        NR_NEWS_RECORDS.EVENT_NAME                  ITEM_NAME, 
        NR_NEWS_RECORDS.ENTRY_URL                   ITEM_URL, 
        NR_NEWS_RECORDS.ENTRY_ATOM_URL              ITEM_ATOM_URL, 
        ''                                          ITEM_CORRELATION_ID, 
        NR_NEWS_RECORDS.BRIEF_DESC                  BRIEF_DESC, 
        NR_NEWS_RECORDS.ACTOR_UUID                  ACTOR_UUID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           EVENT_RECORD_UUID, 
        NR_NEWS_RECORDS.TAGS                        TAGS, 
        NR_NEWS_RECORDS.META_TEMPLATE               META_TEMPLATE, 
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE          TEXT_META_TEMPLATE, 
        ''                                          R_META_TEMPLATE, 
        ''                                          R_TEXT_META_TEMPLATE, 
        0                                           N_COMMENTS, 
        0                                           N_RECOMMANDATIONS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,  HOMEPAGE.TMP_FOLLOWED_TAGS TMP_FOLLOWED_TAGS 
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND 
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND 
        NR_NEWS_RECORDS.SOURCE LIKE 'tag.%' AND 
        NR_NEWS_RECORDS.CONTAINER_ID = TMP_FOLLOWED_TAGS.CONTAINER_ID 
); 
GO

---- NR_STORIES insert stories releted to the tags 
--INSERT INTO HOMEPAGE.NR_STORIES ( 
--    STORY_ID, 
--    EVENT_NAME, 
--    SOURCE, 
--    CONTAINER_ID, 
--    CONTAINER_NAME, 
--    CONTAINER_URL, 
--    ITEM_NAME, 
--    ITEM_URL, 
--    ITEM_ID, 
--    ITEM_CORRELATION_ID, 
--    CREATION_DATE, 
--    BRIEF_DESC, 
--    ACTOR_UUID, 
--    EVENT_RECORD_UUID, 
--    TAGS, 
--    META_TEMPLATE, 
--    R_META_TEMPLATE, 
--    R_TEXT_META_TEMPLATE, 
--    N_COMMENTS, 
--    N_RECOMMANDATIONS 
--) 
--SELECT  TMP_READED_TAGS.STORY_ID, 
--        EVENT_NAME, 
--        SOURCE, 
--        CONTAINER_ID, 
--        CONTAINER_NAME, 
--        CONTAINER_URL, 
--        ITEM_NAME, 
--        ITEM_URL, 
--        ITEM_ID, 
--        ITEM_CORRELATION_ID, 
--        CREATION_DATE, 
--        BRIEF_DESC, 
--        ACTOR_UUID, 
--        EVENT_RECORD_UUID, 
--        TAGS, 
--        META_TEMPLATE, 
--        R_META_TEMPLATE, 
--        R_TEXT_META_TEMPLATE, 
--        N_COMMENTS, 
--        N_RECOMMANDATIONS 
--FROM    ( 
--        SELECT STORY_ID, MAX(FOLLOWED_STORY_ID) A_FOLLOWED_STORY_ID 
--        FROM HOMEPAGE.TMP_READED_TAGS TMP_READED_TAGS 
--        GROUP by TMP_READED_TAGS.STORY_ID 
--        )   TEMP_A, 
--        HOMEPAGE.TMP_READED_TAGS TMP_READED_TAGS 
--WHERE   TEMP_A.A_FOLLOWED_STORY_ID = TMP_READED_TAGS.FOLLOWED_STORY_ID; 
--GO
--
---- NR_FOLLOWED_STORIES insert readers for tags 
--INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
--    FOLLOWED_STORY_ID, 
--    READER_ID, 
--    CATEGORY_TYPE, 
--    SOURCE, 
--    CONTAINER_ID, 
--    ITEM_ID, 
--    RESOURCE_TYPE, 
--    CREATION_DATE, 
--    STORY_ID 
--) 
--SELECT      FOLLOWED_STORY_ID, 
--            READER_ID, 
--            CATEGORY_TYPE, 
--            SOURCE, 
--            CONTAINER_ID, 
--            ITEM_ID, 
--            RESOURCE_TYPE, 
--            CREATION_DATE, 
--            STORY_ID 
--FROM HOMEPAGE.TMP_READED_TAGS;    
--GO

DROP VIEW HOMEPAGE.TMP_READED_TAGS; 
DROP VIEW HOMEPAGE.TMP_FOLLOWED_TAGS;
GO 

---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 2) END: MIGRATION FOR FOLLOWED TAGS *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

---------------------------------------------------------------------------------- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
---------------------------------------------------------------------------------- 



---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 3) START: MIGRATION FOR FOLLOWED PEOPLE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
---------------------------------------------------- 
-- WORKING ON NR_FOLLOWED_STORIES AND NR_STORIES 
---------------------------------------------------- 

-- creating a VIEW to see all the folloed profiles 
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_PROFILES AS ( 
    SELECT  PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID AND NR_RESOURCE.CATEGORY_TYPE = 2 
); 
GO

-- create a VIEW to see all the readed stories tags 
CREATE VIEW HOMEPAGE.TMP_READED_PROFILES AS ( 
SELECT  SUBSTRING(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) + SUBSTRING(TMP_FOLLOWED_PROFILES.PERSON_ID,1,18)  FOLLOWED_STORY_ID, 
        TMP_FOLLOWED_PROFILES.PERSON_ID             READER_ID, 
        2                                           CATEGORY_TYPE, -- profiles 
        NR_NEWS_RECORDS.SOURCE                      SOURCE, 
        TMP_FOLLOWED_PROFILES.CONTAINER_ID          CONTAINER_ID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           ITEM_ID, 
        10                                          RESOURCE_TYPE, -- person 
        NR_NEWS_RECORDS.CREATION_DATE               CREATION_DATE, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           STORY_ID, 
        NR_NEWS_RECORDS.EVENT_NAME                  EVENT_NAME, 
        NR_NEWS_RECORDS.CONTAINER_NAME              CONTAINER_NAME, 
        NR_NEWS_RECORDS.CONTAINER_URL               CONTAINER_URL, 
        NR_NEWS_RECORDS.EVENT_NAME                  ITEM_NAME, 
        NR_NEWS_RECORDS.ENTRY_URL                   ITEM_URL, 
        NR_NEWS_RECORDS.ENTRY_ATOM_URL              ITEM_ATOM_URL, 
        ''                                          ITEM_CORRELATION_ID, 
        NR_NEWS_RECORDS.BRIEF_DESC                  BRIEF_DESC, 
        NR_NEWS_RECORDS.ACTOR_UUID                  ACTOR_UUID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           EVENT_RECORD_UUID, 
        NR_NEWS_RECORDS.TAGS                        TAGS, 
        NR_NEWS_RECORDS.META_TEMPLATE               META_TEMPLATE, 
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE          TEXT_META_TEMPLATE, 
        ''                                          R_META_TEMPLATE, 
        ''                                          R_TEXT_META_TEMPLATE, 
        0                                           N_COMMENTS, 
        0                                           N_RECOMMANDATIONS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,  HOMEPAGE.TMP_FOLLOWED_PROFILES TMP_FOLLOWED_PROFILES 
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL 
        AND ( 
                (NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.SOURCE = 'profiles' AND  NR_NEWS_RECORDS.CONTAINER_ID =  TMP_FOLLOWED_PROFILES.CONTAINER_ID ) 
                OR 
                (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND NR_NEWS_RECORDS.ACTOR_UUID = TMP_FOLLOWED_PROFILES.CONTAINER_ID) 
        ) 
);
GO

-- to have unique values 
CREATE VIEW HOMEPAGE.TMP_READED_PROFILES_FILTERED AS ( 
SELECT      FOLLOWED_STORY_ID, READER_ID, CATEGORY_TYPE, SOURCE, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, 
            CREATION_DATE, STORY_ID, EVENT_NAME, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL, ITEM_CORRELATION_ID, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, 
            TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, N_COMMENTS, N_RECOMMANDATIONS, MAX(FOLLOWED_STORY_ID) MAX_FOLLOWED_STORY_ID 
FROM        HOMEPAGE.TMP_READED_PROFILES TMP_READED_PROFILES 
GROUP BY    FOLLOWED_STORY_ID, READER_ID, CATEGORY_TYPE, SOURCE, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, 
            CREATION_DATE, STORY_ID, EVENT_NAME, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL, ITEM_CORRELATION_ID, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, 
            TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, N_COMMENTS, N_RECOMMANDATIONS 
); 
GO


CREATE VIEW HOMEPAGE.TMP_READED_STORIES_PROFILES AS ( 
    SELECT  TMP_READED_PROFILES_FILTERED.STORY_ID STORY_ID, 
        EVENT_NAME, 
        SOURCE, 
        CONTAINER_ID, 
        CONTAINER_NAME, 
        CONTAINER_URL, 
        ITEM_NAME, 
        ITEM_URL, 
        ITEM_ID, 
        ITEM_CORRELATION_ID, 
        CREATION_DATE, 
        BRIEF_DESC, 
        ACTOR_UUID, 
        EVENT_RECORD_UUID, 
        TAGS, 
        META_TEMPLATE, 
        R_META_TEMPLATE, 
        R_TEXT_META_TEMPLATE, 
        N_COMMENTS, 
        N_RECOMMANDATIONS 
    FROM    ( 
            SELECT STORY_ID, MAX(FOLLOWED_STORY_ID) A_FOLLOWED_STORY_ID 
            FROM HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
            GROUP by TMP_READED_PROFILES_FILTERED.STORY_ID 
            )   TEMP_A, 
            HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
    WHERE   TEMP_A.A_FOLLOWED_STORY_ID = TMP_READED_PROFILES_FILTERED.FOLLOWED_STORY_ID AND 
            TMP_READED_PROFILES_FILTERED.STORY_ID NOT in ( 
                                                    SELECT  NR_STORIES.STORY_ID STORY_ID 
                                                    FROM    HOMEPAGE.NR_STORIES NR_STORIES, 
                                                            HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
                                                    WHERE   TMP_READED_PROFILES_FILTERED.STORY_ID = TMP_READED_PROFILES_FILTERED.STORY_ID 
                                                ) 
);
GO 

---- NR_STORIES insert stories releted to the tags 
--INSERT INTO HOMEPAGE.NR_STORIES ( 
--    STORY_ID, 
--    EVENT_NAME, 
--    SOURCE, 
--    CONTAINER_ID, 
--    CONTAINER_NAME, 
--    CONTAINER_URL, 
--    ITEM_NAME, 
--    ITEM_URL, 
--    ITEM_ID, 
--    ITEM_CORRELATION_ID, 
--    CREATION_DATE, 
--    BRIEF_DESC, 
--    ACTOR_UUID, 
--    EVENT_RECORD_UUID, 
--    TAGS, 
--    META_TEMPLATE, 
--    R_META_TEMPLATE, 
--    R_TEXT_META_TEMPLATE, 
--    N_COMMENTS, 
--    N_RECOMMANDATIONS 
--) 
--SELECT  * 
--FROM HOMEPAGE.TMP_READED_STORIES_PROFILES; 
--GO
--
---- NR_FOLLOWED_STORIES insert readers for profiles 
--INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
--    FOLLOWED_STORY_ID, 
--    READER_ID, 
--    CATEGORY_TYPE, 
--    SOURCE, 
--    CONTAINER_ID, 
--    ITEM_ID, 
--    RESOURCE_TYPE, 
--    CREATION_DATE, 
--    STORY_ID 
--) 
--SELECT      FOLLOWED_STORY_ID, 
--            READER_ID, 
--            CATEGORY_TYPE, 
--            SOURCE, 
--            CONTAINER_ID, 
--            ITEM_ID, 
--            RESOURCE_TYPE, 
--            CREATION_DATE, 
--            STORY_ID 
--FROM HOMEPAGE.TMP_READED_PROFILES_FILTERED; 
--GO

DROP VIEW HOMEPAGE.TMP_FOLLOWED_PROFILES; 
DROP VIEW HOMEPAGE.TMP_READED_PROFILES; 
DROP VIEW HOMEPAGE.TMP_READED_PROFILES_FILTERED; 
DROP VIEW HOMEPAGE.TMP_READED_STORIES_PROFILES; 
GO
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 3) END: MIGRATION FOR FOLLOWED PEOPLE *********************** 
---------------------------------------------------------------------------------- 
----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- SPR #DMCE85VK79 Homepage: Upgrade/Migration 2.5.0.2 to 3.0 Beta1 - Person watchlisted in 2.5 display Follow link in Profiles 3.0 
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

--------------------------------------------------
-- 1) START WATCHLIST CASE (PERSON)
--------------------------------------------------

------------------------------------------------------------------------
-- A) WATCHLIST CASE (PERSON): ADDING SOURCES WITH NO STORIES LINKED
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_RESOURCE (
    RESOURCE_ID,
    SOURCE,
    CONTAINER_ID,
    CONTAINER_NAME,
    CONTAINER_URL,
    CATEGORY_TYPE,
    RESOURCE_TYPE,
    LAST_UPDATE
)
    SELECT  DISTINCT NR_SOURCE.SOURCE_ID         RESOURCE_ID,
            NR_SOURCE.SOURCE            SOURCE,
            NR_SOURCE.CONTAINER_ID      CONTAINER_ID,
            NR_SOURCE.CONTAINER_NAME    CONTAINER_NAME,
            NR_SOURCE.CONTAINER_URL     CONTAINER_URL,
            2                           CATEGORY_TYPE,
            10                          RESOURCE_TYPE,
            NR_SOURCE.LAST_UPDATE       LAST_UPDATE
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            HOMEPAGE.NR_SOURCE NR_SOURCE
    WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID AND
            NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
            NR_SOURCE.SOURCE = 'profiles' AND 
            NR_SOURCE.SOURCE_ID NOT IN      (   SELECT  NR_RESOURCE.RESOURCE_ID
                                                FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE 
                                            )
                                        	AND
			NR_SOURCE.CONTAINER_ID NOT IN 	(   SELECT  NR_RESOURCE.CONTAINER_ID
												FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE
											);
GO

------------------------------------------------------------------------
-- B) WATCHLIST CASE (PERSON):  CREATE A VIEW FOR WATCHLIST STORIES WHERE WE USE IS_ACTIVE = 1
------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
GO

------------------------------------------------------------------------
-- C) WATCHLIST CASE (PERSON):  INSERTING FOLLOWING RELETIONSHIP FOR PERSON
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER AND
        (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) NOT IN (
                                                                        SELECT FOLLOW_ID
                                                                        FROM HOMEPAGE.NR_FOLLOWS
                                                                    );
GO

DROP VIEW HOMEPAGE.TMP_FOLLOWS;

GO
--------------------------------------------------
-- 1) END WATCHLIST CASE (PERSON)
--------------------------------------------------

--------------------------------------------------
-- 2) START WATCHLIST CASE (TAGS)
--------------------------------------------------

------------------------------------------------------------------------
-- A) WATCHLIST CASE (TAGS): ADDING SOURCES WITH NO STORIES LINKED
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_RESOURCE (
    RESOURCE_ID,
    SOURCE,
    CONTAINER_ID,
    CONTAINER_NAME,
    CONTAINER_URL,
    CATEGORY_TYPE,
    RESOURCE_TYPE,
    LAST_UPDATE
)
    SELECT  DISTINCT NR_SOURCE.SOURCE_ID         RESOURCE_ID,
            NR_SOURCE.SOURCE            SOURCE,
            NR_SOURCE.CONTAINER_ID      CONTAINER_ID,
            NR_SOURCE.CONTAINER_NAME    CONTAINER_NAME,
            NR_SOURCE.CONTAINER_URL     CONTAINER_URL,
            10                          CATEGORY_TYPE,
            13                          RESOURCE_TYPE,
            NR_SOURCE.LAST_UPDATE       LAST_UPDATE
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            HOMEPAGE.NR_SOURCE NR_SOURCE
    WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID AND
            NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
            NR_SOURCE.SOURCE = 'tag' AND 
            NR_SOURCE.SOURCE_ID NOT IN      (   SELECT  NR_RESOURCE.RESOURCE_ID
                                                FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE 
                                            )
                                          	AND
			NR_SOURCE.CONTAINER_ID NOT IN 	(   SELECT  NR_RESOURCE.CONTAINER_ID
												FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE
											);
GO

------------------------------------------------------------------------
-- B) WATCHLIST CASE (TAGS):  CREATE A VIEW FOR WATCHLIST STORIES WHERE WE USE IS_ACTIVE = 1
------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE
            WHERE SOURCE = 'tag'
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
GO

------------------------------------------------------------------------
-- C) WATCHLIST CASE (TAGS):  INSERTING FOLLOWING RELETIONSHIP FOR PERSON
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER AND
        (SUBSTRING(PERSON_ID,1,18) + SUBSTRING(RESOURCE_ID,1,18)) NOT IN (
                                                                        SELECT FOLLOW_ID
                                                                        FROM HOMEPAGE.NR_FOLLOWS
                                                                    );
GO

DROP VIEW HOMEPAGE.TMP_FOLLOWS;

GO

UPDATE HOMEPAGE.NR_RESOURCE SET SOURCE='tags' WHERE SOURCE='tag'; 

GO
--------------------------------------------------
-- 2) END WATCHLIST CASE (TAGS)
--------------------------------------------------

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
-- START: CLEANUP DUPLICATED STORIES
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

-- if there are stories that are or in network or in follow we need to normalize them, putting to 1,1 and deleteing the dups
UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET IS_NETWORK_NEWS = 1, IS_FOLLOW_NEWS = 1 WHERE NEWS_STATUS_NETWORK_ID IN (
        SELECT  A.NEWS_STATUS_NETWORK_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND 
                A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 0 AND 
                B.IS_NETWORK_NEWS = 0 AND B.IS_FOLLOW_NEWS = 1 AND
                A.ITEM_ID = B.ITEM_ID
);

GO

DELETE FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE NEWS_STATUS_NETWORK_ID IN (
    SELECT NEWS_STATUS_NETWORK_ID
    FROM (
        SELECT  A.NEWS_STATUS_NETWORK_ID, B.IS_NETWORK_NEWS, B.IS_FOLLOW_NEWS
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 1 AND 
                B.IS_NETWORK_NEWS = 0 AND B.IS_FOLLOW_NEWS = 1 AND
                A.ITEM_ID = B.ITEM_ID
    ) TEMP
    WHERE TEMP.IS_NETWORK_NEWS = 0 AND TEMP.IS_FOLLOW_NEWS = 1
);

GO

DELETE FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE NEWS_STATUS_NETWORK_ID IN (
    SELECT NEWS_STATUS_NETWORK_ID
    FROM (
        SELECT  A.NEWS_STATUS_NETWORK_ID, B.IS_NETWORK_NEWS, B.IS_FOLLOW_NEWS
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 1 AND 
                B.IS_NETWORK_NEWS = 1 AND B.IS_FOLLOW_NEWS = 0 AND
                A.ITEM_ID = B.ITEM_ID
    ) TEMP
    WHERE TEMP.IS_NETWORK_NEWS = 1 AND TEMP.IS_FOLLOW_NEWS = 0
);

GO

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
-- END: CLEANUP DUPLICATED STORIES
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 40
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-------------------------------------------------------------------------------
-- START: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------
-- DROP FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP CONSTRAINT FK_F_STORY_ID;

DELETE FROM HOMEPAGE.NR_STORIES_CONTENT;
GO

DELETE FROM HOMEPAGE.NR_ORGPERSON_STORIES;
GO

DELETE FROM HOMEPAGE.NR_COMM_STORIES;
GO

DELETE FROM HOMEPAGE.NR_FOLLOWED_STORIES;
GO

DELETE FROM HOMEPAGE.NR_STORIES;
GO

DELETE FROM HOMEPAGE.NR_NEWS_DISCOVERY;
GO

DELETE FROM HOMEPAGE.NR_NEWS_SAVED;
GO

-- PUT BACK FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);
GO

-------------------------------------------------------------------------------
-- END: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

---------------------------------------------------------------------
-- START: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------
CREATE VIEW HOMEPAGE.DUPLICATED_CONTAINERS AS (
    select CONTAINER_ID, count(RESOURCE_TYPE) RESOURCE_COUNT
    from HOMEPAGE.NR_RESOURCE NR_RESOURCE
    group by CONTAINER_ID
    having  count(RESOURCE_TYPE) > 1
);
GO

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES AS (
    SELECT  NR_RESOURCE.RESOURCE_ID, NR_RESOURCE.SOURCE, NR_RESOURCE.CONTAINER_ID, NR_RESOURCE.CONTAINER_NAME, 
            NR_RESOURCE.CONTAINER_URL, NR_RESOURCE.CATEGORY_TYPE, NR_RESOURCE.RESOURCE_TYPE, NR_RESOURCE.LAST_UPDATE
    FROM    HOMEPAGE.DUPLICATED_CONTAINERS DUPLICATED_CONTAINERS, HOMEPAGE.NR_RESOURCE NR_RESOURCE
    WHERE   DUPLICATED_CONTAINERS.CONTAINER_ID = NR_RESOURCE.CONTAINER_ID
);
GO 

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE AS (
    SELECT CONTAINER_ID, MAX(RESOURCE_ID) MAX_RESOURCE_ID
    FROM HOMEPAGE.DUPLICATED_RESOURCES
    GROUP BY CONTAINER_ID
);
GO 

-- CLEANUP RECORDS: WE NEED TO REMOVE ALL THE RECORDS WITH MAX_RESOURCE_ID
-- A) REMOVE RECORDS FROM THE FOLLOWS TABLE TO DON'T BREAK FK CONSTRAINTS 
DELETE  FROM HOMEPAGE.NR_FOLLOWS 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
GO

-- B) REMOVE RECORDS FROM THE MASTER TABLE 
DELETE  FROM HOMEPAGE.NR_RESOURCE 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
GO

----------------------------------
-- REMOVE TMP VIEWS
----------------------------------
DROP VIEW HOMEPAGE.DUPLICATED_CONTAINERS;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE;
GO


-------------------------------------------
-- ADDING UNIQUE CONSTRAINTS
-------------------------------------------
-- RESOURCE_TYPE NOT NULL
-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--    ALTER COLUMN RESOURCE_TYPE 
--    NUMERIC(5,0) NOT NULL;

--REORG TABLE HOMEPAGE.NR_RESOURCE USE NEWS4TMPTABSPACE; 

-- UNIQUE CONSTRAINT
-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);
	
---------------------------------------------------------------------
-- END: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

------------------------------------------------------------
-- START: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-- NR_NEWS_SAVED
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_RESOURCE
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_FOLLOWED_STORIES
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_COMM_STORIES
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

-- NR_ORGPERSON_STORIES
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);


------------------------------------------------------------
-- END: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-------------------------------------------------------------------------
-- START: INIT EMD_TRANCHE
-------------------------------------------------------------------------

-- EMD_TRANCHE 1
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_1_KwZTaR7aAiPFw4L08CyRW', 'tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 2
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_2_KwZTaR7aAiPFw4L08CyRW','tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 3
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_3_KwZTaR7aAiPFw4L08CyRW','tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 4
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 4, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_4_KwZTaR7aAiPFw4L08CyRW','tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 5
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_5_KwZTaR7aAiPFw4L08CyRW','tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 6
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 6, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_6_KwZTaR7aAiPFw4L08CyRW','tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 7
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_7_KwZTaR7aAiPFw4L08CyRW','tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 8
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_8_KwZTaR7aAiPFw4L08CyRW','tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 9
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 9, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_9_KwZTaR7aAiPFw4L08CyRW','tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 10
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_10_wZTaR7aAiPFw4L08CyRW','tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 11
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_11_wZTaR7aAiPFw4L08CyRW','tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 12
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 12, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_12_wZTaR7aAiPFw4L08CyRW','tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 13
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 13, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_13_wZTaR7aAiPFw4L08CyRW','tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 14
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 14, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_14_wZTaR7aAiPFw4L08CyRW','tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 15
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_15_wZTaR7aAiPFw4L08CyRW','tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 16
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 16, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_16_wZTaR7aAiPFw4L08CyRW','tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 17
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 17, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_17_wZTaR7aAiPFw4L08CyRW','tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 18
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 18, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_18_wZTaR7aAiPFw4L08CyRW','tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 19
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 19, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_19_wZTaR7aAiPFw4L08CyRW','tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 20
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_20_wZTaR7aAiPFw4L08CyRW','tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);


-------------------------------------------------------------------------
-- END: INIT EMD_TRANCHE
-------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 41
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- NR_FOLLOWS
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_RESOURCE.SOURCE, HOMEPAGE.NR_RESOURCE.CONTAINER_ID, HOMEPAGE.NR_RESOURCE.CONTAINER_NAME, HOMEPAGE.NR_RESOURCE.CONTAINER_URL, 
--        HOMEPAGE.NR_RESOURCE.CATEGORY_TYPE, HOMEPAGE.NR_RESOURCE.RESOURCE_TYPE FROM HOMEPAGE.NR_FOLLOWS INNER JOIN HOMEPAGE.NR_RESOURCE ON 
--        HOMEPAGE.NR_FOLLOWS.RESOURCE_ID = HOMEPAGE.NR_RESOURCE.RESOURCE_ID 
--WHERE   HOMEPAGE.NR_FOLLOWS.PERSON_ID = ? 
--ORDER BY HOMEPAGE.NR_RESOURCE.CONTAINER_NAME
--CREATE INDEX NR_FOLLOWS_IDX
--    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID, PERSON_ID);

CREATE INDEX NR_FOLLOWS_PERS
    ON HOMEPAGE.NR_FOLLOWS (PERSON_ID);

-- SELECT PERSON_ID 
-- FROM HOMEPAGE.NR_FOLLOWS 
-- WHERE RESOURCE_ID = ?
CREATE INDEX NR_FOLLOWS_RES
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID);

-----------------------------------------------------------------------------------
-- NR_NETWORK
-----------------------------------------------------------------------------------
-- SELECT COLLEAGUE_ID 
-- FROM HOMEPAGE.NR_NETWORK 
-- WHERE PERSON_ID = ?
CREATE INDEX NR_NETWORK_PERS
    ON HOMEPAGE.NR_NETWORK (PERSON_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
-----------------------------------------------------------------------------------
CREATE INDEX NR_NEWS_SC_ITEM_COR
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_CORRELATION_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_NEWS_STATUS_COMMENT.NEWS_STATUS_COMMENT_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ACTOR_UUID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.CREATION_DATE,
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.BRIEF_DESC, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID, 
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_URL, HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID FROM HOMEPAGE.NR_NEWS_STATUS_COMMENT, 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE   HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID = HOMEPAGE.NR_NEWS_STATUS_NETWORK.ITEM_ID AND 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID = ? 
--ORDER BY HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID
CREATE INDEX NR_NEWS_STATUS_NETWORK_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (ITEM_ID);

--SELECT  NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE READER_ID=? AND IS_FOLLOW_NEWS = 1 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_FOLLOW_NEWS);

CREATE INDEX NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_NETWORK_NEWS);

-- *
--SELECT NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE READER_ID=? ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID);


-----------------------------------------------------------------------------------
-- NR_NEWS_SAVED
-----------------------------------------------------------------------------------
-- SELECT * 
-- FROM HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? AND CREATION_DATE >= ?

-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
--         TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY


-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, 
--         META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE   READER_ID = ? AND SOURCE = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_SAVED_READER
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID);

CREATE INDEX NR_NEWS_SAVED_READER_SRC
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID, SOURCE);

-----------------------------------------------------------------------------------
-- NR_NEWS_DISCOVERY
-----------------------------------------------------------------------------------
-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, ENTRY_ATOM_URL, CREATION_DATE, 
--        BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, 
--        ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
--FROM    HOMEPAGE.NR_NEWS_DISCOVERY 
--WHERE   SOURCE = ? 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_DISCOVERY_CREAT
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC);

CREATE INDEX NR_NEWS_DISCOVERY_CREAT_SOURCE
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, SOURCE);

-----------------------------------------------------------------------------------
-- NR_FOLLOWED_STORIES
-----------------------------------------------------------------------------------
-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES 
-- WHERE READER_ID = ?
CREATE INDEX NR_FOLLOWED_STORIES_READER
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID);

-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES WHERE 
-- READER_ID = ? AND CATEGORY_TYPE = ?
CREATE INDEX NR_FOLLOWED_STORIES_READER_CAT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CATEGORY_TYPE);

CREATE INDEX NR_FS_READER_CONT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CONTAINER_ID);

CREATE INDEX NR_FOLLOWED_STORIES_STORY_ID
    ON HOMEPAGE.NR_FOLLOWED_STORIES (STORY_ID);

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE INDEX NR_NEWS_COMMENT_CONTENT_ID
    ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT (NEWS_STATUS_COMMENT_ID);

----------------------------------------------------------------------
-- NR_RESOURCE
----------------------------------------------------------------------
-- SELECT  * 
-- FROM    HOMEPAGE.NR_RESOURCE 
-- WHERE   RESOURCE_TYPE = ? AND CONTAINER_ID = ?
CREATE INDEX NR_RESOURCE_TYPE_CONT
    ON HOMEPAGE.NR_RESOURCE (RESOURCE_TYPE, CONTAINER_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_FOLLOW 
----------------------------------------------------------------------
CREATE INDEX NR_COMM_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (PERSON_ID);

CREATE INDEX NR_COMM_FOLLOW_COM_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (COMMUNITY_ID);     

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_FOLLOW
----------------------------------------------------------------------
CREATE INDEX NR_ORGPERSON_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_ORGPERSON_FOLLOW (PERSON_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE INDEX NR_COMM_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_STORIES (STORY_ID);

CREATE INDEX NR_COMM_STORIES_COM_ID
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID);    

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE INDEX NR_ORGPERSON_STORIES_STORY_ID
    ON HOMEPAGE.NR_ORGPERSON_STORIES (STORY_ID);

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 43
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256);

ALTER TABLE HOMEPAGE.NR_RESOURCE DROP CONSTRAINT UNIQUE_RES;
DROP INDEX NR_RESOURCE_TYPE_CONT ON HOMEPAGE.NR_RESOURCE;

ALTER TABLE HOMEPAGE.NR_RESOURCE
    ALTER COLUMN CONTAINER_ID 
    nvarchar(256) NOT NULL;

ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);

CREATE INDEX NR_RESOURCE_TYPE_CONT
    ON HOMEPAGE.NR_RESOURCE (RESOURCE_TYPE, CONTAINER_ID);

-- NEWS REPOSITORY
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SOURCE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SUBSCRIPTION TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_RECORDS TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_TEMPLATE TO HOMEPAGEUSER
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_LMGR TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_LMPR TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_TASK TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_TREG TO HOMEPAGEUSER
GO


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY_TYPE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_SAVED TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_DISCOVERY TO HOMEPAGEUSER
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_COMMENT TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO HOMEPAGEUSER
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE_TYPE  TO HOMEPAGEUSER
GO	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE  TO HOMEPAGEUSER  
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWS  TO HOMEPAGEUSER	
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_FOLLOW  TO HOMEPAGEUSER	  
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_FOLLOW  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO HOMEPAGEUSER    
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES_CONTENT  TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NETWORK  TO HOMEPAGEUSER
GO	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_FREQUENCY_TYPE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_RESOURCE_PREF TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE_INFO TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_EMAIL_PREFS TO HOMEPAGEUSER
GO    

	   
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE UPGRADE30 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 30-32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- HOMEPAGE.SR_FILESCONTENT
------------------------------------------------

-- SPR# MPML7UVM9X
-- Missing index on SR_FILESCONTENT causes full table scan
CREATE INDEX SR_FILESCONTENT_IS_CURRENT_IDX 
ON HOMEPAGE.SR_FILESCONTENT(IS_CURRENT);
GO

DELETE FROM HOMEPAGE.SR_FILESCONTENT
GO

------------------------------------------------
-- HOMEPAGE.SR_FILECONTENTTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FILECONTENTTASKDEF (
	FILECONTENT_TASK_ID NVARCHAR(36) NOT NULL,	
	TASK_ID NVARCHAR(36) NOT NULL,
	FILE_CONTENT_TASK_SERVICES NVARCHAR(256) NOT NULL,
	CONTENT_FAILURES_ONLY NUMERIC(5,0) NOT NULL	
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT PK_FC_TASK_ID PRIMARY KEY (FILECONTENT_TASK_ID)
GO

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT UNIQUE_TASK_ID_FC UNIQUE (TASK_ID)
GO
	
ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT FK_FC_TASK_ID FOREIGN KEY (TASK_ID) 
	REFERENCES  HOMEPAGE.SR_TASKDEF(TASK_ID) ON DELETE CASCADE
GO


------------------------------------------------
-- HOMEPAGE.SR_BACKUPTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_BACKUPTASKDEF (
	BACKUP_TASK_ID NVARCHAR(36) NOT NULL,	
	TASK_ID NVARCHAR(36) NOT NULL,
	TYPE NVARCHAR(36) NOT NULL,
	SCRIPT NVARCHAR(256)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT PK_BKUP_TASK_ID PRIMARY KEY (BACKUP_TASK_ID)	
GO	

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT UNIQUE_TASK_ID_BKP UNIQUE (TASK_ID)
GO
	
ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT FK_BKUP_TASK_ID FOREIGN KEY (TASK_ID) 
	REFERENCES  HOMEPAGE.SR_TASKDEF(TASK_ID) ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_ALLTASKSDEF
------------------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF
GO

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID					 		
)
GO

------------------------------------------------
-- HOMEPAGE.SR_INDEX_MANAGEMENT
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_MANAGEMENT (
	NODE_ID NVARCHAR(36) NOT NULL,
	LAST_CRAWLING_VERSION NUMERIC(19,0) NOT NULL,
	OUT_OF_DATE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
	ADD CONSTRAINT PK_INDEX_MGMT_ID PRIMARY KEY (NODE_ID)
GO	

------------------------------------------------
-- HOMEPAGE.SR_RESUME_TOKENS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_RESUME_TOKENS (
	TOKEN_ID NVARCHAR(36) NOT NULL,
	NODE_ID NVARCHAR(36) NOT NULL,
	TOKEN NVARCHAR(256) NOT NULL,
	SERVICE NVARCHAR(36) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT PK_TOKEN_ID PRIMARY KEY (TOKEN_ID)
GO	

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT FK_RT_IDX_MGMT_ID FOREIGN KEY (NODE_ID)
	REFERENCES HOMEPAGE.SR_INDEX_MANAGEMENT(NODE_ID) ON DELETE CASCADE
GO	

------------------------------------------------
-- HOMEPAGE.SR_INDEX_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_DOCS(
	DOCUMENT_ID NVARCHAR(36) NOT NULL,
	DOCUMENT VARBINARY(MAX) NOT NULL,
	CRAWLING_VERSION NUMERIC(19,0) NOT NULL,
	ACTION NUMERIC(5,0) NOT NULL,
	UPDATE_TIME  DATETIME NOT NULL,
	RESUME_POINT NVARCHAR(256),
	SERVICE NVARCHAR(36) NOT NULL,
	FILESCONTENT_ID NVARCHAR(36)
) ON [PRIMARY]
GO
ALTER TABLE HOMEPAGE.SR_INDEX_DOCS
	ADD CONSTRAINT PK_INDEX_DOCS_ID PRIMARY KEY (DOCUMENT_ID)
GO	

CREATE INDEX SR_INDEX_DOCS_CRAWL_VERSION_IDX
	ON HOMEPAGE.SR_INDEX_DOCS (CRAWLING_VERSION)
GO

------------------------------------------------
-- HOMEPAGE.SR_FACET_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FACET_DOCS(
	FACET_ID NVARCHAR(36) NOT NULL,
	DOCUMENT_ID NVARCHAR(36) NOT NULL,
	FACET VARBINARY(MAX) NOT NULL,
	CRAWLING_VERSION NUMERIC(19,0) NOT NULL
) ON [PRIMARY]
GO


	
ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT PK_FACET_DOCS_ID PRIMARY KEY (FACET_ID)
GO

ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT FK_IDX_DOC_ID FOREIGN KEY (DOCUMENT_ID) 
	REFERENCES  HOMEPAGE.SR_INDEX_DOCS(DOCUMENT_ID) ON DELETE CASCADE
GO	

	
CREATE INDEX SR_FACET_DOCS_PARENT_IDX
	ON HOMEPAGE.SR_FACET_DOCS (DOCUMENT_ID)
GO
	

------------------------------------------
-- START GRANTS
------------------------------------------

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FILECONTENTTASKDEF TO HOMEPAGEUSER;
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_DOCS TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FACET_DOCS TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_RESUME_TOKENS TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_BACKUPTASKDEF TO HOMEPAGEUSER
GO
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_MANAGEMENT TO HOMEPAGEUSER
GO
	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

----------------------------------------
--  SR_SANDTASKDEF
----------------------------------------

CREATE TABLE HOMEPAGE.SR_SANDTASKDEF (
	SAND_TASK_ID NVARCHAR(36) NOT NULL,
	TASK_ID NVARCHAR(36) NOT NULL,
	SAND_TASK_SERVICES NVARCHAR(256) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT PK_ST_TASK_ID PRIMARY KEY (SAND_TASK_ID)
GO

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT UNIQUE_TASK_ID_ST UNIQUE (TASK_ID)
GO
	
ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT FK_ST_TASK_ID FOREIGN KEY (TASK_ID) 
	REFERENCES  HOMEPAGE.SR_TASKDEF(TASK_ID) ON DELETE CASCADE
GO

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED) VALUES('ea789e87-c262-484b-92f4-d60af4bef3d4','nightly-sand-task','0 15 1 * * ?','0 0 1 * * ?','SaNDTask',1);

INSERT INTO HOMEPAGE.SR_SANDTASKDEF(SAND_TASK_ID,TASK_ID,SAND_TASK_SERVICES) VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fb','ea789e87-c262-484b-92f4-d60af4bef3d4','evidence-graph-manageremployees-tags-taggedby');
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_SANDTASKDEF TO HOMEPAGEUSER
GO

----------------------------------------
--  SR_ALLTASKSDEF
----------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF
GO

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS	FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
        ''                  	AS  SAND_TASK_ID,
	''							AS	SAND_TASK_SERVICES,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS 	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
        ''                 	AS  SAND_TASK_ID,
	''                      AS  SAND_TASK_SERVICES,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
        ''                  		AS  SAND_TASK_ID,
	''                      		AS  SAND_TASK_SERVICES,
	'' 								AS  BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	''                  	AS  SAND_TASK_ID,
	''                      AS  SAND_TASK_SERVICES,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
)
UNION
(
        SELECT T9.TASK_ID              AS   PARENT_TASK_ID,
        T9.TASK_NAME                   AS   PARENT_TASK_NAME,
        T9.INTERVAL                    AS   PARENT_TASK_INTERVAL,
        T9.STARTBY                     AS   PARENT_TASK_STARTBY,
        T9.TASK_TYPE                   AS   PARENT_TASK_TYPE,
        T9.ENABLED                     AS   PARENT_TASK_ENABLED,
        ''                             AS   INDEXING_TASK_SERVICES,
        0                              AS   INDEXING_TASK_OPTIMIZE,
        ''                             AS   INDEXING_TASK_ID,
        ''                             AS   OPTIMIZE_TASK_ID,
        ''                             AS   FILECONTENT_TASK_ID,
        ''                             AS   FILE_CONTENT_TASK_SERVICES,
        0                              AS   CONTENT_FAILURES_ONLY,
        T10.SAND_TASK_ID               AS   SAND_TASK_ID,
		T10.SAND_TASK_SERVICES		   AS	SAND_TASK_SERVICES,
        ''                             AS   BACKUP_TASK_ID,
        ''                             AS   BACKUP_TASK_TYPE,
        ''                             AS   BACKUP_TASK_SCRIPT,
        T10.SAND_TASK_ID               AS   CHILDTASK_PK
        FROM   HOMEPAGE.SR_TASKDEF T9,HOMEPAGE.SR_SANDTASKDEF T10
        WHERE  T9.TASK_ID=T10.TASK_ID
)
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO HOMEPAGEUSER
GO

---------------------------------------------------------------------------------
------------------------ END SEARCH -------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=LOWER(INDEXING_TASK_SERVICES)
GO

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES='all_configured' 
WHERE INDEXING_TASK_ID='315a416c-78e2-4cf4-bcb2-69eb8d3a2583';
GO

UPDATE  HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=INDEXING_TASK_SERVICES+'-forums'
WHERE   INDEXING_TASK_SERVICES LIKE '%communities%' AND INDEXING_TASK_SERVICES NOT LIKE '%forums%'
GO

----------------------------------------
--  SR_RESUME_TOKENS
----------------------------------------


ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS 
ALTER COLUMN TOKEN NVARCHAR(256) NULL
GO


	
----------------------------------------
--  SR_FEEDBACK
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK (
	ID NVARCHAR(36) NOT NULL,
	PERSON_ID  NVARCHAR(36) NOT NULL,
	CLIENT_ID VARCHAR(256) NOT NULL,
	ACTION VARCHAR(256) NOT NULL,
	FEEDBACK_TIME DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
	ITEM_ID  VARCHAR(256) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT PK_FEEDBACK_ID PRIMARY KEY (ID)
GO	
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT FK_SRFB_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID)
GO	
	

CREATE INDEX SR_FEEDBACK_CLIENT_IDX
		ON HOMEPAGE.SR_FEEDBACK (CLIENT_ID)
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK TO HOMEPAGEUSER
----------------------------------------
--  SR_FEEDBACK_CONTEXT
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT (
	CONTEXT_ID NVARCHAR(36) NOT NULL,
	ID NVARCHAR(36) NOT NULL,
	TYPE  VARCHAR(256) NOT NULL,
	TYPE_VALUE VARCHAR(256) NOT NULL,
	WEIGHT VARCHAR(256) NOT NULL
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT PK_FBK_CTXT_ID PRIMARY KEY (CONTEXT_ID)
GO	

ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT FK_FBK_CTXT_ID FOREIGN KEY (ID)
	REFERENCES HOMEPAGE.SR_FEEDBACK(ID) ON DELETE CASCADE
GO	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_CONTEXT TO HOMEPAGEUSER
GO

----------------------------------------
--  SR_FEEDBACK_PARAMETERS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS (
	PARAMETERS_ID NVARCHAR(36) NOT NULL,
	ID NVARCHAR(36) NOT NULL,
	PARAM  VARCHAR(256) NOT NULL,
	PARAM_VALUE VARCHAR(256) NOT NULL
) ON [PRIMARY]
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT PK_FBK_PARAMS_ID PRIMARY KEY (PARAMETERS_ID)
GO	
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT FK_FBK_PARAMS_ID FOREIGN KEY (ID)
	REFERENCES HOMEPAGE.SR_FEEDBACK(ID) ON DELETE CASCADE
GO	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_PARAMETERS TO HOMEPAGEUSER
GO
----------------------------------------
--  SR_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STATS(
	STAT_ID		NVARCHAR(36) NOT NULL,
	STAT_KEY 	NVARCHAR(256) NOT NULL,
	STAT_TYPE	NUMERIC(5,0) NOT NULL,
	UPDATED		DATETIME NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT PK_SR_STAT_ID PRIMARY KEY (STAT_ID)
GO	

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT UNIQUE_STAT_KEY UNIQUE (STAT_KEY)
GO	


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STATS TO HOMEPAGEUSER
GO
----------------------------------------
--  SR_STRING_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STRING_STATS(
	STRING_STAT_ID		NVARCHAR(36) NOT NULL,
	STAT_ID				NVARCHAR(36) NOT NULL,
	STAT_VALUE			NVARCHAR(256)  NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT PK_STR_STAT_ID PRIMARY KEY (STRING_STAT_ID)
GO	

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT FK_STR_STAT_ID FOREIGN KEY (STAT_ID)
	REFERENCES HOMEPAGE.SR_STATS(STAT_ID) ON DELETE CASCADE
GO	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STRING_STATS TO HOMEPAGEUSER
GO
----------------------------------------
--  SR_NUMBER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_NUMBER_STATS(
	NUMBER_STAT_ID		NVARCHAR(36) NOT NULL,
	STAT_ID				NVARCHAR(36) NOT NULL,
	STAT_VALUE			NUMERIC(19,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT PK_NUM_STAT_ID PRIMARY KEY (NUMBER_STAT_ID)
GO	


ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT FK_NUM_STAT_ID FOREIGN KEY (STAT_ID)
	REFERENCES HOMEPAGE.SR_STATS(STAT_ID) ON DELETE CASCADE
GO	
	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_NUMBER_STATS TO HOMEPAGEUSER
GO

----------------------------------------
--  SR_TIMER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_TIMER_STATS(
	TIMER_STAT_ID		NVARCHAR(36) NOT NULL,
	STAT_ID				NVARCHAR(36) NOT NULL,
	AVERAGE				NUMERIC(19,0) NOT NULL,
	MINIMUM				NUMERIC(19,0) NOT NULL,
	MAXIMUM				NUMERIC(19,0) NOT NULL,
	COUNTER				NUMERIC(5,0)	NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT PK_TMR_STAT_ID PRIMARY KEY (TIMER_STAT_ID)
GO	
	
ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT FK_TMR_STAT_ID FOREIGN KEY (STAT_ID)
	REFERENCES HOMEPAGE.SR_STATS(STAT_ID) ON DELETE CASCADE
GO	


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_TIMER_STATS TO HOMEPAGEUSER
GO

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 40
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------


UPDATE  HOMEPAGE.SR_SANDTASKDEF SET SAND_TASK_SERVICES='evidence-graph-manageremployees-tags-taggedby-communitymembership'
WHERE SAND_TASK_ID='fd44131a-5075-4bcb-85a9-9e501bd010fb';


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 42
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_TASKDEF
----------------------------------------

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('111111-1111-1111-1111-1111111FCRT','20min-file-retrieval-task','0 10/20 0-23 * * ?','0 1/20 0-23 * * ?','FileContentRetrievalTask',1);

----------------------------------------
--  SR_FILECONTENTTASKDEF
----------------------------------------

INSERT INTO HOMEPAGE.SR_FILECONTENTTASKDEF(FILECONTENT_TASK_ID,TASK_ID,FILE_CONTENT_TASK_SERVICES,CONTENT_FAILURES_ONLY)
VALUES('111111-1111-1111-1111-1111111FCRT','111111-1111-1111-1111-1111111FCRT','all_configured',0);

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEX_MANAGEMENT
----------------------------------------

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS
GO

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT
GO

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS DROP CONSTRAINT FK_RT_IDX_MGMT_ID
GO

DROP TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
GO

CREATE TABLE HOMEPAGE.SR_INDEX_MANAGEMENT (
	NODE_ID NVARCHAR(256) NOT NULL,
	LAST_CRAWLING_VERSION NUMERIC(19,0) NOT NULL,
	OUT_OF_DATE NUMERIC(5,0) NOT NULL,
	INDEXER  NUMERIC(5,0)  DEFAULT 1 NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
	ADD CONSTRAINT PK_INDEX_MGMT_ID PRIMARY KEY (NODE_ID)
GO	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_MANAGEMENT TO HOMEPAGEUSER
GO

----------------------------------------
--  HOMEPAGE.SR_RESUME_TOKENS
----------------------------------------

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
ALTER COLUMN NODE_ID NVARCHAR(256) NOT NULL;
GO

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT FK_RT_IDX_MGMT_ID FOREIGN KEY (NODE_ID)
	REFERENCES HOMEPAGE.SR_INDEX_MANAGEMENT(NODE_ID) ON DELETE CASCADE
GO	

----------------------------------------
--  SR_LOTUSCONNECTIONS*
----------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

CREATE INDEX SR_INDEX_DOCS_RPS_IDX
    ON HOMEPAGE.SR_INDEX_DOCS (RESUME_POINT,SERVICE);
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
GO

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
GO

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
GO

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
GO

DELETE FROM HOMEPAGE.SR_STATS;
GO

DELETE FROM HOMEPAGE.SR_STRING_STATS;
GO

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
GO

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 55
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------ START FIX FOR PMAN89HG7Z ------ 

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/15 0,2-23 * * ?',INTERVAL='0 1/15 0,2-23 * * ?' WHERE TASK_NAME='15min-search-indexing-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/20 0,2-23 * * ?',INTERVAL='0 1/20 0,2-23 * * ?' WHERE TASK_NAME='20min-file-retrieval-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 5 1 * * ?',INTERVAL='0 0 1 * * ?' WHERE TASK_NAME='nightly-sand-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 35 1 * * ?',INTERVAL='0 30 1 * * ?' WHERE TASK_NAME='nightly-optimize-task';


------ END FIX FOR PMAN89HG7Z ------ 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- CLEAR SCHEDULERS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- NEWS

DELETE FROM HOMEPAGE.NR_SCHEDULER_TASK;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_TREG;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMGR;
GO
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMPR;
GO




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
GO
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 43
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 43 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 20;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;