-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

------------------------------------------------
-- INCLUDE UPGRADE30 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 23;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START HOMEPAGE ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- PERSON
------------------------------------------------

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN IS_ACTIVE SMALLINT DEFAULT 1;

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN USER_MAIL_LOWER VARCHAR(256);

UPDATE HOMEPAGE.PERSON SET USER_MAIL_LOWER =  lower(USER_MAIL);

COMMIT;

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN DISPLAYNAME_LOWER VARCHAR(256);	

UPDATE HOMEPAGE.PERSON SET DISPLAYNAME_LOWER =  lower(DISPLAYNAME);

COMMIT;

-- DROP SNCORE_PERSON
-- in 2.5 it didn't exist
-- DROP VIEW HOMEPAGE.SNCORE_PERSON;
	
CREATE INDEX HOMEPAGE.PERSON_USER_MAIL_LWR
    ON HOMEPAGE.PERSON(USER_MAIL_LOWER ASC);

CREATE INDEX HOMEPAGE.PERSON_DISPLAYNAME_LWR
    ON HOMEPAGE.PERSON(DISPLAYNAME_LOWER ASC);

runstats on table HOMEPAGE.PERSON with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_TAB with distribution and detailed indexes all allow write access;

------------------------------------------------
-- SNCORE_PERSON
------------------------------------------------

CREATE VIEW HOMEPAGE.SNCORE_PERSON (SNC_INTERNAL_ID, SNC_IDKEY, SNC_EMAIL_LOWER, SNC_DISPLAY_NAME) 
    AS SELECT PERSON_ID, EXID, USER_MAIL_LOWER, DISPLAYNAME FROM HOMEPAGE.PERSON;		


------------------------------------------------
-- HP_TAB
------------------------------------------------

ALTER TABLE HOMEPAGE.HP_TAB
	ADD COLUMN ENABLED SMALLINT DEFAULT 1;

---------------------------------------------------------------------------------
---------------- END UPDATE HOMEPAGE DATABASE ----------------    
--------------------------------------------------------------


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 30;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Update HOMEPAGE.PERSON  
ALTER TABLE HOMEPAGE.PERSON
ADD STATE SMALLINT DEFAULT 0 NOT NULL;

-- 2) CHANGE HOMEPAGE.NT_NOTIFICATION to be with this size: 16K

-- b) backup the NOTIFICATION table 
------------------------------------------------
-- BK into TMP_NOTIFICATION
------------------------------------------------
CREATE TABLE HOMEPAGE.TMP_NOTIFICATION  (
	  NOTIFICATION_ID VARCHAR(36) NOT NULL,
	  NOTIFICATION_SOURCE VARCHAR(36) NOT NULL,
	  NOTIFICATION_TYPE VARCHAR(256) NOT NULL,
	  DATETIME_STAMP TIMESTAMP NOT NULL,
	  SENDER_EXID VARCHAR(36) NOT NULL,
	  SUBJECT VARCHAR(256),
	  MESSAGE VARCHAR(2048),
	  CONTAINER_NAME VARCHAR(256),
	  CONTAINER_URL VARCHAR(2048),
	  ITEM_NAME VARCHAR(256),
	  ITEM_URL VARCHAR(2048) 
)
IN HPNT16TABSPACE;

INSERT INTO HOMEPAGE.TMP_NOTIFICATION (     NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL)    
SELECT  NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL
FROM HOMEPAGE.NT_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT DROP FOREIGN KEY "FK_RECIP_NOTIF";

DROP TABLE HOMEPAGE.NT_NOTIFICATION;

CREATE TABLE HOMEPAGE.NT_NOTIFICATION  (
	  NOTIFICATION_ID VARCHAR(36) NOT NULL,
	  NOTIFICATION_SOURCE VARCHAR(36) NOT NULL,
	  NOTIFICATION_TYPE VARCHAR(256) NOT NULL,
	  DATETIME_STAMP TIMESTAMP NOT NULL,
	  SENDER_EXID VARCHAR(36) NOT NULL,
	  SUBJECT VARCHAR(256),
	  MESSAGE VARCHAR(2048),
	  CONTAINER_NAME VARCHAR(256),
	  CONTAINER_URL VARCHAR(2048),
	  ITEM_NAME VARCHAR(256),
	  ITEM_URL VARCHAR(2048) 
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ADD CONSTRAINT "PK_NOTIFICATION" PRIMARY KEY ("NOTIFICATION_ID");

CREATE INDEX HOMEPAGE.NT_NOTIFICATION_EXID_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(SENDER_EXID);	

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NT_NOTIFICATION;

INSERT INTO HOMEPAGE.NT_NOTIFICATION (     NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL)    
SELECT  NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL
FROM HOMEPAGE.TMP_NOTIFICATION;

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NT_NOTIFICATION;

DROP TABLE HOMEPAGE.TMP_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
	ADD CONSTRAINT "FK_RECIP_NOTIF" FOREIGN KEY ("NOTIFICATION_ID")
	REFERENCES HOMEPAGE.NT_NOTIFICATION ("NOTIFICATION_ID")
	ON DELETE CASCADE;
	

-- b) update the NT_NOTIFICATION table
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD FIRST_RECIPIENT_EXID VARCHAR(36);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD NUM_RECIPIENTS SMALLINT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD IS_DELETED SMALLINT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD PRIMARY_ACTION_URL VARCHAR(2048);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD SECONDARY_ACTION_URL VARCHAR(2048);

--c) update NT_RECIPIENTS table
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
ADD IS_DELETED SMALLINT;

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------
-- 9 MIGRATION FOR NT_NOTIFICATION TABLES
-----------------------------------------------------

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT SET IS_DELETED = 0;

-- create temp view
CREATE VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT AS (
    select      NT_NOTIFICATION.NOTIFICATION_ID, COUNT(NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID) AS RECIPIENT_COUNT
    from        HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, 
                HOMEPAGE.NT_NOTIFICATION_RECIPIENT NT_NOTIFICATION_RECIPIENT
    where       NT_NOTIFICATION.NOTIFICATION_ID = NT_NOTIFICATION_RECIPIENT.NOTIFICATION_ID
    group by    NT_NOTIFICATION.NOTIFICATION_ID
);


CREATE VIEW HOMEPAGE.TEMP_FIND_RECIPIENT AS (
    select NOTIFICATION_ID, MAX(RECIPIENT_EXID) RECIPIENT_EXID
    from HOMEPAGE.NT_NOTIFICATION_RECIPIENT  NT_NOTIFICATION_RECIPIENT
    GROUP BY NOTIFICATION_ID
);


-- create TEMP_NOTIFICATION table
CREATE TABLE HOMEPAGE.TEMP_NOTIFICATION (
	  NOTIFICATION_ID VARCHAR(36) NOT NULL,
	  NOTIFICATION_SOURCE VARCHAR(36) NOT NULL,
	  NOTIFICATION_TYPE VARCHAR(256) NOT NULL,
	  DATETIME_STAMP TIMESTAMP NOT NULL,
	  SENDER_EXID VARCHAR(36) NOT NULL,
	  SUBJECT VARCHAR(256),
	  MESSAGE VARCHAR(2048),
	  CONTAINER_NAME VARCHAR(256),
	  CONTAINER_URL VARCHAR(2048),
	  ITEM_NAME VARCHAR(256),
	  ITEM_URL VARCHAR(2048),
	  FIRST_RECIPIENT_EXID VARCHAR(36),
	  NUM_RECIPIENTS SMALLINT,
	  IS_DELETED SMALLINT,
	  PRIMARY_ACTION_URL VARCHAR(2048),
	  SECONDARY_ACTION_URL VARCHAR(2048)
)
IN HPNT16TABSPACE;

-- copying temp the results to TEMP_NOTIFICATION
INSERT INTO HOMEPAGE.TEMP_NOTIFICATION (    NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )    
SELECT  NT_NOTIFICATION.NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        TEMP_FIND_RECIPIENT.RECIPIENT_EXID , TEMP_COUNT_RECIPIENT.RECIPIENT_COUNT, 0, '',''
FROM    HOMEPAGE.NT_NOTIFICATION NT_NOTIFICATION, HOMEPAGE.TEMP_COUNT_RECIPIENT TEMP_COUNT_RECIPIENT, HOMEPAGE.TEMP_FIND_RECIPIENT TEMP_FIND_RECIPIENT
WHERE   NT_NOTIFICATION.NOTIFICATION_ID = TEMP_COUNT_RECIPIENT.NOTIFICATION_ID AND
        NT_NOTIFICATION.NOTIFICATION_ID = TEMP_FIND_RECIPIENT.NOTIFICATION_ID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT DROP FOREIGN KEY "FK_RECIP_NOTIF";

DELETE FROM HOMEPAGE.NT_NOTIFICATION;

INSERT INTO HOMEPAGE.NT_NOTIFICATION (    	NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
                                            CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL,
                                            FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
                                        )
SELECT  NOTIFICATION_ID, NOTIFICATION_SOURCE, NOTIFICATION_TYPE, DATETIME_STAMP, SENDER_EXID, SUBJECT, MESSAGE, 
        CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, 
        FIRST_RECIPIENT_EXID, NUM_RECIPIENTS, IS_DELETED, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL
FROM    HOMEPAGE.TEMP_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
	ADD CONSTRAINT "FK_RECIP_NOTIF" FOREIGN KEY ("NOTIFICATION_ID")
	REFERENCES HOMEPAGE.NT_NOTIFICATION ("NOTIFICATION_ID")
	ON DELETE CASCADE;

-- drop temps stuff
DROP TABLE HOMEPAGE.TEMP_NOTIFICATION;

DROP VIEW HOMEPAGE.TEMP_FIND_RECIPIENT;

DROP VIEW HOMEPAGE.TEMP_COUNT_RECIPIENT;    

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NT_NOTIFICATION;

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;    
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING the new widget - UPDATE activities to do list (review) 
----------------------------------------------------------------------
UPDATE 	HOMEPAGE.WIDGET 
SET 	WIDGET_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml', WIDGET_SECURE_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml'
WHERE 	WIDGET_ID='activities-sidebar7x4229x8';

INSERT INTO HOMEPAGE.WIDGET (WIDGET_ID,WIDGET_TITLE,WIDGET_TEXT,WIDGET_URL,WIDGET_ICON,WIDGET_ENABLED,WIDGET_SYSTEM,WIDGET_HOMEPAGE_SPECIFIC,WIDGET_PREVIEW_IMAGE,WIDGET_CATEGORY,WIDGET_IS_DEFAULT_OPENED,WIDGET_MULTIPLE_INSTANCES,WIDGET_MARKED_CACHABLE,WIDGET_SECURE_URL,WIDGET_SECURE_ICON) VALUES ('recommend7x4f6hd93kd9','%widget.sand.recommend.name','%widget.sand.recommend.desc','web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png',1,0,1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg','SAND',1,0,0,'web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB (WIDGET_TAB_ID,WIDGET_ID,TAB_ID,TYPE) VALUES ('UPDATES_recommend-sidebar','recommend7x4f6hd93kd9','_panel.updatex4a43x82aaxb00187218631','primary');

INSERT INTO HOMEPAGE.PREREQ 
			(PREREQ_ID,APP_ID,WIDGET_ID) 
VALUES 		('9t1a20f1xc4cax6cc4x8b0bx51af2ddef2cd','sand','recommend7x4f6hd93kd9');

----------------------------------------------------------------------
-- 2) ADDING TO THE PERSON TABLE A LAST_UPDATE ATTRIBUTE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.PERSON
	ADD LAST_UPDATE TIMESTAMP;

----------------------------------------------------------------------
-- 3) REFACTORING OF THE NOTIFICATIONS tables 
--		DB script update to store internal IDs for users in notification tables
----------------------------------------------------------------------
------------------------------------  NT_NOTIFICATION -------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD SENDER_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD FIRST_RECIPIENT_ID VARCHAR(36);

-- add index (ADDED) - it is new index (we need to remove it after) FIX
CREATE INDEX HOMEPAGE.NT_NOTIFICATION_FP_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(FIRST_RECIPIENT_EXID);	

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

-- sender_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET SENDER_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID);

COMMIT;        

-- first_recipient_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET FIRST_RECIPIENT_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID);

COMMIT;

-- drop (REMOVE) the temp index FIX
DROP INDEX HOMEPAGE.NT_NOTIFICATION_FP_INDEX;       

-- sender
DROP INDEX HOMEPAGE.NT_NOTIFICATION_EXID_INDEX;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN SENDER_EXID;

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT "FK_SENDER_ID" FOREIGN KEY ("SENDER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
	
-- recipient
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN FIRST_RECIPIENT_EXID;

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT "FK_F_RECIPIENT_ID" FOREIGN KEY ("FIRST_RECIPIENT_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

-- add index
CREATE INDEX HOMEPAGE.NT_NOTIFICATION_EXID_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(SENDER_ID);

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

 
------------------ NT_NOTIFICATION_RECIPIENT --------------
-- to remove LOLLO
RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;	
	
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
ADD RECIPIENT_ID VARCHAR(36);

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT    	
SET RECIPIENT_ID = (    SELECT  HOMEPAGE.PERSON.PERSON_ID
                        FROM    HOMEPAGE.PERSON
                        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID);

COMMIT;        
        
DROP INDEX HOMEPAGE.NT_NOTIF_RECT_EXID_INDEX;        

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
DROP COLUMN RECIPIENT_EXID;

REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT; 
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;


-- add fk
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
    ADD CONSTRAINT "FK_RECIPIENT_ID" FOREIGN KEY ("RECIPIENT_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

-- add index
CREATE INDEX HOMEPAGE.NT_NOT_RECIPIENT_INDEX
	ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT(RECIPIENT_ID);

--REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;
    
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 37
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) Insert the panel tab page widget
----------------------------------------------------------------------
INSERT INTO HOMEPAGE.HP_TAB 
			(TAB_ID, DEFAULT_NAME, DEFAULT_N_COLUMNS, IS_NAME_CHANGEABLE, ENABLED)
VALUES 		('_panel.getstartx4a43x82aaxb001872186' , '%panel.getstart' , 1 , 0, 1);

----------------------------------------------------------------------
-- 2) LAST_NOTIFY_VISIT TIMESTAMP
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.HP_UI
	ADD LAST_NOTIFY_VISIT TIMESTAMP;

UPDATE HOMEPAGE.HP_UI SET LAST_NOTIFY_VISIT = CURRENT TIMESTAMP;

REORG TABLE	HOMEPAGE.HP_UI;
RUNSTATS ON TABLE "HOMEPAGE"."HP_UI" FOR INDEXES ALL;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 38
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------
-- 2) MOVING NT_NOTIFICATION_RECIPIENT to HPNT16TABSPACE
------------------------------------------------------------
CREATE TABLE HOMEPAGE.TMP_NT_NOT_RECIPIENT (
		  ID VARCHAR(36) NOT NULL,
		  NOTIFICATION_ID VARCHAR(36) NOT NULL,
		  RECIPIENT_ID VARCHAR(36),
		  IS_DELETED SMALLINT	  
)
IN HPNT16TABSPACE;

insert into  HOMEPAGE.TMP_NT_NOT_RECIPIENT (
      ID,
      NOTIFICATION_ID, 
      RECIPIENT_ID, 
      IS_DELETED	
)
select 
        ID,
        NOTIFICATION_ID, 
        RECIPIENT_ID, 
        IS_DELETED
from    HOMEPAGE.NT_NOTIFICATION_RECIPIENT;
COMMIT;

DROP TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

------------------------------------------------
-- NT_NOTIFICATION_RECIPIENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT (
		  ID VARCHAR(36) NOT NULL,
		  NOTIFICATION_ID VARCHAR(36) NOT NULL,
		  RECIPIENT_ID VARCHAR(36),
		  IS_DELETED SMALLINT	  
)
IN HPNT16TABSPACE;

-- giving grants
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT TO USER LCUSER;
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;

-- copying back the original NT_NOTIFICATION_RECIPIENT
insert into  HOMEPAGE.NT_NOTIFICATION_RECIPIENT (
      ID,
      NOTIFICATION_ID, 
      RECIPIENT_ID, 
      IS_DELETED	
)
select 
        ID,
        NOTIFICATION_ID, 
        RECIPIENT_ID, 
        IS_DELETED
from    HOMEPAGE.TMP_NT_NOT_RECIPIENT;
COMMIT;

-- reorg the tables
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;

-- adding constraints
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
	ADD CONSTRAINT "PK_NOTIF_RECIP" PRIMARY KEY ("ID");

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
	ADD CONSTRAINT "FK_RECIP_NOTIF" FOREIGN KEY ("NOTIFICATION_ID")
	REFERENCES HOMEPAGE.NT_NOTIFICATION ("NOTIFICATION_ID")
	ON DELETE CASCADE;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
    ADD CONSTRAINT "FK_RECIPIENT_ID" FOREIGN KEY ("RECIPIENT_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

CREATE INDEX HOMEPAGE.NT_NOT_RECIPIENT_INDEX
	ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT(RECIPIENT_ID);
	
CREATE INDEX HOMEPAGE.NT_NOTIF_RECT_NID_INDEX
	ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT(NOTIFICATION_ID);

-- reorg table
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;	

-- drop old table
DROP TABLE HOMEPAGE.TMP_NT_NOT_RECIPIENT;

-----------------------------------------------
-- DROPPING TABSPACE AND BUFFERPOOL
-----------------------------------------------
DROP TABLESPACE HPNTTABSPACE; 
DROP TABLESPACE HPNTTMPTABSPACE;
DROP BUFFERPOOL NT8KBP;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 41
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- PERSON
-----------------------------------------------------------------------------------
-- select * 
-- from HOMEPAGE.PERSON 
-- where LAST_UPDATE > ?
CREATE INDEX HOMEPAGE.PERSON_LAST_UPDATE
    ON HOMEPAGE.PERSON (LAST_UPDATE DESC);

-----------------------------------------------------------------------------------
-- NT_NOTIFICATION
-----------------------------------------------------------------------------------
-- select N.NOTIFICATION_ID, N.NOTIFICATION_SOURCE AS SOURCE, N.NOTIFICATION_TYPE AS TYPE, N.DATETIME_STAMP, P1.PERSON_ID, N.SENDER_ID,
--        N.SUBJECT, N.MESSAGE, N.CONTAINER_NAME, N.CONTAINER_URL, N.ITEM_NAME, N.ITEM_URL, P2.PERSON_ID AS FIRST_RECIPIENT_PERSON_ID,
--         P2.EXID AS FIRST_RECIPIENT_EXID, P2.DISPLAYNAME AS FIRST_RECIPIENT_DISPLAY_NAME, N.NUM_RECIPIENTS
-- from HOMEPAGE.NT_NOTIFICATION N, HOMEPAGE.PERSON P1, HOMEPAGE.PERSON P2 
-- where P1.PERSON_ID = ? AND P2.PERSON_ID = N.FIRST_RECIPIENT_ID AND N.SENDER_ID = P1.PERSON_ID AND N.IS_DELETED = 0 
-- order by N.DATETIME_STAMP DESC
CREATE INDEX HOMEPAGE.NT_NOTIFICATION_IDX
    ON HOMEPAGE.NT_NOTIFICATION (DATETIME_STAMP DESC, FIRST_RECIPIENT_ID, SENDER_ID);

CREATE INDEX HOMEPAGE.NT_FIRST_RECIPIENT_PER
    ON HOMEPAGE.NT_NOTIFICATION (FIRST_RECIPIENT_ID);


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 43
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
UPDATE HOMEPAGE.PERSON SET IS_ACTIVE = 1;
 
ALTER TABLE HOMEPAGE.PERSON
	ALTER COLUMN IS_ACTIVE SET NOT NULL;

reorg table HOMEPAGE.PERSON use TEMPSPACE1;

UPDATE HOMEPAGE.HP_TAB SET ENABLED = 1;

-- giving grants again

-- HOME PAGE
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HOMEPAGE_SCHEMA TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.PERSON TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SNCORE_PERSON TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.LOGINNAME TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.PREREQ TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.WIDGET  TO USER LCUSER;


GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_UI  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_TAB  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_TAB_INST  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_WIDGET_INST  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.HP_WIDGET_TAB  TO USER LCUSER;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- HOMEPAGE.MT_METRICS 
----------------------------------------------------------------------

CREATE TABLE HOMEPAGE.MT_METRIC_STAT  (
      METRIC_STAT_ID VARCHAR(36) NOT NULL,
      RECORDED_ON TIMESTAMP NOT NULL,
      METRIC_TYPE SMALLINT NOT NULL,
      METRIC_DESC VARCHAR(36) NOT NULL,
      RES_BUNDLE_KEY VARCHAR(144) NOT NULL,
      COUNT_LAST_24_H BIGINT,
      COUNT_LAST_7_D BIGINT,
      COUNT_LAST_1_M BIGINT,
      TOP_STATS VARCHAR(512),
      TOT_STAT BIGINT,
      AVG_TOT_STAT BIGINT
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.MT_METRIC_STAT 
    ADD CONSTRAINT PK_METRIC_STAT_ID PRIMARY KEY(METRIC_STAT_ID);

CREATE INDEX HOMEPAGE.MT_METRICS_IDX
    ON HOMEPAGE.MT_METRIC_STAT (RECORDED_ON ASC, METRIC_TYPE);
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.MT_METRIC_STAT TO USER LCUSER;


-------------------------------------------------
-- FIXING NT_NOTIFICATION TABLE
-------------------------------------------------

-- 1 NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID
------------------------------------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID IS NULL;
------------------------------------------------------------------------------------------------------------
DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) <= '30' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '30' AND (HEX(SUBSTR(ID,1,1))) <= '34' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '34' AND (HEX(SUBSTR(ID,1,1))) <= '39' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '39' AND (HEX(SUBSTR(ID,1,1))) <= '61' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '61' AND (HEX(SUBSTR(ID,1,1))) <= '64' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '64' AND (HEX(SUBSTR(ID,1,1))) <= '66' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '66' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT
WHERE RECIPIENT_ID IS NULL;

COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
	ALTER COLUMN RECIPIENT_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;

COMMIT;

-- 2 NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID
-----------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID IS NULL;
----------------------------------------------------------------------------------- 
DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '30' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '30' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '34' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '34' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '39' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '39' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '61' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '61' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '64' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '64' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '66' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '66' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE FIRST_RECIPIENT_ID IS NULL;

COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ALTER COLUMN FIRST_RECIPIENT_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;
	
-- 3 NT_NOTIFICATION WHERE SENDER_ID
-----------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE SENDER_ID IS NULL;
-----------------------------------------------------------------------------------
DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '30' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '30' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '34' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '34' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '39' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '39' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '61' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '61' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '64' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '64' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '66' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '66' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE SENDER_ID IS NULL;

COMMIT;
	
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ALTER COLUMN SENDER_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;

COMMIT;	





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Update PERSON table SAND_OPT SMALLINT DEFAULT 1	NOT NULL
ALTER TABLE HOMEPAGE.PERSON
    ADD COLUMN SAND_OPT SMALLINT DEFAULT 1;

reorg table HOMEPAGE.PERSON use TEMPSPACE1;

UPDATE HOMEPAGE.PERSON SET SAND_OPT = 1;

COMMIT;

reorg table HOMEPAGE.PERSON use TEMPSPACE1;

-- 2) Drop IS_ACTIVE from PERSON table
ALTER TABLE HOMEPAGE.PERSON
    DROP COLUMN IS_ACTIVE;

reorg table HOMEPAGE.PERSON use TEMPSPACE1;    

    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 48
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) ADDING TO THE PERSON TABLE A SAND_LAST_UPDATE ATTRIBUTE 
ALTER TABLE HOMEPAGE.PERSON
    ADD COLUMN SAND_LAST_UPDATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

--UPDATE HOMEPAGE.PERSON SET SAND_LAST_UPDATE=CURRENT_TIMESTAMP;

--ALTER TABLE HOMEPAGE.PERSON 
--ALTER COLUMN  SAND_LAST_UPDATE SET NOT NULL;

COMMIT;

reorg table HOMEPAGE.PERSON;

CREATE INDEX HOMEPAGE.PERSON_SAND_LAST_UPDATE
    ON HOMEPAGE.PERSON (SAND_LAST_UPDATE ASC);

COMMIT;


RUNSTATS ON TABLE "HOMEPAGE"."PERSON" FOR INDEXES ALL;

-- SPR #RAPA86XGVU Brief Description:*   SAND: Migration: Recommendations widget should show up in 
-- Updates page by default for all new users and existing 2.5 users

-- delete existing widgets (just to be sure) from the ui of the users
DELETE FROM HOMEPAGE.HP_WIDGET_INST WHERE WIDGET_ID = 'recommend7x4f6hd93kd9';

-- inserting for all the users the new widget so it is showed into the ui
INSERT INTO HOMEPAGE.HP_WIDGET_INST 
    (
        WIDGET_INST_ID,
        WIDGET_ID,
        TAB_INST_ID,
        WIDGET_SETTING,
        CONTAINER,
        ORDER_SEQUENCE,
        IS_FIXED,
        IS_TOGGLED,
        LAST_MODIFIED,
        LAST_UPDATED
    ) 
SELECT  ('recom' || SUBSTR(TAB_INST_ID,1,30)) WIDGET_INST_ID,
        'recommend7x4f6hd93kd9' WIDGET_ID,
        TAB_INST_ID TAB_INST_ID,
        '' WIDGET_SETTING,
        '1' CONTAINER,
        1 ORDER_SEQUENCE,
        0 IS_FIXED,
        1 IS_TOGGLED,
        CURRENT TIMESTAMP LAST_MODIFIED,
        CURRENT TIMESTAMP LAST_UPDATED
FROM    HOMEPAGE.HP_TAB_INST WHERE TAB_NAME = '%panel.update';


    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE30 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- NR_NEWS_RECORDS
------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD COLUMN ITEM_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD COLUMN ITEM_CORRELATION_ID VARCHAR(36);

---------------------------------------------------------------------------------
------------------------ END NEWS -----------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 23;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------


---------------------------------------------------------------
-- TO MANAGE PARTECIPATION: IMPLICIT SUBSCRIPTION
---------------------------------------------------------------

------------------------------------------------
-- NR_GROUP_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP_TYPE (
	GROUP_TYPE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL,
	GROUP_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
    ADD CONSTRAINT "PK_GROUP_TYPE_ID" PRIMARY KEY("GROUP_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
	ADD CONSTRAINT GROUP_TYPE_UNIQUE UNIQUE(GROUP_TYPE);

------------------------------------------------
-- NR_GROUP
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP (
	GROUP_ID VARCHAR(36) NOT NULL,
	GROUP_NAME VARCHAR(256) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP 
    ADD CONSTRAINT "PK_GROUP_ID" PRIMARY KEY("GROUP_ID");

ALTER TABLE HOMEPAGE.NR_GROUP
	ADD CONSTRAINT "FK_GROUP_TYPE" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

------------------------------------------------
-- NR_PERSON_SOURCE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PERSON_SOURCE (
	PARTICIPATION_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE 
    ADD CONSTRAINT "PK_PART_PER_ID" PRIMARY KEY("PARTICIPATION_ID");

reorg table HOMEPAGE.NR_PERSON_SOURCE use NEWSTMPTABSPACE;

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_READER_PER_ID" FOREIGN KEY ("READER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_SOURCE_PER_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_GROUP_TYPE_PER" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

------------------------------------------------
-- NR_GROUP_SOURCE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP_SOURCE (
	PARTICIPATION_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE 
    ADD CONSTRAINT "PK_PART_GRP_ID" PRIMARY KEY("PARTICIPATION_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_READER_GRP_ID" FOREIGN KEY ("READER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_SOURCE_GRP_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_GROUP_TYPE_GRP" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY_TYPE 
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY_TYPE (
	CATEGORY_TYPE_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE_NAME VARCHAR(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
    ADD CONSTRAINT "PK_CAT_TYPE_ID" PRIMARY KEY("CATEGORY_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
	ADD CONSTRAINT CAT_TYPE_UNIQUE UNIQUE(CATEGORY_TYPE);

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY (
	CATEGORY_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	CATEGORY_NAME VARCHAR(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_CATEGORY
    ADD CONSTRAINT "PK_CATEGORY_ID" PRIMARY KEY("CATEGORY_ID");

ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT "FK_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");
	
ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_SOURCE_WATCHED
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_WATCHED (
	SOURCE_ID VARCHAR(36) NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36) NOT NULL,
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	ENTRY_ID VARCHAR(36),
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	IS_ACL SMALLINT NOT NULL,
	IS_PRIVATE SMALLINT,
	LAST_UPDATE TIMESTAMP,
	IS_CNAME_RTL SMALLINT NOT NULL DEFAULT 0,
	IS_ENAME_RTL SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_SOURCE_WATCHED 
    ADD CONSTRAINT "PK_SRC_WATCHED_ID" PRIMARY KEY("SOURCE_ID");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- NR_FOLLOW
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_ID VARCHAR(36) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT "PK_FOLLOW_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_ID" FOREIGN KEY ("CATEGORY_ID")
	REFERENCES HOMEPAGE.NR_CATEGORY("CATEGORY_ID");


--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_FOLLOW_GROUP
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW_GROUP (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_ID VARCHAR(36) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP 
    ADD CONSTRAINT "PK_FOLLOW_GRP_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_PERSON_GRP_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_FGSOURCE_GRP_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_CATEGORY_GRP_ID" FOREIGN KEY ("CATEGORY_ID")
	REFERENCES HOMEPAGE.NR_CATEGORY("CATEGORY_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_TOP_UPDATES
---------------------------------------------------------

-- SCRIPT to simulate a new design for the news table --
CREATE TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES 
    ADD CONSTRAINT "PK_TOP_UPDATES_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE..NR_NEWS_SAVED
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_SAVED (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED 
    ADD CONSTRAINT "PK_SAVED_ID" PRIMARY KEY("NEWS_RECORDS_ID");    

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_DISCOVERY
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_DISCOVERY (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	-- READER_ID VARCHAR(36), re remove it because it is a discovery table
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL,
	-- IS_SAVED SMALLINT NOT NULL, we cannot save a discovery
	-- IS_TOP_STORY SMALLINT NOT NULL, re remove it because it is a discovery table
	-- IS_PUBLIC SMALLINT NOT NULL, this is always public
	-- IS_MAILED SMALLINT NOT NULL, never used
	-- TIME_STAMP TIMESTAMP NOT NULL, never used
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	-- IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY 
    ADD CONSTRAINT "PK_DISCOVERY_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_WATCHLIST
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_WATCHLIST (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	SOURCE_ID VARCHAR(36), -- reader_id in this context is replaced by source_id
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST 
    ADD CONSTRAINT "PK_WATCHLIST_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_STATUS_NETWORK
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK 
    ADD CONSTRAINT "PK_STATUS_ID" PRIMARY KEY("NEWS_RECORDS_ID");

----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
-- HOMEPAGE.NR_NEWS_STORY
----------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STORY (
	NEWS_STORY_ID VARCHAR(36) NOT NULL,
	CONTENT CLOB NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STORY 
    ADD CONSTRAINT "PK_NEWS_STORY_ID" PRIMARY KEY("NEWS_STORY_ID");

----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
-- HOMEPAGE.NR_NEWS_COMMENT
----------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT (
	COMMENT_ID VARCHAR(36) NOT NULL,
	NEWS_STORY_ID VARCHAR(36) NOT NULL,
	COMMENT VARCHAR(4096) DEFAULT '' NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT 
    ADD CONSTRAINT "PK_COMMENT_ID" PRIMARY KEY("COMMENT_ID");

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT
	ADD CONSTRAINT "FK_NEWS_STORY_ID" FOREIGN KEY ("NEWS_STORY_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STORY("NEWS_STORY_ID");

COMMIT;

-- GIVING GRANTS TO THE NEW TABLES --
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_PERSON_SOURCE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_SOURCE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SOURCE_WATCHED TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW_GROUP TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_TOP_UPDATES TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_SAVED TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_DISCOVERY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_WATCHLIST TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STORY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT TO USER LCUSER;


------------------------------------- RUN STATS ---------------------------------

runstats on table HOMEPAGE.NR_GROUP_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_PERSON_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_CATEGORY_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_CATEGORY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SOURCE_WATCHED with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOW_GROUP with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_TOP_UPDATES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_SAVED with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_DISCOVERY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_WATCHLIST with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STATUS_NETWORK with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STORY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_COMMENT with distribution and detailed indexes all allow write access;


--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------

------------------------------------- MIGRATION DATA ---------------------------------


--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_TOP_UPDATES
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_TOP_STORY = 1 AND READER_ID IS NOT NULL;

COMMIT;

--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_SAVED
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_SAVED
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_SAVED = 1;    

COMMIT;

--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_DISCOVERY
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_PUBLIC = 1 AND READER_ID IS NULL AND IS_CONTAINER=0;

COMMIT;

-----------------------------------------------------------------------------------------------------------------
-- WATCHLIST
-----------------------------------------------------------------------------------------------------------------

-- INSERTING CATEGORY_TYPE (profiles and tag)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles_c9cax4cc4x8b0bx51af2ddef2cd', 1, '%profile', 'profiles');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('tags_0f1xc9cax4cc4x8b0bx51af2ddef2cd', 2, '%tag', 'tag');

COMMIT;

-- CREATE FOR EACH USERS A DEFAULT CATEGORY FOR EACH CATEGORY TYPE. 
-- THIS TABLE WILL HAVE HAS RESULTS N_USERS X CATEGORY_TYPES RECORDS
INSERT INTO HOMEPAGE.NR_CATEGORY 
    (
        CATEGORY_ID,
        PERSON_ID,
        CATEGORY_NAME,
        CATEGORY_TYPE
    )
    SELECT
        '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || PERSON.PERSON_ID),2,LENGTH(PERSON.PERSON_ID)-2) CATEGORY_ID,
        PERSON.PERSON_ID, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE
    FROM HOMEPAGE.PERSON PERSON, HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE;

COMMIT;

-- SELECT THE PROFILES SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;

COMMIT;

-- SELECT THE TAG SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;

COMMIT;

-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,LENGTH(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;

COMMIT;

-- CREATE THE RELETIONSHIP FOR TAGS SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,LENGTH(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;

COMMIT;

-- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
-- INSERTING PROFILES STORIES
-- 1 profile status update
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

-- 2 where actor uuid is specified        
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   READER_ID IS NULL AND
        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

-- INSERTING TAGS STORIES
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

UPDATE 	HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING='collection.name;htmlURL'
WHERE 	TEMPLATE_ID='collection-7jEWoKkWx8ucNTo6Z7AndhRFh';

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
-- UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
-- WHERE   DBSCHEMAVER = 30;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Missing fk for NR_NEWS_WATCHLIST
ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT "FK_F_WSOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");
	
-- REMOVING NR_FOLLOW_GROUP table
DROP TABLE HOMEPAGE.NR_FOLLOW_GROUP;

-- REFACTORING THE NR_FOLLOW table; 
DROP TABLE HOMEPAGE.NR_FOLLOW;

-- REMOVING NR_CATEGORY table
DROP TABLE HOMEPAGE.NR_CATEGORY;

------------------------------------------------
-- NR_FOLLOW
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT "PK_FOLLOW_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO USER LCUSER;

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		1
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles';

---- MIGRATE DATA TO THE FOLLOW TABLE
---- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE    
--)
--SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
--        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
--        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		2
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
--        NR_SOURCE.SOURCE = 'tag';        

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) UPDATE THE TOP UPDATES TABLE. Adding SOURCE_ID and CATEGORY_TYPE attributes
ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD COLUMN SOURCE_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD COLUMN CATEGORY_TYPE SMALLINT;

REORG TABLE	HOMEPAGE.NR_NEWS_TOP_UPDATES;
	
-- 2) REMOVE IS_ACL FROM NR_SOURCE TABLE
DROP INDEX HOMEPAGE.NR_SOURCE_IX_UNIQUE;

DROP INDEX HOMEPAGE.NR_SOURCE_CONTAINER_NAME_IDX;

ALTER TABLE HOMEPAGE.NR_SOURCE
DROP COLUMN IS_ACL;

REORG TABLE HOMEPAGE.NR_SOURCE;

CREATE INDEX HOMEPAGE.NR_SOURCE_IX_UNIQUE
	ON HOMEPAGE.NR_SOURCE("SOURCE" ASC, "CONTAINER_ID" ASC, "ENTRY_ID" ASC);

CREATE INDEX HOMEPAGE.NR_SOURCE_CONTAINER_NAME_IDX
  	ON HOMEPAGE.NR_SOURCE(SOURCE ASC, CONTAINER_NAME ASC, ENTRY_ID ASC);

-- 3) UPDATE THE FK FOR SOURCE_ID AND REMOVE NR_SOURCE_WATCHED
-- NR_NEWS_WATCHLIST
DELETE FROM HOMEPAGE.NR_NEWS_WATCHLIST;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
DROP FOREIGN KEY "FK_F_WSOURCE_ID";

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT "FK_F_WSOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

REORG TABLE HOMEPAGE.NR_NEWS_WATCHLIST;

-- 	NR_FOLLOW
DELETE FROM HOMEPAGE.NR_FOLLOW;

ALTER TABLE HOMEPAGE.NR_FOLLOW
DROP FOREIGN KEY "FK_F_SOURCE_ID";

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

REORG TABLE HOMEPAGE.NR_FOLLOW;

DROP TABLE HOMEPAGE.NR_SOURCE_WATCHED;	

-- 4) ADDING THE TABLE TO MANAGE NEWS STATUS NETWORK

DROP TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK;

------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_STATUS_NETWORK_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36),
	ACTOR_UUID VARCHAR(36) NOT NULL,
	BRIEF_DESC VARCHAR(500),
	ITEM_URL VARCHAR(2048),
	ITEM_ID  VARCHAR(36),
	EVENT_NAME VARCHAR(36),
	TARGET_SUBJECT_ID VARCHAR(36),
	IS_WALL_POST  SMALLINT NOT NULL DEFAULT 0,
	CREATION_DATE TIMESTAMP,
	UPDATE_DATE TIMESTAMP,
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0,
	IS_NETWORK_NEWS SMALLINT NOT NULL DEFAULT 0,
	IS_FOLLOW_NEWS SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK
  	ADD CONSTRAINT "PK_NEWS_STATUS_ID" PRIMARY KEY("NEWS_STATUS_NETWORK_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO USER LCUSER;  	    

------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT (
	NEWS_STATUS_COMMENT_ID VARCHAR(36) NOT NULL,
	ACTOR_UUID VARCHAR(36) NOT NULL,
	CREATION_DATE TIMESTAMP,
	BRIEF_DESC VARCHAR(500),
	ITEM_ID  VARCHAR(36),
	ITEM_CORRELATION_ID VARCHAR(36),
	ITEM_URL VARCHAR(2048)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT
  	ADD CONSTRAINT "PK_NEWS_COMMENT_ID" PRIMARY KEY("NEWS_STATUS_COMMENT_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_COMMENT TO USER LCUSER;  	    

------------------------------------------------
-- NR_NEWS_STATUS_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	ITEM_ID  VARCHAR(36)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
  	ADD CONSTRAINT "PK_S_CONTENT_ID" PRIMARY KEY("NEWS_STATUS_CONTENT_ID");    

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO USER LCUSER; 

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	NEWS_STATUS_COMMENT_ID  VARCHAR(36)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "PK_C_CONTENT_ID" PRIMARY KEY("NEWS_COMMENT_CONTENT_ID");    

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "FK_C_COMMENT_ID" FOREIGN KEY ("NEWS_STATUS_COMMENT_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT("NEWS_STATUS_COMMENT_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO USER LCUSER;
	
----------------------------------------------------
----------------------------------------------------
-- MIGRATION
----------------------------------------------------
----------------------------------------------------

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE    
--)
--SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
--        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
--        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		1
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
--        NR_SOURCE.SOURCE = 'profiles';
--
-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
--INSERT INTO HOMEPAGE.NR_FOLLOW (
--    FOLLOW_ID,
--    PERSON_ID,
--    SOURCE_ID,
--    CATEGORY_TYPE    
--)
--SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
--        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
--        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
--        NR_SUBSCRIPTION.PERSON_ID,
--        NR_SOURCE.SOURCE_ID,
--		2
--FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
--        HOMEPAGE.NR_SOURCE NR_SOURCE, 
--        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
--WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
--        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
--        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
--        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
--        NR_SOURCE.SOURCE = 'tag';
--
-- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
-- INSERTING PROFILES STORIES
-- 1 profile status update
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
--        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
--        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;
--
--COMMIT;
--
-- 2 where actor uuid is specified        
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   READER_ID IS NULL AND
--        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
--        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE.CONTAINER_ID;
--
--COMMIT;
--
-- INSERTING TAGS STORIES
--INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
--    (
--        NEWS_RECORDS_ID,
--        EVENT_NAME,
--        SOURCE_ID,
--        SOURCE,
--        CONTAINER_ID,
--        CONTAINER_NAME,
--        CONTAINER_URL,
--        ENTRY_NAME,
--        ENTRY_URL,
--        ENTRY_ATOM_URL,
--        CREATION_DATE,
--        BRIEF_DESC,
--        IS_BRIEF_DESC_RTL,
--        ACTOR_UUID,
--        EVENT_RECORD_UUID,
--        RELATED_COMM_UUID,
--        RELATED_COMM_NAME,
--        TAGS,
--        META_TEMPLATE,
--        TEXT_META_TEMPLATE,
--        IS_CONTAINER,
--        ITEM_ID,
--        ITEM_CORRELATION_ID,
--        N_COMMENTS,
--        N_RECOMMANDATIONS,
--        GROUP_TYPE,
--        NEWS_STORY_ID
--    )
--SELECT 
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
--        NR_NEWS_RECORDS.EVENT_NAME,
--        NR_SOURCE.SOURCE_ID,
--        NR_NEWS_RECORDS.SOURCE,
--        NR_NEWS_RECORDS.CONTAINER_ID,
--        NR_NEWS_RECORDS.CONTAINER_NAME,
--        NR_NEWS_RECORDS.CONTAINER_URL,
--        --NR_NEWS_RECORDS.ENTRY_ID,
--        NR_NEWS_RECORDS.ENTRY_NAME,
--        NR_NEWS_RECORDS.ENTRY_URL,
--        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
--        NR_NEWS_RECORDS.CREATION_DATE,
--        --NR_NEWS_RECORDS.IS_INBOX,
--        --NR_NEWS_RECORDS.IS_SAVED,
--        --NR_NEWS_RECORDS.IS_TOP_STORY,
--        --NR_NEWS_RECORDS.IS_PUBLIC,
--        --NR_NEWS_RECORDS.IS_MAILED,
--        --NR_NEWS_RECORDS.TIME_STAMP,
--        NR_NEWS_RECORDS.BRIEF_DESC,
--        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
--        NR_NEWS_RECORDS.ACTOR_UUID,
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_UUID,
--        NR_NEWS_RECORDS.RELATED_COMM_NAME,
--        NR_NEWS_RECORDS.TAGS,
--        NR_NEWS_RECORDS.META_TEMPLATE,
--        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
--        NR_NEWS_RECORDS.IS_CONTAINER,
--        NR_NEWS_RECORDS.ITEM_ID,
--        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
--        0,
--        0,
--        0,
--        NR_NEWS_RECORDS.NEWS_RECORDS_ID
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
--WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
--        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
--        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
--        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;
--  	
--COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) UPDATE CATEGORY
----------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_FOLLOW DROP CONSTRAINT "FK_CATEGORY_TYPE";

UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%tags', CATEGORY_TYPE_DESC='tags', CATEGORY_TYPE=10 WHERE CATEGORY_TYPE = 2;

UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%profiles', CATEGORY_TYPE=2 WHERE CATEGORY_TYPE = 1;

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('communities_0f1xc9cax4cc4x8b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('activities_0ff1xc9cax4cc4x8b0bx51af2', 4, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('blogs_0ffdsfds1xc9cax4cc4x8b0bx51af2', 5, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('bookmarks_0fdf1xc9cax4cc4x8b0bx51af2', 6, '%bookmarks', 'bookmarks');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('files_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 7, '%files', 'files');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('forums_0fdsfdf1xc9cax4cc4x8b0bx51af2', 8, '%forums', 'forums');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('wikis_0fdsfdsf1xc9cax4cc4x8b0bx51af2', 9, '%wikis', 'wikis');

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

RUNSTATS ON TABLE "HOMEPAGE"."NR_CATEGORY_TYPE" FOR INDEXES ALL;           
REORG TABLE	HOMEPAGE.NR_CATEGORY_TYPE;

----------------------------------------------------------------------
-- 2) UPDATE TEMPLATES
----------------------------------------------------------------------
DELETE FROM HOMEPAGE.NR_TEMPLATE;

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actor-Bei35oPldKwZTaR7aAiPFw4L08CyRW','actor', 'actorInternalId', 'profilePhoto', 1); 

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actorProfile-CAsyXgPhQd7N3wSMw7C0IUe','actorProfiles', 'actorInternalId', 'profilePhoto', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('target-Ah3vEOPQZDEpgpwcQ2JNaHFfMnMcG','subject', 'targetSubjectsInternalIds', 'profilePhoto', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEnt-anXIr0xP82OSZnuoYbAZa2M5AsRFr', 'activityEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k','activityEntryWithComment', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-WHHEhu6HTkRWtCQPylcUdSENF4mU', 'activityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actCont-Mg2xRFBLmRqg3Zj7Etrdttiyc6OH','activityContainerNameACL', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('actToDo-psOHtvbY4lOJv8jOXJH5YgLoGYP7','toDoEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blog-Itf9INx14G6bbCWRYNRpLhSawJXF8Qs','blogContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogNew-qsgRrfp88AKWys4wcm4gIuZm3T2p','newBlogContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogEntry-ubpjmKeG6Vi8XpQXYKVx3mtCqm','blogEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('blogComment-92JYbZEOrk0CBLEJHYwkrqPA','blogEntryWithComment', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-Qf0I5rSEaImjaCcds3HYi4SeCGYCDCN','newCommunityContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-new-IduwKhHDNCLdmJFi0G7lwrE86IJ','communityContainerName', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-topic6V808ijHf9TRgUSUqVVZoSOGg5','topicEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-book-VSWMFF7uZVaE11XRe4Q1ElJIc6','communityBookmarkEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('comm-feed-Ja6XFBT7kyfEJv07Unitc0MsJT','feedEntryName', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('dogear-book-DXAWZl1FIGMuMr4Ea4Lejbum','dogearBookmarkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('tags-a7YmLTHTY2FdHKPsHU0wbAZCkgYrkk1','tag', 'contentTags', 'plain', 3);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profileEntry-Vrh9M5YNmxNogF2oERZWyRE','profileLinkEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('profile-status-HNX0o3AF32cFuPWhtYMjl','profileStatusEntry', 'status', 'plain', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQ0gZl5','wikiContainerName','containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-page-P75oD6oAdgoWCRNt4YYh7hZfuM','wikiEntryPage', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-comment-Ye2xdX8pbYM996pc7je30LI','wikiEntryPageCommented', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('file-bbqZpR6oxvE2sYAXxasKS0EtS1mDg4h','fileEntry', 'itemName;itemHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('collection-7jEWoKkWx8ucNTo6Z7AndhRFh','collectionContainer', 'containerName;containerHtmlPath', 'link', 1);

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('wiki-9qgQLuYLDdh66pf82um3c6q1lQdfgt5','newWikiContainer','containerName;containerHtmlPath', 'link', 1);

RUNSTATS ON TABLE "HOMEPAGE"."NR_TEMPLATE" FOR INDEXES ALL;           
REORG TABLE	HOMEPAGE.NR_TEMPLATE;

----------------------------------------------------------------------
-- 3) Adding FOLLOW tables
----------------------------------------------------------------------

------------------------------------------------
-- NR_RESOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESOURCE_TYPE (
	RESOURCE_TYPE_ID VARCHAR(36) NOT NULL,
	RESOURCE_TYPE_NAME VARCHAR(36) NOT NULL, -- this is externalized
	RESOURCE_TYPE SMALLINT NOT NULL,
	RESOURCE_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWS8TABSPACE;

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
  	ADD CONSTRAINT "PK_RES_TYPE_ID" PRIMARY KEY("RESOURCE_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
	ADD CONSTRAINT RES_TYPE_UNIQUE UNIQUE (RESOURCE_TYPE);

RUNSTATS ON TABLE "HOMEPAGE"."NR_RESOURCE_TYPE" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_RESOURCE_TYPE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE_TYPE  TO USER LCUSER;	

----------------------------------------------------------------------
-- HOMEPAGE.NR_RESOURCE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESOURCE (
	RESOURCE_ID VARCHAR(36) NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36) NOT NULL,
	CONTAINER_NAME VARCHAR(36),
	CONTAINER_URL VARCHAR(2048),
	CATEGORY_TYPE SMALLINT,
	RESOURCE_TYPE SMALLINT
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_RESOURCE 
    ADD CONSTRAINT "PK_RESOURCE_ID" PRIMARY KEY("RESOURCE_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_RESOURCE" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_RESOURCE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE  TO USER LCUSER;  

----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWS 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWS (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	RESOURCE_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOWS 
    ADD CONSTRAINT "PK_FOLLOWS_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOWS
    ADD CONSTRAINT "FK_FS_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOWS
    ADD CONSTRAINT "FK_FS_RESOURCE_ID" FOREIGN KEY ("RESOURCE_ID")
	REFERENCES HOMEPAGE.NR_RESOURCE ("RESOURCE_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_FOLLOWS" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_FOLLOWS;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWS  TO USER LCUSER;	

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_FOLLOW 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_FOLLOW (
	COMM_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	COMMUNITY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT "PK_COMM_FOLLOW_ID" PRIMARY KEY("COMM_FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT "FK_COMM_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_COMM_FOLLOW" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_COMM_FOLLOW;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_FOLLOW  TO USER LCUSER;	  

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_FOLLOW
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW (
	ORGPERSON_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	ORGANIZATION_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW
    ADD CONSTRAINT "PK_ORGP_FOLLOW_ID" PRIMARY KEY("ORGPERSON_FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW
    ADD CONSTRAINT "FK_ORGP_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_ORGPERSON_FOLLOW" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_ORGPERSON_FOLLOW;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_FOLLOW  TO USER LCUSER;

----------------------------------------------------------------------
-- HOMEPAGE.NR_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),	
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	ITEM_NAME VARCHAR(256),
	ITEM_URL VARCHAR(2048),
	ITEM_ATOM_URL VARCHAR(2048),
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR(512),
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	R_META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	R_TEXT_META_TEMPLATE VARCHAR(1024),
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0 -- NEW
)
IN NEWS32TABSPACE;

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT "PK_STORY_ID" PRIMARY KEY("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO USER LCUSER;

----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWED_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWED_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL, 
	ITEM_ID VARCHAR(36) NOT NULL, -- I don't think we need SOURCE_ID here, this should be in the SOURCE table?
	RESOURCE_TYPE_ID VARCHAR(36) NOT NULL, -- ???? what is this ??
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "PK_F_STORY_ID" PRIMARY KEY("FOLLOWED_STORY_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "FK_F_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_FOLLOWED_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_FOLLOWED_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO USER LCUSER;    

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_STORIES (
	COMM_STORY_ID VARCHAR(36) NOT NULL,
	COMMUNITY_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36),
	RESOURCE_TYPE_ID VARCHAR(36) NOT NULL, -- ???? what is this ??
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "PK_F_CSTORY_ID" PRIMARY KEY("COMM_STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "FK_COMM_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_COMM_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_COMM_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO USER LCUSER;

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_STORIES (
	ORGPERSON_STORY_ID VARCHAR(36) NOT NULL,
	ORGANIZATION_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36),
	ITEM_ID VARCHAR(36) NOT NULL,
	RESOURCE_TYPE_ID VARCHAR(36) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "PK_ORGP_STORY_ID" PRIMARY KEY("ORGPERSON_STORY_ID");

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "FK_ORGP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_ORGPERSON_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_ORGPERSON_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO USER LCUSER;
	
------------------------------------------------------
-- 4) Adding a dedicated tabspace to store blob
------------------------------------------------------

DROP TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT;
------------------------------------------------
-- NR_NEWS_STATUS_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	ITEM_ID  VARCHAR(36)
)
IN NEWSCONT4KTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
  	ADD CONSTRAINT "PK_S_CONTENT_ID" PRIMARY KEY("NEWS_STATUS_CONTENT_ID");    

RUNSTATS ON TABLE "HOMEPAGE"."NR_NEWS_STATUS_CONTENT" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_NEWS_STATUS_CONTENT;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO USER LCUSER;

DROP TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	NEWS_STATUS_COMMENT_ID  VARCHAR(36)
)
IN NEWSCONT4KTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "PK_C_CONTENT_ID" PRIMARY KEY("NEWS_COMMENT_CONTENT_ID");    

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "FK_C_COMMENT_ID" FOREIGN KEY ("NEWS_STATUS_COMMENT_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT("NEWS_STATUS_COMMENT_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_NEWS_COMMENT_CONTENT" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT  TO USER LCUSER;

----------------------------------------------------------------------------------
-- 5) Creating the story table where to store the actual content for a story
----------------------------------------------------------------------------------

------------------------------------------------
-- NR_STORIES_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES_CONTENT (
	STORY_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL
)
IN NEWSCONT4KTABSPACE;

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
  	ADD CONSTRAINT "PK_STORY_CONT_ID" PRIMARY KEY("STORY_CONTENT_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_STORIES_CONTENT" FOR INDEXES ALL;           
REORG TABLE	HOMEPAGE.NR_STORIES_CONTENT;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES_CONTENT  TO USER LCUSER;
	   
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 35
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING RESOURCE TYPE
----------------------------------------------------------------------

------------
--- START INSERT NR_RESOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('activity_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%activity', 'activity');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('blog________0f1xc9cax4cc4x8b0bx51af2', 3, '%blog', 'blog');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('community____f1xc9cax4cc4x8b0bx51af2', 4, '%community', 'community');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_change_ds1xc9cax4cc4x8b0bx51af2', 5, '%file_change', 'file_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_comment_df1xc9cax4cc4x8b0bx5af2', 6, '%file_comment', 'file_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_collection_fdfca4cc4x8b0bx51af2', 7, '%file_collection', 'file_collection');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_topic_fdfdxc9cax4cc4xb0bx51af2', 8, '%forum_topic', 'forum_topic');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_0fdsfdsf1xc9cax4cc4xb0bxd51af2', 9, '%forum', 'forum');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('person_0f1xc9cax4cc4xb0bx51af2def2cd', 10, '%person', 'person');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_change_fdfdc9cax8b0bx51af2', 11, '%wiki_page_change', 'wiki_page_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_comment_0cax4c4x8b0bx51af2', 12, '%wiki_page_comment', 'wiki_page_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('tag_0f1xc9cax4cc4x8cdb0bx51f2ddef2cd', 13, '%tag', 'tag');

------------
--- END INSERT NR_RESOURCE_TYPE
------------

----------------------------------------------------------------------
-- 2) CHANGE FROM THE USE OF RESOURCE_TYPE_ID to USE RESOURCE_TYPE AND ADDING ITEM_ID TO NR_COMM_STORIES
----------------------------------------------------------------------

-- a) NR_FOLLOWED_STORIES
DROP TABLE HOMEPAGE.NR_FOLLOWED_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_FOLLOWED_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOWED_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36),
	ITEM_ID VARCHAR(36), -- I don't think we need SOURCE_ID here, this should be in the SOURCE table?
	RESOURCE_TYPE SMALLINT NOT NULL, -- ???? what is this ??
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "PK_F_STORY_ID" PRIMARY KEY("FOLLOWED_STORY_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "FK_F_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_FOLLOWED_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_FOLLOWED_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO USER LCUSER;  

-- b) NR_COMM_STORIES
DROP TABLE HOMEPAGE.NR_COMM_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_STORIES (
	COMM_STORY_ID VARCHAR(36) NOT NULL,
	COMMUNITY_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "PK_F_CSTORY_ID" PRIMARY KEY("COMM_STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "FK_COMM_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_COMM_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_COMM_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO USER LCUSER;

-- c) NR_ORGPERSON_STORIES
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ORGPERSON_STORIES (
	ORGPERSON_STORY_ID VARCHAR(36) NOT NULL,
	ORGANIZATION_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "PK_ORGP_STORY_ID" PRIMARY KEY("ORGPERSON_STORY_ID");

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "FK_ORGP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_ORGPERSON_STORIES" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_ORGPERSON_STORIES;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO USER LCUSER;

------------------------------------------------------
-- 3) REMOVING THE IS_ACTIVE FLAG and REDO the VIEW
------------------------------------------------------
--ALTER TABLE HOMEPAGE.PERSON DROP COLUMN IS_ACTIVE;

------------------------------------------------------
-- 4) ADDING FK TO THE NR_RESOURCE for CATEGORY_TYPE AND - RESOURCE TYPE
------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT "FK_RES_RES_TYPE" FOREIGN KEY ("RESOURCE_TYPE")
	REFERENCES HOMEPAGE.NR_RESOURCE_TYPE ("RESOURCE_TYPE");
	
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT "FK_RES_CAT_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE ("CATEGORY_TYPE");
	
------------------------------------------------------
-- 5) ADDING NR_NETWORK TABLE TO MANAGE PEOPLE IN YOUR NETWORK
------------------------------------------------------

----------------------------------------------------------------------
-- HOMEPAGE.NR_NETWORK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NETWORK (
	NETWORK_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	COLLEAGUE_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT "PK_NETWORK_ID" PRIMARY KEY("NETWORK_ID");

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT "FK_NTW_PERS_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_NETWORK
    ADD CONSTRAINT "FK_NTW_COLL_ID" FOREIGN KEY ("COLLEAGUE_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

RUNSTATS ON TABLE "HOMEPAGE"."NR_NETWORK" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.NR_NETWORK;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NETWORK  TO USER LCUSER;	
	
------------------------------------------------------
-- 6) REMOVING OLD EMAIL DIGEST TABLES
------------------------------------------------------
DROP TABLE HOMEPAGE.EMD_JOBS_STATS;
DROP TABLE HOMEPAGE.EMD_JOBS;
DROP TABLE HOMEPAGE.EMD_RECIPIENTS;

------------------------------------------------------
-- 7) ADDING NEW EMAIL DIGEST TABLES
------------------------------------------------------

-----------------------------------------
-- HOMEPAGE.EMD_FREQUENCY_TYPE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_FREQUENCY_TYPE (
	FREQUENCY_TYPE_ID VARCHAR(36) NOT NULL,
	FREQUENCY_TYPE_NAME VARCHAR(36) NOT NULL, -- this is externalized
	FREQUENCY_TYPE SMALLINT NOT NULL,
	FREQUENCY_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE 
  	ADD CONSTRAINT "PK_FRQ_TYPE_ID" PRIMARY KEY("FREQUENCY_TYPE_ID");

ALTER TABLE HOMEPAGE.EMD_FREQUENCY_TYPE
	ADD CONSTRAINT FRQ_TYPE_UNIQUE UNIQUE (FREQUENCY_TYPE);

RUNSTATS ON TABLE "HOMEPAGE"."EMD_FREQUENCY_TYPE" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.EMD_FREQUENCY_TYPE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_FREQUENCY_TYPE  TO USER LCUSER; 	

-----------------------------------------
-- HOMEPAGE.EMD_RESOURCE_PREF
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_RESOURCE_PREF (
	RESOURCE_PREF_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	RESOURCE_TYPE SMALLINT NOT NULL,
	FREQUENCY_TYPE SMALLINT NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF 
  	ADD CONSTRAINT "PK_RES_PREF_ID" PRIMARY KEY("RESOURCE_PREF_ID");

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT "FK_RES_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

ALTER TABLE HOMEPAGE.EMD_RESOURCE_PREF
    ADD CONSTRAINT "FK_RES_FRQ_TYPE" FOREIGN KEY ("FREQUENCY_TYPE")
	REFERENCES HOMEPAGE.EMD_FREQUENCY_TYPE ("FREQUENCY_TYPE");

RUNSTATS ON TABLE "HOMEPAGE"."EMD_RESOURCE_PREF" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.EMD_RESOURCE_PREF;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_RESOURCE_PREF  TO USER LCUSER;  	 	

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE (
	TRANCHE_ID VARCHAR(36) NOT NULL,
	SEQ_NUMBER SMALLINT NOT NULL,
	LAST_PROCESSED_DAILY TIMESTAMP,
	LAST_PROCESSED_WEEKLY TIMESTAMP,
	IS_LOCKED SMALLINT NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
  	ADD CONSTRAINT "PK_TRANCHE_ID" PRIMARY KEY("TRANCHE_ID");

ALTER TABLE HOMEPAGE.EMD_TRANCHE 
	ADD CONSTRAINT SEQ_NUMBER_UNIQUE UNIQUE (SEQ_NUMBER);  	

RUNSTATS ON TABLE "HOMEPAGE"."EMD_TRANCHE" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.EMD_TRANCHE;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE  TO USER LCUSER;  

-----------------------------------------
-- HOMEPAGE.EMD_TRANCHE_INFO
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_TRANCHE_INFO (
	TRANCHE_INFO_ID VARCHAR(36) NOT NULL,
	TRANCHE_ID VARCHAR(36) NOT NULL,
	COUNT_PROCESSED_DAILY SMALLINT,
	COUNT_PROCESSED_WEEKLY SMALLINT,
	AVG_EXEC_TIME_DAILY_MIN SMALLINT,
	AVG_EXEC_TIME_WEEKLY_MIN SMALLINT,
	DOMAIN_AFFINITY VARCHAR(2048) NOT NULL,
	N_USERS SMALLINT
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
  	ADD CONSTRAINT "PK_TRC_INFO_ID" PRIMARY KEY("TRANCHE_INFO_ID");

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
    ADD CONSTRAINT "FK_TRANCHE_ID" FOREIGN KEY ("TRANCHE_ID")
	REFERENCES HOMEPAGE.EMD_TRANCHE ("TRANCHE_ID");	 	

RUNSTATS ON TABLE "HOMEPAGE"."EMD_TRANCHE_INFO" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.EMD_TRANCHE_INFO;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE_INFO  TO USER LCUSER;  

-----------------------------------------
-- HOMEPAGE.EMD_EMAIL_PREFS
-----------------------------------------
CREATE TABLE HOMEPAGE.EMD_EMAIL_PREFS (
	EMAIL_PREFS_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SEND_DIRECTED SMALLINT NOT NULL,
	TRANCHE_ID VARCHAR(36) NOT NULL,
	EMAIL_ADDRESS VARCHAR(256) NOT NULL,
	LANG VARCHAR(36) NOT NULL,
	USE_TEXT_EMAIL SMALLINT NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
  	ADD CONSTRAINT "PK_EMAIL_PREFS_ID" PRIMARY KEY("EMAIL_PREFS_ID");

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ADD CONSTRAINT "FK_EMD_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

RUNSTATS ON TABLE "HOMEPAGE"."EMD_EMAIL_PREFS" FOR INDEXES ALL;
REORG TABLE	HOMEPAGE.EMD_EMAIL_PREFS;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_EMAIL_PREFS  TO USER LCUSER;	
	
--------------------------------------
-- 8) INIT EMD_FREQUENCY_TYPE
--------------------------------------

-----------------------------------
-- START EMD_FREQUENCY_TYPE
-----------------------------------	
INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('never_____0fdf1xc9cax4cc4x8b0bx51af2', 1, '%never', 'never');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('immediete_9cax4cc4x8b0bx51af2ddef2cd', 2, '%immediete', 'immediete');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('daily_______0f1xc9cax4cc4x8b0bx51af2', 3, '%daily', 'daily');

INSERT INTO HOMEPAGE.EMD_FREQUENCY_TYPE (FREQUENCY_TYPE_ID, FREQUENCY_TYPE, FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESC)
VALUES ('weekly_______f1xc9cax4cc4x8b0bx51af2', 4, '%weekly', 'weekly');  	
-----------------------------------
-- END EMD_FREQUENCY_TYPE
-----------------------------------





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
----------------------------------------------------------------------
-- 4) ADDING A UNIQUE CONSTRAINT on EMD_EMAIL_PREFES - PERSON ID
---------------------------------------------------------------------
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
	ADD CONSTRAINT UNIQUE_PREFS UNIQUE ("PERSON_ID");

----------------------------------------------------------------------
-- 5) REMOVE NR_NEWS_COMMENT table
----------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_COMMENT;

----------------------------------------------------------------------
-- 6) SET HP_UI.WELCOME MODE  to 1 for all the users 
----------------------------------------------------------------------
UPDATE HOMEPAGE.HP_UI SET WELCOME_MODE = 1;

----------------------------------------------------------------------
-- 7) DROP NOT NULL on NR_STORIES for column R_META_TEMPLATE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP FOREIGN KEY "FK_F_STORY_ID";
ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP FOREIGN KEY "FK_COMM_STORY_ID";
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES  DROP FOREIGN KEY "FK_ORGP_STORY_ID";

DROP TABLE HOMEPAGE.NR_STORIES;

CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),	
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	ITEM_NAME VARCHAR(256),
	ITEM_URL VARCHAR(2048),
	ITEM_ATOM_URL VARCHAR(2048),
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR(512),
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	R_META_TEMPLATE VARCHAR(4096),
	R_TEXT_META_TEMPLATE VARCHAR(1024),
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0 -- NEW
)
IN NEWS32TABSPACE;

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT "PK_STORY_ID" PRIMARY KEY("STORY_ID");
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO USER LCUSER;  

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "FK_F_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "FK_COMM_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "FK_ORGP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");    

----------------------------------------------------------------------
-- 8) REMOVE RELATED COMMUNITY COLUMNS FROM DISCOVERY TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_NAME;

----------------------------------------------------------------------
-- 9) REMOVE RELATED COMMUNITY COLUMNS FROM NR_NEWS_SAVED TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_NAME;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 37
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 3) ADDING LAST UPDATE FOR RESORUCE TABLE
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD LAST_UPDATE TIMESTAMP;

UPDATE HOMEPAGE.NR_RESOURCE SET LAST_UPDATE = CURRENT TIMESTAMP;

REORG TABLE	HOMEPAGE.NR_RESOURCE;
RUNSTATS ON TABLE "HOMEPAGE"."NR_RESOURCE" FOR INDEXES ALL;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 38
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 0) ADDING UNIQUE CONSTRAINTS FOR NR_FOLLOWS TABLE
----------------------------------------------------------------------
CREATE UNIQUE INDEX HOMEPAGE.NR_FOLLOWS_IDX
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID, PERSON_ID);

----------------------------------------------------------------------
-- 1) REMOVING UN-USED TABLE
----------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_STORY;
DROP TABLE HOMEPAGE.NR_NEWS_WATCHLIST;
DROP TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES;
DROP TABLE HOMEPAGE.NR_FOLLOW;
DROP TABLE HOMEPAGE.NR_GROUP_SOURCE;
DROP TABLE HOMEPAGE.NR_PERSON_SOURCE;
DROP TABLE HOMEPAGE.NR_GROUP;
DROP TABLE HOMEPAGE.NR_GROUP_TYPE;
DROP TABLE HOMEPAGE.NR_EVENT_RECORDS;
-- DROP TABLE HOMEPAGE.NR_NEWS_RECORDS;
-- DROP TABLE HOMEPAGE.NR_SUBSCRIPTION;
-- DROP TABLE HOMEPAGE.NR_SOURCE;

------------------------------------------------------------
-- 2) MOVING NR_RESOURCE_TYPE to NEWS4TABSPACE
------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE DROP FOREIGN KEY "FK_RES_RES_TYPE";

DROP TABLE HOMEPAGE.NR_RESOURCE_TYPE;

------------------------------------------------
-- NR_RESOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESOURCE_TYPE (
	RESOURCE_TYPE_ID VARCHAR(36) NOT NULL,
	RESOURCE_TYPE_NAME VARCHAR(36) NOT NULL, -- this is externalized
	RESOURCE_TYPE SMALLINT NOT NULL,
	RESOURCE_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
  	ADD CONSTRAINT "PK_RES_TYPE_ID" PRIMARY KEY("RESOURCE_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_RESOURCE_TYPE 
	ADD CONSTRAINT RES_TYPE_UNIQUE UNIQUE (RESOURCE_TYPE);

------------
--- START INSERT NR_RESOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('responses_0fdf1xc9cax4cc4x8b0bx51af2', 1, '%responses', 'responses');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('activity_c9cax4cc4x8b0bx51af2ddef2cd', 2, '%activity', 'activity');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('blog________0f1xc9cax4cc4x8b0bx51af2', 3, '%blog', 'blog');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('community____f1xc9cax4cc4x8b0bx51af2', 4, '%community', 'community');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_change_ds1xc9cax4cc4x8b0bx51af2', 5, '%file_change', 'file_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_comment_df1xc9cax4cc4x8b0bx5af2', 6, '%file_comment', 'file_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('file_collection_fdfca4cc4x8b0bx51af2', 7, '%file_collection', 'file_collection');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_topic_fdfdxc9cax4cc4xb0bx51af2', 8, '%forum_topic', 'forum_topic');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('forum_0fdsfdsf1xc9cax4cc4xb0bxd51af2', 9, '%forum', 'forum');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('person_0f1xc9cax4cc4xb0bx51af2def2cd', 10, '%person', 'person');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_change_fdfdc9cax8b0bx51af2', 11, '%wiki_page_change', 'wiki_page_change');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('wiki_page_comment_0cax4c4x8b0bx51af2', 12, '%wiki_page_comment', 'wiki_page_comment');

INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('tag_0f1xc9cax4cc4x8cdb0bx51f2ddef2cd', 13, '%tag', 'tag');

------------
--- END INSERT NR_RESOURCE_TYPE
------------

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE_TYPE TO USER LCUSER;
reorg table HOMEPAGE.NR_RESOURCE_TYPE use NEWS4TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NR_RESOURCE_TYPE" FOR INDEXES ALL;


ALTER TABLE HOMEPAGE.NR_RESOURCE
    ADD CONSTRAINT "FK_RES_RES_TYPE" FOREIGN KEY ("RESOURCE_TYPE")
	REFERENCES HOMEPAGE.NR_RESOURCE_TYPE ("RESOURCE_TYPE");

------------------------------------------------------------
-- 3) MOVING NR_STORIES_CONTENT to NEWS4TABSPACE
------------------------------------------------------------
-- create tmp
CREATE TABLE HOMEPAGE.NR_CONTENT_TMP (
	STORY_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL
)
IN NEWS4TABSPACE;

-- moving data to tmp
insert into HOMEPAGE.NR_CONTENT_TMP (
	STORY_CONTENT_ID,
	CONTENT,
	CREATION_DATE
)
select
	STORY_CONTENT_ID,
	CONTENT,
	CREATION_DATE
from  HOMEPAGE.NR_STORIES_CONTENT;

-- dropping original table
DROP TABLE HOMEPAGE.NR_STORIES_CONTENT;

-- re-creating original table
------------------------------------------------
-- NR_STORIES_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES_CONTENT (
	STORY_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
  	ADD CONSTRAINT "PK_STORY_CONT_ID" PRIMARY KEY("STORY_CONTENT_ID");

-- moving back the data
insert into HOMEPAGE.NR_STORIES_CONTENT (
	STORY_CONTENT_ID,
	CONTENT,
	CREATION_DATE
)
select
	STORY_CONTENT_ID,
	CONTENT,
	CREATION_DATE
from  HOMEPAGE.NR_CONTENT_TMP;

-- drop tmp table
DROP TABLE  HOMEPAGE.NR_CONTENT_TMP;

-- reorg runstats
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES_CONTENT TO USER LCUSER;
reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NR_STORIES_CONTENT" FOR INDEXES ALL;  	

------------------------------------------------------------
-- 4) MOVING NR_NEWS_COMMENT_CONTENT to NEWS4TABSPACE
------------------------------------------------------------
-- create tmp
CREATE TABLE HOMEPAGE.NR_CONTENT_TMP (
	NEWS_COMMENT_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	NEWS_STATUS_COMMENT_ID TIMESTAMP NOT NULL
)
IN NEWS4TABSPACE;

-- moving data to tmp
insert into HOMEPAGE.NR_CONTENT_TMP (
	NEWS_COMMENT_CONTENT_ID,
	CONTENT,
	NEWS_STATUS_COMMENT_ID
)
select
	NEWS_COMMENT_CONTENT_ID,
	CONTENT,
	NEWS_STATUS_COMMENT_ID
from  HOMEPAGE.NR_NEWS_COMMENT_CONTENT;

-- dropping original table
DROP TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT;

-- re-creating original table
------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	NEWS_STATUS_COMMENT_ID  VARCHAR(36)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "PK_C_CONTENT_ID" PRIMARY KEY("NEWS_COMMENT_CONTENT_ID");    

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "FK_C_COMMENT_ID" FOREIGN KEY ("NEWS_STATUS_COMMENT_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT("NEWS_STATUS_COMMENT_ID");

-- moving back the data
insert into HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID,
	CONTENT,
	NEWS_STATUS_COMMENT_ID
)
select
	NEWS_COMMENT_CONTENT_ID,
	CONTENT,
	NEWS_STATUS_COMMENT_ID
from  HOMEPAGE.NR_CONTENT_TMP;

-- drop tmp table
DROP TABLE  HOMEPAGE.NR_CONTENT_TMP;

-- reorg runstats
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO USER LCUSER;
reorg table HOMEPAGE.NR_NEWS_COMMENT_CONTENT use NEWS4TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NR_NEWS_COMMENT_CONTENT" FOR INDEXES ALL;   


------------------------------------------------------------
-- 5) MOVING NR_NEWS_STATUS_CONTENT to NEWS4TABSPACE
------------------------------------------------------------
-- create tmp
CREATE TABLE HOMEPAGE.NR_CONTENT_TMP (
	NEWS_STATUS_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	ITEM_ID VARCHAR(36)
)
IN NEWS4TABSPACE;

-- moving data to tmp
insert into HOMEPAGE.NR_CONTENT_TMP (
	NEWS_STATUS_CONTENT_ID,
	CONTENT,
	ITEM_ID
)
select
	NEWS_STATUS_CONTENT_ID,
	CONTENT,
	ITEM_ID
from  HOMEPAGE.NR_NEWS_STATUS_CONTENT;

-- dropping original table
DROP TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT;

-- re-creating original table
------------------------------------------------
-- NR_NEWS_STATUS_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	ITEM_ID  VARCHAR(36)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
  	ADD CONSTRAINT "PK_S_CONTENT_ID" PRIMARY KEY("NEWS_STATUS_CONTENT_ID");

-- moving back the data
insert into HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID,
	CONTENT,
	ITEM_ID
)
select
	NEWS_STATUS_CONTENT_ID,
	CONTENT,
	ITEM_ID
from  HOMEPAGE.NR_CONTENT_TMP;

-- drop tmp table
DROP TABLE  HOMEPAGE.NR_CONTENT_TMP;

-- reorg runstats
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO USER LCUSER;
reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;
RUNSTATS ON TABLE "HOMEPAGE"."NR_NEWS_STATUS_CONTENT" FOR INDEXES ALL;

-----------------------------------------------
-- DROPPING TABSPACE AND BUFFERPOOL
-----------------------------------------------
DROP TABLESPACE NEWS8TABSPACE; 
DROP TABLESPACE NEWS8TMPTABSPACE;
DROP BUFFERPOOL NEWS8KBP;

DROP TABLESPACE NEWSCONT4KTABSPACE;
DROP BUFFERPOOL NEWSCONTBFP;







-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 39
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-------------------------------------------------------------------------------
-- ADDING TEMPLATE
-------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('membership-9qgdh66pf82um3c6q1lQdfgt5','newMembers', 'memberAddedInternalIds', 'profilePhoto', 3);

---------------------------------------------------------------------------------- 
-- PRE FIX SCHEMA 
---------------------------------------------------------------------------------- 
ALTER TABLE HOMEPAGE.NR_RESOURCE 
DROP COLUMN CONTAINER_NAME; 

ALTER TABLE HOMEPAGE.NR_RESOURCE 
ADD CONTAINER_NAME VARCHAR(256);

----------------------------------------------------------------------------------
-- FIX DUPLICATED RECORDS - ADDING CONSTRAINSTS
----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ALTER COLUMN RESOURCE_TYPE 
    SET NOT NULL;

REORG TABLE HOMEPAGE.NR_RESOURCE USE NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);

---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 1) START: MIGRATION FOR STATUS UPDATE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- BUILDING RESOURCE TABLE WITH CONTAINER NAME FOR PROFILES 
---------------------------------------------------------------------------------- 
CREATE VIEW HOMEPAGE.PROFILE_SOURCES_NAME AS  ( 
    SELECT  NR_SOURCE.SOURCE_ID     SOURCE_ID, 
            B_CONTAINER_ID          CONTAINER_ID, 
            B_CONTAINER_NAME        CONTAINER_NAME 
    FROM    ( 
                SELECT  TEMP_A.A_CONTAINER_ID B_CONTAINER_ID, MAX(NR_NEWS_RECORDS.CONTAINER_NAME) B_CONTAINER_NAME 
                FROM    (   SELECT  NR_SOURCE.SOURCE_ID, MAX(NR_NEWS_RECORDS.CONTAINER_ID) A_CONTAINER_ID 
                            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
                            WHERE NR_NEWS_RECORDS.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID AND NR_SOURCE.SOURCE = 'profiles' 
                            GROUP BY NR_SOURCE.SOURCE_ID 
                        )   TEMP_A, 
                            HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
                WHERE       NR_NEWS_RECORDS.SOURCE = 'profiles' AND TEMP_A.A_CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
                GROUP BY    TEMP_A.A_CONTAINER_ID 
                ) TEMP_B, 
                HOMEPAGE.NR_SOURCE NR_SOURCE 
    WHERE NR_SOURCE.CONTAINER_ID = TEMP_B.B_CONTAINER_ID 
);

---------
-- START: FIX - create PROFILE_SOURCES_NAME_FILTERED
--------
CREATE VIEW HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE AS (
    SELECT CONTAINER_ID, CONTAINER_NAME, MAX (SOURCE_ID) SOURCE_ID
    FROM HOMEPAGE.PROFILE_SOURCES_NAME
    GROUP BY  CONTAINER_ID, CONTAINER_NAME
);

---------
-- END: FIX
-------- 

-- INSERTING PROFILES RESOURCES WITH THE NAME 
INSERT INTO HOMEPAGE.NR_RESOURCE ( 
    RESOURCE_ID, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    CATEGORY_TYPE, 
    RESOURCE_TYPE 
) 
SELECT  SOURCE_ID, 
        'profiles', 
        CONTAINER_ID,  
        CONTAINER_NAME, 
        '' , 
        2 , -- profile type 
        10 -- person 
FROM    HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE; 
COMMIT; 

---------------------------------------------------------------------------------- 
-- BUILDING NETWORK TABLE FOR STATUS UPDATE 
---------------------------------------------------------------------------------- 
-- FROM the subscription TABLE we SELECT what IS implicit. thIS the USEr network 
CREATE VIEW HOMEPAGE.TMP_NETWORK AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID COLLEAGUE_ID 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 0 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
); 

-- to build the network relationship 
INSERT INTO HOMEPAGE.NR_NETWORK ( 
    NETWORK_ID, 
    PERSON_ID, 
    COLLEAGUE_ID 
) 
SELECT  (SUBSTR(TMP_NETWORK.PERSON_ID,1,18) || SUBSTR(TMP_NETWORK.COLLEAGUE_ID,1,18)), TMP_NETWORK.PERSON_ID,  TMP_NETWORK.COLLEAGUE_ID 
FROM    HOMEPAGE.TMP_NETWORK TMP_NETWORK; 
COMMIT; 

----------------------------------------------------------------------------------------------- 
-- BUILIDING FOLLOWER TABLES FOR PROFILES 
------------------------------------------------------------------------------------------------ 
-- FROM the subscription TABLE we SELECT what IS explicit. thIS the what an USEr IS following 
-- what an USEr IS following 
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 1 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
); 

INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER; 
COMMIT; 


--------------------------------------------------------------------------------------------------------------- 
-- A - BUILDING STATUS UPDATE NETWORK + FOLLOWED (NOTe in the pASt who IS in your network IS automated followed) 
--------------------------------------------------------------------------------------------------------------- 
---------------------------------------------------------------- 
-- A-1) insert all the status updates releted to the USEr network 
---------------------------------------------------------------- 
-- profiles.status.updated 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
        NR_NEWS_RECORDS.READER_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
        'MIGRATED' || SUBSTR(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        1   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated'; 
COMMIT; 

---------------------------------------------------------------- 
-- A-1b) insert all MY status updates releted to myself 
---------------------------------------------------------------- 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
)
SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
        NR_NEWS_RECORDS.READER_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
        'MIGRATED' || SUBSTR(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        0   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.PERSON PERSON
WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND IS_PUBLIC = 1 AND
        ACTOR_UUID = PERSON.PERSON_ID;
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET READER_ID = ACTOR_UUID WHERE READER_ID IS NULL;
COMMIT;

---------------------------------------------------------------- 
-- A-1c) insert all MY network updates 
---------------------------------------------------------------- 
-- profiles.status.updated 
-- performing this insertions two times because there is a bidirectional reletionship

-- PERSON - COLLEAGUE
-- COLLEAGUE - PERSON
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT  (   SUBSTR(NR_NETWORK.PERSON_ID,1,12) || 
            SUBSTR(NR_NEWS_RECORDS.ACTOR_UUID,1,12) ||
            SUBSTR(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,12)
        ) NEWS_STATUS_NETWORK_ID, 
        NR_NETWORK.PERSON_ID, 
        NR_NEWS_RECORDS.ACTOR_UUID, 
        NR_NEWS_RECORDS.BRIEF_DESC, 
        NR_NEWS_RECORDS.ENTRY_URL, 
        'MIGRATED' || SUBSTR(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27), 
        NR_NEWS_RECORDS.EVENT_NAME, 
        '', -- TARGET_SUBJECT_ID 
        0, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        NR_NEWS_RECORDS.CREATION_DATE, 
        0, 
        1,  -- IS_NETWORK_NEWS 
        0   -- IS_FOLLOW_NEWS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,
        HOMEPAGE.NR_NETWORK NR_NETWORK
WHERE   NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND NR_NEWS_RECORDS.READER_ID IS NULL AND 
        NR_NEWS_RECORDS.ACTOR_UUID = NR_NETWORK.COLLEAGUE_ID;

COMMIT;
        
-------------------------------------- 
---- A-2) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created'; 
--COMMIT; 

-------------------------------------- 
---- A-3) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.you' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.READER_ID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.READER_ID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you'; 
--COMMIT; 

-------------------------------------- 
---- A-4) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.their' 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID, 
--        NR_NEWS_RECORDS.READER_ID, -- READER ID 
--        NR_NEWS_RECORDS.ACTOR_UUID, -- ACTOR_UUID 
--        NR_NEWS_RECORDS.BRIEF_DESC, 
--        NR_NEWS_RECORDS.ENTRY_URL, 
--        NR_NEWS_RECORDS.EVENT_RECORD_UUID, 
--        NR_NEWS_RECORDS.EVENT_NAME, 
--        NR_NEWS_RECORDS.READER_ID, -- TARGET_SUBJECT_ID 
--        1, -- IS_WALL_POST 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        NR_NEWS_RECORDS.CREATION_DATE, 
--        0, 
--        1,  -- IS_NETWORK_NEWS 
--        1   -- IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
--WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NOT NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.their'; 
--COMMIT;



--------------------------------------------------------------------------------------------------------------- 
-- B - BUILDING STATUS UPDATE FOLLOWED 
--------------------------------------------------------------------------------------------------------------- 
CREATE VIEW HOMEPAGE.TMP_FOLLOWS_CONTAINER AS ( 
    SELECT  FOLLOW_ID, PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID 
); 



---------------------------------------------------------------- 
-- B-1) insert all the status updates releted to the USEr network 
---------------------------------------------------------------- 
-- profiles.status.updated 
CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS (            
    SELECT  SUBSTR(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) || SUBSTR(TMP_FOLLOWS_CONTAINER.PERSON_ID,1,18)  NEWS_STATUS_NETWORK_ID, 
            TMP_FOLLOWS_CONTAINER.PERSON_ID         READER_ID, 
            NR_NEWS_RECORDS.ACTOR_UUID              ACTOR_UUID, 
            NR_NEWS_RECORDS.BRIEF_DESC              BRIEF_DESC, 
            NR_NEWS_RECORDS.ENTRY_URL               ITEM_URL, 
            'MIGRATED' || SUBSTR(NR_NEWS_RECORDS.EVENT_RECORD_UUID,1,27)	ITEM_ID,
            NR_NEWS_RECORDS.EVENT_NAME              EVENT_NAME, 
            ''         TARGET_SUBJECT_ID, -- target subject 
            0                                       IS_WALL_POST, -- IS wall post 
            NR_NEWS_RECORDS.CREATION_DATE           CREATION_DATE, 
            NR_NEWS_RECORDS.CREATION_DATE           UPDATE_DATE, 
            0                                       N_COMMENTS, 
            0                                       IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
            1                                       IS_FOLLOW_NEWS  -- thIS IS just a followed news 
    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
            HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.status.updated' AND 
            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
); 

CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
); 
 
INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
    NEWS_STATUS_NETWORK_ID, 
    READER_ID, 
    ACTOR_UUID, 
    BRIEF_DESC, 
    ITEM_URL, 
    ITEM_ID, 
    EVENT_NAME, 
    TARGET_SUBJECT_ID, 
    IS_WALL_POST, 
    CREATION_DATE, 
    UPDATE_DATE, 
    N_COMMENTS, 
    IS_NETWORK_NEWS, 
    IS_FOLLOW_NEWS 
) 
SELECT      NEWS_STATUS_NETWORK_ID, 
            READER_ID, 
            ACTOR_UUID, 
            BRIEF_DESC, 
            ITEM_URL, 
            ITEM_ID, 
            EVENT_NAME, 
            TARGET_SUBJECT_ID, 
            IS_WALL_POST, 
            CREATION_DATE, 
            UPDATE_DATE, 
            N_COMMENTS, 
            IS_NETWORK_NEWS, 
            IS_FOLLOW_NEWS 
FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
COMMIT; 


-------------------------------------------------------------------- 
------ B-2) INSERT STATUS UPDATE WALLPOST 
-------------------------------------------------------------------- 
----DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED; 
----CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS (            
----    SELECT  SUBSTR(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) || SUBSTR(TMP_FOLLOWS_CONTAINER.PERSON_ID,1,18)  NEWS_STATUS_NETWORK_ID, 
----            TMP_FOLLOWS_CONTAINER.PERSON_ID         READER_ID, 
----            NR_NEWS_RECORDS.ACTOR_UUID              ACTOR_UUID, 
----            NR_NEWS_RECORDS.BRIEF_DESC              BRIEF_DESC, 
----            NR_NEWS_RECORDS.ENTRY_URL               ITEM_URL, 
----            NR_NEWS_RECORDS.EVENT_RECORD_UUID       ITEM_ID, 
----            NR_NEWS_RECORDS.EVENT_NAME              EVENT_NAME, 
----            TMP_FOLLOWS_CONTAINER.PERSON_ID         TARGET_SUBJECT_ID, -- target subject 
----            0                                       IS_WALL_POST, -- IS wall post 
----            NR_NEWS_RECORDS.CREATION_DATE           CREATION_DATE, 
----            NR_NEWS_RECORDS.CREATION_DATE           UPDATE_DATE, 
----            0                                       N_COMMENTS, 
----            0                                       IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
----            1                                       IS_FOLLOW_NEWS  -- thIS IS just a followed news 
----    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
----            HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
----    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created' AND 
----            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
----); 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--); 
---- profiles.wallpost.created 
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--COMMIT; 

-------------------------------------- 
---- B-3) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.you' 
--DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED; 
--CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS ( 
--    SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID NEWS_STATUS_NETWORK_ID, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID READER_ID, 
--            NR_NEWS_RECORDS.ACTOR_UUID ACTOR_UUID, 
--            NR_NEWS_RECORDS.BRIEF_DESC BRIEF_DESC, 
--            NR_NEWS_RECORDS.ENTRY_URL ITEM_URL, 
--            NR_NEWS_RECORDS.EVENT_RECORD_UUID ITEM_ID, 
--            NR_NEWS_RECORDS.EVENT_NAME EVENT_NAME, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID TARGET_SUBJECT_ID, -- target subject 
--            1 IS_WALL_POST, -- IS wall post 
--            NR_NEWS_RECORDS.CREATION_DATE CREATION_DATE, 
--            NR_NEWS_RECORDS.CREATION_DATE UPDATE_DATE, 
--            0 N_COMMENTS, 
--            0 IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
--            1 IS_FOLLOW_NEWS  -- thIS IS just a followed news 
--    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
--    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you' AND 
--            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
--); 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--); 
--
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--COMMIT; 
--
-------------------------------------- 
---- B-4) INSERT STATUS UPDATE WALLPOST 
-------------------------------------- 
---- 'profiles.wallpost.created.their' 
--DROP VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED; 
--CREATE VIEW HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED AS ( 
--    SELECT  NR_NEWS_RECORDS.NEWS_RECORDS_ID NEWS_STATUS_NETWORK_ID, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID READER_ID, 
--            NR_NEWS_RECORDS.ACTOR_UUID ACTOR_UUID, 
--            NR_NEWS_RECORDS.BRIEF_DESC BRIEF_DESC, 
--            NR_NEWS_RECORDS.ENTRY_URL ITEM_URL, 
--            NR_NEWS_RECORDS.EVENT_RECORD_UUID ITEM_ID, 
--            NR_NEWS_RECORDS.EVENT_NAME EVENT_NAME, 
--            TMP_FOLLOWS_CONTAINER.PERSON_ID TARGET_SUBJECT_ID, -- target subject 
--            1 IS_WALL_POST, -- IS wall post 
--            NR_NEWS_RECORDS.CREATION_DATE CREATION_DATE, 
--            NR_NEWS_RECORDS.CREATION_DATE UPDATE_DATE, 
--            0 N_COMMENTS, 
--            0 IS_NETWORK_NEWS,  -- thIS IS NOT a network news 
--            1 IS_FOLLOW_NEWS  -- thIS IS just a followed news 
--    FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.TMP_FOLLOWS_CONTAINER TMP_FOLLOWS_CONTAINER 
--    WHERE   NR_NEWS_RECORDS.SOURCE = 'profiles' AND READER_ID IS NULL AND NR_NEWS_RECORDS.EVENT_NAME = 'profiles.wallpost.created.you' AND 
--            TMP_FOLLOWS_CONTAINER.CONTAINER_ID = NR_NEWS_RECORDS.CONTAINER_ID 
--); 
--
--DROP VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--CREATE VIEW HOMEPAGE.TMP_FOLLOWED_FILTERED AS ( 
--    SELECT      NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS, MAX(NEWS_STATUS_NETWORK_ID) MAX_NEWS_STATUS_NETWORK_ID 
--    FROM        HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED 
--    GROUP BY    NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME,  TARGET_SUBJECT_ID, IS_WALL_POST, 
--                CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--); 
--
--INSERT INTO HOMEPAGE.NR_NEWS_STATUS_NETWORK ( 
--    NEWS_STATUS_NETWORK_ID, 
--    READER_ID, 
--    ACTOR_UUID, 
--    BRIEF_DESC, 
--    ITEM_URL, 
--    ITEM_ID, 
--    EVENT_NAME, 
--    TARGET_SUBJECT_ID, 
--    IS_WALL_POST, 
--    CREATION_DATE, 
--    UPDATE_DATE, 
--    N_COMMENTS, 
--    IS_NETWORK_NEWS, 
--    IS_FOLLOW_NEWS 
--) 
--SELECT      NEWS_STATUS_NETWORK_ID, 
--            READER_ID, 
--            ACTOR_UUID, 
--            BRIEF_DESC, 
--            ITEM_URL, 
--            ITEM_ID, 
--            EVENT_NAME, 
--            TARGET_SUBJECT_ID, 
--            IS_WALL_POST, 
--            CREATION_DATE, 
--            UPDATE_DATE, 
--            N_COMMENTS, 
--            IS_NETWORK_NEWS, 
--            IS_FOLLOW_NEWS 
--FROM HOMEPAGE.TMP_FOLLOWED_FILTERED; 
--COMMIT; 

DROP VIEW  HOMEPAGE.PROFILE_SOURCES_NAME_UNIQUE;
DROP VIEW  HOMEPAGE.PROFILE_SOURCES_NAME; 
DROP VIEW  HOMEPAGE.TMP_NETWORK; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWS; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWS_CONTAINER; 
DROP VIEW  HOMEPAGE.TMP_STATUS_UPDATED_FOLLOWED; 
DROP VIEW  HOMEPAGE.TMP_FOLLOWED_FILTERED; 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 1) END: MIGRATION FOR STATUS UPDATE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

---------------------------------------------------------------------------------- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
---------------------------------------------------------------------------------- 




---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 2) START: MIGRATION FOR FOLLOWED TAGS *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

-- INSERTING TAG RESOURCES WITH THE NAME 
INSERT INTO HOMEPAGE.NR_RESOURCE ( 
    RESOURCE_ID, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    CATEGORY_TYPE, 
    RESOURCE_TYPE 
) 
SELECT  SOURCE_ID, 
        'tag', 
        CONTAINER_ID,  
        CONTAINER_NAME, 
        '' , 
        10 , -- tags category typw 
        13 -- tag reSOURCE type 
FROM    HOMEPAGE.NR_SOURCE NR_SOURCE 
WHERE   NR_SOURCE.SOURCE = 'tag'; 
COMMIT; 

-- CREATING THE FOLLOWS RELETIONSHIP FOR TAG 
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) FOLLOWS_ID, 
        PERSON_ID, 
        RESOURCE_ID 
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_RESOURCE NR_RESOURCE 
WHERE   NR_SUBSCRIPTION.IS_ACTIVE = 1 AND NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND 
        NR_RESOURCE.RESOURCE_ID = NR_SUBSCRIPTION.SOURCE_ID AND 
        NR_RESOURCE.CATEGORY_TYPE = 10; 

-- sanitize the SOURCE tag. moving tag to be tags 
update HOMEPAGE.NR_RESOURCE set SOURCE='tags' WHERE SOURCE='tag'; 
COMMIT; 

---------------------------------------------------- 
-- WORKING ON NR_FOLLOWED_STORIES AND NR_STORIES 
---------------------------------------------------- 

-- creating a VIEW to see all the folloed tags 
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_TAGS AS ( 
    SELECT  PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID AND NR_RESOURCE.CATEGORY_TYPE = 10 
); 

-- create a VIEW to see all the readed stories tags 
CREATE VIEW HOMEPAGE.TMP_READED_TAGS AS ( 
SELECT  SUBSTR(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) || SUBSTR(TMP_FOLLOWED_TAGS.PERSON_ID,1,18)              FOLLOWED_STORY_ID, 
        TMP_FOLLOWED_TAGS.PERSON_ID                 READER_ID, 
        10                                          CATEGORY_TYPE, 
        NR_NEWS_RECORDS.SOURCE                      SOURCE, 
        TMP_FOLLOWED_TAGS.CONTAINER_ID              CONTAINER_ID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           ITEM_ID, 
        13                                          RESOURCE_TYPE, 
        NR_NEWS_RECORDS.CREATION_DATE               CREATION_DATE, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           STORY_ID, 
        NR_NEWS_RECORDS.EVENT_NAME                  EVENT_NAME, 
        NR_NEWS_RECORDS.CONTAINER_NAME              CONTAINER_NAME, 
        NR_NEWS_RECORDS.CONTAINER_URL               CONTAINER_URL, 
        NR_NEWS_RECORDS.EVENT_NAME                  ITEM_NAME, 
        NR_NEWS_RECORDS.ENTRY_URL                   ITEM_URL, 
        NR_NEWS_RECORDS.ENTRY_ATOM_URL              ITEM_ATOM_URL, 
        ''                                          ITEM_CORRELATION_ID, 
        NR_NEWS_RECORDS.BRIEF_DESC                  BRIEF_DESC, 
        NR_NEWS_RECORDS.ACTOR_UUID                  ACTOR_UUID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           EVENT_RECORD_UUID, 
        NR_NEWS_RECORDS.TAGS                        TAGS, 
        NR_NEWS_RECORDS.META_TEMPLATE               META_TEMPLATE, 
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE          TEXT_META_TEMPLATE, 
        ''                                          R_META_TEMPLATE, 
        ''                                          R_TEXT_META_TEMPLATE, 
        0                                           N_COMMENTS, 
        0                                           N_RECOMMANDATIONS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,  HOMEPAGE.TMP_FOLLOWED_TAGS TMP_FOLLOWED_TAGS 
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND 
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND 
        NR_NEWS_RECORDS.SOURCE LIKE 'tag.%' AND 
        NR_NEWS_RECORDS.CONTAINER_ID = TMP_FOLLOWED_TAGS.CONTAINER_ID 
); 
COMMIT; 

---- NR_STORIES insert stories releted to the tags 
--INSERT INTO HOMEPAGE.NR_STORIES ( 
--    STORY_ID, 
--    EVENT_NAME, 
--    SOURCE, 
--    CONTAINER_ID, 
--    CONTAINER_NAME, 
--    CONTAINER_URL, 
--    ITEM_NAME, 
--    ITEM_URL, 
--    ITEM_ID, 
--    ITEM_CORRELATION_ID, 
--    CREATION_DATE, 
--    BRIEF_DESC, 
--    ACTOR_UUID, 
--    EVENT_RECORD_UUID, 
--    TAGS, 
--    META_TEMPLATE, 
--    R_META_TEMPLATE, 
--    R_TEXT_META_TEMPLATE, 
--    N_COMMENTS, 
--    N_RECOMMANDATIONS 
--) 
--SELECT  TMP_READED_TAGS.STORY_ID, 
--        EVENT_NAME, 
--        SOURCE, 
--        CONTAINER_ID, 
--        CONTAINER_NAME, 
--        CONTAINER_URL, 
--        ITEM_NAME, 
--        ITEM_URL, 
--        ITEM_ID, 
--        ITEM_CORRELATION_ID, 
--        CREATION_DATE, 
--        BRIEF_DESC, 
--        ACTOR_UUID, 
--        EVENT_RECORD_UUID, 
--        TAGS, 
--        META_TEMPLATE, 
--        R_META_TEMPLATE, 
--        R_TEXT_META_TEMPLATE, 
--        N_COMMENTS, 
--        N_RECOMMANDATIONS 
--FROM    ( 
--        SELECT STORY_ID, MAX(FOLLOWED_STORY_ID) A_FOLLOWED_STORY_ID 
--        FROM HOMEPAGE.TMP_READED_TAGS TMP_READED_TAGS 
--        GROUP by TMP_READED_TAGS.STORY_ID 
--        )   TEMP_A, 
--        HOMEPAGE.TMP_READED_TAGS TMP_READED_TAGS 
--WHERE   TEMP_A.A_FOLLOWED_STORY_ID = TMP_READED_TAGS.FOLLOWED_STORY_ID; 
--COMMIT; 
--
---- NR_FOLLOWED_STORIES insert readers for tags 
--INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
--    FOLLOWED_STORY_ID, 
--    READER_ID, 
--    CATEGORY_TYPE, 
--    SOURCE, 
--    CONTAINER_ID, 
--    ITEM_ID, 
--    RESOURCE_TYPE, 
--    CREATION_DATE, 
--    STORY_ID 
--) 
--SELECT      FOLLOWED_STORY_ID, 
--            READER_ID, 
--            CATEGORY_TYPE, 
--            SOURCE, 
--            CONTAINER_ID, 
--            ITEM_ID, 
--            RESOURCE_TYPE, 
--            CREATION_DATE, 
--            STORY_ID 
--FROM HOMEPAGE.TMP_READED_TAGS;    


DROP VIEW HOMEPAGE.TMP_READED_TAGS; 
DROP VIEW HOMEPAGE.TMP_FOLLOWED_TAGS; 

---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 2) END: MIGRATION FOR FOLLOWED TAGS *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

---------------------------------------------------------------------------------- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
-- **************************************************************************** -- 
---------------------------------------------------------------------------------- 



---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 3) START: MIGRATION FOR FOLLOWED PEOPLE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
---------------------------------------------------- 
-- WORKING ON NR_FOLLOWED_STORIES AND NR_STORIES 
---------------------------------------------------- 

-- creating a VIEW to see all the folloed profiles 
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_PROFILES AS ( 
    SELECT  PERSON_ID, CONTAINER_ID, CONTAINER_NAME 
    FROM    HOMEPAGE.NR_FOLLOWS NR_FOLLOWS, HOMEPAGE.NR_RESOURCE NR_RESOURCE 
    WHERE   NR_FOLLOWS.RESOURCE_ID = NR_RESOURCE.RESOURCE_ID AND NR_RESOURCE.CATEGORY_TYPE = 2 
); 

-- create a VIEW to see all the readed stories tags 
CREATE VIEW HOMEPAGE.TMP_READED_PROFILES AS ( 
SELECT  SUBSTR(NR_NEWS_RECORDS.NEWS_RECORDS_ID,1,18) || SUBSTR(TMP_FOLLOWED_PROFILES.PERSON_ID,1,18)  FOLLOWED_STORY_ID, 
        TMP_FOLLOWED_PROFILES.PERSON_ID             READER_ID, 
        2                                           CATEGORY_TYPE, -- profiles 
        NR_NEWS_RECORDS.SOURCE                      SOURCE, 
        TMP_FOLLOWED_PROFILES.CONTAINER_ID          CONTAINER_ID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           ITEM_ID, 
        10                                          RESOURCE_TYPE, -- person 
        NR_NEWS_RECORDS.CREATION_DATE               CREATION_DATE, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           STORY_ID, 
        NR_NEWS_RECORDS.EVENT_NAME                  EVENT_NAME, 
        NR_NEWS_RECORDS.CONTAINER_NAME              CONTAINER_NAME, 
        NR_NEWS_RECORDS.CONTAINER_URL               CONTAINER_URL, 
        NR_NEWS_RECORDS.EVENT_NAME                  ITEM_NAME, 
        NR_NEWS_RECORDS.ENTRY_URL                   ITEM_URL, 
        NR_NEWS_RECORDS.ENTRY_ATOM_URL              ITEM_ATOM_URL, 
        ''                                          ITEM_CORRELATION_ID, 
        NR_NEWS_RECORDS.BRIEF_DESC                  BRIEF_DESC, 
        NR_NEWS_RECORDS.ACTOR_UUID                  ACTOR_UUID, 
        NR_NEWS_RECORDS.EVENT_RECORD_UUID           EVENT_RECORD_UUID, 
        NR_NEWS_RECORDS.TAGS                        TAGS, 
        NR_NEWS_RECORDS.META_TEMPLATE               META_TEMPLATE, 
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE          TEXT_META_TEMPLATE, 
        ''                                          R_META_TEMPLATE, 
        ''                                          R_TEXT_META_TEMPLATE, 
        0                                           N_COMMENTS, 
        0                                           N_RECOMMANDATIONS 
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS,  HOMEPAGE.TMP_FOLLOWED_PROFILES TMP_FOLLOWED_PROFILES 
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL 
        AND ( 
                (NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.SOURCE = 'profiles' AND  NR_NEWS_RECORDS.CONTAINER_ID =  TMP_FOLLOWED_PROFILES.CONTAINER_ID ) 
                OR 
                (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND NR_NEWS_RECORDS.ACTOR_UUID = TMP_FOLLOWED_PROFILES.CONTAINER_ID) 
        ) 
); 

-- to have unique values 
CREATE VIEW HOMEPAGE.TMP_READED_PROFILES_FILTERED AS ( 
SELECT      FOLLOWED_STORY_ID, READER_ID, CATEGORY_TYPE, SOURCE, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, 
            CREATION_DATE, STORY_ID, EVENT_NAME, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL, ITEM_CORRELATION_ID, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, 
            TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, N_COMMENTS, N_RECOMMANDATIONS, MAX(FOLLOWED_STORY_ID) MAX_FOLLOWED_STORY_ID 
FROM        HOMEPAGE.TMP_READED_PROFILES TMP_READED_PROFILES 
GROUP BY    FOLLOWED_STORY_ID, READER_ID, CATEGORY_TYPE, SOURCE, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, 
            CREATION_DATE, STORY_ID, EVENT_NAME, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL, ITEM_CORRELATION_ID, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, 
            TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, N_COMMENTS, N_RECOMMANDATIONS 
); 


CREATE VIEW HOMEPAGE.TMP_READED_STORIES_PROFILES AS ( 
    SELECT  TMP_READED_PROFILES_FILTERED.STORY_ID STORY_ID, 
        EVENT_NAME, 
        SOURCE, 
        CONTAINER_ID, 
        CONTAINER_NAME, 
        CONTAINER_URL, 
        ITEM_NAME, 
        ITEM_URL, 
        ITEM_ID, 
        ITEM_CORRELATION_ID, 
        CREATION_DATE, 
        BRIEF_DESC, 
        ACTOR_UUID, 
        EVENT_RECORD_UUID, 
        TAGS, 
        META_TEMPLATE, 
        R_META_TEMPLATE, 
        R_TEXT_META_TEMPLATE, 
        N_COMMENTS, 
        N_RECOMMANDATIONS 
    FROM    ( 
            SELECT STORY_ID, MAX(FOLLOWED_STORY_ID) A_FOLLOWED_STORY_ID 
            FROM HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
            GROUP by TMP_READED_PROFILES_FILTERED.STORY_ID 
            )   TEMP_A, 
            HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
    WHERE   TEMP_A.A_FOLLOWED_STORY_ID = TMP_READED_PROFILES_FILTERED.FOLLOWED_STORY_ID AND 
            TMP_READED_PROFILES_FILTERED.STORY_ID NOT in ( 
                                                    SELECT  NR_STORIES.STORY_ID STORY_ID 
                                                    FROM    HOMEPAGE.NR_STORIES NR_STORIES, 
                                                            HOMEPAGE.TMP_READED_PROFILES_FILTERED TMP_READED_PROFILES_FILTERED 
                                                    WHERE   TMP_READED_PROFILES_FILTERED.STORY_ID = TMP_READED_PROFILES_FILTERED.STORY_ID 
                                                ) 
); 

---- NR_STORIES insert stories releted to the tags 
--INSERT INTO HOMEPAGE.NR_STORIES ( 
--    STORY_ID, 
--    EVENT_NAME, 
--    SOURCE, 
--    CONTAINER_ID, 
--    CONTAINER_NAME, 
--    CONTAINER_URL, 
--    ITEM_NAME, 
--    ITEM_URL, 
--    ITEM_ID, 
--    ITEM_CORRELATION_ID, 
--    CREATION_DATE, 
--    BRIEF_DESC, 
--    ACTOR_UUID, 
--    EVENT_RECORD_UUID, 
--    TAGS, 
--    META_TEMPLATE, 
--    R_META_TEMPLATE, 
--    R_TEXT_META_TEMPLATE, 
--    N_COMMENTS, 
--    N_RECOMMANDATIONS 
--) 
--SELECT  * 
--FROM HOMEPAGE.TMP_READED_STORIES_PROFILES; 
--COMMIT; 
--
---- NR_FOLLOWED_STORIES insert readers for profiles 
--INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
--    FOLLOWED_STORY_ID, 
--    READER_ID, 
--    CATEGORY_TYPE, 
--    SOURCE, 
--    CONTAINER_ID, 
--    ITEM_ID, 
--    RESOURCE_TYPE, 
--    CREATION_DATE, 
--    STORY_ID 
--) 
--SELECT      FOLLOWED_STORY_ID, 
--            READER_ID, 
--            CATEGORY_TYPE, 
--            SOURCE, 
--            CONTAINER_ID, 
--            ITEM_ID, 
--            RESOURCE_TYPE, 
--            CREATION_DATE, 
--            STORY_ID 
--FROM HOMEPAGE.TMP_READED_PROFILES_FILTERED; 
 
COMMIT; 

DROP VIEW HOMEPAGE.TMP_FOLLOWED_PROFILES; 
DROP VIEW HOMEPAGE.TMP_READED_PROFILES; 
DROP VIEW HOMEPAGE.TMP_READED_PROFILES_FILTERED; 
DROP VIEW HOMEPAGE.TMP_READED_STORIES_PROFILES; 
COMMIT; 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 
-- ***************** 3) END: MIGRATION FOR FOLLOWED PEOPLE *********************** 
---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------- 

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- SPR #DMCE85VK79 Homepage: Upgrade/Migration 2.5.0.2 to 3.0 Beta1 - Person watchlisted in 2.5 display Follow link in Profiles 3.0 
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

--------------------------------------------------
-- 1) START WATCHLIST CASE (PERSON)
--------------------------------------------------

------------------------------------------------------------------------
-- A) WATCHLIST CASE (PERSON): ADDING SOURCES WITH NO STORIES LINKED
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_RESOURCE (
    RESOURCE_ID,
    SOURCE,
    CONTAINER_ID,
    CONTAINER_NAME,
    CONTAINER_URL,
    CATEGORY_TYPE,
    RESOURCE_TYPE,
    LAST_UPDATE
)
    SELECT  DISTINCT NR_SOURCE.SOURCE_ID         RESOURCE_ID,
            NR_SOURCE.SOURCE            SOURCE,
            NR_SOURCE.CONTAINER_ID      CONTAINER_ID,
            NR_SOURCE.CONTAINER_NAME    CONTAINER_NAME,
            NR_SOURCE.CONTAINER_URL     CONTAINER_URL,
            2                           CATEGORY_TYPE,
            10                          RESOURCE_TYPE,
            NR_SOURCE.LAST_UPDATE       LAST_UPDATE
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            HOMEPAGE.NR_SOURCE NR_SOURCE
    WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID AND
            NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
            NR_SOURCE.SOURCE = 'profiles' AND 
            NR_SOURCE.SOURCE_ID NOT IN      (   SELECT  NR_RESOURCE.RESOURCE_ID
                                                FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE 
                                            )
                                     	AND
			NR_SOURCE.CONTAINER_ID NOT IN 	(   SELECT  NR_RESOURCE.CONTAINER_ID
												FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE
											);
COMMIT;

------------------------------------------------------------------------
-- B) WATCHLIST CASE (PERSON):  CREATE A VIEW FOR WATCHLIST STORIES WHERE WE USE IS_ACTIVE = 1
------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
COMMIT;

------------------------------------------------------------------------
-- C) WATCHLIST CASE (PERSON):  INSERTING FOLLOWING RELETIONSHIP FOR PERSON
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER AND
        (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) NOT IN (
                                                                        SELECT FOLLOW_ID
                                                                        FROM HOMEPAGE.NR_FOLLOWS
                                                                    );
COMMIT;

DROP VIEW HOMEPAGE.TMP_FOLLOWS;

COMMIT;
--------------------------------------------------
-- 1) END WATCHLIST CASE (PERSON)
--------------------------------------------------

--------------------------------------------------
-- 2) START WATCHLIST CASE (TAGS)
--------------------------------------------------

------------------------------------------------------------------------
-- A) WATCHLIST CASE (TAGS): ADDING SOURCES WITH NO STORIES LINKED
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_RESOURCE (
    RESOURCE_ID,
    SOURCE,
    CONTAINER_ID,
    CONTAINER_NAME,
    CONTAINER_URL,
    CATEGORY_TYPE,
    RESOURCE_TYPE,
    LAST_UPDATE
)
    SELECT  DISTINCT NR_SOURCE.SOURCE_ID         RESOURCE_ID,
            NR_SOURCE.SOURCE            SOURCE,
            NR_SOURCE.CONTAINER_ID      CONTAINER_ID,
            NR_SOURCE.CONTAINER_NAME    CONTAINER_NAME,
            NR_SOURCE.CONTAINER_URL     CONTAINER_URL,
            10                          CATEGORY_TYPE,
            13                          RESOURCE_TYPE,
            NR_SOURCE.LAST_UPDATE       LAST_UPDATE
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            HOMEPAGE.NR_SOURCE NR_SOURCE
    WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID AND
            NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
            NR_SOURCE.SOURCE = 'tag' AND 
            NR_SOURCE.SOURCE_ID NOT IN      (   SELECT  NR_RESOURCE.RESOURCE_ID
                                                FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE 
                                            )
                                     	AND
			NR_SOURCE.CONTAINER_ID NOT IN 	(   SELECT  NR_RESOURCE.CONTAINER_ID
												FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE
											);                                            
COMMIT;

------------------------------------------------------------------------
-- B) WATCHLIST CASE (TAGS):  CREATE A VIEW FOR WATCHLIST STORIES WHERE WE USE IS_ACTIVE = 1
------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE
            WHERE SOURCE = 'tag'
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);
COMMIT;

------------------------------------------------------------------------
-- C) WATCHLIST CASE (TAGS):  INSERTING FOLLOWING RELETIONSHIP FOR PERSON
------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_FOLLOWS ( 
    FOLLOW_ID, 
    PERSON_ID, 
    RESOURCE_ID 
) 
SELECT  (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) FOLLOWS_ID, PERSON_ID, RESOURCE_ID 
FROM    HOMEPAGE.NR_RESOURCE NR_RESOURCE, HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS 
WHERE   NR_RESOURCE.CONTAINER_ID = TMP_FOLLOWS.FOLLOWED_CONTAINER AND
        (SUBSTR(PERSON_ID,1,18) || SUBSTR(RESOURCE_ID,1,18)) NOT IN (
                                                                        SELECT FOLLOW_ID
                                                                        FROM HOMEPAGE.NR_FOLLOWS
                                                                    );
COMMIT;

DROP VIEW HOMEPAGE.TMP_FOLLOWS;

COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE SET SOURCE='tags' WHERE SOURCE='tag'; 

COMMIT;
--------------------------------------------------
-- 2) END WATCHLIST CASE (TAGS)
--------------------------------------------------

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
-- START: CLEANUP DUPLICATED STORIES
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

-- if there are stories that are or in network or in follow we need to normalize them, putting to 1,1 and deleteing the dups
UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET IS_NETWORK_NEWS = 1, IS_FOLLOW_NEWS = 1 WHERE NEWS_STATUS_NETWORK_ID IN (
        SELECT  A.NEWS_STATUS_NETWORK_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND 
                A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 0 AND 
                B.IS_NETWORK_NEWS = 0 AND B.IS_FOLLOW_NEWS = 1 AND
                A.ITEM_ID = B.ITEM_ID
);

COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE NEWS_STATUS_NETWORK_ID IN (
    SELECT NEWS_STATUS_NETWORK_ID
    FROM (
        SELECT  A.NEWS_STATUS_NETWORK_ID, B.IS_NETWORK_NEWS, B.IS_FOLLOW_NEWS
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 1 AND 
                B.IS_NETWORK_NEWS = 0 AND B.IS_FOLLOW_NEWS = 1 AND
                A.ITEM_ID = B.ITEM_ID
    ) TEMP
    WHERE TEMP.IS_NETWORK_NEWS = 0 AND TEMP.IS_FOLLOW_NEWS = 1
);

COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE NEWS_STATUS_NETWORK_ID IN (
    SELECT NEWS_STATUS_NETWORK_ID
    FROM (
        SELECT  A.NEWS_STATUS_NETWORK_ID, B.IS_NETWORK_NEWS, B.IS_FOLLOW_NEWS
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK A,
                HOMEPAGE.NR_NEWS_STATUS_NETWORK B
        WHERE   A.READER_ID = B.READER_ID AND A.ACTOR_UUID = B.ACTOR_UUID AND A.IS_NETWORK_NEWS = 1 AND A.IS_FOLLOW_NEWS = 1 AND 
                B.IS_NETWORK_NEWS = 1 AND B.IS_FOLLOW_NEWS = 0 AND
                A.ITEM_ID = B.ITEM_ID
    ) TEMP
    WHERE TEMP.IS_NETWORK_NEWS = 1 AND TEMP.IS_FOLLOW_NEWS = 0
);

COMMIT;

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
-- END: CLEANUP DUPLICATED STORIES
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 40
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Note: in case you receive this error:
-- DB21034E  The command was processed as an SQL statement because it was not a 
-- valid Command Line Processor command.  During SQL processing it returned:
-- SQL0964C  The transaction log for the database is full.  SQLSTATE=57011

-- try before to run the script to update the LOGFILSIZ
-- "db2 update database configuration for HOMEPAGE using LOGFILSIZ 8192"
-- "db2 update database configuration for HOMEPAGE using LOGPRIMARY 50"
-- "db2 update database configuration for HOMEPAGE using LOGSECOND 50"

-------------------------------------------------------------------------------
-- START: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------
-- DROP FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP CONSTRAINT FK_F_STORY_ID;

reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_ORGPERSON_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_COMM_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_FOLLOWED_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_STORIES use NEWS32TMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_SAVED use NEWSTMPTABSPACE;


DELETE FROM HOMEPAGE.NR_STORIES_CONTENT;
COMMIT;

DELETE FROM HOMEPAGE.NR_ORGPERSON_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_COMM_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_FOLLOWED_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_DISCOVERY;
COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_SAVED;
COMMIT;

reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_ORGPERSON_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_COMM_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_FOLLOWED_STORIES use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_STORIES use NEWS32TMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_SAVED use NEWSTMPTABSPACE;

-- PUT BACK FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

-------------------------------------------------------------------------------
-- END: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

---------------------------------------------------------------------
-- START: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------
CREATE VIEW HOMEPAGE.DUPLICATED_CONTAINERS AS (
    select CONTAINER_ID, count(RESOURCE_TYPE) RESOURCE_COUNT
    from HOMEPAGE.NR_RESOURCE NR_RESOURCE
    group by CONTAINER_ID
    having  count(RESOURCE_TYPE) > 1
);

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES AS (
    SELECT  NR_RESOURCE.RESOURCE_ID, NR_RESOURCE.SOURCE, NR_RESOURCE.CONTAINER_ID, NR_RESOURCE.CONTAINER_NAME, 
            NR_RESOURCE.CONTAINER_URL, NR_RESOURCE.CATEGORY_TYPE, NR_RESOURCE.RESOURCE_TYPE, NR_RESOURCE.LAST_UPDATE
    FROM    HOMEPAGE.DUPLICATED_CONTAINERS DUPLICATED_CONTAINERS, HOMEPAGE.NR_RESOURCE NR_RESOURCE
    WHERE   DUPLICATED_CONTAINERS.CONTAINER_ID = NR_RESOURCE.CONTAINER_ID
);

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE AS (
    SELECT CONTAINER_ID, MAX(RESOURCE_ID) MAX_RESOURCE_ID
    FROM HOMEPAGE.DUPLICATED_RESOURCES
    GROUP BY CONTAINER_ID
);

-- CLEANUP RECORDS: WE NEED TO REMOVE ALL THE RECORDS WITH MAX_RESOURCE_ID
-- A) REMOVE RECORDS FROM THE FOLLOWS TABLE TO DON'T BREAK FK CONSTRAINTS 
DELETE  FROM HOMEPAGE.NR_FOLLOWS 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
COMMIT;

-- B) REMOVE RECORDS FROM THE MASTER TABLE 
DELETE  FROM HOMEPAGE.NR_RESOURCE 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
COMMIT;

----------------------------------
-- REMOVE TMP VIEWS
----------------------------------
DROP VIEW HOMEPAGE.DUPLICATED_CONTAINERS;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE;


-------------------------------------------
-- ADDING UNIQUE CONSTRAINTS
-------------------------------------------
-- RESOURCE_TYPE NOT NULL
-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--    ALTER COLUMN RESOURCE_TYPE 
--    SET NOT NULL;

--REORG TABLE HOMEPAGE.NR_RESOURCE USE NEWS4TMPTABSPACE; 

-- UNIQUE CONSTRAINT

-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);
	
---------------------------------------------------------------------
-- END: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

------------------------------------------------------------
-- START: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-- NR_NEWS_SAVED
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_RESOURCE
ALTER TABLE HOMEPAGE.NR_RESOURCE
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_FOLLOWED_STORIES
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_COMM_STORIES
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

-- NR_ORGPERSON_STORIES
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);


------------------------------------------------------------
-- END: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-------------------------------------------------------------------------
-- START: INIT EMD_TRANCHE
-------------------------------------------------------------------------

-- EMD_TRANCHE 1
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 1, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_1_KwZTaR7aAiPFw4L08CyRW', 'tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 2
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 2, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_2_KwZTaR7aAiPFw4L08CyRW','tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 3
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 3, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_3_KwZTaR7aAiPFw4L08CyRW','tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 4
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 4, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_4_KwZTaR7aAiPFw4L08CyRW','tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 5
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 5, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_5_KwZTaR7aAiPFw4L08CyRW','tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 6
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 6, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_6_KwZTaR7aAiPFw4L08CyRW','tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 7
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 7, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_7_KwZTaR7aAiPFw4L08CyRW','tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 8
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 8, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_8_KwZTaR7aAiPFw4L08CyRW','tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 9
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 9, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_9_KwZTaR7aAiPFw4L08CyRW','tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 10
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 10, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_10_wZTaR7aAiPFw4L08CyRW','tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 11
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 11, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_11_wZTaR7aAiPFw4L08CyRW','tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 12
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 12, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_12_wZTaR7aAiPFw4L08CyRW','tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 13
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 13, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_13_wZTaR7aAiPFw4L08CyRW','tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 14
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 14, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_14_wZTaR7aAiPFw4L08CyRW','tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 15
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 15, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_15_wZTaR7aAiPFw4L08CyRW','tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 16
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 16, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_16_wZTaR7aAiPFw4L08CyRW','tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 17
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 17, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_17_wZTaR7aAiPFw4L08CyRW','tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 18
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 18, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_18_wZTaR7aAiPFw4L08CyRW','tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 19
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 19, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_19_wZTaR7aAiPFw4L08CyRW','tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);

-- EMD_TRANCHE 20
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 20, CURRENT TIMESTAMP, CURRENT TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_20_wZTaR7aAiPFw4L08CyRW','tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,'',0);


-------------------------------------------------------------------------
-- END: INIT EMD_TRANCHE
-------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 41
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- NR_FOLLOWS
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_RESOURCE.SOURCE, HOMEPAGE.NR_RESOURCE.CONTAINER_ID, HOMEPAGE.NR_RESOURCE.CONTAINER_NAME, HOMEPAGE.NR_RESOURCE.CONTAINER_URL, 
--        HOMEPAGE.NR_RESOURCE.CATEGORY_TYPE, HOMEPAGE.NR_RESOURCE.RESOURCE_TYPE FROM HOMEPAGE.NR_FOLLOWS INNER JOIN HOMEPAGE.NR_RESOURCE ON 
--        HOMEPAGE.NR_FOLLOWS.RESOURCE_ID = HOMEPAGE.NR_RESOURCE.RESOURCE_ID 
--WHERE   HOMEPAGE.NR_FOLLOWS.PERSON_ID = ? 
--ORDER BY HOMEPAGE.NR_RESOURCE.CONTAINER_NAME
--CREATE INDEX HOMEPAGE.NR_FOLLOWS_IDX
--    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID, PERSON_ID);

CREATE INDEX HOMEPAGE.NR_FOLLOWS_PERS
    ON HOMEPAGE.NR_FOLLOWS (PERSON_ID);

-- SELECT PERSON_ID 
-- FROM HOMEPAGE.NR_FOLLOWS 
-- WHERE RESOURCE_ID = ?
CREATE INDEX HOMEPAGE.NR_FOLLOWS_RES
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID);

-----------------------------------------------------------------------------------
-- NR_NETWORK
-----------------------------------------------------------------------------------
-- SELECT COLLEAGUE_ID 
-- FROM HOMEPAGE.NR_NETWORK 
-- WHERE PERSON_ID = ?
CREATE INDEX HOMEPAGE.NR_NETWORK_PERS
    ON HOMEPAGE.NR_NETWORK (PERSON_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
-----------------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_NEWS_SC_ITEM_COR
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_CORRELATION_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_NEWS_STATUS_COMMENT.NEWS_STATUS_COMMENT_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ACTOR_UUID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.CREATION_DATE,
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.BRIEF_DESC, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID, 
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_URL, HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID FROM HOMEPAGE.NR_NEWS_STATUS_COMMENT, 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE   HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID = HOMEPAGE.NR_NEWS_STATUS_NETWORK.ITEM_ID AND 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID = ? 
--ORDER BY HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID
CREATE INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (ITEM_ID);

--SELECT  NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE READER_ID=? AND IS_FOLLOW_NEWS = 1 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_FOLLOW_NEWS);

CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_NETWORK_NEWS);

-- *
--SELECT NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE READER_ID=? ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID);


-----------------------------------------------------------------------------------
-- NR_NEWS_SAVED
-----------------------------------------------------------------------------------
-- SELECT * 
-- FROM HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? AND CREATION_DATE >= ?

-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
--         TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY


-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, 
--         META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE   READER_ID = ? AND SOURCE = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX HOMEPAGE.NR_NEWS_SAVED_READER
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID);

CREATE INDEX HOMEPAGE.NR_NEWS_SAVED_READER_SRC
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID, SOURCE);

-----------------------------------------------------------------------------------
-- NR_NEWS_DISCOVERY
-----------------------------------------------------------------------------------
-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, ENTRY_ATOM_URL, CREATION_DATE, 
--        BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, 
--        ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
--FROM    HOMEPAGE.NR_NEWS_DISCOVERY 
--WHERE   SOURCE = ? 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_CREAT
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC);

CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_CREAT_SOURCE
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, SOURCE);

-----------------------------------------------------------------------------------
-- NR_FOLLOWED_STORIES
-----------------------------------------------------------------------------------
-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES 
-- WHERE READER_ID = ?
CREATE INDEX HOMEPAGE.NR_FOLLOWED_STORIES_READER
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID);

-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES WHERE 
-- READER_ID = ? AND CATEGORY_TYPE = ?
CREATE INDEX HOMEPAGE.NR_FOLLOWED_STORIES_READER_CAT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.NR_FS_READER_CONT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CONTAINER_ID);

CREATE INDEX HOMEPAGE.NR_FOLLOWED_STORIES_STORY_ID
    ON HOMEPAGE.NR_FOLLOWED_STORIES (STORY_ID);

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE INDEX HOMEPAGE.NR_NEWS_COMMENT_CONTENT_ID
    ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT(NEWS_STATUS_COMMENT_ID);

----------------------------------------------------------------------
-- NR_RESOURCE
----------------------------------------------------------------------
-- SELECT  * 
-- FROM    HOMEPAGE.NR_RESOURCE 
-- WHERE   RESOURCE_TYPE = ? AND CONTAINER_ID = ?
CREATE INDEX HOMEPAGE.NR_RESOURCE_TYPE_CONT
    ON HOMEPAGE.NR_RESOURCE (RESOURCE_TYPE, CONTAINER_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_FOLLOW 
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_COMM_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (PERSON_ID);

CREATE INDEX HOMEPAGE.NR_COMM_FOLLOW_COM_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (COMMUNITY_ID);    

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_FOLLOW
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_ORGPERSON_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_ORGPERSON_FOLLOW (PERSON_ID);
 
----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_COMM_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_STORIES (STORY_ID);
    
CREATE INDEX HOMEPAGE.NR_COMM_STORIES_COM_ID
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_ORGPERSON_STORIES_STORY_ID
    ON HOMEPAGE.NR_ORGPERSON_STORIES (STORY_ID);



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 43
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
    ALTER COLUMN CONTAINER_ID 
    SET DATA TYPE VARCHAR(256);

reorg table HOMEPAGE.NR_NEWS_RECORDS use NEWSTMPTABSPACE;

-- NEWS REPOSITORY
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SOURCE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SUBSCRIPTION TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_RECORDS TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_TEMPLATE TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_LMGR TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_LMPR TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_TASK TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SCHEDULER_TREG TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_SAVED TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_DISCOVERY TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_COMMENT TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE_TYPE  TO USER LCUSER;	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESOURCE  TO USER LCUSER;  
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWS  TO USER LCUSER;	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_FOLLOW  TO USER LCUSER;	  
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_FOLLOW  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES  TO USER LCUSER;    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_STORIES  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ORGPERSON_STORIES  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES_CONTENT  TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NETWORK  TO USER LCUSER;	

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_FREQUENCY_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_RESOURCE_PREF TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_TRANCHE_INFO TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.EMD_EMAIL_PREFS TO USER LCUSER;
	    



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------
-- FIXING DB INCONSISTENCES
--------------------------------------------------------------

-- 1) NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    ALTER COLUMN R_META_TEMPLATE DROP NOT NULL;
    
reorg table HOMEPAGE.NR_STORIES use NEWS32TMPTABSPACE;

-- 2) EMD_EMAIL_PREFS
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN EMAIL_ADDRESS DROP NOT NULL;

reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

-- 3) NR_STORIES_CONTENT
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    ALTER COLUMN CONTENT DROP NOT NULL;

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    ADD COLUMN STORY_ID VARCHAR(36);
    
reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;

-- 4) NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    ADD COLUMN IS_COMMUNITY_STORY SMALLINT DEFAULT 0;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET IS_COMMUNITY_STORY = 0;

------------------------------------------------------------------
-- FIXING TEMPLATE ISSUES
------------------------------------------------------------------
UPDATE HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING = 'itemName;itemHtmlPath' 
WHERE TEMPLATE_ID = 'actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k';

INSERT INTO HOMEPAGE.NR_TEMPLATE values ('blogCorrName-2G3abCWRYNRpLhSawJXF6Qd', 'blogCorrelationName', 'link', 'correlationName;correlationHtmlPath', 1);

-----------------------------------------------------------------
-- ADDING TABLES TO SUPPORT THE NEWS FFED
-----------------------------------------------------------------

------------------------------
-- NR_COMM_PERSON_FOLLOW
------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	PERSON_COMMUNITY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT "PK_COMM_PER_ID" PRIMARY KEY("COMM_PERSON_FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT "FK_COMM_PER_PER_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

CREATE INDEX HOMEPAGE.NR_COMM_PER_FOLLOW_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_ID);

CREATE INDEX HOMEPAGE.NR_COMM_FOLLOW_COM_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_COMMUNITY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_FOLLOW TO USER LCUSER;


----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_PERSON_STORIES 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT "PK_COMPER_STORY_ID" PRIMARY KEY("COMM_PER_STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT "FK_FCP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_READER
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC, COMM_PER_READER_ID);

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (STORY_ID);  

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_STORIES TO USER LCUSER;

 
      
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) Adding the new resource bookmark for EMD:
INSERT INTO HOMEPAGE.NR_RESOURCE_TYPE (RESOURCE_TYPE_ID, RESOURCE_TYPE, RESOURCE_TYPE_NAME, RESOURCE_TYPE_DESC)
VALUES ('bookmarks_0f1xc9cax4cc4x8cdb0bx51f2d', 14, '%bookmarks', 'bookmarks');

-- 2) move stories to the new tables:

----------------------------------------------------------------------------------
-- NR_COMM_PERSON_FOLLOW
----------------------------------------------------------------------------------

-- INSERT 1 RECORD FOR EACH PERSON
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (COMM_PERSON_FOLLOW_ID, PERSON_ID, PERSON_COMMUNITY_ID)
    SELECT  MAX(COMM_FOLLOW_ID) COMM_PERSON_FOLLOW_ID,
            PERSON_ID PERSON_ID,         
            PERSON_ID PERSON_COMMUNITY_ID
    FROM    HOMEPAGE.NR_COMM_FOLLOW NR_COMM_FOLLOW
    GROUP BY PERSON_ID;

COMMIT;

-- RENAME TO AVOID PK CONFLICTS
UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW SET COMM_PERSON_FOLLOW_ID = SUBSTR(COMM_PERSON_FOLLOW_ID,1,18) || SUBSTR(PERSON_ID,1,18);

COMMIT;

-- INSERT THE OLD EXISTING RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (COMM_PERSON_FOLLOW_ID, PERSON_ID, PERSON_COMMUNITY_ID)
    SELECT  COMM_FOLLOW_ID COMM_PERSON_FOLLOW_ID,
            PERSON_ID PERSON_ID,         
            COMMUNITY_ID PERSON_COMMUNITY_ID
    FROM HOMEPAGE.NR_COMM_FOLLOW NR_COMM_FOLLOW;

COMMIT;

----------------------------------------------------------------------------------
-- NR_COMM_PERSON_FOLLOW
----------------------------------------------------------------------------------

-- COPYING BACK THE OLD NR_COMM_STORIES
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (COMM_PER_STORY_ID, COMM_PER_READER_ID, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, CATEGORY_TYPE, CREATION_DATE, SOURCE, STORY_ID)
    SELECT  NR_COMM_STORIES.COMM_STORY_ID COMM_PER_STORY_ID,
            NR_COMM_STORIES.COMMUNITY_ID COMM_PER_READER_ID, 
            NR_COMM_STORIES.CONTAINER_ID CONTAINER_ID, 
            NR_COMM_STORIES.ITEM_ID ITEM_ID, 
            NR_COMM_STORIES.RESOURCE_TYPE RESOURCE_TYPE, 
            2 CATEGORY_TYPE, 
            NR_COMM_STORIES.CREATION_DATE CREATION_DATE, 
            'communities' SOURCE, 
            NR_COMM_STORIES.STORY_ID STORY_ID
    FROM HOMEPAGE.NR_COMM_STORIES NR_COMM_STORIES;

COMMIT;

-- COPYING BACK THE OLD NR_FOLLOWED_STORIES
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (COMM_PER_STORY_ID, COMM_PER_READER_ID, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE, CATEGORY_TYPE, CREATION_DATE, SOURCE, STORY_ID)
    SELECT  NR_FOLLOWED_STORIES.FOLLOWED_STORY_ID COMM_PER_STORY_ID,
            NR_FOLLOWED_STORIES.READER_ID COMM_PER_READER_ID, 
            NR_FOLLOWED_STORIES.CONTAINER_ID CONTAINER_ID, 
            NR_FOLLOWED_STORIES.ITEM_ID ITEM_ID, 
            NR_FOLLOWED_STORIES.RESOURCE_TYPE RESOURCE_TYPE, 
            NR_FOLLOWED_STORIES.CATEGORY_TYPE CATEGORY_TYPE,  
            NR_FOLLOWED_STORIES.CREATION_DATE CREATION_DATE, 
            NR_FOLLOWED_STORIES.SOURCE SOURCE, 
            NR_FOLLOWED_STORIES.STORY_ID STORY_ID
    FROM HOMEPAGE.NR_FOLLOWED_STORIES NR_FOLLOWED_STORIES;

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 46
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------------------------------
-- 1) ENFORCE A UNIQUE FIELD ON READER_ID, STORY_ID TO AVOID THE USE OF DISTINCT
------------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT COMM_PER_READER_ID, STORY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
-- GROUP BY COMM_PER_READER_ID, STORY_ID
-- HAVING count(*) > 1

-- CREATE A TEMP DUP TABLE
CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

COMMIT;

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PER_STORY_ID, 
            T2.COMM_PER_READER_ID, 
            T2.CONTAINER_ID, 
            T2.ITEM_ID, 
            T2.RESOURCE_TYPE, 
            T2.CATEGORY_TYPE, 
            T2.CREATION_DATE, 
            T2.SOURCE, 
            T2.STORY_ID
    FROM (
            SELECT  COMM_PER_READER_ID, STORY_ID, MAX(COMM_PER_STORY_ID) COMM_PER_STORY_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
            GROUP BY COMM_PER_READER_ID, STORY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_STORIES T2
    WHERE T1.COMM_PER_STORY_ID = T2.COMM_PER_STORY_ID;

COMMIT;

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES
    WHERE COMM_PER_STORY_ID IN (
    SELECT  NR_COMM_PERSON_STORIES.COMM_PER_STORY_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES,  HOMEPAGE.TMP_COMM_PERSON_STORIES TMP_COMM_PERSON_STORIES
    WHERE   NR_COMM_PERSON_STORIES.COMM_PER_READER_ID = TMP_COMM_PERSON_STORIES.COMM_PER_READER_ID AND
            NR_COMM_PERSON_STORIES.STORY_ID = TMP_COMM_PERSON_STORIES.STORY_ID
);

COMMIT;

-- CREATE THE UNIQUE CONSTRAINTS
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT UNIQUE_COMM_PERSON UNIQUE (COMM_PER_READER_ID, STORY_ID);

COMMIT;

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    SELECT  COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            CATEGORY_TYPE, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;

------------------------------------------------------------------------------------
-- 2) REMOVE NOT NULL CONSTRAINTS FROM EMD_EMAIL_PREFS
------------------------------------------------------------------------------------
-- SEND_DIRECTED
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN SEND_DIRECTED DROP NOT NULL;

-- LANG
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN LANG DROP NOT NULL;

-- USE_TEXT_EMAIL
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN USE_TEXT_EMAIL DROP NOT NULL;

reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 3) NR_COMM_FOLLOW 
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_COMM UNIQUE (PERSON_ID, COMMUNITY_ID);

reorg table HOMEPAGE.NR_COMM_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 4) NR_COMM_PERSON_FOLLOW
-----------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT PERSON_ID, PERSON_COMMUNITY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW
-- GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
-- HAVING count(*) > 1

CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	PERSON_COMMUNITY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

COMMIT;

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID, 
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PERSON_FOLLOW_ID, 
            T2.PERSON_ID, 
            T2.PERSON_COMMUNITY_ID
    FROM (
            SELECT  PERSON_ID, PERSON_COMMUNITY_ID, MAX(COMM_PERSON_FOLLOW_ID) COMM_PERSON_FOLLOW_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW COMM_PERSON_FOLLOW
            GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_FOLLOW T2
    WHERE T1.COMM_PERSON_FOLLOW_ID = T2.COMM_PERSON_FOLLOW_ID;

COMMIT;

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_FOLLOW
    WHERE   COMM_PERSON_FOLLOW_ID IN (
    SELECT  NR_COMM_PERSON_FOLLOW.COMM_PERSON_FOLLOW_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW,  HOMEPAGE.TMP_COMM_PERSON_FOLLOW TMP_COMM_PERSON_FOLLOW
    WHERE   NR_COMM_PERSON_FOLLOW.PERSON_ID = TMP_COMM_PERSON_FOLLOW.PERSON_ID AND
            NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = TMP_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID
);

COMMIT;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_P_COMM UNIQUE (PERSON_ID, PERSON_COMMUNITY_ID);

COMMIT;

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID,
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    SELECT  COMM_PERSON_FOLLOW_ID, 
            PERSON_ID, 
            PERSON_COMMUNITY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

COMMIT;

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 5) ADDING NR_NEWS_DISCOVERY_CREAT_IS_COM
-----------------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_CREAT_IS_COM
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, IS_COMMUNITY_STORY);

reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_NEWS_DISCOVERY;

-----------------------------------------------------------------------------------
-- 6) ADDING TO NR_NEWS_STATUS_NETWORK 
-- CREATION_DATE
-- ACTOR_UUID
-- TARGET_SUBJECT_ID
-- ITEM_URL
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN ACTOR_UUID VARCHAR(36);
    
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN CREATION_DATE TIMESTAMP;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN TARGET_SUBJECT_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN ITEM_URL  VARCHAR(2048);        

reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;

COMMIT;

-- ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT NR_NEWS_STATUS_CONTENT SET ACTOR_UUID = (
    SELECT DISTINCT(ACTOR_UUID)
    FROM (
        SELECT  ACTOR_UUID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET CREATION_DATE = (
    SELECT DISTINCT(CREATION_DATE)
    FROM (
        SELECT  CREATION_DATE, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- TARGET_SUBJECT_ID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET TARGET_SUBJECT_ID = (
    SELECT DISTINCT(TARGET_SUBJECT_ID)
    FROM (
        SELECT  TARGET_SUBJECT_ID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- ITEM_URL
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT NR_NEWS_STATUS_CONTENT SET ITEM_URL = (
    SELECT DISTINCT(ITEM_URL)
    FROM (
        SELECT  ITEM_URL, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;


CREATE INDEX HOMEPAGE.NR_NEWS_SC_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (ITEM_ID);

CREATE INDEX HOMEPAGE.NR_NEWS_SC_CD
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (CREATION_DATE ASC);

COMMIT;

reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;

------------------------------------------------------------------------
-- 7) DROPPING UN-USED INDEXES FROM NR_FOLLOWED_STORIES TABLE
------------------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_FOLLOWED_STORIES_READER;

DROP INDEX HOMEPAGE.NR_FS_READER_CONT;

DROP INDEX HOMEPAGE.NR_FOLLOWED_STORIES_STORY_ID;

reorg indexes all for table HOMEPAGE.NR_FOLLOWED_STORIES;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 47
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES DROP UNIQUE UNIQUE_COMM_PERSON;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 48
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------------------------------
-- 1) ENFORCE A UNIQUE FIELD ON READER_ID, STORY_ID TO AVOID THE USE OF DISTINCT
------------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT COMM_PER_READER_ID, STORY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
-- GROUP BY COMM_PER_READER_ID, STORY_ID
-- HAVING count(*) > 1

-- CREATE A TEMP DUP TABLE
CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

COMMIT;

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PER_STORY_ID, 
            T2.COMM_PER_READER_ID, 
            T2.CONTAINER_ID, 
            T2.ITEM_ID, 
            T2.RESOURCE_TYPE, 
            T2.CATEGORY_TYPE, 
            T2.CREATION_DATE, 
            T2.SOURCE, 
            T2.STORY_ID
    FROM (
            SELECT  COMM_PER_READER_ID, STORY_ID, MAX(COMM_PER_STORY_ID) COMM_PER_STORY_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
            GROUP BY COMM_PER_READER_ID, STORY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_STORIES T2
    WHERE T1.COMM_PER_STORY_ID = T2.COMM_PER_STORY_ID;

COMMIT;

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES
    WHERE COMM_PER_STORY_ID IN (
    SELECT  NR_COMM_PERSON_STORIES.COMM_PER_STORY_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES,  HOMEPAGE.TMP_COMM_PERSON_STORIES TMP_COMM_PERSON_STORIES
    WHERE   NR_COMM_PERSON_STORIES.COMM_PER_READER_ID = TMP_COMM_PERSON_STORIES.COMM_PER_READER_ID AND
            NR_COMM_PERSON_STORIES.STORY_ID = TMP_COMM_PERSON_STORIES.STORY_ID
);

COMMIT;

-- CREATE THE UNIQUE CONSTRAINTS
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT UNIQUE_COMM_PERSON UNIQUE (COMM_PER_READER_ID, STORY_ID);

COMMIT;

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    SELECT  COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            CATEGORY_TYPE, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;

------------------------------------------------------------------------------------------------
-- JREN875KSE  Brief Description:*   Database Update: IS_COMMUNITY_STORY Column needed to support 
-- Saved -> Communities news filtering
------------------------------------------------------------------------------------------------

-------------------------------------------------
--2) NR_NEWS_SAVED IS_COMMUNITY_STORY
-------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
    ADD COLUMN IS_COMMUNITY_STORY SMALLINT DEFAULT 0;

reorg table HOMEPAGE.NR_NEWS_SAVED use NEWSTMPTABSPACE;

CREATE INDEX HOMEPAGE.NR_NEWS_SAVED_CREAT_IS_COM
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID, IS_COMMUNITY_STORY);

reorg indexes all for table HOMEPAGE.NR_NEWS_SAVED;    

UPDATE HOMEPAGE.NR_NEWS_SAVED SET IS_COMMUNITY_STORY = 0;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET IS_COMMUNITY_STORY = 1 WHERE SOURCE = 'communities';

-------------------------------------------------
--3) NR_STORIES IS_COMMUNITY_STORY
-------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES
    ADD COLUMN IS_COMMUNITY_STORY SMALLINT DEFAULT 0;

reorg table HOMEPAGE.NR_STORIES use NEWS32TMPTABSPACE;

CREATE INDEX HOMEPAGE.NR_STORIES_CREAT_IS_COM
    ON HOMEPAGE.NR_STORIES (CREATION_DATE DESC, IS_COMMUNITY_STORY);

reorg indexes all for table HOMEPAGE.NR_STORIES;    

UPDATE HOMEPAGE.NR_STORIES SET IS_COMMUNITY_STORY = 0;

UPDATE HOMEPAGE.NR_STORIES SET IS_COMMUNITY_STORY = 1 WHERE SOURCE = 'communities';

--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
-- SPR #LNOO88DP2R Move outside java migration utility the creation of view. 
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------

----------------------------------------------------------------------
-- CLEANUP DATABASE FROM AN OLD MIGRATION
----------------------------------------------------------------------
-- ALL the migrated stories have the story id = to the event record uuid

-- delete saved migrated
DELETE FROM HOMEPAGE.NR_NEWS_SAVED WHERE NEWS_STORY_ID IN ( SELECT STORY_ID FROM HOMEPAGE.NR_STORIES  WHERE STORY_ID = EVENT_RECORD_UUID );

COMMIT;

-- delete discovery
DELETE FROM HOMEPAGE.NR_NEWS_DISCOVERY WHERE NEWS_STORY_ID IN ( SELECT STORY_ID FROM HOMEPAGE.NR_STORIES  WHERE STORY_ID = EVENT_RECORD_UUID );

COMMIT;

-- delete community person stories
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES WHERE STORY_ID IN ( SELECT STORY_ID FROM HOMEPAGE.NR_STORIES  WHERE STORY_ID = EVENT_RECORD_UUID );

COMMIT;

-- delete profiles and tags stories
DELETE FROM HOMEPAGE.NR_FOLLOWED_STORIES WHERE STORY_ID IN ( SELECT STORY_ID FROM HOMEPAGE.NR_STORIES WHERE STORY_ID = EVENT_RECORD_UUID );

COMMIT;

-- delete stories
DELETE FROM HOMEPAGE.NR_STORIES WHERE STORY_ID = EVENT_RECORD_UUID;

COMMIT;
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------------
-- PERFORM A MIGRATION DATABASE FROM AN OLD MIGRATION
----------------------------------------------------------------------

----------------------------------------------------
-- NR_NEWS_SAVED
----------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_SAVED ( 
    NEWS_RECORDS_ID, 
    EVENT_NAME, 
    READER_ID, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    ENTRY_NAME, 
    ENTRY_URL, 
    ENTRY_ATOM_URL, 
    CREATION_DATE, 
    BRIEF_DESC, 
    IS_BRIEF_DESC_RTL, 
    ACTOR_UUID, 
    EVENT_RECORD_UUID, 
    TAGS, 
    META_TEMPLATE, 
    TEXT_META_TEMPLATE, 
    IS_CONTAINER, 
    ITEM_ID, 
    ITEM_CORRELATION_ID, 
    N_COMMENTS, 
    N_RECOMMANDATIONS, 
    GROUP_TYPE, 
    NEWS_STORY_ID 
) 
    SELECT 
        NEWS_RECORDS_ID, 
        EVENT_NAME, 
        READER_ID, 
        SOURCE, 
        CONTAINER_ID, 
        CONTAINER_NAME, 
        CONTAINER_URL, 
        ENTRY_NAME, 
        ENTRY_URL, 
        ENTRY_ATOM_URL, 
        CREATION_DATE, 
        BRIEF_DESC, 
        IS_BRIEF_DESC_RTL, 
        ACTOR_UUID, 
        EVENT_RECORD_UUID, 
        TAGS, 
        META_TEMPLATE, 
        TEXT_META_TEMPLATE, 
        IS_CONTAINER, 
        ITEM_ID, 
        ITEM_CORRELATION_ID, 
        0, 
        0, 
        0, 
        EVENT_RECORD_UUID 
    FROM HOMEPAGE.NR_NEWS_RECORDS 
    WHERE IS_SAVED = 1;

COMMIT;
----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

------------------------------------------------------------
-- NR_NEWS_DISCOVERY
------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_DISCOVERY 
( 
            NEWS_RECORDS_ID, 
            EVENT_NAME, 
            SOURCE, 
            CONTAINER_ID, 
            CONTAINER_NAME, 
            CONTAINER_URL, 
            ENTRY_NAME, 
            ENTRY_URL, 
            ENTRY_ATOM_URL, 
            CREATION_DATE, 
            BRIEF_DESC, 
            IS_BRIEF_DESC_RTL, 
            ACTOR_UUID, 
            EVENT_RECORD_UUID, 
            TAGS, 
            META_TEMPLATE, 
            TEXT_META_TEMPLATE, 
            ITEM_ID, 
            ITEM_CORRELATION_ID, 
            N_COMMENTS, 
            N_RECOMMANDATIONS, 
            GROUP_TYPE, 
            NEWS_STORY_ID, 
            IS_COMMUNITY_STORY 
) 
    SELECT 
            NEWS_RECORDS_ID, 
            EVENT_NAME, 
            SOURCE, 
            CONTAINER_ID, 
            CONTAINER_NAME, 
            CONTAINER_URL, 
            ENTRY_NAME, 
            ENTRY_URL, 
            ENTRY_ATOM_URL, 
            CREATION_DATE, 
            BRIEF_DESC, 
            IS_BRIEF_DESC_RTL, 
            ACTOR_UUID, 
            EVENT_RECORD_UUID, 
            TAGS, 
            META_TEMPLATE, 
            TEXT_META_TEMPLATE, 
            ITEM_ID, 
            ITEM_CORRELATION_ID, 
            0, 
            0, 
            0, 
            EVENT_RECORD_UUID, 
            0 
    FROM    HOMEPAGE.NR_NEWS_RECORDS 
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_PUBLIC = 1 AND READER_ID IS NULL AND IS_CONTAINER = 0;

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY 
SET CONTAINER_URL = '{communities}' || SUBSTR( CONTAINER_URL, LOCATE('/service/html',CONTAINER_URL) )
WHERE EVENT_NAME = 'files.file.created' AND CONTAINER_URL LIKE 'http%';

COMMIT;

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

--------------------------------
-- NR_TAGS_STORIES
--------------------------------
-- a) create TMP_FOLLOWS
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE 
            WHERE SOURCE = 'tag' 
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);

-- b) create TMP_FOLLOWED_STORIES
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_STORIES AS ( 
    SELECT  NR_NEWS_RECORDS.EVENT_RECORD_UUID   STORY_ID, 
            NR_NEWS_RECORDS.EVENT_NAME          EVENT_NAME, 
            NR_NEWS_RECORDS.SOURCE              SOURCE, 
            NR_NEWS_RECORDS.CONTAINER_ID        CONTAINER_ID, 
            NR_NEWS_RECORDS.CONTAINER_NAME      CONTAINER_NAME, 
            NR_NEWS_RECORDS.CONTAINER_URL       CONTAINER_URL, 
            ''                                  ITEM_NAME, 
            ''                                  ITEM_URL, 
            ''                                  ITEM_ATOM_URL, 
            ''                                  ITEM_ID, 
            ''                                  ITEM_CORRELATION_ID, 
            NR_NEWS_RECORDS.CREATION_DATE       CREATION_DATE, 
            NR_NEWS_RECORDS.BRIEF_DESC          BRIEF_DESC, 
            NR_NEWS_RECORDS.ACTOR_UUID          ACTOR_UUID, 
            NR_NEWS_RECORDS.EVENT_RECORD_UUID   EVENT_RECORD_UUID, 
            NR_NEWS_RECORDS.TAGS                TAGS, 
            NR_NEWS_RECORDS.META_TEMPLATE       META_TEMPLATE, 
            NR_NEWS_RECORDS.TEXT_META_TEMPLATE  TEXT_META_TEMPLATE, 
            ''                                  R_META_TEMPLATE, 
            ''                                  R_TEXT_META_TEMPLATE, 
            0                                   N_COMMENTS, 
            0                                   N_RECOMMANDATIONS, 
            0                                   IS_COMMUNITY_STORY 
    FROM ( 
            SELECT  EVENT_RECORD_UUID               STORY_ID, 
                    EVENT_NAME                      EVENT_NAME, 
                    MAX(NEWS_RECORDS_ID)            NEWS_RECORDS_ID 
            FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
                    ( 
                        SELECT DISTINCT (PERSON_ID) PERSON_ID, FOLLOWED_CONTAINER 
                        FROM HOMEPAGE.TMP_FOLLOWS 
                    ) FOLLOWERS 
            WHERE   NR_NEWS_RECORDS.IS_CONTAINER = 1 AND 
                    NR_NEWS_RECORDS.SOURCE LIKE 'tag.%' AND 
                    NR_NEWS_RECORDS.CONTAINER_ID = FOLLOWERS.FOLLOWED_CONTAINER AND 
                    NR_NEWS_RECORDS.READER_ID IS NULL 
            GROUP BY EVENT_RECORD_UUID, EVENT_NAME 
        ) T2, HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
    WHERE T2.NEWS_RECORDS_ID = NR_NEWS_RECORDS.NEWS_RECORDS_ID 
);

COMMIT;

-- c) copy stories
INSERT INTO HOMEPAGE.NR_STORIES ( 
    STORY_ID, 
    EVENT_NAME, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    ITEM_NAME, 
    ITEM_ATOM_URL, 
    ITEM_ID, 
    ITEM_CORRELATION_ID, 
    CREATION_DATE, 
    BRIEF_DESC, 
    ACTOR_UUID, 
    EVENT_RECORD_UUID, 
    TAGS, 
    META_TEMPLATE, 
    TEXT_META_TEMPLATE, 
    R_TEXT_META_TEMPLATE, 
    N_COMMENTS, 
    N_RECOMMANDATIONS, 
    IS_COMMUNITY_STORY 
) 
    SELECT  STORY_ID, 
            EVENT_NAME, 
            SOURCE, 
            CONTAINER_ID, 
            CONTAINER_NAME, 
            CONTAINER_URL, 
            ITEM_NAME, 
            ITEM_ATOM_URL, 
            ITEM_ID, 
            ITEM_CORRELATION_ID, 
            CREATION_DATE, 
            BRIEF_DESC, 
            ACTOR_UUID, 
            EVENT_RECORD_UUID, 
            TAGS, 
            META_TEMPLATE, 
            TEXT_META_TEMPLATE, 
            R_TEXT_META_TEMPLATE, 
            N_COMMENTS, 
            N_RECOMMANDATIONS, 
            IS_COMMUNITY_STORY 
    FROM HOMEPAGE.TMP_FOLLOWED_STORIES;

COMMIT;

-- d) copy tags stories
INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
    FOLLOWED_STORY_ID, 
    READER_ID, 
    CATEGORY_TYPE, 
    SOURCE, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CREATION_DATE, 
    STORY_ID 
) 
SELECT (SUBSTR(TMP_FOLLOWED_STORIES.STORY_ID,1,18) || SUBSTR(TMP_FOLLOWS.PERSON_ID,1,18))        FOLLOWED_STORY_ID, 
        TMP_FOLLOWS.PERSON_ID                       READER_ID, 
        10                                          CATEGORY_TYPE, 
        TMP_FOLLOWED_STORIES.SOURCE                 SOURCE, 
        TMP_FOLLOWED_STORIES.CONTAINER_ID           CONTAINER_ID, 
        TMP_FOLLOWED_STORIES.ITEM_ID                ITEM_ID, 
        13                                          RESOURCE_TYPE, 
        TMP_FOLLOWED_STORIES.CREATION_DATE          CREATION_DATE, 
        TMP_FOLLOWED_STORIES.STORY_ID               STORY_ID 
FROM    HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS, HOMEPAGE.TMP_FOLLOWED_STORIES TMP_FOLLOWED_STORIES 
WHERE   TMP_FOLLOWS.FOLLOWED_CONTAINER = TMP_FOLLOWED_STORIES.CONTAINER_ID;

COMMIT;

-- e) SANITIZE
DELETE FROM HOMEPAGE.NR_STORIES WHERE TEXT_META_TEMPLATE = '' OR TEXT_META_TEMPLATE IS NULL OR TEXT_META_TEMPLATE = ' ';

COMMIT;

-- f) drop HOMEPAGE.TMP_FOLLOWED_STORIES
DROP VIEW HOMEPAGE.TMP_FOLLOWED_STORIES;

-- g) drop HOMEPAGE.TMP_FOLLOWS
DROP VIEW HOMEPAGE.TMP_FOLLOWS;

COMMIT;

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

--------------------------------
-- NR_PROFILES_STORIES
--------------------------------
-- a) create TMP_FOLLOWS
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE 
            WHERE SOURCE = 'profiles' 
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
); 

-- b) create TMP_FOLLOWED_STORIES
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_STORIES AS ( 
    SELECT  NR_NEWS_RECORDS.EVENT_RECORD_UUID   STORY_ID, 
            NR_NEWS_RECORDS.EVENT_NAME          EVENT_NAME, 
            NR_NEWS_RECORDS.SOURCE              SOURCE, 
            NR_NEWS_RECORDS.CONTAINER_ID        CONTAINER_ID, 
            NR_NEWS_RECORDS.CONTAINER_NAME      CONTAINER_NAME, 
            NR_NEWS_RECORDS.CONTAINER_URL       CONTAINER_URL, 
            ''                                  ITEM_NAME, 
            ''                                  ITEM_URL, 
            ''                                  ITEM_ATOM_URL, 
            ''                                  ITEM_ID, 
            ''                                  ITEM_CORRELATION_ID, 
            NR_NEWS_RECORDS.CREATION_DATE       CREATION_DATE, 
            NR_NEWS_RECORDS.BRIEF_DESC			BRIEF_DESC, 
            NR_NEWS_RECORDS.ACTOR_UUID          ACTOR_UUID, 
            NR_NEWS_RECORDS.EVENT_RECORD_UUID   EVENT_RECORD_UUID, 
            NR_NEWS_RECORDS.TAGS                TAGS, 
            NR_NEWS_RECORDS.META_TEMPLATE       META_TEMPLATE, 
            NR_NEWS_RECORDS.TEXT_META_TEMPLATE  TEXT_META_TEMPLATE, 
            ''                                  R_META_TEMPLATE, 
            ''                                  R_TEXT_META_TEMPLATE, 
            0                                   N_COMMENTS, 
            0                                   N_RECOMMANDATIONS, 
            0                                   IS_COMMUNITY_STORY 
    FROM ( 
            SELECT  EVENT_RECORD_UUID               STORY_ID, 
                    MIN(NEWS_RECORDS_ID)            NEWS_RECORDS_ID 
            FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, 
                    ( 
                        SELECT DISTINCT (PERSON_ID) PERSON_ID, FOLLOWED_CONTAINER 
                        FROM HOMEPAGE.TMP_FOLLOWS 
                    ) FOLLOWERS 
            WHERE   (NR_NEWS_RECORDS.ACTOR_UUID = FOLLOWERS.FOLLOWED_CONTAINER AND NR_NEWS_RECORDS.IS_PUBLIC = 1 ) OR 
                    (NR_NEWS_RECORDS.ACTOR_UUID = FOLLOWERS.FOLLOWED_CONTAINER AND NR_NEWS_RECORDS.SOURCE = 'profiles') 
            GROUP BY EVENT_RECORD_UUID 
        ) T2, HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS 
    WHERE T2.NEWS_RECORDS_ID = NR_NEWS_RECORDS.NEWS_RECORDS_ID 
); 

COMMIT;

-- c) copy stories
INSERT INTO HOMEPAGE.NR_STORIES ( 
    STORY_ID, 
    EVENT_NAME, 
    SOURCE, 
    CONTAINER_ID, 
    CONTAINER_NAME, 
    CONTAINER_URL, 
    ITEM_NAME, 
    ITEM_ATOM_URL, 
    ITEM_ID, 
    ITEM_CORRELATION_ID, 
    CREATION_DATE, 
    BRIEF_DESC, 
    ACTOR_UUID, 
    EVENT_RECORD_UUID, 
    TAGS, 
    META_TEMPLATE, 
    TEXT_META_TEMPLATE, 
    R_TEXT_META_TEMPLATE, 
    N_COMMENTS, 
    N_RECOMMANDATIONS, 
    IS_COMMUNITY_STORY 
) 
    SELECT  STORY_ID, 
            EVENT_NAME, 
            SOURCE, 
            CONTAINER_ID, 
            CONTAINER_NAME, 
            CONTAINER_URL, 
            ITEM_NAME, 
            ITEM_ATOM_URL, 
            ITEM_ID, 
            ITEM_CORRELATION_ID, 
            CREATION_DATE, 
            BRIEF_DESC, 
            ACTOR_UUID, 
            EVENT_RECORD_UUID, 
            TAGS, 
            META_TEMPLATE, 
            TEXT_META_TEMPLATE, 
            R_TEXT_META_TEMPLATE, 
            N_COMMENTS, 
            N_RECOMMANDATIONS, 
            IS_COMMUNITY_STORY 
    FROM HOMEPAGE.TMP_FOLLOWED_STORIES WHERE STORY_ID NOT IN ( SELECT STORY_ID FROM HOMEPAGE.NR_STORIES);
		
COMMIT;

-- d) copy profiles stories
INSERT INTO HOMEPAGE.NR_FOLLOWED_STORIES ( 
FOLLOWED_STORY_ID, 
READER_ID, 
CATEGORY_TYPE, 
SOURCE, 
CONTAINER_ID, 
ITEM_ID, 
RESOURCE_TYPE, 
CREATION_DATE, 
STORY_ID 
) 
    SELECT SUBSTR(TMP_FOLLOWS.PERSON_ID,1,18) || SUBSTR(TMP_FOLLOWED_STORIES.STORY_ID,1,18)       FOLLOWED_STORY_ID, 
            TMP_FOLLOWS.PERSON_ID                       READER_ID, 
            2                                           CATEGORY_TYPE, 
            TMP_FOLLOWED_STORIES.SOURCE                 SOURCE, 
            TMP_FOLLOWED_STORIES.CONTAINER_ID           CONTAINER_ID, 
            TMP_FOLLOWED_STORIES.ITEM_ID                ITEM_ID, 
            10                                          RESOURCE_TYPE, 
            TMP_FOLLOWED_STORIES.CREATION_DATE          CREATION_DATE, 
            TMP_FOLLOWED_STORIES.STORY_ID               STORY_ID 
    FROM    HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS, HOMEPAGE.TMP_FOLLOWED_STORIES TMP_FOLLOWED_STORIES 
    WHERE   TMP_FOLLOWS.FOLLOWED_CONTAINER = TMP_FOLLOWED_STORIES.ACTOR_UUID; 

COMMIT;

-- e) SANITIZE
DELETE FROM HOMEPAGE.NR_STORIES WHERE TEXT_META_TEMPLATE = '' OR TEXT_META_TEMPLATE IS NULL OR TEXT_META_TEMPLATE = ' ';

COMMIT;

-- f) drop HOMEPAGE.TMP_FOLLOWED_STORIES
DROP VIEW HOMEPAGE.TMP_FOLLOWED_STORIES;

-- g) drop HOMEPAGE.TMP_FOLLOWS
DROP VIEW HOMEPAGE.TMP_FOLLOWS;

COMMIT;

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

--------------------------------
-- NR_COMM_PERSON_STORIES
--------------------------------

-- a) create tmp_follows view
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
    SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, CONTAINER_ID FOLLOWED_CONTAINER 
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE 
            WHERE SOURCE = 'tag' or  SOURCE = 'profiles' 
            ) TEMP 
    WHERE   IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID 
);

-- b) create tmp_followed_stories
CREATE VIEW HOMEPAGE.TMP_FOLLOWED_STORIES AS ( 
    SELECT  NR_STORIES.STORY_ID         STORY_ID, 
            T3.COMM_PER_READER_ID       COMM_PER_READER_ID, 
            T3.RESOURCE_TYPE            RESOURCE_TYPE, 
            NR_STORIES.CONTAINER_ID     CONTAINER_ID, 
            NR_STORIES.ITEM_ID          ITEM_ID, 
            NR_STORIES.CREATION_DATE    CREATION_DATE, 
            NR_STORIES.SOURCE           SOURCE 
    FROM HOMEPAGE.NR_STORIES NR_STORIES, ( 
        SELECT  T2.STORY_ID                 STORY_ID, 
                T2.READER_ID                COMM_PER_READER_ID, 
                MAX(T2.RESOURCE_TYPE)       RESOURCE_TYPE 
        FROM ( 
                SELECT  READER_ID,  MAX(STORY_ID) STORY_ID 
                FROM    HOMEPAGE.NR_FOLLOWED_STORIES NR_FOLLOWED_STORIES 
                WHERE   (NR_FOLLOWED_STORIES.CATEGORY_TYPE = 2 AND NR_FOLLOWED_STORIES.RESOURCE_TYPE = 10) OR 
                        (NR_FOLLOWED_STORIES.CATEGORY_TYPE = 10 AND NR_FOLLOWED_STORIES.RESOURCE_TYPE = 13) 
                GROUP BY READER_ID, STORY_ID 
            ) T1, HOMEPAGE.NR_FOLLOWED_STORIES T2 
        WHERE T1.STORY_ID = T2.STORY_ID 
        GROUP BY T2.STORY_ID, T2.READER_ID 
    ) T3 
    WHERE NR_STORIES.STORY_ID = T3.STORY_ID 
);

COMMIT;

INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW ( 
    COMM_PERSON_FOLLOW_ID, 
    PERSON_ID, 
    PERSON_COMMUNITY_ID 
) 
SELECT SUBSTR(STORY_ID,1,18)  || SUBSTR(A,1,18) STORY_ID, A PERSON_ID, B PERSON_COMMUNITY_ID 
FROM ( 
    SELECT MAX(STORY_ID) STORY_ID, COMM_PER_READER_ID A, COMM_PER_READER_ID B 
    FROM HOMEPAGE.TMP_FOLLOWED_STORIES 
    WHERE COMM_PER_READER_ID NOT IN ( 
        SELECT PERSON_ID 
        FROM HOMEPAGE.NR_COMM_PERSON_FOLLOW 
    	) 
    GROUP BY COMM_PER_READER_ID 
    ) AS T;


COMMIT;

INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES ( 
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID 
) 
    SELECT  SUBSTR(COMM_PER_READER_ID,1,18) || SUBSTR(STORY_ID,1,18)      COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            MAX (CONTAINER_ID) CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            2, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID 
    FROM HOMEPAGE.TMP_FOLLOWED_STORIES WHERE RESOURCE_TYPE = 10
    GROUp BY COMM_PER_READER_ID, CONTAINER_ID, ITEM_ID, RESOURCE_TYPE,  CREATION_DATE, SOURCE, STORY_ID;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES ( 
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID 
) 
    SELECT  SUBSTR(COMM_PER_READER_ID,1,18) || SUBSTR(STORY_ID,1,18)       COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            10, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID 
    FROM HOMEPAGE.TMP_FOLLOWED_STORIES WHERE RESOURCE_TYPE = 13;

COMMIT;

-- f) drop HOMEPAGE.TMP_FOLLOWED_STORIES
DROP VIEW HOMEPAGE.TMP_FOLLOWED_STORIES;

-- g) drop HOMEPAGE.TMP_FOLLOWS
DROP VIEW HOMEPAGE.TMP_FOLLOWS;

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE INDEX HOMEPAGE.EMD_RES_PREF_PER_ID
    ON HOMEPAGE.EMD_RESOURCE_PREF (PERSON_ID);

runstats on table HOMEPAGE.EMD_RESOURCE_PREF with distribution and detailed indexes all allow write access;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
ADD UPDATE_DATE TIMESTAMP;

reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;

--------------------------------------------------------------------------------------------------
--------------- START: UPDATE CONTENT FOR NR_NEWS_STATUS_CONTENT ---------------------------------
--------------------------------------------------------------------------------------------------

-- 1) fixup49 CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET CREATION_DATE = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.CREATION_DATE)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

COMMIT;    

-- 2) fixup49 UPDATE_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET UPDATE_DATE = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.UPDATE_DATE)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

COMMIT;    

-- 3) fixup49 TARGET_SUBJECT_ID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET TARGET_SUBJECT_ID = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.TARGET_SUBJECT_ID)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

COMMIT;    

-- 4) fixup49  ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET  ACTOR_UUID = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.ACTOR_UUID)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

COMMIT;    

-- 5) fixup49  ITEM_URL
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET  ITEM_URL = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.ITEM_URL)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

COMMIT;    

--------------------------------------------------------------------------------------------------
--------------- END: UPDATE CONTENT FOR NR_NEWS_STATUS_CONTENT -----------------------------------
--------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 50
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------
-- ADDING COLUMN ITEM_CORRELATION_NAME TO NR_STORIES
--------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES
    ADD COLUMN ITEM_CORRELATION_NAME VARCHAR(256);
    
--------------------------------------------------------------------------
-- 1 NR_RESPONSES_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RESPONSES_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT1_TYPE
    				CHECK
    				(CATEGORY_TYPE = 1)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES 
    ADD CONSTRAINT PK_RESP_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES
    ADD CONSTRAINT FK_RESP_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.RESPONSES_STORIES_IDX
    ON HOMEPAGE.NR_RESPONSES_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.RESPONSES_STORIES_CIDX
    ON HOMEPAGE.NR_RESPONSES_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.RESPONSES_STORIES_SIDX
    ON HOMEPAGE.NR_RESPONSES_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_RESPONSES_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 2 NR_PROFILES_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PROFILES_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT2_TYPE
    				CHECK
    				(CATEGORY_TYPE = 2)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES 
    ADD CONSTRAINT PK_PROF_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES
    ADD CONSTRAINT FK_PROF_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.PROFILES_STORIES_IDX
    ON HOMEPAGE.NR_PROFILES_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.PROFILES_STORIES_CIDX
    ON HOMEPAGE.NR_PROFILES_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.PROFILES_STORIES_SIDX
    ON HOMEPAGE.NR_PROFILES_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_PROFILES_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 3 NR_COMMUNITIES_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMMUNITIES_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT3_TYPE
    				CHECK
    				(CATEGORY_TYPE = 3)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES 
    ADD CONSTRAINT PK_COMM_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES
    ADD CONSTRAINT FK_COM_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.COMMUNITIES_STORIES_IDX
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.COMMUNITIES_STORIES_CIDX
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.COMMUNITIES_STORIES_SIDX
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMMUNITIES_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 4 NR_ACTIVITIES_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIVITIES_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   		CK_CAT4_TYPE
    					CHECK
    					(CATEGORY_TYPE = 4)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES 
    ADD CONSTRAINT PK_ACT_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES
    ADD CONSTRAINT FK_ACT_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.ACTIVITIES_STORIES_IDX
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.ACTIVITIES_STORIES_CIDX
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.ACTIVITIES_STORIES_SIDX
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ACTIVITIES_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 5 NR_BLOGS_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_BLOGS_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   		CK_CAT5_TYPE
    					CHECK
    					(CATEGORY_TYPE = 5)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES 
    ADD CONSTRAINT PK_BLOGS_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES
    ADD CONSTRAINT FK_BLOGS_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.BLOGS_STORIES_IDX
    ON HOMEPAGE.NR_BLOGS_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.BLOGS_STORIES_CIDX
    ON HOMEPAGE.NR_BLOGS_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.BLOGS_STORIES_SIDX
    ON HOMEPAGE.NR_BLOGS_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_BLOGS_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 6 NR_BOOKMARKS_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_BOOKMARKS_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT6_TYPE
    				CHECK
    				(CATEGORY_TYPE = 6)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES 
    ADD CONSTRAINT PK_BOOKS_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES
    ADD CONSTRAINT FK_BOOKS_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.BOOKMARKS_STORIES_IDX
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.BOOKMARKS_STORIES_CIDX
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.BOOKMARKS_STORIES_SIDX
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_BOOKMARKS_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 7 NR_FILES_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FILES_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   		CK_CAT7_TYPE
    					CHECK
    					(CATEGORY_TYPE = 7)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_FILES_STORIES 
    ADD CONSTRAINT PK_FILES_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_FILES_STORIES
    ADD CONSTRAINT FK_FILES_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.FILES_STORIES_IDX
    ON HOMEPAGE.NR_FILES_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.FILES_STORIES_CIDX
    ON HOMEPAGE.NR_FILES_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.FILES_STORIES_SIDX
    ON HOMEPAGE.NR_FILES_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FILES_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 8 NR_FORUMS_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FORUMS_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT8_TYPE
    				CHECK
    				(CATEGORY_TYPE = 8)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES 
    ADD CONSTRAINT PK_FORUMS_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES
    ADD CONSTRAINT FK_FORUMS_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.FORUMS_STORIES_IDX
    ON HOMEPAGE.NR_FORUMS_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.FORUMS_STORIES_CIDX
    ON HOMEPAGE.NR_FORUMS_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.FORUMS_STORIES_SIDX
    ON HOMEPAGE.NR_FORUMS_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FORUMS_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 9 NR_WIKIS_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_WIKIS_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT9_TYPE
    				CHECK
    				(CATEGORY_TYPE = 9)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES 
    ADD CONSTRAINT PK_WIKIS_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES
    ADD CONSTRAINT FK_WIKIS_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.WIKIS_STORIES_IDX
    ON HOMEPAGE.NR_WIKIS_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.WIKIS_STORIES_CIDX
    ON HOMEPAGE.NR_WIKIS_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.WIKIS_STORIES_SIDX
    ON HOMEPAGE.NR_WIKIS_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_WIKIS_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------
-- 10 NR_WIKIS_STORIES
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_TAGS_STORIES (
	FOLLOWED_STORY_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL,
	CONSTRAINT   	CK_CAT10_TYPE
    				CHECK
    				(CATEGORY_TYPE = 10)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_TAGS_STORIES 
    ADD CONSTRAINT PK_TAGS_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);

ALTER TABLE HOMEPAGE.NR_TAGS_STORIES
    ADD CONSTRAINT FK_TAGS_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

CREATE INDEX HOMEPAGE.TAGS_STORIES_IDX
    ON HOMEPAGE.NR_TAGS_STORIES (READER_ID, CREATION_DATE ASC);

CREATE INDEX HOMEPAGE.TAGS_STORIES_CIDX
    ON HOMEPAGE.NR_TAGS_STORIES (CATEGORY_TYPE);

CREATE INDEX HOMEPAGE.TAGS_STORIES_SIDX
    ON HOMEPAGE.NR_TAGS_STORIES (STORY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_TAGS_STORIES TO USER LCUSER;

COMMIT;

--------------------------------------------------------------------------------------------------------------
-- RENAME THE ORIGINAL TABLE SO WE CAN USE THE VIEW NAME TO REFERENCE FROM THE CODE THE NEW SET OF TABLES
--------------------------------------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP FOREIGN KEY FK_F_STORY_ID;

RENAME TABLE HOMEPAGE.NR_FOLLOWED_STORIES TO FOLLOWED_STORIES_ORIGINAL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.FOLLOWED_STORIES_ORIGINAL TO USER LCUSER;

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_FOLLOWED_STORIES AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_STORIES
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_STORIES
);

--ALTER VIEW HOMEPAGE.NR_FOLLOWED_STORIES ENABLE QUERY OPTIMIZATION;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOWED_STORIES TO USER LCUSER;

COMMIT;

------------------------------------------------------------------------------------------------------
-- MOVING BACK DATA
------------------------------------------------------------------------------------------------------

----------------------------
-- 1 NR_RESPONSES_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 1;

COMMIT;

INSERT INTO HOMEPAGE.NR_RESPONSES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 1;

COMMIT;

----------------------------
-- 2 NR_PROFILES_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 2;

COMMIT;

INSERT INTO HOMEPAGE.NR_PROFILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 2;

COMMIT;

----------------------------
-- 3 NR_COMMUNITIES_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 3;

COMMIT;

INSERT INTO HOMEPAGE.NR_COMMUNITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 3;

COMMIT;

----------------------------
-- 4 NR_ACTIVITIES_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 4;

COMMIT;

INSERT INTO HOMEPAGE.NR_ACTIVITIES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 4;

COMMIT;

----------------------------
-- 5 NR_BLOGS_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 5;

COMMIT;

INSERT INTO HOMEPAGE.NR_BLOGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 5;

COMMIT;

----------------------------
-- 6 NR_BOOKMARKS_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 6;

COMMIT;

INSERT INTO HOMEPAGE.NR_BOOKMARKS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 6;

COMMIT;

----------------------------
-- 7 NR_FILES_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 7;

COMMIT;

INSERT INTO HOMEPAGE.NR_FILES_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 7;

COMMIT;

----------------------------
-- 8 NR_FORUMS_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 8;

COMMIT;

INSERT INTO HOMEPAGE.NR_FORUMS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 8;

COMMIT;

----------------------------
-- 9 NR_WIKIS_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 9;

COMMIT;

INSERT INTO HOMEPAGE.NR_WIKIS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 9;

COMMIT;

----------------------------
-- 10 NR_TAGS_STORIES
----------------------------
INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '0%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '1%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '2%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '3%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '4%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '5%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '6%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '7%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '8%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE '9%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'a%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'b%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'c%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'd%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'e%' AND CATEGORY_TYPE = 10;

COMMIT;

INSERT INTO HOMEPAGE.NR_TAGS_STORIES SELECT * FROM HOMEPAGE.FOLLOWED_STORIES_ORIGINAL WHERE FOLLOWED_STORY_ID LIKE 'f%' AND CATEGORY_TYPE = 10;

COMMIT;

------------------------------------
-- DROP TEMP TABLE
------------------------------------
DROP TABLE HOMEPAGE.FOLLOWED_STORIES_ORIGINAL;

COMMIT;

--------------------------------------------------------------------------------------------------------
-- REORG AND RUNSTATS
--------------------------------------------------------------------------------------------------------
reorg table HOMEPAGE.NR_RESPONSES_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_RESPONSES_STORIES;
runstats on table HOMEPAGE.NR_RESPONSES_STORIES;
runstats on table HOMEPAGE.NR_RESPONSES_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_PROFILES_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_PROFILES_STORIES;
runstats on table HOMEPAGE.NR_PROFILES_STORIES;
runstats on table HOMEPAGE.NR_PROFILES_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_COMMUNITIES_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_COMMUNITIES_STORIES;
runstats on table HOMEPAGE.NR_COMMUNITIES_STORIES;
runstats on table HOMEPAGE.NR_COMMUNITIES_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_ACTIVITIES_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_ACTIVITIES_STORIES;
runstats on table HOMEPAGE.NR_ACTIVITIES_STORIES;
runstats on table HOMEPAGE.NR_ACTIVITIES_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_BLOGS_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_BLOGS_STORIES;
runstats on table HOMEPAGE.NR_BLOGS_STORIES;
runstats on table HOMEPAGE.NR_BLOGS_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_BOOKMARKS_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_BOOKMARKS_STORIES;
runstats on table HOMEPAGE.NR_BOOKMARKS_STORIES;
runstats on table HOMEPAGE.NR_BOOKMARKS_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_FILES_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_FILES_STORIES;
runstats on table HOMEPAGE.NR_FILES_STORIES;
runstats on table HOMEPAGE.NR_FILES_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_FORUMS_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_FORUMS_STORIES;
runstats on table HOMEPAGE.NR_FORUMS_STORIES;
runstats on table HOMEPAGE.NR_FORUMS_STORIES with distribution and detailed indexes all allow write access;

reorg table HOMEPAGE.NR_WIKIS_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_WIKIS_STORIES;
runstats on table HOMEPAGE.NR_WIKIS_STORIES;
runstats on table HOMEPAGE.NR_WIKIS_STORIES with distribution and detailed indexes all allow write access;


reorg table HOMEPAGE.NR_TAGS_STORIES use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_TAGS_STORIES;
runstats on table HOMEPAGE.NR_TAGS_STORIES;
runstats on table HOMEPAGE.NR_TAGS_STORIES with distribution and detailed indexes all allow write access;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE UPGRADE30 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 30-32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- HOMEPAGE.SR_FILESCONTENT
------------------------------------------------

-- SPR# MPML7UVM9X
-- Missing index on SR_FILESCONTENT causes full table scan
CREATE INDEX HOMEPAGE.SR_FILESCONTENT_IS_CURRENT_IDX 
ON HOMEPAGE.SR_FILESCONTENT(IS_CURRENT);

DELETE FROM HOMEPAGE.SR_FILESCONTENT;

------------------------------------------------
-- HOMEPAGE.SR_FILECONTENTTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FILECONTENTTASKDEF (
	FILECONTENT_TASK_ID VARCHAR(36) NOT NULL,	
	TASK_ID VARCHAR(36) NOT NULL,
	FILE_CONTENT_TASK_SERVICES VARCHAR(256) NOT NULL,
	CONTENT_FAILURES_ONLY SMALLINT NOT NULL	
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "PK_FC_TASK_ID" PRIMARY KEY ("FILECONTENT_TASK_ID");

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_FC" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "FK_FC_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_BACKUPTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_BACKUPTASKDEF (
	BACKUP_TASK_ID VARCHAR(36) NOT NULL,	
	TASK_ID VARCHAR(36) NOT NULL,
	TYPE VARCHAR(36) NOT NULL,
	SCRIPT VARCHAR(256)
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "PK_BKUP_TASK_ID" PRIMARY KEY ("BACKUP_TASK_ID");	

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_BKP" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "FK_BKUP_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_ALLTASKSDEF
------------------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
);

------------------------------------------------
-- HOMEPAGE.SR_INDEX_MANAGEMENT
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_MANAGEMENT (
	NODE_ID VARCHAR(36) NOT NULL,
	LAST_CRAWLING_VERSION BIGINT NOT NULL,
	OUT_OF_DATE SMALLINT NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
	ADD CONSTRAINT "PK_INDEX_MGMT_ID" PRIMARY KEY ("NODE_ID");
	
------------------------------------------------
-- HOMEPAGE.SR_RESUME_TOKENS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_RESUME_TOKENS (
	TOKEN_ID VARCHAR(36) NOT NULL,
	NODE_ID VARCHAR(36) NOT NULL,
	TOKEN VARCHAR(256) NOT NULL,
	SERVICE VARCHAR(36) NOT NULL
)
IN HOMEPAGETABSPACE;


ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT "PK_TOKEN_ID" PRIMARY KEY ("TOKEN_ID");


ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT "FK_RT_IDX_MGMT_ID" FOREIGN KEY ("NODE_ID")
	REFERENCES HOMEPAGE.SR_INDEX_MANAGEMENT("NODE_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_INDEX_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_DOCS(
	DOCUMENT_ID VARCHAR(36) NOT NULL,
	DOCUMENT BLOB NOT NULL,
	CRAWLING_VERSION BIGINT NOT NULL,
	ACTION SMALLINT NOT NULL,
	UPDATE_TIME  TIMESTAMP NOT NULL,
	RESUME_POINT VARCHAR(256),
	SERVICE VARCHAR(36) NOT NULL,
	FILESCONTENT_ID VARCHAR(36)
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS
	ADD CONSTRAINT "PK_INDEX_DOCS_ID" PRIMARY KEY ("DOCUMENT_ID");

CREATE INDEX HOMEPAGE.SR_INDEX_CRAWL_VERSION_IDX
	ON HOMEPAGE.SR_INDEX_DOCS (CRAWLING_VERSION);

------------------------------------------------
-- HOMEPAGE.SR_FACET_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FACET_DOCS(
	FACET_ID VARCHAR(36) NOT NULL,
	DOCUMENT_ID VARCHAR(36) NOT NULL,
	FACET BLOB NOT NULL,
	CRAWLING_VERSION BIGINT NOT NULL
)
IN HOMEPAGETABSPACE;
	
ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT "PK_FACET_DOCS_ID" PRIMARY KEY ("FACET_ID");
	
-- This statement will be included in FIXUP32
--ALTER TABLE HOMEPAGE.SR_FACET_DOCS
--	ADD CONSTRAINT "FK_IDX_DOC_ID" FOREIGN KEY ("DOCUMENT_ID") 
--	REFERENCES  HOMEPAGE.SR_INDEX_DOCS("DOCUMENT_ID") ON DELETE CASCADE;

CREATE INDEX HOMEPAGE.SR_FACET_DOCS_PARENT_IDX
		ON HOMEPAGE.SR_FACET_DOCS (DOCUMENT_ID);


------------------------------------------
-- START GRANTS
------------------------------------------

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FILECONTENTTASKDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_DOCS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FACET_DOCS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_RESUME_TOKENS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_BACKUPTASKDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_MANAGEMENT TO USER LCUSER;

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--SPR #JJOL82AEP2
DELETE FROM HOMEPAGE.SR_FACET_DOCS WHERE DOCUMENT_ID NOT IN (SELECT DOCUMENT_ID FROM HOMEPAGE.SR_INDEX_DOCS);

ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT "FK_IDX_DOC_ID" FOREIGN KEY ("DOCUMENT_ID") 
	REFERENCES  HOMEPAGE.SR_INDEX_DOCS("DOCUMENT_ID") ON DELETE CASCADE;	

----------------------------------------
--  SR_SANDTASKDEF
----------------------------------------

CREATE TABLE HOMEPAGE.SR_SANDTASKDEF (
    SAND_TASK_ID VARCHAR(36) NOT NULL,
    TASK_ID VARCHAR(36) NOT NULL,
	SAND_TASK_SERVICES VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "PK_ST_TASK_ID" PRIMARY KEY ("SAND_TASK_ID");

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_ST" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "FK_ST_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED) VALUES('ea789e87-c262-484b-92f4-d60af4bef3d4','nightly-sand-task','0 15 1 * * ?','0 0 1 * * ?','SaNDTask',1);

INSERT INTO HOMEPAGE.SR_SANDTASKDEF(SAND_TASK_ID,TASK_ID,SAND_TASK_SERVICES) VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fb','ea789e87-c262-484b-92f4-d60af4bef3d4','evidence-graph-manageremployees-tags-taggedby');

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_SANDTASKDEF TO USER LCUSER;


----------------------------------------
--  SR_ALLTASKSDEF
----------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''			AS	SAND_TASK_SERVICES,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
        ''                 AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
)
UNION
(
        SELECT T9.TASK_ID                               AS      PARENT_TASK_ID,
        T9.TASK_NAME                                    AS      PARENT_TASK_NAME,
        T9.INTERVAL                                             AS      PARENT_TASK_INTERVAL,
        T9.STARTBY                                              AS      PARENT_TASK_STARTBY,
        T9.TASK_TYPE                                    AS      PARENT_TASK_TYPE,
        T9.ENABLED                                              AS      PARENT_TASK_ENABLED,
        ''                                                              AS      INDEXING_TASK_SERVICES,
        0                                                               AS      INDEXING_TASK_OPTIMIZE,
        ''                                                              AS      INDEXING_TASK_ID,
        ''                                                              AS      OPTIMIZE_TASK_ID,
        ''                                              AS      FILECONTENT_TASK_ID,
        ''                                              AS      FILE_CONTENT_TASK_SERVICES,
        0                                               AS      CONTENT_FAILURES_ONLY,
        T10.SAND_TASK_ID                  AS      SAND_TASK_ID,
	T10.SAND_TASK_SERVICES			AS	SAND_TASK_SERVICES,
        ''                                                              AS      BACKUP_TASK_ID,
        ''                                                              AS      BACKUP_TASK_TYPE,
        ''                                                              AS      BACKUP_TASK_SCRIPT,
        T10.SAND_TASK_ID                  AS      CHILDTASK_PK
        FROM   HOMEPAGE.SR_TASKDEF T9,HOMEPAGE.SR_SANDTASKDEF T10
        WHERE  T9.TASK_ID=T10.TASK_ID
);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO USER LCUSER;

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=LOWER(INDEXING_TASK_SERVICES);

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES='all_configured' 
WHERE INDEXING_TASK_ID='315a416c-78e2-4cf4-bcb2-69eb8d3a2583';

UPDATE  HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=INDEXING_TASK_SERVICES || '-forums'
WHERE   INDEXING_TASK_SERVICES LIKE '%communities%' AND INDEXING_TASK_SERVICES NOT LIKE '%forums%';

----------------------------------------
--  SR_RESUME_TOKENS
----------------------------------------


CREATE TABLE HOMEPAGE.TMP_SR_RESUME_TOKENS(
	TOKEN_ID VARCHAR(36) NOT NULL,
	NODE_ID VARCHAR(36) NOT NULL,
	TOKEN VARCHAR(256),
	SERVICE VARCHAR(36) NOT NULL
)
IN HOMEPAGETABSPACE;

INSERT INTO HOMEPAGE.TMP_SR_RESUME_TOKENS(
	SELECT TOKEN_ID,NODE_ID,TOKEN,SERVICE FROM HOMEPAGE.SR_RESUME_TOKENS
);

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS 
DROP COLUMN TOKEN;

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS 
ADD COLUMN TOKEN VARCHAR(256);

reorg table HOMEPAGE.SR_RESUME_TOKENS use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_RESUME_TOKENS;

RUNSTATS ON TABLE "HOMEPAGE"."SR_RESUME_TOKENS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_RESUME_TOKENS" FOR INDEXES ALL;

UPDATE HOMEPAGE.SR_RESUME_TOKENS 
SET TOKEN=( SELECT TMP.TOKEN 
			 FROM HOMEPAGE.TMP_SR_RESUME_TOKENS TMP
			 WHERE  TMP.TOKEN_ID=HOMEPAGE.SR_RESUME_TOKENS.TOKEN_ID
			);

DROP TABLE HOMEPAGE.TMP_SR_RESUME_TOKENS;

----------------------------------------
--  SR_FEEDBACK
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK (
	ID VARCHAR(36) NOT NULL,
	PERSON_ID  VARCHAR(36) NOT NULL,
	CLIENT_ID VARCHAR(256) NOT NULL,
	ACTION VARCHAR(256) NOT NULL,
	FEEDBACK_TIME	TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ITEM_ID  VARCHAR(256) NOT NULL 
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT "PK_FEEDBACK_ID" PRIMARY KEY ("ID");	
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT "FK_SRFB_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");
	
CREATE INDEX HOMEPAGE.SR_FEEDBACK_CLIENT_IDX
		ON HOMEPAGE.SR_FEEDBACK (CLIENT_ID);

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK TO USER LCUSER;


----------------------------------------
--  SR_FEEDBACK_CONTEXT
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT (
	CONTEXT_ID VARCHAR(36) NOT NULL,
	ID VARCHAR(36) NOT NULL,
	TYPE  VARCHAR(256) NOT NULL,
	TYPE_VALUE VARCHAR(256) NOT NULL,
	WEIGHT VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;


ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT "PK_FBK_CTXT_ID" PRIMARY KEY ("CONTEXT_ID");	

ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT "FK_FBK_CTXT_ID" FOREIGN KEY ("ID")
	REFERENCES HOMEPAGE.SR_FEEDBACK("ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_CONTEXT";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_CONTEXT" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_CONTEXT TO USER LCUSER;

----------------------------------------
--  SR_FEEDBACK_PARAMETERS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS (
	PARAMETERS_ID VARCHAR(36) NOT NULL,
	ID VARCHAR(36) NOT NULL,
	PARAM  VARCHAR(256) NOT NULL,
	PARAM_VALUE VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT "PK_FBK_PARAMS_ID" PRIMARY KEY ("PARAMETERS_ID");
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT "FK_FBK_PARAMS_ID" FOREIGN KEY ("ID")
	REFERENCES HOMEPAGE.SR_FEEDBACK("ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_PARAMETERS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_PARAMETERS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_PARAMETERS TO USER LCUSER;

----------------------------------------
--  SR_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STATS(
	STAT_ID		VARCHAR(36) NOT NULL,
	STAT_KEY 	VARCHAR(256) NOT NULL,
	STAT_TYPE	SMALLINT NOT NULL,
	UPDATED		TIMESTAMP NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT "PK_SR_STAT_ID" PRIMARY KEY ("STAT_ID");

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT "UNIQUE_STAT_KEY" UNIQUE ("STAT_KEY");


RUNSTATS ON TABLE "HOMEPAGE"."SR_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STATS TO USER LCUSER;

----------------------------------------
--  SR_STRING_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STRING_STATS(
	STRING_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	STAT_VALUE			VARCHAR(256)  NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT "PK_STR_STAT_ID" PRIMARY KEY ("STRING_STAT_ID");

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT "FK_STR_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_STRING_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_STRING_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STRING_STATS TO USER LCUSER;

----------------------------------------
--  SR_NUMBER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_NUMBER_STATS(
	NUMBER_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	STAT_VALUE			BIGINT NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT "PK_NUM_STAT_ID" PRIMARY KEY ("NUMBER_STAT_ID");


ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT "FK_NUM_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_NUMBER_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_NUMBER_STATS" FOR INDEXES ALL;
	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_NUMBER_STATS TO USER LCUSER;


----------------------------------------
--  SR_TIMER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_TIMER_STATS(
	TIMER_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	AVERAGE				BIGINT NOT NULL,
	MINIMUM				BIGINT NOT NULL,
	MAXIMUM				BIGINT NOT NULL,
	COUNTER				INTEGER	NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT "PK_TMR_STAT_ID" PRIMARY KEY ("TIMER_STAT_ID");	
	
ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT "FK_TMR_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_TIMER_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_TIMER_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_TIMER_STATS TO USER LCUSER;
	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 40
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------


UPDATE  HOMEPAGE.SR_SANDTASKDEF SET SAND_TASK_SERVICES='evidence-graph-manageremployees-tags-taggedby-communitymembership'
WHERE SAND_TASK_ID='fd44131a-5075-4bcb-85a9-9e501bd010fb';


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 42
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_TASKDEF
----------------------------------------
reorg table HOMEPAGE.SR_TASKDEF use TEMPSPACE1;
runstats on table HOMEPAGE.SR_TASKDEF with distribution and detailed indexes all allow write access;
 
INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED)
VALUES('111111-1111-1111-1111-1111111FCRT','20min-file-retrieval-task','0 10/20 0-23 * * ?','0 1/20 0-23 * * ?','FileContentRetrievalTask',1);

----------------------------------------
--  SR_FILECONTENTTASKDEF
----------------------------------------
reorg table HOMEPAGE.SR_FILECONTENTTASKDEF use TEMPSPACE1;
runstats on table HOMEPAGE.SR_FILECONTENTTASKDEF with distribution and detailed indexes all allow write access;

INSERT INTO HOMEPAGE.SR_FILECONTENTTASKDEF(FILECONTENT_TASK_ID,TASK_ID,FILE_CONTENT_TASK_SERVICES,CONTENT_FAILURES_ONLY)
VALUES('111111-1111-1111-1111-1111111FCRT','111111-1111-1111-1111-1111111FCRT','all_configured',0);

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 45
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEX_MANAGEMENT
----------------------------------------

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;

reorg table HOMEPAGE.SR_INDEX_MANAGEMENT use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_INDEX_MANAGEMENT;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT 
ADD COLUMN INDEXER SMALLINT DEFAULT 1 NOT NULL
ALTER COLUMN NODE_ID SET DATA TYPE VARCHAR(256);

----------------------------------------
--  HOMEPAGE.SR_RESUME_TOKENS
----------------------------------------

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;

reorg table HOMEPAGE.SR_RESUME_TOKENS use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_RESUME_TOKENS;

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
ALTER COLUMN NODE_ID SET DATA TYPE VARCHAR(256);

----------------------------------------
--  SR_LOTUSCONNECTIONS*
----------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_RPS_IDX  
	ON HOMEPAGE.SR_INDEX_DOCS (RESUME_POINT,SERVICE);

COMMIT;

runstats on table HOMEPAGE.SR_INDEX_DOCS with distribution and detailed indexes all allow write access;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
COMMIT;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_STRING_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 55
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------ START FIX FORPMAN89HG7Z ------ 

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/15 0,2-23 * * ?',INTERVAL='0 1/15 0,2-23 * * ?' WHERE TASK_NAME='15min-search-indexing-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/20 0,2-23 * * ?',INTERVAL='0 1/20 0,2-23 * * ?' WHERE TASK_NAME='20min-file-retrieval-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 5 1 * * ?',INTERVAL='0 0 1 * * ?' WHERE TASK_NAME='nightly-sand-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 35 1 * * ?',INTERVAL='0 30 1 * * ?' WHERE TASK_NAME='nightly-optimize-task';

------ END FIX FOR PMAN89HG7Z ------ 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- CLEAR SCHEDULERS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- NEWS

DELETE FROM HOMEPAGE.NR_SCHEDULER_TASK;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_TREG;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMGR;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMPR;
COMMIT;
 





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 50
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 50 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 21;
 
--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;