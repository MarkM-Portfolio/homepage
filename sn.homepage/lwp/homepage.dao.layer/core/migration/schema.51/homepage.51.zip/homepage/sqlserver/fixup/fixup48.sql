-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 48
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 48 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 0) Adding SAND_LAST_UPDATE
ALTER TABLE HOMEPAGE.PERSON
    ADD SAND_LAST_UPDATE DATETIME DEFAULT CURRENT_TIMESTAMP
GO

--UPDATE HOMEPAGE.PERSON SET SAND_LAST_UPDATE = CURRENT_TIMESTAMP
--GO

--ALTER TABLE HOMEPAGE.PERSON
--	ALTER COLUMN SAND_LAST_UPDATE DATETIME NOT NULL
--GO

CREATE INDEX PERSON_SAND_LAST_UPDATE
    ON HOMEPAGE.PERSON (SAND_LAST_UPDATE ASC)
GO

-- SPR #RAPA86XGVU Brief Description:*   SAND: Migration: Recommendations widget should show up in 
-- Updates page by default for all new users and existing 2.5 users

-- delete existing widgets (just to be sure) from the ui of the users
DELETE FROM HOMEPAGE.HP_WIDGET_INST WHERE WIDGET_ID = 'recommend7x4f6hd93kd9';

-- inserting for all the users the new widget so it is showed into the ui
INSERT INTO HOMEPAGE.HP_WIDGET_INST 
    (
        WIDGET_INST_ID,
        WIDGET_ID,
        TAB_INST_ID,
        WIDGET_SETTING,
        CONTAINER,
        ORDER_SEQUENCE,
        IS_FIXED,
        IS_TOGGLED,
        LAST_MODIFIED,
        LAST_UPDATED
    ) 
SELECT  ('recom' + SUBSTRING(TAB_INST_ID,1,30)) WIDGET_INST_ID,
        'recommend7x4f6hd93kd9' WIDGET_ID,
        TAB_INST_ID TAB_INST_ID,
        '' WIDGET_SETTING,
        '1' CONTAINER,
        1 ORDER_SEQUENCE,
        0 IS_FIXED,
        1 IS_TOGGLED,
        CURRENT_TIMESTAMP LAST_MODIFIED,
        CURRENT_TIMESTAMP LAST_UPDATED
FROM    HOMEPAGE.HP_TAB_INST WHERE TAB_NAME = '%panel.update';
    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 48 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------------------------------
-- 1) ENFORCE A UNIQUE FIELD ON READER_ID, STORY_ID TO AVOID THE USE OF DISTINCT
------------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT COMM_PER_READER_ID, STORY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
-- GROUP BY COMM_PER_READER_ID, STORY_ID
-- HAVING count(*) > 1

-- CREATE A TEMP DUP TABLE
CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID nvarchar(36) NOT NULL,
	COMM_PER_READER_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	STORY_ID nvarchar(36) NOT NULL
)
ON [PRIMARY]
GO

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PER_STORY_ID, 
            T2.COMM_PER_READER_ID, 
            T2.CONTAINER_ID, 
            T2.ITEM_ID, 
            T2.RESOURCE_TYPE, 
            T2.CATEGORY_TYPE, 
            T2.CREATION_DATE, 
            T2.SOURCE, 
            T2.STORY_ID
    FROM (
            SELECT  COMM_PER_READER_ID, STORY_ID, MAX(COMM_PER_STORY_ID) COMM_PER_STORY_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
            GROUP BY COMM_PER_READER_ID, STORY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_STORIES T2
    WHERE T1.COMM_PER_STORY_ID = T2.COMM_PER_STORY_ID;

GO

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES
    WHERE COMM_PER_STORY_ID IN (
    SELECT  NR_COMM_PERSON_STORIES.COMM_PER_STORY_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES,  HOMEPAGE.TMP_COMM_PERSON_STORIES TMP_COMM_PERSON_STORIES
    WHERE   NR_COMM_PERSON_STORIES.COMM_PER_READER_ID = TMP_COMM_PERSON_STORIES.COMM_PER_READER_ID AND
            NR_COMM_PERSON_STORIES.STORY_ID = TMP_COMM_PERSON_STORIES.STORY_ID
);

GO

-- CREATE THE UNIQUE CONSTRAINTS
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT UNIQUE_COMM_PERSON UNIQUE (COMM_PER_READER_ID, STORY_ID);

GO

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    SELECT  COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            CATEGORY_TYPE, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_STORIES;

GO

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES;

GO

--reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;

-------------------------------------------------
--2) NR_NEWS_SAVED IS_COMMUNITY_STORY
-------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
    ADD IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0;
GO

CREATE INDEX NR_NEWS_SAVED_CREAT_IS_COM
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID, IS_COMMUNITY_STORY);
GO    

UPDATE HOMEPAGE.NR_NEWS_SAVED SET IS_COMMUNITY_STORY = 0;
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET IS_COMMUNITY_STORY = 1 WHERE SOURCE = 'communities';
GO

-------------------------------------------------
--3) NR_STORIES IS_COMMUNITY_STORY
-------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES
    ADD IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0;
GO

CREATE INDEX NR_STORIES_CREAT_IS_COM
    ON HOMEPAGE.NR_STORIES (CREATION_DATE DESC, IS_COMMUNITY_STORY);
GO    

UPDATE HOMEPAGE.NR_STORIES SET IS_COMMUNITY_STORY = 0;
GO

UPDATE HOMEPAGE.NR_STORIES SET IS_COMMUNITY_STORY = 1 WHERE SOURCE = 'communities';
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 48 FOR SEARCH
------------------------------------------------

--{include.search-fixup48.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 48
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 48 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 47;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 48
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
