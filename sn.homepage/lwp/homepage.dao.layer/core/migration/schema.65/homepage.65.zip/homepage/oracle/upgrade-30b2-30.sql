-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

------------------------------------------------
-- INCLUDE UPGRADE-30b2-30 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 51
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------
-- 1) HOMEPAGE.EMD_EMAIL_PREFS
-----------------------------------------
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    DROP CONSTRAINT UNIQUE_PREFS;

CREATE UNIQUE INDEX HOMEPAGE.EMD_EMAIL_PREFS_PER
    ON HOMEPAGE.EMD_EMAIL_PREFS (PERSON_ID) TABLESPACE NEWSINDEXTABSPACE;

------------------------------------------------
-- 2) NR_NEWS_SAVED
------------------------------------------------
CREATE INDEX HOMEPAGE.SAVED_ITEM_ID
    ON HOMEPAGE.NR_NEWS_SAVED (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SAVED_STORY_ID
    ON HOMEPAGE.NR_NEWS_SAVED (NEWS_STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

------------------------------------------------
-- 3) NR_NEWS_DISCOVERY
------------------------------------------------
CREATE INDEX HOMEPAGE.DISCOVERY_ITEM_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.DISCOVERY_STORY_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (NEWS_STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.DISCOVERY_CONTAINER_ID
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CONTAINER_ID) TABLESPACE NEWSINDEXTABSPACE;

------------------------------------------------
-- 4) NR_NEWS_STATUS_COMMENT
------------------------------------------------
CREATE INDEX HOMEPAGE.STATUS_COMMENT_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_STORIES
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_STORIES (CONTAINER_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.STORIES_ITEM_ID
    ON HOMEPAGE.NR_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_STORIES (ITEM_CORRELATION_ID) TABLESPACE NEWSINDEXTABSPACE;

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.COMM_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMM_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

------------------------------------------------
-- 7) NR_STORIES_CONTENT
------------------------------------------------
CREATE INDEX HOMEPAGE.STORIES_CONTENT_STORY
    ON HOMEPAGE.NR_STORIES_CONTENT (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_COMM_PERSON_STORIES 
----------------------------------------------------------------------
CREATE INDEX HOMEPAGE.COMM_PERSON_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 1 NR_RESPONSES_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.RESPONSES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_RESPONSES_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 2 NR_PROFILES_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.PROFILES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_PROFILES_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 3 NR_COMMUNITIES_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.COMMUNITIES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 4 NR_ACTIVITIES_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.ACTIVITIES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 5 NR_BLOGS_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.BLOGS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_BLOGS_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 6 NR_BOOKMARKS_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.BOOKMARKS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 7 NR_FILES_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.FILES_STORIES_ITEM_ID
    ON HOMEPAGE.NR_FILES_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 8 NR_FORUMS_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.FORUMS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_FORUMS_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 9 NR_WIKIS_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.WIKIS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_WIKIS_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

--------------------------------------------------------------------------
-- 10 NR_TAGS_STORIES
--------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.TAGS_STORIES_ITEM_ID
    ON HOMEPAGE.NR_TAGS_STORIES (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 52
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
MODIFY N_USERS NUMBER(10 ,0);

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE UNIQUE INDEX HOMEPAGE.NR_STORIES_ER_UUID
	ON HOMEPAGE.NR_STORIES(EVENT_RECORD_UUID) TABLESPACE "NEWSINDEXTABSPACE";
	
COMMIT;

DROP INDEX HOMEPAGE.NR_STORIES_CREAT_IS_COM;

COMMIT;

CREATE INDEX HOMEPAGE.NR_STORIES_DATE
	ON HOMEPAGE.NR_STORIES(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";
	
COMMIT;	
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 54
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- STATUS_UPDATES tables

-- HOMEPAGE.NR_NEWS_STATUS_NETWORK
-- HOMEPAGE.NR_NEWS_STATUS_COMMENT
-- HOMEPAGE.NR_NEWS_STATUS_CONTENT

CREATE INDEX HOMEPAGE.NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;    

CREATE INDEX HOMEPAGE.NR_STATUS_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;


-- NR_STORIES_CONTENT table
CREATE INDEX HOMEPAGE.NR_STORIES_CONTENT_DATE
    ON HOMEPAGE.NR_STORIES_CONTENT (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

-- FOLLOWED STORIES tableS

--HOMEPAGE.NR_RESPONSES_STORIES 
--HOMEPAGE.NR_PROFILES_STORIES
--HOMEPAGE.NR_COMMUNITIES_STORIES
--HOMEPAGE.NR_ACTIVITIES_STORIES
--HOMEPAGE.NR_BLOGS_STORIES
--HOMEPAGE.NR_BOOKMARKS_STORIES
--HOMEPAGE.NR_FILES_STORIES
--HOMEPAGE.NR_FORUMS_STORIES
--HOMEPAGE.NR_WIKIS_STORIES
--HOMEPAGE.NR_TAGS_STORIES

CREATE INDEX HOMEPAGE.NR_RESPONSES_STORIES_DATE
    ON HOMEPAGE.NR_RESPONSES_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_NR_PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_NR_COMMUNITIES_STORIES_DATE
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_ACTIVITIES_STORIES_DATE
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_BLOGS_STORIES_DATE
    ON HOMEPAGE.NR_BLOGS_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_BOOKMARKS_STORIES_DATE
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_FILES_STORIES_DATE
    ON HOMEPAGE.NR_FILES_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_FORUMS_STORIES_DATE
    ON HOMEPAGE.NR_FORUMS_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_WIKIS_STORIES_DATE
    ON HOMEPAGE.NR_WIKIS_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

CREATE INDEX HOMEPAGE.NR_TAGS_STORIES_DATE
    ON HOMEPAGE.NR_TAGS_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

-- HOMEPAGE.NR_COMM_PERSON_STORIES
CREATE INDEX HOMEPAGE.NR_COMM_PERSON_STORIES_DATE
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

-- HOMEPAGE.NR_COMM_STORIES
CREATE INDEX HOMEPAGE.NR_COMM_STORIES_DATE
    ON HOMEPAGE.NR_COMM_STORIES (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;    
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE INDEX HOMEPAGE.NR_SC_UDATE
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (UPDATE_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;   
   
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_ITEM_C
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_CORRELATION_ID) TABLESPACE NEWSINDEXTABSPACE;   
   
COMMIT;

-- SPR #RSTR8A5Q7R
-- Slow query on Homepage nr_news_status_network table: Oracle
CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_IDX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID) TABLESPACE  NEWSINDEXTABSPACE;

COMMIT;

--SPR #MAKN8A8DXJ SVT: 
--Homepage News Feed (Filter Responses and People) is very slow
CREATE INDEX HOMEPAGE.NR_EVENT_READER 
	ON HOMEPAGE.NR_NEWS_SAVED (READER_ID,EVENT_RECORD_UUID) TABLESPACE  NEWSINDEXTABSPACE;

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE UPGRADE-30b2-30  FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 53
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
COMMIT;

DELETE FROM HOMEPAGE.SR_FACET_DOCS;
COMMIT;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_STRING_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 55
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------ START FIX FOR PMAN89HG7Z ------ 

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/15 0,2-23 * * ?',INTERVAL='0 1/15 0,2-23 * * ?' WHERE TASK_NAME='15min-search-indexing-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 10/20 0,2-23 * * ?',INTERVAL='0 1/20 0,2-23 * * ?' WHERE TASK_NAME='20min-file-retrieval-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 5 1 * * ?',INTERVAL='0 0 1 * * ?' WHERE TASK_NAME='nightly-sand-task';

UPDATE HOMEPAGE.SR_TASKDEF SET STARTBY='0 35 1 * * ?',INTERVAL='0 30 1 * * ?' WHERE TASK_NAME='nightly-optimize-task';

------ END FIX FOR PMAN89HG7Z ------ 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- CLEAR SCHEDULERS
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- NEWS

DELETE FROM HOMEPAGE.NR_SCHEDULER_TASK;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_TREG;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMGR;
COMMIT;
DELETE FROM HOMEPAGE.NR_SCHEDULER_LMPR;
COMMIT;
 





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;
COMMIT;
DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;
COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 56
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 56 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 50;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;

--------------------------------------
-- DISCONNECT
--------------------------------------

DISCONNECT ALL;

QUIT;