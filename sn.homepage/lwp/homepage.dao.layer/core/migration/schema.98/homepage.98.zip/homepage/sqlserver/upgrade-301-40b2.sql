-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE
GO

BEGIN TRANSACTION
GO

------------------------------------------------
-- INCLUDE UPGRADE40b2 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36),
	EVENT_NAME nvarchar(256) NOT NULL,
	CONTAINER_ID nvarchar(256),	
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),	
	CREATION_DATE DATETIME NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID nvarchar(36) NOT NULL,
	REPLYTO_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,	
	REPLYTO_ADDRESS_ID nvarchar(36) NOT NULL,
	LAST_UPDATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_ID FOREIGN KEY (REPLYTO_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX REPLYTO_ADDRESS_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ADDRESS_ID);



GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_NOTIFICATION
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ADD NOTIFICATION_SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 1 WHERE NOTIFICATION_SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 2 WHERE NOTIFICATION_SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 3 WHERE NOTIFICATION_SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 4 WHERE NOTIFICATION_SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 5 WHERE NOTIFICATION_SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 6 WHERE NOTIFICATION_SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 7 WHERE NOTIFICATION_SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 8 WHERE NOTIFICATION_SOURCE = 'files';
GO

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 9 WHERE NOTIFICATION_SOURCE = 'forums';
GO	

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_REPLYTO
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_REPLYTO
	ADD SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO   
    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
-- SPR #JSTH8EZJXT - Removing dups records from HP_UI table and others issues like EMD delviery locks
---------------------------------------------------------------------------------

DELETE FROM HOMEPAGE.HP_WIDGET_INST WHERE WIDGET_INST_ID IN 
(
	SELECT HP_WIDGET_INST.WIDGET_INST_ID
	FROM HOMEPAGE.HP_WIDGET_INST HP_WIDGET_INST,
		(
			SELECT  	HP_TAB_INST.TAB_INST_ID
			FROM 	HOMEPAGE.HP_TAB_INST HP_TAB_INST,
					(
						SELECT UI_ID 
						FROM HOMEPAGE.HP_UI HP_UI 
						INNER JOIN (
								SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
								GROUP BY PERSON_ID 
								HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
						WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	) TMP_UI
			WHERE	HP_TAB_INST.UI_ID = TMP_UI.UI_ID
		) TMP_TAB_INST
	WHERE HP_WIDGET_INST.TAB_INST_ID = TMP_TAB_INST.TAB_INST_ID
);

GO

DELETE FROM HOMEPAGE.HP_TAB_INST WHERE TAB_INST_ID IN 
(
	SELECT  HP_TAB_INST.TAB_INST_ID
	FROM HOMEPAGE.HP_TAB_INST HP_TAB_INST,
		(
			SELECT UI_ID 
			FROM HOMEPAGE.HP_UI HP_UI 
			INNER JOIN (
					SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
					GROUP BY PERSON_ID 
					HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
			WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	) TMP_UI
	WHERE	HP_TAB_INST.UI_ID = TMP_UI.UI_ID
);

GO

DELETE FROM HOMEPAGE.HP_UI WHERE UI_ID IN
(
	SELECT UI_ID 
	FROM HOMEPAGE.HP_UI HP_UI 
	INNER JOIN (
			SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
			GROUP BY PERSON_ID 
			HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
	WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	
);

GO

DROP INDEX HP_UI_PERSON_ID_INDEX ON HOMEPAGE.HP_UI;

CREATE UNIQUE INDEX HP_UI_UNQ
	ON HOMEPAGE.HP_UI (PERSON_ID);

GO

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 86
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON
	ADD PROF_TYPE nvarchar(128);

GO

-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- START: OAUTH TABLES
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: OAUTH Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

------------------------------------------------
-- TOKEN
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_TOKEN (
	ID nvarchar(36) NOT NULL,
	TOKEN nvarchar(1024) NOT NULL,
	SECRET nvarchar(1024)NOT NULL,
	EXPIRATION DATETIME,
	CREATED DATETIME NOT NULL,
	MODIFIED DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_TOKEN 
    ADD CONSTRAINT PK_OH_TOKEN_ID PRIMARY KEY(ID);
 
    

------------------------------------------------
-- PROVIDER
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_PROVIDER (
	ID nvarchar(36) NOT NULL,
	NAME nvarchar(256) NOT NULL,
	DESCRIPTION nvarchar(1024),
	REQUESTTOKENURL nvarchar(512) NOT NULL,
	AUTHORIZEURL nvarchar(512) NOT NULL,
	ACCESSTOKENURL nvarchar(512) NOT NULL,
	BASEURL nvarchar(512),
	MANAGEURL nvarchar(512),	
	REGISTERURL nvarchar(512),	
	SIGNMETHOD nvarchar(32),
	VERSION nvarchar(8),
	CREATEED DATETIME NOT NULL,
	MODIFIED DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_PROVIDER
    ADD CONSTRAINT PK_PROVIDER_ID PRIMARY KEY(ID);

CREATE UNIQUE INDEX PRVD_NAME_UNIQUE 
	ON HOMEPAGE.OH_PROVIDER (NAME);
	
------------------------------------------------
-- CLIENT
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_CLIENT (
	ID nvarchar(36) NOT NULL,
	NAME nvarchar(256) NOT NULL,
	TOKENID nvarchar(36) NOT NULL,
	PROVIDERID nvarchar(36) NOT NULL,
	DESCRIPTION nvarchar(1024),
	CALLBACKURL nvarchar(512),
	USERNAME nvarchar(256) NOT NULL,
	CREATEED DATETIME NOT NULL,
	MODIFIED DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_CLIENT
    ADD CONSTRAINT PK_CLIENT_ID PRIMARY KEY(ID);

CREATE UNIQUE INDEX CLNT_NAME_UNIQUE
	ON HOMEPAGE.OH_CLIENT (NAME);

ALTER TABLE HOMEPAGE.OH_CLIENT
	ADD CONSTRAINT FK_CLIENT_PRO_ID FOREIGN KEY (PROVIDERID)
	REFERENCES HOMEPAGE.OH_PROVIDER(ID);

ALTER TABLE HOMEPAGE.OH_CLIENT
	ADD CONSTRAINT FK_CLIENT_TOKEN_ID FOREIGN KEY (TOKENID)
	REFERENCES HOMEPAGE.OH_TOKEN(ID);

CREATE UNIQUE INDEX CLIENT_PROVIDER_IDX
    ON HOMEPAGE.OH_CLIENT (PROVIDERID);

CREATE UNIQUE INDEX CLIENT_TOKEN_IDX
    ON HOMEPAGE.OH_CLIENT (TOKENID);	

------------------------------------------------
-- CONTEXT
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_CONTEXT (
	ID nvarchar(36) NOT NULL,
	CLIENTID nvarchar(36) NOT NULL,
	USERID nvarchar(256),
	CALLBACKURL nvarchar(1024),
	REQUESTAUTHURL nvarchar(1024),
	TOKENID nvarchar(36) NOT NULL,
	CREATED DATETIME NOT NULL,
	MODIFIED DATETIME,
	SESSIONHANDLE nvarchar(256),
	REFERER nvarchar(512),
	EXPIRATION DATETIME,
	AUTHORIZED NUMERIC(5,0),
	COMPLETED NUMERIC(5,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_CONTEXT
    ADD CONSTRAINT PK_CONTEXT_ID PRIMARY KEY(ID);

ALTER TABLE HOMEPAGE.OH_CONTEXT
	ADD CONSTRAINT FK_CNTXT_CLIENT_ID FOREIGN KEY (CLIENTID)
	REFERENCES HOMEPAGE.OH_CLIENT(ID);

ALTER TABLE HOMEPAGE.OH_CONTEXT
	ADD CONSTRAINT FK_CNTXT_TOKEN_ID FOREIGN KEY (TOKENID)
	REFERENCES HOMEPAGE.OH_TOKEN(ID);

CREATE UNIQUE INDEX CONTEXT_CLIENT_IDX
    ON HOMEPAGE.OH_CONTEXT (CLIENTID);

CREATE UNIQUE INDEX CONTEXT_TOKEN_IDX
    ON HOMEPAGE.OH_CONTEXT (TOKENID);
	
------------------------------------------------
-- APPLICATION
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_APPLICATION (
	ID nvarchar(36) NOT NULL,
	NAME nvarchar(256) NOT NULL,
	DESCRIPTION nvarchar(1024),
	BASEURL nvarchar(512) NOT NULL,
	SECUREBASEURL nvarchar(512),
	PROVIDERID nvarchar(36) NOT NULL,
	CREATEED DATETIME NOT NULL,
	MODIFIED DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_APPLICATION
    ADD CONSTRAINT PK_APP_ID PRIMARY KEY(ID);

CREATE UNIQUE INDEX APP_NAME_UNIQUE
	ON HOMEPAGE.OH_APPLICATION (NAME);

ALTER TABLE HOMEPAGE.OH_APPLICATION
	ADD CONSTRAINT FK_APP_PROVIDER_ID FOREIGN KEY (PROVIDERID)
	REFERENCES HOMEPAGE.OH_PROVIDER(ID);

CREATE UNIQUE INDEX APP_PROVIDER_IDX
    ON HOMEPAGE.OH_APPLICATION (PROVIDERID);
	
------------------------------------------------
-- OAUTHACL
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_OAUTHACL (
	ID nvarchar(36) NOT NULL,
	CONTEXTID nvarchar(36) NOT NULL,
	AUTHORIZETYPE NUMERIC(5,0),
	AUTHORIZEDAPPID nvarchar(36),
	CREATED DATETIME NOT NULL,
	MODIFIED DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.OH_OAUTHACL
    ADD CONSTRAINT PK_OAUTHACL_ID PRIMARY KEY(ID);

ALTER TABLE HOMEPAGE.OH_OAUTHACL
	ADD CONSTRAINT FK_ACL_CONTEXT_ID FOREIGN KEY (CONTEXTID)
	REFERENCES HOMEPAGE.OH_CONTEXT(ID);

ALTER TABLE HOMEPAGE.OH_OAUTHACL
	ADD CONSTRAINT FK_ACL_APP_ID FOREIGN KEY (AUTHORIZEDAPPID)
	REFERENCES HOMEPAGE.OH_APPLICATION(ID);

CREATE UNIQUE INDEX ACL_CONTEXT_IDX
    ON HOMEPAGE.OH_OAUTHACL (CONTEXTID);

CREATE UNIQUE INDEX ACL_APP_IDX
    ON HOMEPAGE.OH_OAUTHACL (AUTHORIZEDAPPID);
    
GO
	
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END OAUTH Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- END: OAUTH TABLES
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- Adding column to trace the LAST_ACTIONABLE_VISIT
---------------------------------------------------------
ALTER TABLE HOMEPAGE.HP_UI
	ADD LAST_ACTIONABLE_VISIT DATETIME;
GO	

UPDATE HOMEPAGE.HP_UI SET LAST_ACTIONABLE_VISIT = CURRENT_TIMESTAMP;
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- RENAME REPLYTO COLUMNS - DROP AND CREATE THE TABLES
----------------------------------------------------------------------
    	
DROP TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT;
GO

DROP TABLE HOMEPAGE.NT_REPLYTO; 
GO

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_NOTIFICATION_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36),
	EVENT_NAME nvarchar(256) NOT NULL,
	CONTAINER_ID nvarchar(256),	
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),	
	CREATION_DATE DATETIME NOT NULL,
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0),
	SOURCE_TYPE NUMERIC(5,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_NOTIFICATION_ID);
GO
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID nvarchar(36) NOT NULL,
	REPLYTO_NOTIFICATION_ID nvarchar(36) NOT NULL,
	PERSON_ID nvarchar(36) NOT NULL,	
	REPLYTO_ID nvarchar(36) NOT NULL,
	LAST_UPDATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_NOT_ID FOREIGN KEY (REPLYTO_NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_NOTIFICATION_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX REPLYTO_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ID);

GO	


GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON ADD CREATION_DATE DATETIME;
GO

UPDATE 		HOMEPAGE.PERSON SET CREATION_DATE = LAST_UPDATE;
GO

-----------------------------------------------
-- UPDATE PERSON
-----------------------------------------------
ALTER TABLE HOMEPAGE.PERSON
	ADD THEME_ID nvarchar(36);

ALTER TABLE HOMEPAGE.PERSON
	ADD COMM_VISIBILITY NUMERIC(5 ,0);	

ALTER TABLE HOMEPAGE.PERSON
	ADD MEMBER_TYPE NUMERIC(5 ,0) DEFAULT 0;
GO
	
UPDATE HOMEPAGE.PERSON SET MEMBER_TYPE = 0;

GO

ALTER TABLE HOMEPAGE.PERSON 
	ALTER COLUMN MEMBER_TYPE NUMERIC(5 ,0) NOT NULL;
 
GO

UPDATE HOMEPAGE.PERSON SET MEMBER_TYPE = 2 WHERE PERSON_ID = '00000000-0000-0000-0000-000000000000';
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON ADD ORGANIZATION_ID nvarchar(36);
ALTER TABLE HOMEPAGE.PERSON ADD COMMUNITY_INTERNAL_ONLY NUMERIC(5 ,0);
GO

-------------------------------------------------------------
-- START: OA updates scripts
-------------------------------------------------------------
INSERT INTO HOMEPAGE.OH_PROVIDER (ID, NAME, DESCRIPTION, REQUESTTOKENURL, AUTHORIZEURL, ACCESSTOKENURL, BASEURL, MANAGEURL, REGISTERURL, CREATEED) 
VALUES ( '00000000-0000-0000-0000-000000000000', 'connectionsProvider', 'IBM Connections OAuth Provider', 'provider/requestToken', 'provider/authorize', 'provider/accessToken', '', 'provider/manageAccess?serviceProvider=connectionsProvider', 'provider/register?serviceProvider=connectionsProvider', CURRENT_TIMESTAMP);

GO

CREATE INDEX OH_CONTEXT_USER_IDX 			ON HOMEPAGE.OH_CONTEXT (USERID);
CREATE INDEX OH_CONTEXT_CLIENT_USER_IDX 	ON HOMEPAGE.OH_CONTEXT (CLIENTID,USERID);
CREATE INDEX OH_CLIENT_USERNAME_IDX 		ON HOMEPAGE.OH_CLIENT (USERNAME);

GO


-- DROP UNIQUE INDEXES
DROP INDEX APP_PROVIDER_IDX ON HOMEPAGE.OH_APPLICATION;

DROP INDEX CLIENT_PROVIDER_IDX ON HOMEPAGE.OH_CLIENT;
DROP INDEX CLIENT_TOKEN_IDX ON HOMEPAGE.OH_CLIENT;	

DROP INDEX CONTEXT_CLIENT_IDX ON HOMEPAGE.OH_CONTEXT;
DROP INDEX CONTEXT_TOKEN_IDX ON HOMEPAGE.OH_CONTEXT;

DROP INDEX ACL_CONTEXT_IDX ON HOMEPAGE.OH_OAUTHACL;
DROP INDEX ACL_APP_IDX ON HOMEPAGE.OH_OAUTHACL;

GO

-- RECREATE
CREATE INDEX APP_PROVIDER_IDX 				ON HOMEPAGE.OH_APPLICATION (PROVIDERID);

CREATE INDEX CLIENT_PROVIDER_IDX 			ON HOMEPAGE.OH_CLIENT (PROVIDERID);
CREATE INDEX CLIENT_TOKEN_IDX 				ON HOMEPAGE.OH_CLIENT (TOKENID);	

CREATE INDEX CONTEXT_CLIENT_IDX 			ON HOMEPAGE.OH_CONTEXT (CLIENTID);
CREATE INDEX CONTEXT_TOKEN_IDX 				ON HOMEPAGE.OH_CONTEXT (TOKENID);

CREATE INDEX ACL_CONTEXT_IDX 				ON HOMEPAGE.OH_OAUTHACL (CONTEXTID);
CREATE INDEX ACL_APP_IDX 					ON HOMEPAGE.OH_OAUTHACL (AUTHORIZEDAPPID);

GO

-------------------------------------------------------------
-- END START: OA updates scripts
-------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 92
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------
-- TOKEN
------------------------------------------------
-- HOMEPAGE.OH_TOKEN: DROP TOKEN COLUMN AND RECREATE + Add Index
--ALTER TABLE HOMEPAGE.OH_TOKEN DROP COLUMN TOKEN;
--ALTER TABLE HOMEPAGE.OH_TOKEN ADD TOKEN nvarchar(450);

--GO


--CREATE UNIQUE INDEX TOKEN_IDX 
--	ON HOMEPAGE.OH_TOKEN (TOKEN);
	
-----------------------
-- PERSON
-----------------------
CREATE UNIQUE INDEX PERSON_IDX   
	ON HOMEPAGE.PERSON (PERSON_ID) INCLUDE (USER_MAIL, DISPLAYNAME);

GO	

INSERT INTO HOMEPAGE.PERSON
		(PERSON_ID,DISPLAYNAME,EXID,STATE,MEMBER_TYPE)
VALUES  ('00000000-0000-0000-0000-000000000001','%anyone','00000000-0000-0000-0000-000000000001',0,2);

GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE40b2 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------------
-- [start] 49953 -  At migration time we lose some informations regarding few stories.
--------------------------------------------------------------------------------------------
-- Before to start migration we need to sanitize the source name of the following source
-- tag.activities
-- tag.blogs
-- tag.communities
-- tag.files
-- tag.homepage
-- tag.profiles
-- tag.wikis
--------------------------------------------------------------------------------------------
UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

--------------------------------

-- HOMEPAGE.NR_RESPONSES_STORIES
UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO


-- HOMEPAGE.NR_PROFILES_STORIES
UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_COMMUNITIES_STORIES
UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_ACTIVITIES_STORIES
UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_BLOGS_STORIES
UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_BOOKMARKS_STORIES
UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_FILES_STORIES
UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_FORUMS_STORIES
UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_WIKIS_STORIES
UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-- HOMEPAGE.NR_TAGS_STORIES
UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

-----------------------------------

-- HOMEPAGE.NR_COMM_PERSON_STORIES
UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

--HOMEPAGE.NR_NEWS_DISCOVERY
UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

--HOMEPAGE.NR_NEWS_SAVED
UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
GO

--------------------------------------------------------------------------------------------
-- [end] 49953 -  At migration time we lose some informations regarding few stories.
--------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- [START] PMR 48211,L6Q,000: Fixing Entries in following reletionship after migration
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
   SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, TEMP.CONTAINER_ID FOLLOWED_CONTAINER, RESOURCE_ID
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, HOMEPAGE.NR_RESOURCE NR_RESOURCE,
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 0 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID AND TEMP.CONTAINER_ID = NR_RESOURCE.CONTAINER_ID
);
GO

DELETE FROM HOMEPAGE.NR_FOLLOWS WHERE EXISTS 
	(SELECT 1 FROM HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS WHERE NR_FOLLOWS.PERSON_ID = TMP_FOLLOWS.PERSON_ID AND NR_FOLLOWS.RESOURCE_ID = TMP_FOLLOWS.RESOURCE_ID );
GO
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- [END] PMR 48211,L6Q,000: Fixing Entries in following reletionship after migration
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- PRE sanitize sql as we start from a 3.0.1 and we need to migrate it to 4.0

DROP INDEX NR_ATT_STORY_ID ON HOMEPAGE.NR_ATTACHMENT;
DROP INDEX NR_REC_STORY_ID ON HOMEPAGE.NR_RECOMMENDATION;
DROP INDEX NR_RECOMMENDER_STORY_ID ON HOMEPAGE.NR_RECOMMENDATION;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT DROP CONSTRAINT PK_ATTACHMENT;
ALTER TABLE HOMEPAGE.NR_RECOMMENDATION DROP CONSTRAINT PK_RECOMMENDATION;


EXEC sp_rename 'HOMEPAGE.NR_ATTACHMENT' 	,		'NR_ATTACHMENT_301';
EXEC sp_rename 'HOMEPAGE.NR_RECOMMENDATION'	, 	'NR_RECOMMENDATION_301';

 

GO

-------------------------------------------------------
-- RENAMING NATIONWIDE specific table
-------------------------------------------------------

----------------------------------------------------------------
-- SPR #DMCE8ECKYM
----------------------------------------------------------------
-- #1 - Community Forum icon in news stories displays the Community icon
-- When you migrate 2.5.0x content that includes a community with community forum content, 
-- the story icon used in the 3.0.1 system appears to be misleading (Community icon currently  instead of Forum icon). 
-- See screenshot below as an example. This is not a ship stop if fix not included.
UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

GO

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

GO

-- #4 - Status Updates \ People I'm Following - should also include status by people in My Network
-- If you are networked with a user in 2.5.0.3, their latest status should be present in the "People I'm Following" view in 3.0.1 when migrated.
-- The default behaviour is that any network colleague making a status update automatically appears in your People I'm Following view.
-- This is not a ship stop if fix not included, but we should be including all relevant data in the migration process.
UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET IS_FOLLOW_NEWS = 1 WHERE IS_NETWORK_NEWS = 1;

GO

-- #5 - Icon for Following a person is the Homepage icon instead of Profiles icon
-- In LC 2.5.0.3, you will see a story for adding a user to your Homepage Watchlist. This story has a Homepage icon when migrated to LC 3.0.1
-- Ideally this story should have a "Profiles" icon in LC 3.0.1, as this is now a profiles story - profiles.person.followed
UPDATE HOMEPAGE.NR_STORIES  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

GO


UPDATE HOMEPAGE.NR_NEWS_SAVED  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

GO

--------------------------------------------------------------
-- CREATING A PARTITIONED TABLES
--------------------------------------------------------------

------------------------------------------------
-- 1) NR_SOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE_NAME nvarchar(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE_TYPE_DESC nvarchar(256) NOT NULL
) ON [PRIMARY]
GO 

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD CONSTRAINT PK_SRC_TYPE_ID PRIMARY KEY(SOURCE_TYPE_ID);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNIQUE UNIQUE(SOURCE_TYPE);
GO
-------------------------------------------------
-- 2) ADDING SOURCE TYPE COLUMNS TO EXISTING TABLES
-------------------------------------------------

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_SOURCE
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE
	ADD SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_SAVED
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_DISCOVERY
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESOURCE
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_COMM_STORIES
	SET SOURCE_TYPE = 3;
GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_PERSON_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO


-- categories tables
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESPONSES_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_PROFILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMMUNITIES_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_ACTIVITIES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BLOGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BOOKMARKS_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FILES_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FORUMS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_WIKIS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_TAGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_TAGS_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO

-------------------------------------------------
-- 3) ADDING PARTITIONED TABLES
-------------------------------------------------

----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_ACT (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
    ADD CONSTRAINT PK_ACT_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_ACT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_ACT(CREATION_DATE DESC);

CREATE INDEX SRC_ACT_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (CONTAINER_ID);

CREATE INDEX SRC_ACT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_ID);

CREATE INDEX SRC_ACT_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_ACT_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (SOURCE_TYPE);

----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_SRC_STORIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_BLG (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
    ADD CONSTRAINT PK_BLG_STORY_ID PRIMARY KEY (STORY_ID);

CREATE INDEX NR_SRC_STORIES_BLG_DATE
	ON HOMEPAGE.NR_SRC_STORIES_BLG(CREATION_DATE DESC);

CREATE INDEX SRC_BLG_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (CONTAINER_ID);

CREATE INDEX SRC_BLG_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_ID);

CREATE INDEX SRC_BLG_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_BLG_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (SOURCE_TYPE);


----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_SRC_STORIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_COM (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
    ADD CONSTRAINT PK_COM_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_COM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_COM (CREATION_DATE DESC);

CREATE INDEX SRC_COM_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (CONTAINER_ID);

CREATE INDEX SRC_COM_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_ID);

CREATE INDEX SRC_COM_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_COM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (SOURCE_TYPE);
  
    
----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_SRC_STORIES_WIK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_WIK (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
    ADD CONSTRAINT PK_WIK_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_WIK_DATE
	ON HOMEPAGE.NR_SRC_STORIES_WIK(CREATION_DATE DESC);

CREATE INDEX SRC_WIK_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (CONTAINER_ID);

CREATE INDEX SRC_WIK_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_ID);

CREATE INDEX SRC_WIK_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_WIK_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (SOURCE_TYPE);
  
    
----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_SRC_STORIES_PRF
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_PRF (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
    ADD CONSTRAINT PK_PRF_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_PRF_DATE
	ON HOMEPAGE.NR_SRC_STORIES_PRF(CREATION_DATE DESC);

CREATE INDEX SRC_PRF_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (CONTAINER_ID);

CREATE INDEX SRC_PRF_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_ID);

CREATE INDEX SRC_PRF_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_PRF_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (SOURCE_TYPE);
    

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_SRC_STORIES_HP
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_HP (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
    ADD CONSTRAINT PK_HP_STORY_ID PRIMARY KEY (STORY_ID);

CREATE INDEX NR_SRC_STORIES_HP_DATE
	ON HOMEPAGE.NR_SRC_STORIES_HP(CREATION_DATE DESC);

CREATE INDEX SRC_HP_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (CONTAINER_ID);

CREATE INDEX SRC_HP_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_ID);

CREATE INDEX SRC_HP_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_HP_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (SOURCE_TYPE);
   

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_SRC_STORIES_DGR
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_DGR (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
    ADD CONSTRAINT PK_DGR_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_DGR_DATE
	ON HOMEPAGE.NR_SRC_STORIES_DGR(CREATION_DATE DESC);

CREATE INDEX SRC_DGR_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (CONTAINER_ID);

CREATE INDEX SRC_DGR_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_ID);

CREATE INDEX SRC_DGR_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_DGR_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (SOURCE_TYPE);
  

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_SRC_STORIES_FILE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FILE (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
    ADD CONSTRAINT PK_FILE_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_FILE_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FILE(CREATION_DATE DESC);

CREATE INDEX SRC_FILE_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (CONTAINER_ID);

CREATE INDEX SRC_FILE_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_ID);

CREATE INDEX SRC_FILE_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_FILE_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (SOURCE_TYPE);


----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_SRC_STORIES_FRM 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FRM  (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36), -- NEW
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	SOURCE_TYPE NUMERIC(5,0),
	CONSTRAINT   	CK_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 
    ADD CONSTRAINT PK_FRM_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX NR_SRC_STORIES_FRM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FRM (CREATION_DATE DESC);

CREATE INDEX SRC_FRM_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (CONTAINER_ID);

CREATE INDEX SRC_FRM_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_ID);

CREATE INDEX SRC_FRM_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_FRM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (SOURCE_TYPE);
  

---------------------------------------------------------------------------------
-- 4) RUNNING DATA MIGRATION
---------------------------------------------------------------------------------

------------
--- START INSERT NR_SOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('blogs________0f1xc9caxcc4x8b0bx51af2', 2, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('communities____f1xc9caxcc48b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('wikis________dfdxc9cax4cc4xb0bx51af2', 4, '%wikis', 'wikis');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('profiles____________fdfdc98b0bx51af2', 5, '%profiles', 'profiles');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('homepage_0f1xc9cax4cc4x8cdb0bx51f2dd', 6, '%homepage', 'homepage');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('dogear_0f1xc9cax4cc4x8cdb0bx51f2d', 7, '%dogear', 'dogear');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('files____________fdfdc9cax8b0bx51af2', 8, '%files', 'files');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('forums____________fdfdc9cax80bx51af2', 9, '%forums', 'forums');
------------
--- END INSERT NR_SOURCE_TYPE
------------

GO

--------------------------------------------------------------------------------
-- START MIGRATING OLD DATA FROM THE NR_STORIES TABLE TO THE PARTITIONED TABLES
--------------------------------------------------------------------------------

-- PARTITIONING MAIN TABLE
ALTER TABLE HOMEPAGE.NR_STORIES
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
GO

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
GO    

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_STORIES_CONTENT (THIS IS BASED ON A JOIN WITH NR_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD  SOURCE_TYPE NUMERIC(5,0);
GO	

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 1 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'activities'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 2 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'blogs'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 3 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'communities'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 4 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'wikis'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 5 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'profiles'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 6 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'homepage'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 7 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'dogear'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 8 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'files'
);
GO

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 9 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'forums'
);
GO

-- COPYING BACK THE DATA


------------------------------
-- i) COMMIT all the work
-- ii) enable xp_cmdshell
-----------------------------
COMMIT;


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE

---------------------------------
-- Move the data
---------------------------------



--1) HOMEPAGE.NR_SRC_STORIES_ACT
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 1
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_ACT' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--2) HOMEPAGE.NR_SRC_STORIES_BLG
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 2
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_BLG' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--3) HOMEPAGE.NR_SRC_STORIES_COM
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 3
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_COM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--4) HOMEPAGE.NR_SRC_STORIES_WIK
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 4
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_WIK' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--5) HOMEPAGE.NR_SRC_STORIES_PRF
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 5
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_PRF' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--6) HOMEPAGE.NR_SRC_STORIES_HP
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 6
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_HP' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--7) HOMEPAGE.NR_SRC_STORIES_DGR
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 7
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_DGR' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--8) HOMEPAGE.NR_SRC_STORIES_FILE
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 8
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FILE' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--9) HOMEPAGE.NR_SRC_STORIES_FRM
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT * 
	FROM HOMEPAGE.HOMEPAGE.NR_STORIES 
	WHERE SOURCE_TYPE = 9
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FRM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;



-----------------------------------
-- Disable xp_cmdshell
----------------------------------

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 0
RECONFIGURE

----------------------------------
-----------------------------------

BEGIN TRANSACTION
GO



---------------------------------------------------------------------------------
-- DROPPING OLD TABLE TO CREATE A NEW VIEW
---------------------------------------------------------------------------------
--ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP CONSTRAINT FK_COMM_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES DROP CONSTRAINT FK_ORGP_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES DROP CONSTRAINT FK_FCP_STORY_ID;

--ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT FK_RESP_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT FK_PROF_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT FK_COM_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT FK_ACT_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT FK_BLOGS_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT FK_BOOKS_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT FK_FILES_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT FK_FORUMS_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT FK_WIKIS_STORY_ID;
--ALTER TABLE HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT FK_TAGS_STORY_ID;
--GO

DROP TABLE HOMEPAGE.NR_STORIES;
GO

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE SOURCE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_STORIES AS (
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FRM
);
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 81
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------
-- 1) ADDING NEW COLUMN TO THE NR_COMM_FOLLOW TABLE (FROM FIXUP 58)
--------------------------------------------------------------
-- it is already in 3.0.1
--ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
--	ADD COMMUNITY_NAME VARCHAR(256);

--------------------------------------------------------------
-- 2) ADDING NEW COLUMN (HAS_ATTACHMENT) TO THE STORIES TABLES
--------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0;
GO


----------------------------------------------------------------
-- 3) ADDING TABLE FOR PROFILES STORIES COMMENTS 
----------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT (
	NEWS_COMMENT_ID nvarchar(36) NOT NULL,
	ACTOR_UUID nvarchar(36) NOT NULL,
	CREATION_DATE DATETIME,
	BRIEF_DESC nvarchar(500),
	STORY_ID  nvarchar(36),
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ITEM_ID  nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_URL nvarchar(2048),
	CONTENT  varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT PK_NEWS_PRF_COMMENT_ID PRIMARY KEY(NEWS_COMMENT_ID);

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT FK_PRF_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_SRC_STORIES_PRF (STORY_ID);

CREATE INDEX PRF_COMMENT_STORY_ID
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (STORY_ID);

CREATE INDEX NR_NEWS_PRF_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (CREATION_DATE ASC);     
GO
	
----------------------------------------------------------------
-- 4) ADDING NR_ATTACHMENT - CAN RELATE TO ANY STORIES TABLE
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ATTACHMENT (
	ATTACHMENT_ID nvarchar(36) NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC (5,0),
	CREATION_DATE DATETIME,
	FILE_NAME nvarchar(2048),
	FILE_DESC nvarchar(4000),	
	FILE_ID  nvarchar(128),
	REPO_ID nvarchar(128)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 
    ADD CONSTRAINT PK_ATTACHMENT PRIMARY KEY(ATTACHMENT_ID);

CREATE INDEX NR_ATT_STORY_ID
    ON HOMEPAGE.NR_ATTACHMENT (STORY_ID);
GO

----------------------------------------------------------------
-- 5) ADDING NR_RECOMMENDATION - CAN RELATE TO ANY STORY TABLE
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RECOMMENDATION  (
	RECOMMENDATION_ID nvarchar(36) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	STORY_ID nvarchar(36) NOT NULL, 
	SOURCE_TYPE NUMERIC (5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 
    ADD CONSTRAINT PK_RECOMMENDATION PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX NR_REC_STORY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (STORY_ID);
    
CREATE UNIQUE INDEX NR_RECOMMENDER_STORY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID, STORY_ID);
GO




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 82
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_ENTRIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_ACT (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
    ADD CONSTRAINT PK_ACT_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_ACT_CONT
    ON HOMEPAGE.NR_ENTRIES_ACT (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_ACT_SRC
    ON HOMEPAGE.NR_ENTRIES_ACT (SOURCE_TYPE);

GO

----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_ENTRIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_BLG (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
    ADD CONSTRAINT PK_BLG_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_BLG_CONT
    ON HOMEPAGE.NR_ENTRIES_BLG (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_BLG_SRC
    ON HOMEPAGE.NR_ENTRIES_BLG (SOURCE_TYPE);
    

GO

----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_ENTRIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_COM (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
    ADD CONSTRAINT PK_COM_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_COM_CONT
    ON HOMEPAGE.NR_ENTRIES_COM (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_COM_SRC
    ON HOMEPAGE.NR_ENTRIES_COM (SOURCE_TYPE);

GO

----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_ENTRIES_WIK
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_WIK (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
    ADD CONSTRAINT PK_WIK_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_WIK_CONT
    ON HOMEPAGE.NR_ENTRIES_WIK (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_WIK_SRC
    ON HOMEPAGE.NR_ENTRIES_WIK (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_ENTRIES_PRF
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_PRF (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
    ADD CONSTRAINT PK_PRF_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_PRF_CONT
    ON HOMEPAGE.NR_ENTRIES_PRF (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_PRF_SRC
    ON HOMEPAGE.NR_ENTRIES_PRF (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_ENTRIES_HP
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_HP (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
    ADD CONSTRAINT PK_HP_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_HP_CONT
    ON HOMEPAGE.NR_ENTRIES_HP (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_HP_SRC
    ON HOMEPAGE.NR_ENTRIES_HP (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_ENTRIES_DGR
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_DGR (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
) ON [PRIMARY]
GO 


ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
    ADD CONSTRAINT PK_DGR_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_DGR_CONT
    ON HOMEPAGE.NR_ENTRIES_DGR (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_DGR_SRC
    ON HOMEPAGE.NR_ENTRIES_DGR (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_ENTRIES_FILE
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FILE (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
    ADD CONSTRAINT PK_FILE_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_FILE_CONT
    ON HOMEPAGE.NR_ENTRIES_FILE (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_FILE_SRC
    ON HOMEPAGE.NR_ENTRIES_FILE (SOURCE_TYPE);


GO

----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_ENTRIES_FRM
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FRM (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	CONSTRAINT   	CK_ENT_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
    ADD CONSTRAINT PK_FRM_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_FRM_CONT
    ON HOMEPAGE.NR_ENTRIES_FRM (CONTAINER_ID);

CREATE INDEX NR_ENTRIES_FRM_SRC
    ON HOMEPAGE.NR_ENTRIES_FRM (SOURCE_TYPE);


GO

----------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE ADDING TABLE FOR PROFILES STORIES COMMENTS 
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT;

CREATE TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT (
	NEWS_COMMENT_ID nvarchar(36) NOT NULL,
	ACTOR_UUID nvarchar(36) NOT NULL,
	CREATION_DATE DATETIME,
	UPDATE_DATE DATETIME,
	BRIEF_DESC nvarchar(500),
	ENTRY_ID  nvarchar(36),
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	ITEM_ID  nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_URL nvarchar(2048),
	TARGET_SUBJECT_ID nvarchar(36),
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT PK_PRF_COMMENT_ID PRIMARY KEY(NEWS_COMMENT_ID);

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT FK_ENTRY_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
  	
CREATE INDEX PRF_COMMENT_ENTRY_ID
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (ENTRY_ID);

CREATE INDEX NR_NEWS_PRF_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (UPDATE_DATE ASC);



GO

----------------------------------------------------------------
-- DROPPING AND RECREATE NR_RECOMMENDATION - CAN RELATE TO ANY ENTRY TABLE
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_RECOMMENDATION;

CREATE TABLE HOMEPAGE.NR_RECOMMENDATION  (
	RECOMMENDATION_ID nvarchar(36) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(36) NOT NULL, 
	SOURCE_TYPE NUMERIC(5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 
    ADD CONSTRAINT PK_RECOMMENDATION PRIMARY KEY(RECOMMENDATION_ID);

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION
  	ADD CONSTRAINT FK_RECOMMENDER_ID FOREIGN KEY (RECOMMENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);
    
CREATE INDEX NR_REC_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (ENTRY_ID);

CREATE INDEX NR_RECCOMANDER_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID);
    
CREATE UNIQUE INDEX NR_RECOMMENDER_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID, ENTRY_ID);


GO

---------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE HOMEPAGE.NR_ATTACHMENT
---------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ATTACHMENT;

CREATE TABLE HOMEPAGE.NR_ATTACHMENT (
	ATTACHMENT_ID nvarchar(36) NOT NULL,
	ENTRY_ID nvarchar(36) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC(5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 
    ADD CONSTRAINT PK_ATTACHMENT PRIMARY KEY(ATTACHMENT_ID);

CREATE INDEX NR_ATT_ENTRY_ID
    ON HOMEPAGE.NR_ATTACHMENT (ENTRY_ID);    



GO

---------------------------------------------------------------
-- Adding flag for debug purpose on PERSON_COMM table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
	ADD IS_READER_COMM NUMERIC(5,0) DEFAULT 0 NOT NULL;
GO	


UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW  SET IS_READER_COMM = 0;

GO

UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW  SET IS_READER_COMM = 1 WHERE NOT EXISTS (
	SELECT 	1
 	FROM  	HOMEPAGE.PERSON PERSON
 	WHERE 	HOMEPAGE.NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = PERSON.PERSON_ID 
);
		
GO	

---------------------------------------------------------------
-- Adding flag for debug purpose on NR_COMM_PERSON_STORIES table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD IS_STORY_COMM NUMERIC(5,0);
GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET IS_STORY_COMM = 1;

GO

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES 
SET    IS_STORY_COMM = 0
WHERE  EXISTS ( SELECT 1
                FROM   HOMEPAGE.PERSON
                WHERE  PERSON_ID = COMM_PER_READER_ID );

GO

---------------------------------------------------------------
---------------------------------------------------------------	
-- SEEDLIST AND BOARD TABLES	
---------------------------------------------------------------
---------------------------------------------------------------
--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMERIC (5,0),
	CATEGORY_TYPE NUMERIC (5,0),
	SOURCE nvarchar(36),
	SOURCE_TYPE NUMERIC (5,0),
	STORY_ID nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE DATETIME NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID nvarchar(36),
	N_COMMENTS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_COMMUNITY_STORY NUMERIC (5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMERIC (5,0) DEFAULT 0,
	TARGET_SUBJECT_ID nvarchar(256),
	IS_NETWORK_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	TAGS nvarchar(1024),
	SL_IS_UPDATED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE DATETIME NOT NULL, -- this field is used by the seedlist
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID);

CREATE INDEX NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC);
  
CREATE INDEX NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC);

GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID nvarchar(36) NOT NULL,
	IS_READER_COMM NUMERIC (5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID);

CREATE INDEX NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);

GO

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	ITEM_ID nvarchar(47),
	ITEM_CORRELATION_ID nvarchar(47),
	ITEM_URL nvarchar(2048),	
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID);   

GO

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC (5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID);     
	
GO

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID nvarchar(47) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(47) NOT NULL,
	SOURCE_TYPE NUMERIC (5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID);
    
CREATE UNIQUE INDEX BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID);

GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 83
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------
-- START: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD TMP_DOMAIN_AFFINITY VARCHAR(MAX);

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET TMP_DOMAIN_AFFINITY = DOMAIN_AFFINITY;

GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD DOMAIN_AFFINITY VARCHAR(MAX);

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET DOMAIN_AFFINITY = TMP_DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN TMP_DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

GO

--------------------------------------------------------------------------------------
-- END: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
-- START: ADDING ENTRY_ID
--------------------------------------------------------------------------------------

-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD ENTRY_ID nvarchar(36);

CREATE INDEX NR_SRC_STORIES_ACT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);
	
GO

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_BLG_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ENTRY_ID);      

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID); 
	
GO

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_COM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (ENTRY_ID); 

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);
	
GO

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_WIK_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID);
	
GO

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_PRF_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
	
GO

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_HP_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID); 
	
GO

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_DGR_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID); 
	
GO
    
-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_FILE_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);
	
GO

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_FRM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID); 
	
GO

--------------------------------------------------------------------------------------
-- FIXING BOARD TABLES
-------------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_RECOMMENDATIONS;

DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

DROP TABLE HOMEPAGE.BOARD_COMMENTS;

DROP TABLE HOMEPAGE.BOARD_READERS;

DROP TABLE HOMEPAGE.BOARD_ENTRIES;

GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMERIC (5,0),
	CATEGORY_TYPE NUMERIC (5,0),
	SOURCE nvarchar(36),
	SOURCE_TYPE NUMERIC (5,0),
	ITEM_ID nvarchar(36),
	ITEM_URL nvarchar(2048),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE DATETIME NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID nvarchar(36),
	N_COMMENTS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_COMMUNITY_STORY NUMERIC (5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMERIC (5,0) DEFAULT 0,
	TARGET_SUBJECT_ID nvarchar(256),
	TAGS nvarchar(1024),
	SL_IS_UPDATED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE DATETIME NOT NULL, -- this field is used by the seedlist
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID);

CREATE INDEX NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC);
  
CREATE INDEX NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC);

CREATE UNIQUE INDEX NEWS_BRD_ITEM
    ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID);     
GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID nvarchar(36) NOT NULL,
	IS_READER_COMM NUMERIC (5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL,
	IS_NETWORK_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID);

CREATE INDEX NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);
GO

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	ITEM_ID nvarchar(47),
	ITEM_CORRELATION_ID nvarchar(47),
	ITEM_URL nvarchar(2048),	
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID);   
GO

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC (5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID);     
GO

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID nvarchar(47) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(47) NOT NULL,
	SOURCE_TYPE NUMERIC (5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID);
    
CREATE UNIQUE INDEX BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID);
GO

GO



------------------------------------------------------
-- CREATE VIEW NR_ENTRIES
------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_ENTRIES AS (
    SELECT * FROM HOMEPAGE.NR_ENTRIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FRM
);
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------
-- START [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-- Dropping the constraints
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT 	DROP CONSTRAINT FK_ENTRY_ID_ACT;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG 	DROP CONSTRAINT FK_ENTRY_ID_BLG;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM 	DROP CONSTRAINT FK_ENTRY_ID_COM;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK 	DROP CONSTRAINT FK_ENTRY_ID_WIK;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF 	DROP CONSTRAINT FK_ENTRY_ID_PRF;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP 		DROP CONSTRAINT FK_ENTRY_ID_HP;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR 	DROP CONSTRAINT FK_ENTRY_ID_DGR;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE 	DROP CONSTRAINT FK_ENTRY_ID_FILE;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 	DROP CONSTRAINT FK_ENTRY_ID_FRM;

GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
GO

-----------------------------------------------------------------------------------------------
-- END [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- STARTING DATA MIGRATION FROM THE NR_STORIES TABLE TO THE NR_ENTRIES TABLE
-----------------------------------------------------------------------------------------------
-- 1 NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_ACT (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_ACT.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_ACT.SOURCE,
				NR_SRC_STORIES_ACT.SOURCE_TYPE,
				NR_SRC_STORIES_ACT.CONTAINER_ID,
				NR_SRC_STORIES_ACT.CONTAINER_NAME,
				NR_SRC_STORIES_ACT.CONTAINER_URL,
				NR_SRC_STORIES_ACT.ITEM_ID,
				NR_SRC_STORIES_ACT.ITEM_NAME,
				NR_SRC_STORIES_ACT.ITEM_URL,			
				NR_SRC_STORIES_ACT.CREATION_DATE,
				NR_SRC_STORIES_ACT.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_ACT.TAGS,
				NR_SRC_STORIES_ACT.N_COMMENTS,
				NR_SRC_STORIES_ACT.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_ACT.BRIEF_DESC,
				NR_SRC_STORIES_ACT.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_ACT,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_ACT
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_ACT.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_ACT
								);
GO


-- 2 NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_BLG (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_BLG.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_BLG.SOURCE,
				NR_SRC_STORIES_BLG.SOURCE_TYPE,
				NR_SRC_STORIES_BLG.CONTAINER_ID,
				NR_SRC_STORIES_BLG.CONTAINER_NAME,
				NR_SRC_STORIES_BLG.CONTAINER_URL,
				NR_SRC_STORIES_BLG.ITEM_ID,
				NR_SRC_STORIES_BLG.ITEM_NAME,
				NR_SRC_STORIES_BLG.ITEM_URL,			
				NR_SRC_STORIES_BLG.CREATION_DATE,
				NR_SRC_STORIES_BLG.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_BLG.TAGS,
				NR_SRC_STORIES_BLG.N_COMMENTS,
				NR_SRC_STORIES_BLG.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_BLG.BRIEF_DESC,
				NR_SRC_STORIES_BLG.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_BLG NR_SRC_STORIES_BLG,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_BLG
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_BLG.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_BLG
								);
GO

-- 3 HOMEPAGE.NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_COM (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_COM.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_COM.SOURCE,
				NR_SRC_STORIES_COM.SOURCE_TYPE,
				NR_SRC_STORIES_COM.CONTAINER_ID,
				NR_SRC_STORIES_COM.CONTAINER_NAME,
				NR_SRC_STORIES_COM.CONTAINER_URL,
				NR_SRC_STORIES_COM.ITEM_ID,
				NR_SRC_STORIES_COM.ITEM_NAME,
				NR_SRC_STORIES_COM.ITEM_URL,			
				NR_SRC_STORIES_COM.CREATION_DATE,
				NR_SRC_STORIES_COM.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_COM.TAGS,
				NR_SRC_STORIES_COM.N_COMMENTS,
				NR_SRC_STORIES_COM.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_COM.BRIEF_DESC,
				NR_SRC_STORIES_COM.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_COM NR_SRC_STORIES_COM,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_COM
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_COM.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_COM
								);
GO

-- 4 NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_WIK (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_WIK.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_WIK.SOURCE,
				NR_SRC_STORIES_WIK.SOURCE_TYPE,
				NR_SRC_STORIES_WIK.CONTAINER_ID,
				NR_SRC_STORIES_WIK.CONTAINER_NAME,
				NR_SRC_STORIES_WIK.CONTAINER_URL,
				NR_SRC_STORIES_WIK.ITEM_ID,
				NR_SRC_STORIES_WIK.ITEM_NAME,
				NR_SRC_STORIES_WIK.ITEM_URL,			
				NR_SRC_STORIES_WIK.CREATION_DATE,
				NR_SRC_STORIES_WIK.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_WIK.TAGS,
				NR_SRC_STORIES_WIK.N_COMMENTS,
				NR_SRC_STORIES_WIK.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_WIK.BRIEF_DESC,
				NR_SRC_STORIES_WIK.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_WIK NR_SRC_STORIES_WIK,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_WIK
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_WIK.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_WIK
								);
GO

-- 5 NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_PRF (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_PRF.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_PRF.SOURCE,
				NR_SRC_STORIES_PRF.SOURCE_TYPE,
				NR_SRC_STORIES_PRF.CONTAINER_ID,
				NR_SRC_STORIES_PRF.CONTAINER_NAME,
				NR_SRC_STORIES_PRF.CONTAINER_URL,
				NR_SRC_STORIES_PRF.ITEM_ID,
				NR_SRC_STORIES_PRF.ITEM_NAME,
				NR_SRC_STORIES_PRF.ITEM_URL,			
				NR_SRC_STORIES_PRF.CREATION_DATE,
				NR_SRC_STORIES_PRF.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_PRF.TAGS,
				NR_SRC_STORIES_PRF.N_COMMENTS,
				NR_SRC_STORIES_PRF.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_PRF.BRIEF_DESC,
				NR_SRC_STORIES_PRF.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_PRF NR_SRC_STORIES_PRF,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_PRF
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_PRF.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_PRF
								);
GO

-- 6 NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_HP (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_HP.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_HP.SOURCE,
				NR_SRC_STORIES_HP.SOURCE_TYPE,
				NR_SRC_STORIES_HP.CONTAINER_ID,
				NR_SRC_STORIES_HP.CONTAINER_NAME,
				NR_SRC_STORIES_HP.CONTAINER_URL,
				NR_SRC_STORIES_HP.ITEM_ID,
				NR_SRC_STORIES_HP.ITEM_NAME,
				NR_SRC_STORIES_HP.ITEM_URL,			
				NR_SRC_STORIES_HP.CREATION_DATE,
				NR_SRC_STORIES_HP.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_HP.TAGS,
				NR_SRC_STORIES_HP.N_COMMENTS,
				NR_SRC_STORIES_HP.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_HP.BRIEF_DESC,
				NR_SRC_STORIES_HP.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_HP NR_SRC_STORIES_HP,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_HP
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_HP.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_HP
								);
GO

-- 7 NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_DGR (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_DGR.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_DGR.SOURCE,
				NR_SRC_STORIES_DGR.SOURCE_TYPE,
				NR_SRC_STORIES_DGR.CONTAINER_ID,
				NR_SRC_STORIES_DGR.CONTAINER_NAME,
				NR_SRC_STORIES_DGR.CONTAINER_URL,
				NR_SRC_STORIES_DGR.ITEM_ID,
				NR_SRC_STORIES_DGR.ITEM_NAME,
				NR_SRC_STORIES_DGR.ITEM_URL,			
				NR_SRC_STORIES_DGR.CREATION_DATE,
				NR_SRC_STORIES_DGR.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_DGR.TAGS,
				NR_SRC_STORIES_DGR.N_COMMENTS,
				NR_SRC_STORIES_DGR.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_DGR.BRIEF_DESC,
				NR_SRC_STORIES_DGR.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_DGR NR_SRC_STORIES_DGR,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_DGR
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_DGR.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_DGR
								);
GO

-- 8 NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_FILE (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_FILE.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_FILE.SOURCE,
				NR_SRC_STORIES_FILE.SOURCE_TYPE,
				NR_SRC_STORIES_FILE.CONTAINER_ID,
				NR_SRC_STORIES_FILE.CONTAINER_NAME,
				NR_SRC_STORIES_FILE.CONTAINER_URL,
				NR_SRC_STORIES_FILE.ITEM_ID,
				NR_SRC_STORIES_FILE.ITEM_NAME,
				NR_SRC_STORIES_FILE.ITEM_URL,			
				NR_SRC_STORIES_FILE.CREATION_DATE,
				NR_SRC_STORIES_FILE.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_FILE.TAGS,
				NR_SRC_STORIES_FILE.N_COMMENTS,
				NR_SRC_STORIES_FILE.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_FILE.BRIEF_DESC,
				NR_SRC_STORIES_FILE.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_FILE NR_SRC_STORIES_FILE,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_FILE
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_FILE.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FILE
								);
GO

-- 9 NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ADD ITEM_ATOM_URL nvarchar(2048);
GO

INSERT INTO HOMEPAGE.NR_ENTRIES_FRM (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_FRM.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_FRM.SOURCE,
				NR_SRC_STORIES_FRM.SOURCE_TYPE,
				NR_SRC_STORIES_FRM.CONTAINER_ID,
				NR_SRC_STORIES_FRM.CONTAINER_NAME,
				NR_SRC_STORIES_FRM.CONTAINER_URL,
				NR_SRC_STORIES_FRM.ITEM_ID,
				NR_SRC_STORIES_FRM.ITEM_NAME,
				NR_SRC_STORIES_FRM.ITEM_URL,			
				NR_SRC_STORIES_FRM.CREATION_DATE,
				NR_SRC_STORIES_FRM.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_FRM.TAGS,
				NR_SRC_STORIES_FRM.N_COMMENTS,
				NR_SRC_STORIES_FRM.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_FRM.BRIEF_DESC,
				NR_SRC_STORIES_FRM.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_FRM NR_SRC_STORIES_FRM,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_FRM
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_FRM.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FRM
								);
GO

-----------------------------------------------------------------------------------------------
-- START [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------
-- Putting back the constraints
-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);

GO	

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID);

GO

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);

GO

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID); 

GO

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID); 

GO

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID);

GO

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID);

GO

-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);

GO

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID);

GO
-----------------------------------------------------------------------------------------------
-- END [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-- END DATA MIGRATION
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

-- DROPPING VIEW NR_ENTRIES 
DROP VIEW HOMEPAGE.NR_ENTRIES;
GO

--  DROPPING VIEW NR_STORIES
DROP VIEW HOMEPAGE.NR_STORIES;
GO

-----------------------------------------------------------------------
-- REFACTORING STORIES TABLE
-----------------------------------------------------------------------
-- DROPPING OLD COLUNNS FOR STORY TABLE: ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS
-- 1 NR_SRC_STORIES_ACT
DROP INDEX SRC_ACT_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_ACT
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_ACT') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_ACT') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--2 NR_SRC_STORIES_BLG
DROP INDEX SRC_BLG_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_BLG
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_BLG') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_BLG') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--3 NR_SRC_STORIES_COM
DROP INDEX SRC_COM_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_COM
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_COM') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_COM') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--4 NR_SRC_STORIES_WIK
DROP INDEX SRC_WIK_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_WIK
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_WIK') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_WIK') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--5 NR_SRC_STORIES_PRF
DROP INDEX SRC_PRF_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_PRF
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_PRF') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_PRF') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--6 NR_SRC_STORIES_HP
DROP INDEX SRC_HP_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_HP
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_HP') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_HP') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--7 NR_SRC_STORIES_DGR
DROP INDEX SRC_DGR_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_DGR
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_DGR') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_DGR') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--8 NR_SRC_STORIES_FILE
DROP INDEX SRC_FILE_STORIES_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_FILE
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_FILE') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_FILE') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--9 NR_SRC_STORIES_FRM
DROP INDEX SRC_FRM_ITEM_ID ON HOMEPAGE.NR_SRC_STORIES_FRM
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_FRM') and name like '%DF__NR_SRC_ST__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.NR_SRC_STORIES_FRM') and name like '%DF__NR_SRC_ST__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM DROP COLUMN ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS;
GO

--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------
-- EMD FIX - ADDING UNIQUE CONSTRAINT
--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------

---------------------------------------------------------------------------------------------------------------------------
-- TO REMOVE ALL DUPLICATED RECORDS - WE NEED TO EXECUTE THIS QUERY N_TIME IN A PARTITIONED WAY TO DON'T GET FULL THE LOG.
-- THIS IS THE NOT PARTITIONED QUERIES
---------------------------------------------------------------------------------------------------------------------------
-- Sanitize first the table:
--[old query]
--DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID NOT IN (
--	SELECT TEMP.RESOURCE_PREF_ID
--	FROM (
--		SELECT 	MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE  
--		FROM  	HOMEPAGE.EMD_RESOURCE_PREF
--		GROUP BY 	PERSON_ID, RESOURCE_TYPE
--	)  TEMP
--);
--[old query]

-- delete using 0
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '0..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '0..f'			
);

GO

-- delete using 1
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '1..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '1..f'			
);

GO

-- delete using 2
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '2..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '2..f'			
);

GO

-- delete using 3
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '3..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '3..f'			
);

GO

-- delete using 4
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '4..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '4..f'			
);

GO

-- delete using 5
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '5..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '5..f'			
);

GO

-- delete using 6
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '6..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '6..f'			
);

GO

-- delete using 7
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '7..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '7..f'			
);

GO

-- delete using 8
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '8..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '8..f'			
);

GO

-- delete using 9
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < '9..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < '9..f'			
);

GO

-- delete using a
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < 'a..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < 'a..f'			
);

GO

-- delete using b
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < 'b..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < 'b..f'			
);

GO

-- delete using c
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < 'c..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < 'c..f'			
);

GO

-- delete using d
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < 'd..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < 'd..f'			
);

GO

-- delete using e
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		WHERE RESOURCE_PREF_ID < 'e..f'
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE AND
			EMD_RESOURCE_PREF.RESOURCE_PREF_ID < 'e..f'			
);

GO

-- The last delete all
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID IN (
	select EMD_RESOURCE_PREF.RESOURCE_PREF_ID
	from (
		SELECT MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE 
		FROM HOMEPAGE.EMD_RESOURCE_PREF
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
		) T,
		 HOMEPAGE.EMD_RESOURCE_PREF EMD_RESOURCE_PREF
	where 	EMD_RESOURCE_PREF.RESOURCE_PREF_ID < T.RESOURCE_PREF_ID AND 
			EMD_RESOURCE_PREF.PERSON_ID = T.PERSON_ID AND
			EMD_RESOURCE_PREF.RESOURCE_TYPE = T.RESOURCE_TYPE		
);
GO

-- Add unique constraint:
CREATE UNIQUE INDEX EMD_RESOURCE_PREF_UNQ
	ON HOMEPAGE.EMD_RESOURCE_PREF (PERSON_ID, RESOURCE_TYPE);

GO

---------------------------------------------------------------------------------
-- ADDING QUARANTINE TABLE
---------------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.DELETED_STORIES_QUEUE (
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE 	nvarchar(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE 
  	ADD CONSTRAINT PK_QUARANTINE PRIMARY KEY(STORY_ID);
  	

GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 85
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------
-- 1) ADD COLUMN TO THE EMD_EMAIL_PREFS TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS ADD REPLYTO_ENABLED NUMERIC(5,0) NOT NULL DEFAULT 1;

GO

-----------------------------------------------------------------------------------------------
-- 2) ADD COLUMNS TO THE EMD_TRANCHE TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE ADD 
	IS_LOCKED_DAILY NUMERIC(5,0) NOT NULL DEFAULT 0,
	IS_LOCKED_WEEKLY NUMERIC(5,0) NOT NULL DEFAULT 0,
	LAST_STARTED_DAILY DATETIME,
	LAST_STARTED_WEEKLY DATETIME,
	LAST_EXEC_TIME_DAILY_MIN  NUMERIC(10 ,0),
	LAST_EXEC_TIME_WEEKLY_MIN  NUMERIC(10 ,0),
	LAST_RUNNER_DAILY nvarchar(256),
	LAST_RUNNER_WEEKLY nvarchar(256);

GO

---------------------------------------------------------------------------------
-- 3) MODIFY QUARANTINE TABLE
---------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE ADD STATUS NUMERIC(5,0) NOT NULL DEFAULT 0;

GO

--------------------------------------------------------------------------------
-- 4) RENAMING TABLES
--------------------------------------------------------------------------------
DROP VIEW HOMEPAGE.NR_FOLLOWED_STORIES;

GO

ALTER TABLE 	HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT CK_CAT1_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_RESPONSES_STORIES', 'NR_RESPONSES_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CONSTRAINT CK_CAT1_TYPE CHECK (CATEGORY_TYPE = 1);

GO

ALTER TABLE 	HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT CK_CAT2_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_PROFILES_STORIES', 'NR_PROFILES_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CONSTRAINT CK_CAT2_TYPE CHECK (CATEGORY_TYPE = 2);

GO

ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT CK_CAT3_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_COMMUNITIES_STORIES', 'NR_COMMUNITIES_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CONSTRAINT CK_CAT3_TYPE CHECK (CATEGORY_TYPE = 3);

GO

ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT CK_CAT4_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_ACTIVITIES_STORIES', 'NR_ACTIVITIES_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CONSTRAINT CK_CAT4_TYPE CHECK (CATEGORY_TYPE = 4);

GO

ALTER TABLE 	HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT CK_CAT5_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_BLOGS_STORIES', 'NR_BLOGS_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CONSTRAINT CK_CAT5_TYPE CHECK (CATEGORY_TYPE = 5);

GO

ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT CK_CAT6_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_BOOKMARKS_STORIES', 'NR_BOOKMARKS_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CONSTRAINT CK_CAT6_TYPE CHECK (CATEGORY_TYPE = 6);

GO

ALTER TABLE 	HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT CK_CAT7_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_FILES_STORIES', 'NR_FILES_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CONSTRAINT CK_CAT7_TYPE CHECK (CATEGORY_TYPE = 7);

GO

ALTER TABLE 	HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT CK_CAT8_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_FORUMS_STORIES', 'NR_FORUMS_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CONSTRAINT CK_CAT8_TYPE CHECK (CATEGORY_TYPE = 8);

GO

ALTER TABLE 	HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT CK_CAT9_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_WIKIS_STORIES', 'NR_WIKIS_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CONSTRAINT CK_CAT9_TYPE CHECK (CATEGORY_TYPE = 9);

GO

ALTER TABLE 	HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT CK_CAT10_TYPE;
GO
EXEC sp_rename 'HOMEPAGE.NR_TAGS_STORIES', 'NR_TAGS_READERS';
GO
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CONSTRAINT CK_CAT10_TYPE CHECK (CATEGORY_TYPE = 10);

GO


--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE CATEGORIES READERS TABLE
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
);

GO





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 86
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- The field to store the latest contributor
-- The latest contributor is equal to the latest comment creator or if no comments are provided
-- is equal to the status update creator (actor_uuid)
ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD LAST_CONTRIBUTOR_ID nvarchar(36);

-- The field to store the latest updated date for a comment
-- If a comment is not updated it is equal to the creation date
ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD UPDATE_DATE DATETIME;

-------------------------------------------------------
-- HOMEPAGE.BOARD_CURRENT_STATUS 
-- table to store the history of current status updates
-------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_CURRENT_STATUS  (
	CURRENT_STATUS_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL,
	CURRENT_STATUS_SET DATETIME NOT NULL
) ON [PRIMARY]
GO


ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS 
    ADD CONSTRAINT PK_CUR_ST_ID PRIMARY KEY (CURRENT_STATUS_ID);

ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS
	ADD CONSTRAINT FK_CUR_ST_ACTOR_ID FOREIGN KEY (ACTOR_UUID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS
	ADD CONSTRAINT FK_CUR_ST_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES(ENTRY_ID);

CREATE INDEX CURRENT_STATUS_INDEX 
	ON HOMEPAGE.BOARD_CURRENT_STATUS	(ACTOR_UUID ASC, CURRENT_STATUS_SET ASC, CURRENT_STATUS_ID ASC, ENTRY_ID ASC);

CREATE UNIQUE INDEX ACTOR_ENTRY 
	ON HOMEPAGE.BOARD_CURRENT_STATUS (ACTOR_UUID);

GO	





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- UPDATING SOURCE_TYPE TABLE
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
	ADD IS_ENABLE NUMERIC(5,0);

GO
	
UPDATE HOMEPAGE.NR_SOURCE_TYPE SET IS_ENABLE = 1;

GO


----------------------------------------------------------------------
-- [START] INDEX CLEANUP
----------------------------------------------------------------------

-----------------------------------------------
-- FIXING INDEXES ON COMM_STORIES TABLE
-----------------------------------------------
DROP INDEX  NR_COMM_STORIES_COM_ID ON HOMEPAGE.NR_COMM_STORIES;

CREATE INDEX NR_COMM_STORIES_CDATE
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, CREATION_DATE ASC); 

CREATE INDEX NR_COM_STORY_ID			ON	HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, STORY_ID);

GO

-- DROPPING UNUSED INDEXES FOR READERS TABLES
DROP INDEX  RESPONSES_STORIES_CIDX 		ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX  PROFILES_STORIES_CIDX		ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX  COMMUNITIES_STORIES_CIDX	ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX  ACTIVITIES_STORIES_CIDX		ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX  BLOGS_STORIES_CIDX			ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX  BOOKMARKS_STORIES_CIDX		ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX  FILES_STORIES_CIDX			ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX  FORUMS_STORIES_CIDX			ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX  WIKIS_STORIES_CIDX			ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX  TAGS_STORIES_CIDX			ON HOMEPAGE.NR_TAGS_READERS;

-- ADDING INDEXES used to retrieve the evidence and delete records
CREATE INDEX NR_RESP_READER_STORY 		ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID); 
CREATE INDEX NR_PRO_READER_STORY 		ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_COM_READER_STORY 		ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_ACT_READER_STORY 		ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_BLG_READER_STORY 		ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_BOOK_READER_STORY 		ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_FILES_READER_STORY 		ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_FORUMS_READER_STORY 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_WIKIS_READER_STORY 		ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID);
CREATE INDEX NR_TAGS_READER_STORY 		ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID);



GO

-- DROPPING UNUSED INDEXES FOR ENTRIES TABLES
DROP INDEX  NR_ENTRIES_ACT_SRC		ON HOMEPAGE.NR_ENTRIES_ACT;
DROP INDEX  NR_ENTRIES_BLG_SRC 		ON HOMEPAGE.NR_ENTRIES_BLG;
DROP INDEX  NR_ENTRIES_COM_SRC 		ON HOMEPAGE.NR_ENTRIES_COM;
DROP INDEX  NR_ENTRIES_WIK_SRC 		ON HOMEPAGE.NR_ENTRIES_WIK;
DROP INDEX  NR_ENTRIES_PRF_SRC 		ON HOMEPAGE.NR_ENTRIES_PRF;
DROP INDEX  NR_ENTRIES_HP_SRC 		ON HOMEPAGE.NR_ENTRIES_HP;
DROP INDEX  NR_ENTRIES_DGR_SRC 		ON HOMEPAGE.NR_ENTRIES_DGR;
DROP INDEX  NR_ENTRIES_FILE_SRC 	ON HOMEPAGE.NR_ENTRIES_FILE;
DROP INDEX  NR_ENTRIES_FRM_SRC 		ON HOMEPAGE.NR_ENTRIES_FRM;

-- DROPPING UNUSED INDEXES FOR STORIES TABLES
DROP INDEX  NR_SRC_STORIES_ACT_SIDX 	ON HOMEPAGE.NR_SRC_STORIES_ACT;
DROP INDEX  NR_SRC_STORIES_BLG_SIDX		ON HOMEPAGE.NR_SRC_STORIES_BLG;
DROP INDEX  NR_SRC_STORIES_COM_SIDX		ON HOMEPAGE.NR_SRC_STORIES_COM;
DROP INDEX  NR_SRC_STORIES_WIK_SIDX		ON HOMEPAGE.NR_SRC_STORIES_WIK;
DROP INDEX  NR_SRC_STORIES_PRF_SIDX		ON HOMEPAGE.NR_SRC_STORIES_PRF;
DROP INDEX  NR_SRC_STORIES_HP_SIDX		ON HOMEPAGE.NR_SRC_STORIES_HP;
DROP INDEX  NR_SRC_STORIES_DGR_SIDX		ON HOMEPAGE.NR_SRC_STORIES_DGR;
DROP INDEX  NR_SRC_STORIES_FILE_SIDX	ON HOMEPAGE.NR_SRC_STORIES_FILE;
DROP INDEX  NR_SRC_STORIES_FRM_SIDX		ON HOMEPAGE.NR_SRC_STORIES_FRM;




----------------------------------------------------------------------
-- [END] INDEX CLEANUP
----------------------------------------------------------------------

---------------------------------------------------------
-- [START] EMD INIT DATA
---------------------------------------------------------
UPDATE HOMEPAGE.EMD_TRANCHE	SET 	
		IS_LOCKED = 0,
		IS_LOCKED_DAILY = 0,
		IS_LOCKED_WEEKLY = 0;
---------------------------------------------------------
-- [END] EMD INIT DATA
---------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_STORIES TABLES 
--------------------------------------------------------
-- Adding to story table:
-- i) MESSAGE
-- ii) EVENT_TIME
--- iii) VERB
--------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)

GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128);


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128);


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)


GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD MESSAGE nvarchar(4000),
	 	EVENT_TIME DATETIME,
	 	VERB nvarchar (128)
	

GO	
--------------------------------------------------------
-- [END] UPDATING NR_STORIES TABLES
--------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_ENTRIES TABLES ADDING
--------------------------------------------------------
--  FIRST: we need to move it do a bigger table space
-- i) Adding preview URL
-- ii) Adding status update column
-- iii) Adding JSON_META_DATA column
-- iv) Event time
--------------------------------------------------------
------------------------------------------------------------------------------------
-- CREATING NEW TABLES (Those new tables will also have the new required fields)
-- Which are: MESSAGE, PREVIEW_IMAGE_URL, JSON_META_DATA
--	MESSAGE VARCHAR2(4000),
--	PREVIEW_IMAGE_URL VARCHAR2(2048),
--	JSON_META_DATA VARCHAR2(4000),
--	EVENT_TIME TIMESTAMP,
------------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME
GO
		
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
	ADD MESSAGE nvarchar(4000),
		PREVIEW_IMAGE_URL nvarchar(2048),
		JSON_META_DATA nvarchar(4000),
		EVENT_TIME DATETIME		
GO		

--------------------------------------------------------
-- [END] UPDATING NR_ENTRIES TABLES
--------------------------------------------------------


---------------------------------------------
-- Adding VERB and USE_IN_ROLLUP columns to the readers tables
---------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME
	

GO

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME
	
GO

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_FILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME	

GO

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

ALTER TABLE HOMEPAGE.NR_TAGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMERIC(5,0),
				IS_NETWORK			NUMERIC(5,0),
				IS_FOLLOWER			NUMERIC(5,0),
				EVENT_TIME 			DATETIME

GO

-----------------------------------------------------------
-- ADDING A NR_STATUS_UPDATE_READER
-----------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories (we don't need to add source here as they already exist)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('status_update_x8b0bx51af2ddef2cd', 11, '%status_update', 'status_update');

--------------------------------------------------------------------------
-- 11) HOMEPAGE.NR_STATUS_UPDATE_READERS
--------------------------------------------------------------------------	
CREATE TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
   	CONSTRAINT  CK_CAT11_TYPE
    			CHECK
    			(CATEGORY_TYPE = 11)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS 
    ADD CONSTRAINT PK_SU_READERS PRIMARY KEY(FOLLOWED_STORY_ID);

CREATE INDEX SU_STORIES_IDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX SU_STORIES_SIDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (STORY_ID);

CREATE INDEX SU_STORIES_ITEM_ID
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ITEM_ID);

CREATE INDEX SU_STORIES_READER_STORY
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID);	

GO



---------------------------------------------------------
-- [START] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------
----------------------------------------------------------
-- Adding ACTIVITY_META_DATA to NR_STORIES_CONTENT table
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD ACTIVITY_META_DATA VARCHAR(MAX);
GO
----------------------------------------------------------

---------------------------------------------------------------------------------
-- INSERTING THIRD PARTY CATEGORIES AND SOURCES
---------------------------------------------------------------------------------
-- Adding a new category (used from UI rendering) and source (used a source of stories from component)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('ext_9cax4cc4x8b0bx51af2ddef2cd', 12, '%external', 'external');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC, IS_ENABLE)
VALUES ('ext_____fdfdc9cax80bx51af2', 100, '%external', 'external', 0);

---------------------------------------------------------
-- 12) ADDING A NR_EXTERNAL_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_EXTERNAL_READERS (
	FOLLOWED_STORY_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
   	CONSTRAINT  CK_CAT12_TYPE
    			CHECK
    			(CATEGORY_TYPE = 12)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS 
    ADD CONSTRAINT PK_EXT_STORIES PRIMARY KEY(FOLLOWED_STORY_ID);
    
CREATE INDEX EXT_STORIES_IDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX EXT_STORIES_SIDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (STORY_ID);

CREATE INDEX EXT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_EXTERNAL_READERS (ITEM_ID);

CREATE INDEX EXT_STORIES_READER_STORY
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID);    



--------------------------------------------------------------
-- ADDING A NR_ENTRIES_EXTERNAL TABLE
--------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36) NOT NULL,
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL,
	UPDATE_DATE DATETIME NOT NULL,
	TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC nvarchar(512),
	LAST_RECOMMENDER_ID nvarchar(36),
	LAST_DATE_RECOMMENDER_ID DATETIME,
	PREV_RECOMMENDER_ID nvarchar(36),
	PREV_DATE_RECOMMENDER_ID DATETIME,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_DESC_COMMENT nvarchar(256),
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_DESC_COMMENT nvarchar(256),
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	ITEM_ATOM_URL nvarchar(2048),
	MESSAGE nvarchar(4000),
	PREVIEW_IMAGE_URL nvarchar(2048),
	JSON_META_DATA nvarchar(4000),
	EVENT_TIME DATETIME,
	CONSTRAINT   	CK_ENT_SRC10_TYPE
    				CHECK
    				(SOURCE_TYPE = 10)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL 
    ADD CONSTRAINT PK_EXT_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_EXT_CONT
    ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CONTAINER_ID);
    
GO



----------------------------------------------------
-- ADDING A NR_SRC_STORIES_EXTERNAL TABLE
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_CORRELATION_ID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	MESSAGE nvarchar(4000),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),	
	CONSTRAINT   	CK_SRC100_TYPE
    				CHECK
    				(SOURCE_TYPE >= 100)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
    ADD CONSTRAINT PK_EXT_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
  	ADD CONSTRAINT FK_ENTRY_ID_EXT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_EXTERNAL (ENTRY_ID);    

CREATE INDEX SRC_STORIES_EXT_DATE
	ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CREATION_DATE DESC);

CREATE INDEX SRC_EXT_CONTAINER_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CONTAINER_ID);

CREATE INDEX SRC_EXT_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ITEM_CORRELATION_ID);
    
CREATE INDEX SRC_STORIES_EXT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ENTRY_ID);  


---------------------------------------------------------
-- [END] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------


---------------------------------------------------------
-- [START] ACTIONABLE
---------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_saved_stories_4cc4x8b0bx', 13, '%actionable_saved_stories', 'actionable_saved_stories');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_directed_notification_bx', 14, '%actionable_directed_notification', 'actionable_directed_notification');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_todo_______cax4cc4x8b0bx', 15, '%actionable_todo', 'actionable_todo');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_action_required__4x8b0bx', 16, '%actionable_action_required', 'actionable_action_required');

GO


---------------------------------------------------------
-- ADDING NR_ACTIONABLE_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_READERS (
	ACTIONABLE_READER_ID nvarchar(36) NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
	NOTE_TEXT nvarchar(4000),
	NOTE_UPDATE_DATE DATETIME,
	CONSTRAINT   	CK_CAT_ACTION_TYPE
    				CHECK
    				(CATEGORY_TYPE >= 13 AND CATEGORY_TYPE <= 16)	
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS 
    ADD CONSTRAINT PK_ACTION_STORIES PRIMARY KEY (ACTIONABLE_READER_ID);
    
CREATE INDEX ACTION_READER_STORIES_IDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX ACTION_READER_SIDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (STORY_ID);

CREATE INDEX ACTION_READER_ITEM_ID
    ON HOMEPAGE.NR_ACTIONABLE_READERS (ITEM_ID);

CREATE UNIQUE INDEX ACTION_READER_STORY
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, STORY_ID);    

    
GO

---------------------------------------------------------
-- ADDING NR_ACTIONABLE_STORIES TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_STORIES (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_CORRELATION_ID nvarchar(36), -- NEW	
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(512),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	MESSAGE nvarchar(4000),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	CONSTRAINT   	CK_SRC_ACTION_TYPE
    				CHECK
    				(SOURCE_TYPE >= 1 AND SOURCE_TYPE <= 10 )
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_STORIES
    ADD CONSTRAINT PK_ACTION_STORY_ID PRIMARY KEY(STORY_ID);

CREATE INDEX ACTION_CONTAINER_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (CONTAINER_ID);

CREATE INDEX ACTION_ITEM_CORR_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ITEM_CORRELATION_ID);

CREATE INDEX ACTION_ACT_ENTRYID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ENTRY_ID);    


GO
	
---------------------------------------------------------
-- [END] ACTIONABLE
---------------------------------------------------------

DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;
GO
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- FIX CONSTRAINT ON SOURCE_TYPE FOR NR_ENTRIES_EXTERNAL
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL DROP CONSTRAINT CK_ENT_SRC10_TYPE;

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD CONSTRAINT CK_ENT_SRC100_TYPE
    													CHECK
    													(SOURCE_TYPE >= 100);
GO

-----------------------------------------------
-- ADD ROLLUP_ENTRY_ID FOREIGN KEY TO READER TABLES
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_FILES_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_TAGS_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD ROLLUP_ENTRY_ID nvarchar(36);
GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- Remove NR_NEWS_PRF_COMMENT
-----------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT;

GO


-----------------------------------------------------------------------------------
-- Rename all the PK in the reader tables to be CATEGORY_READER_ID;
-----------------------------------------------------------------------------------
-- 1
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS DROP CONSTRAINT PK_RESP_STORIES;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_RESPONSES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CONSTRAINT PK_RESP_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS DROP COLUMN FOLLOWED_STORY_ID;	

ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_RESP_READER_STORY ON HOMEPAGE.NR_RESPONSES_READERS;
GO

CREATE UNIQUE INDEX NR_RESP_READER_STORY 		
	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID);
	
GO

-- 2
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS DROP CONSTRAINT PK_PROF_STORIES;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_PROFILES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CONSTRAINT PK_PROF_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_PRO_READER_STORY ON HOMEPAGE.NR_PROFILES_READERS;
GO

CREATE UNIQUE INDEX NR_PRO_READER_STORY 		
	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID); 
	
GO

-- 3
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS DROP CONSTRAINT PK_COMM_STORIES;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_COMMUNITIES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CONSTRAINT PK_COMM_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_COM_READER_STORY ON HOMEPAGE.NR_COMMUNITIES_READERS;
GO

CREATE UNIQUE INDEX NR_COM_READER_STORY 		
	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID);
	
GO

-- 4
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS DROP CONSTRAINT PK_ACT_STORIES;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_ACTIVITIES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CONSTRAINT PK_ACT_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_ACT_READER_STORY ON HOMEPAGE.NR_ACTIVITIES_READERS;
GO

CREATE UNIQUE INDEX NR_ACT_READER_STORY 		
	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID);
	
GO

-- 5
ALTER TABLE		HOMEPAGE.NR_BLOGS_READERS DROP CONSTRAINT PK_BLOGS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_BLOGS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CONSTRAINT PK_BLOGS_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_BLG_READER_STORY ON HOMEPAGE.NR_BLOGS_READERS;
GO

CREATE UNIQUE INDEX NR_BLG_READER_STORY 		
	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID);
	
GO

-- 6
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS  DROP CONSTRAINT PK_BOOKS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_BOOKMARKS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CONSTRAINT PK_BOOKS_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_BOOK_READER_STORY ON HOMEPAGE.NR_BOOKMARKS_READERS;
GO

CREATE UNIQUE INDEX NR_BOOK_READER_STORY 		
	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID);

GO

-- 7
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS DROP CONSTRAINT PK_FILES_STORIES;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_FILES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CONSTRAINT PK_FILES_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_FILES_READER_STORY ON HOMEPAGE.NR_FILES_READERS;
GO

CREATE UNIQUE INDEX NR_FILES_READER_STORY 		
	ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID);
GO

-- 8
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS DROP CONSTRAINT PK_FORUMS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_FORUMS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CONSTRAINT PK_FORUMS_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_FORUMS_READER_STORY ON HOMEPAGE.NR_FORUMS_READERS;
GO

CREATE UNIQUE INDEX NR_FORUMS_READER_STORY 	
	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID);
GO

-- 9
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS DROP CONSTRAINT PK_WIKIS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_WIKIS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CONSTRAINT PK_WIKIS_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX NR_WIKIS_READER_STORY ON HOMEPAGE.NR_WIKIS_READERS;
GO

CREATE UNIQUE INDEX NR_WIKIS_READER_STORY 		
	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID);

GO

-- 10
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS DROP CONSTRAINT PK_TAGS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_TAGS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CONSTRAINT PK_TAGS_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

--DROP INDEX NR_TAGS_READER_STORY ON HOMEPAGE.NR_TAGS_READERS;
--GO

--CREATE UNIQUE INDEX NR_TAGS_READER_STORY 		
--	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID);

--GO

-- 11 NR_STATUS_UPDATE_READERS
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS DROP CONSTRAINT PK_SU_READERS;
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_STATUS_UPDATE_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD CONSTRAINT PK_SU_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX SU_STORIES_READER_STORY ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
GO

CREATE UNIQUE INDEX SU_STORIES_READER_STORY
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID);

GO

-- 12 NR_EXTERNAL_READERS
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS DROP CONSTRAINT PK_EXT_STORIES;
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_EXTERNAL_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD CONSTRAINT PK_EXT_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

DROP INDEX EXT_STORIES_READER_STORY ON HOMEPAGE.NR_EXTERNAL_READERS;
GO

CREATE UNIQUE INDEX EXT_STORIES_READER_STORY
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID);

GO

-- 13-16 ACTIONABLE TABLES
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS DROP CONSTRAINT PK_ACTION_STORIES;
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL;
GO
UPDATE 			HOMEPAGE.NR_ACTIONABLE_READERS SET CATEGORY_READER_ID = ACTIONABLE_READER_ID;
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD CONSTRAINT PK_ACTION_READERS PRIMARY KEY(CATEGORY_READER_ID);
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS DROP COLUMN ACTIONABLE_READER_ID;

ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD IS_STORY_COMM NUMERIC(5 ,0);

GO

-------------------------------------------------------------------
-- Remove NR_ACTIONABLE_STORIES
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ACTIONABLE_STORIES; 
GO

-------------------------------------------------------------------
-- TODO: Remove the 4 categories type, leave just one category (16)
-------------------------------------------------------------------

-------------------------------------------------------------------
-- TODO: Rename COMM_PERSON_STORIES to be HOMEPAGE.NR_AGGREGATED_READERS. Make it compatible withe other table
-------------------------------------------------------------------
-- Add a category type: aggregated_readers
CREATE TABLE HOMEPAGE.NR_AGGREGATED_READERS (
	CATEGORY_READER_ID nvarchar(36) DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5 ,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5 ,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5 ,0),
	USE_IN_ROLLUP NUMERIC(5 ,0),
	IS_NETWORK	NUMERIC(5 ,0),
	IS_FOLLOWER	NUMERIC(5 ,0),
	EVENT_TIME 	DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_AGGREGATED_READERS
    ADD CONSTRAINT PK_AGG_READERS PRIMARY KEY(CATEGORY_READER_ID);

CREATE INDEX NR_AGGREGATED_READERS_IDX
    ON HOMEPAGE.NR_AGGREGATED_READERS (CREATION_DATE ASC, READER_ID);

CREATE INDEX NR_AGGREGATED_READERS_STORY_ID
    ON HOMEPAGE.NR_AGGREGATED_READERS (STORY_ID);

CREATE INDEX NR_AGGREGATED_READERS_ITEM_ID
    ON HOMEPAGE.NR_AGGREGATED_READERS (ITEM_ID);

CREATE INDEX NR_AGGREGATED_READERS_DATE
    ON HOMEPAGE.NR_AGGREGATED_READERS (CREATION_DATE ASC);

CREATE UNIQUE INDEX NR_AGG_READERS_UNQ
    ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, STORY_ID); 



-------------------------------------------------------------------    
-- MIGRATION FROM: NR_COMM_PERSON_STORIES -> NR_AGGREGATED_READERS
-------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_AGGREGATED_READERS
	SELECT 	COMM_PER_STORY_ID,
			COMM_PER_READER_ID,
			CATEGORY_TYPE,
			SOURCE,
			CONTAINER_ID,
			ITEM_ID,
			' ' ROLLUP_ENTRY_ID,
			RESOURCE_TYPE,
			CREATION_DATE,
			STORY_ID,
			SOURCE_TYPE,
			USE_IN_ROLLUP,
			IS_NETWORK,
			IS_FOLLOWER,
			EVENT_TIME,
			IS_STORY_COMM
	FROM 	HOMEPAGE.NR_COMM_PERSON_STORIES;

GO

-- DROPPING PREV. TABLE
DROP TABLE HOMEPAGE.NR_COMM_PERSON_STORIES;
GO
-------------------------------------------------------------------
-- Remove N_COMMENTS and N_RECOMMANDATIONS from BOARD_ENTRIES
-------------------------------------------------------------------

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.BOARD_ENTRIES') and name like '%DF__BOARD_ENT__N_COM%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.HOMEPAGE.BOARD_ENTRIES DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.BOARD_ENTRIES') and name like '%DF__BOARD_ENT__N_REC%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.BOARD_ENTRIES DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.BOARD_ENTRIES DROP COLUMN N_COMMENTS;
GO
ALTER TABLE 	HOMEPAGE.BOARD_ENTRIES DROP COLUMN N_RECOMMANDATIONS;
GO

-------------------------------------------------------------------
-- BOARD_OBJECT_REFERENCE 
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

CREATE TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE (
	OBJECT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL,
	DISPLAY_NAME nvarchar(2048),
	IMAGE_NAME   nvarchar(2048),
	NAME nvarchar(1024),
	URL nvarchar(2048),
	CONTENT nvarchar(4000),
	IMAGE_URL nvarchar(2048),
	SOURCE  nvarchar(36),
	SOURCE_TYPE  NUMERIC(5 ,0),
	CREATION_DATE DATETIME,
	MIME_TYPE nvarchar(36),
	AUTHOR_ID nvarchar(36),
	AUTHOR_DISPLAY_NAME nvarchar(256)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE 
    ADD CONSTRAINT PK_BRD_OBJ_ID PRIMARY KEY(OBJECT_ID);

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_OBJ_ENTRY FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_AUTHOR_ID FOREIGN KEY (AUTHOR_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE INDEX BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (ENTRY_ID);

CREATE INDEX BRD_AUTHOR_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (AUTHOR_ID);

GO


-----------------------------------------------
-- HOMEPAGE.NR_COMM_SETTINGS
-----------------------------------------------

CREATE TABLE HOMEPAGE.NR_COMM_SETTINGS (
	COMM_ID nvarchar(36) NOT NULL,
	MICROBLOGGING_ENABLED NUMERIC(5 ,0),
	FLAGS nvarchar(36)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS
    ADD CONSTRAINT PK_COMM_ID PRIMARY KEY(COMM_ID);


--------------------------------------------------------------------------
-- 17 HOMEPAGE.NR_DISCOVERY_VIEW
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_DISCOVERY_VIEW (
	CATEGORY_READER_ID nvarchar(36)  DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36),
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME 	DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0),
	CONSTRAINT   	CK_CAT17_TYPE
					CHECK
					(CATEGORY_TYPE = 17)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_DISCOVERY_VIEW 
    ADD CONSTRAINT PK_DISCOVERY_VIEW PRIMARY KEY(CATEGORY_READER_ID);

CREATE INDEX DISCOVERY_STORIES_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE ASC);

CREATE INDEX DISCOVERY_SIDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (STORY_ID);

CREATE INDEX DISCOVERY_ITEM
    ON HOMEPAGE.NR_DISCOVERY_VIEW (ITEM_ID);

CREATE INDEX DISCOVERY_STORIES_DATE
    ON HOMEPAGE.NR_DISCOVERY_VIEW (CREATION_DATE ASC);

CREATE UNIQUE INDEX DISCOVERY_READER_STORY 		
	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, STORY_ID);   



INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('discovery-view', 17, '%discovery', 'discovery');


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.NR_COMM_SETTINGS;

-----------------------------------------------
-- HOMEPAGE.NR_COMM_SETTINGS
-----------------------------------------------

CREATE TABLE HOMEPAGE.NR_COMM_SETTINGS (
	COMM_ID nvarchar(36) NOT NULL,
	MICROBLOGGING_WRITE_ACL NUMERIC(5 ,0),
	FLAGS nvarchar(36)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS
    ADD CONSTRAINT PK_COMM_ID PRIMARY KEY(COMM_ID);


GO 

-----------------------------------------------------
-- NR_PROFILES_VIEW
-----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PROFILES_VIEW (
	CATEGORY_READER_ID nvarchar(36)  DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36),
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME 	DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0),
	IS_BROADCAST NUMERIC(5 ,0),
	ORGANIZATION_ID nvarchar(36),
	CONSTRAINT   	CK_CAT18_TYPE
    				CHECK
    				(CATEGORY_TYPE = 18)
)
ON [PRIMARY]
GO
ALTER TABLE HOMEPAGE.NR_PROFILES_VIEW 
    ADD CONSTRAINT PK_PROFILES_VIEW PRIMARY KEY(CATEGORY_READER_ID);

CREATE INDEX PROFILES_VIEW_IDX
    ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, CREATION_DATE ASC);

CREATE INDEX PROFILES_SIDX
    ON HOMEPAGE.NR_PROFILES_VIEW (STORY_ID);

CREATE INDEX PROFILES_ITEM
    ON HOMEPAGE.NR_PROFILES_VIEW (ITEM_ID);

CREATE INDEX PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE ASC);

CREATE UNIQUE INDEX PROFILES_READER_STORY 		
	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, STORY_ID); 



---------------------------------------------------------------------------------
-- Adding a new category for profiles view
---------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles-view', 18, '%profiles', 'profiles');

---------------------------------------------------------------------------------
-- Adding IS_BROADCAST to ALL the readers table
---------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  ORGANIZATION_ID nvarchar(36);
GO
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  ORGANIZATION_ID nvarchar(36);

GO

-------------------------------------------------------------------------------
-- ADDING ACTIVITY_META_DATA_1 and ACTIVITY_META_DATA_2
-------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO

-------------------------------------------------------------------
-- REMOVING NR_ORGPERSON_FOLLOW AND NR_ORGPERSON_STORIES
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
DROP TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW;
GO

-------------------------------------------------------------------
-- Add to: NR_ENTRIES_* the column SCOPE
-------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_ACT			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_BLG			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_COM			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_WIK			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_PRF			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_HP			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_DGR			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FILE		ADD  SCOPE NUMERIC(5,0);	
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FRM			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_EXTERNAL	ADD  SCOPE NUMERIC(5,0);
GO
---------------------------------
-- CONVERT BLOB to CLOB
---------------------------------
-- TODO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 92
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------
-- [START] Changing definition for SOURCE_TYPE table
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SOURCE_TYPE;

CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0) NOT NULL, -- numeric that is 1,2,3 etc.. 100, 101..
	EXTERNAL_ID nvarchar(256) NOT NULL,
	DISPLAY_NAME nvarchar(4000),
	IMAGE_URL nvarchar(2048),
	PUBLISHED DATETIME,
	UPDATED nvarchar(256),	
	IS_ENABLED NUMERIC(5,0),
	SUMMARY nvarchar (4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD CONSTRAINT PK_SRC_TYPE_ID PRIMARY KEY(SOURCE_TYPE_ID);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNQ UNIQUE(SOURCE_TYPE);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_EXT_ID_UNQ UNIQUE(EXTERNAL_ID);
	
-- Update also the init data 

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'int_activities_id', 'activities', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'int_blogs_id', 'blogs', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'int_communities_id', 'communities', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'int_wikis_id', 'wikis', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'int_profiles_id', 'profiles', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'int_homepage_id', 'homepage', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'int_dogear_id', 'dogear', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'int_files_id', 'files', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'int_forums_id', 'forums', null, null, null, 1, null);
	
	
----------------------------------------------------------------
-- [END] Changing definition for SOURCE_TYPE table
----------------------------------------------------------------

------------------------------------------------------
-- [START] Adding indexes to the readers tables
------------------------------------------------------

--DISCOVERY VIEW READERS:
CREATE INDEX DISCOVERY_STORIES_SRC_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
    
CREATE INDEX DISCOVERY_STORIES_COM_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, IS_STORY_COMM);

--EXTERNAL READERS
CREATE INDEX EXT_STORIES_SRC_IDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);

--RESPONSES READERS
CREATE INDEX RESPONSES_STORIES_SRC_IDX
    ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);

--ACTIONABLE READERS
CREATE INDEX ACTION_STORIES_SRC_IDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
    
------------------------------------------------------
-- [END] Adding indexes to the readers tables
-----------------------------------------------------
    
------------------------------------------
-- Dropping HOMEPAGE.BOARD_READERS
-------------------------------------------
DROP TABLE HOMEPAGE.BOARD_READERS;

----------------------------------------------------------------------------------------------
-- [START] This is a list of indexes to speed up seedlist performance and profiles API
----------------------------------------------------------------------------------------------

-----------------------
-- BOARD_ENTRIES
-----------------------
DROP INDEX NEWS_BRD_UPDATE ON HOMEPAGE.BOARD_ENTRIES;
DROP INDEX NEWS_BRD_ITEM ON HOMEPAGE.BOARD_ENTRIES;

GO

CREATE UNIQUE INDEX ITEM_ID_IDX
   ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID ASC) INCLUDE (CONTAINER_ID);

GO

CREATE INDEX CREATION_ITEM_IDX 
	ON HOMEPAGE.BOARD_ENTRIES (CREATION_DATE DESC, ITEM_ID DESC);

GO
   
---------------------
-- BOARD_COMMENTS
---------------------
CREATE INDEX CREATION_DATE_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (CREATION_DATE ASC);

GO

CREATE INDEX ITEM_CORR_CREATION_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (ITEM_CORRELATION_ID, CREATION_DATE ASC);

GO

CREATE INDEX ITEM_ITEM_CORR_IDX
	ON HOMEPAGE.BOARD_COMMENTS (ITEM_ID ASC, ITEM_CORRELATION_ID ASC);
   
----------------------
-- NR_NETWORK
----------------------
CREATE INDEX COLL_PERSON_IDX 
	ON HOMEPAGE.NR_NETWORK (COLLEAGUE_ID, PERSON_ID);

GO

----------------------------------------------------------------------------------------------
-- [END] This is a list of indexes to speed up seedlist performance and profiles API
----------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------
-- 1) HOMEPAGE.BOARD
-------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD  (
	BOARD_ID nvarchar(256) NOT NULL,
	BOARD_CONTAINER_ID nvarchar(256) NOT NULL,
	BOARD_TYPE nvarchar(64) NOT NULL,
	BOARD_OWNER_ASSOC_ID nvarchar(36) NOT NULL,
	BOARD_OWNER_ASSOC_TYPE nvarchar(64) NOT NULL,
	CREATED DATETIME NOT NULL,
	CREATED_BY nvarchar(36) NOT NULL,
	LASTUPDATE DATETIME NOT NULL,
	LASTUPDATE_BY nvarchar(36) NOT NULL,
	IS_ENABLED NUMERIC(5, 0) DEFAULT 1 NOT NULL,
	VISIBILITY nvarchar(36),
	EDITABILITY nvarchar(36)		
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT BOARD_PK PRIMARY KEY (BOARD_ID);

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_OWNER FOREIGN KEY (BOARD_OWNER_ASSOC_ID) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_CREATED FOREIGN KEY (CREATED_BY) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);	

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_LASTUPDATE FOREIGN KEY (LASTUPDATE_BY) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX BOARD_OWNER_ASSOC_UIDX 
	ON HOMEPAGE.BOARD (BOARD_OWNER_ASSOC_ID ASC, BOARD_TYPE ASC);

ALTER TABLE HOMEPAGE.BOARD
	ADD CONSTRAINT CONTAINER_ID_UNQ UNIQUE (BOARD_CONTAINER_ID);
      
CREATE UNIQUE INDEX BRD_CONTAINER_ID_UIDX 
	ON HOMEPAGE.BOARD (BOARD_CONTAINER_ID);	
	
GO

-------------------------------------------------------
-- 2) Adding fk to the existing BOARD_ENTRIES
-------------------------------------------------------

--CLEAR BOARD_* tables before applying CONTAINER_ID FK
DELETE FROM HOMEPAGE.BOARD_OBJECT_REFERENCE;
DELETE FROM HOMEPAGE.BOARD_CURRENT_STATUS;
DELETE FROM HOMEPAGE.BOARD_RECOMMENDATIONS;
DELETE FROM HOMEPAGE.BOARD_COMMENTS;
DELETE FROM HOMEPAGE.BOARD_ENTRIES;

GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD CONSTRAINT FK_CONTAINER_ID FOREIGN KEY (CONTAINER_ID) 
	REFERENCES HOMEPAGE.BOARD (BOARD_CONTAINER_ID);

CREATE INDEX BRD_E_CONTAINER_ID_UIDX 
	ON HOMEPAGE.BOARD_ENTRIES (CONTAINER_ID);

GO
--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------

------------------------
-- BUG TYPO FIXING
------------------------
-- RENAME FROM:  N_RECCOMANDATIONS to the correct: N_RECOMMENDATIONS 
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_ACT.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_BLG.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_COM.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_DGR.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_EXTERNAL.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_FILE.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_FRM.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_HP.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_PRF.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO
EXEC sp_rename 'HOMEPAGE.NR_ENTRIES_WIK.N_RECCOMANDATIONS', 'N_RECOMMANDATIONS' , 'COLUMN';
GO





------------------------------
-- i) COMMIT all the work
-- ii) enable xp_cmdshell to allow use of bcp
-----------------------------
COMMIT;


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE

---------------------------------
-- Move the data
---------------------------------


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[START] DISCOVERY MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------



-- 1 ACTIVITIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_ACT
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_ACT.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 2 BLOGS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_BLG NR_SRC_STORIES_BLG
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_BLG.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 3 COMMUNITIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_COM NR_SRC_STORIES_COM
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_COM.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 4 WIKIS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_WIK NR_SRC_STORIES_WIK
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_WIK.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 5 PROFILES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_PRF NR_SRC_STORIES_PRF
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_PRF.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 6 HOMEPAGE
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_HP NR_SRC_STORIES_HP
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_HP.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 7 DOGEAR
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_DGR NR_SRC_STORIES_DGR
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_DGR.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 8  FILES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_FILE
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_FILE.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 9  FORUMS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_FRM NR_SRC_STORIES_FRM
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_FRM.STORY_ID
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.DISCOVERY TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.DISCOVERY' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_DISCOVERY_VIEW' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[START] SAVED MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

-- A) INSERT ENTRIES
-- B) INSERT STORIES
-- C) INSERT ACTIONABLE

-- 1) ACT ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 1
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_ACT
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_ACT' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 2) BLG ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 2
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_BLG
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_BLG' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 3) COM ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 3
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_COM
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_COM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 4) WIK ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 4
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_WIK
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_WIK' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 5) PRF ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 5
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_PRF
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_PRF' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 6) HP ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 6
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_HP
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_HP' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO


DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 7) DGR ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 7
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_DGR
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_DGR' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 8) FILES ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 8
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FILE
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_FILE' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO


DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 9) FRM ENTRIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, NEWS_STORY_ID STORY_ID, MAX(CREATION_DATE) CREATION_DATE
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 9
				GROUP	BY ITEM_ID, NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID AND NR_NEWS_SAVED.CREATION_DATE = TEMP.CREATION_DATE
		) TEMP_STORIES  
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FRM
								)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_ENTRIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO


declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_ENTRIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES_FRM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;


----------------------------------------------------
----- STORIES
----------------------------------------------------

-- 1 ACT STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 1
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 1 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_ACT
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_ACT' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 2 BLG STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 2
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 2 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_BLG
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_BLG' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 3 COM STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 3
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 3 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_COM
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_COM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 4 WIK STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 4
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 4 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_WIK
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_WIK' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 5 PRF STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 5
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 5 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_PRF
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_PRF' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 6 HP STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 6
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 6 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_HP
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_HP' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 7 DGR STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 7
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 7 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_DGR
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_DGR' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 8 FILE STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 8
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 8 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_FILE
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FILE' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 9 FRM STORIES
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT NEWS_STORY_ID STORY_ID, MAX (CREATION_DATE) MAX_CREATION_DATE
				FROM HOMEPAGE.NR_NEWS_SAVED
				WHERE SOURCE_TYPE = 9
				GROUP BY NEWS_STORY_ID
			) TEMP
		WHERE 	NR_NEWS_SAVED.SOURCE_TYPE = 9 AND 	NR_NEWS_SAVED.CREATION_DATE = TEMP.MAX_CREATION_DATE AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_FRM
												)
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.STORIES TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.STORIES' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FRM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--------------------------------------------------------------------------
-- READERS
--------------------------------------------------------------------------

-- 1 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 1
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 2 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 2
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO


DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 3 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 3
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 4 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 4
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 5 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 5
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 6 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 6
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 7 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 7
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 8 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 8
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.READERS;

COMMIT;

-- 9 READERS
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.READERS AS (
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 9
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.READERS TO HOMEPAGEUSER
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.READERS' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ACTIONABLE_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO


DROP VIEW HOMEPAGE.READERS;

COMMIT;


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[END] SAVED MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-----------------------------------
-- Disable xp_cmdshell
----------------------------------

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 0
RECONFIGURE

----------------------------------
-----------------------------------



BEGIN TRANSACTION
GO




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 93
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- [START] RECREATING NR_CATEGORIES_READERS VIEW
---------------------------------------------------------
DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;

GO
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);

GO

---------------------------------------------------------
-- [END] RECREATING NR_CATEGORIES_READERS VIEW
---------------------------------------------------------

-----------------------------------------------------
-- 1) ADDING INDEXES 
-----------------------------------------------------
CREATE INDEX BRD_SL_UPDATED_DEL 
	ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC, SL_IS_DELETED);

GO

CREATE INDEX BRD_CURRENT_STATUS 
	ON HOMEPAGE.BOARD_CURRENT_STATUS (ENTRY_ID);

GO	

CREATE INDEX BRD_RECOMMENDER_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID);

GO

----------------------------------------------------
-- 2) ADDING A MISSING FK TO BOARD_RECOMMENDATIONS: FK_BRD_RECOMMENDER AND 
----------------------------------------------------
ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	ADD CONSTRAINT FK_BRD_RECOMMENDER FOREIGN KEY (RECOMMENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

GO		    

----------------------------------------------------------
-- 3) Adding an ORGANISATION_ID
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE ADD ORGANIZATION_ID nvarchar(36);

GO

UPDATE HOMEPAGE.NR_SOURCE_TYPE SET ORGANIZATION_ID = 'default';


----------------------------------------------------------
-- 4) Change the CATEGORY_TYPE INFO FOR PROFILE VIEW
----------------------------------------------------------
UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET CATEGORY_TYPE_NAME = '%profiles-view', CATEGORY_TYPE_DESC = 'profiles-view' WHERE CATEGORY_TYPE = 18;

----------------------------------------------------------
-- 5) CREATING AN INDEX FOR ALL THE READERS TABLE INCLUDING ALSO THE SOURCE_TYPE
-- THIS INDEX IS USED FOR THIRD FILTER LEVEL
----------------------------------------------------------
CREATE INDEX NR_AGG_READERS 
	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX PROFILES_STORIES_SRC_IDX
	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX COMMUNITIES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX ACTIVITIES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX BLOGS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX BOOKMARKS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX FILES_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_FILES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX FORUMS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX WIKIS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX TAGS_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
	
CREATE INDEX SU_STORIES_SRC_IDX 
	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);

-- they already have indexed the SOURCE_TYPE those tables
--NR_RESPONSES_READERS
--NR_EXTERNAL_READERS
--NR_ACTIONABLE_READERS

GO

-------------------------------------------------------------------------------------------
-- 6) Adding IS_LAST_COMMENT_PUBLIC and IS_PREV_COMMENT_PUBLIC to  NR_ENTRIES_XXX tables
-------------------------------------------------------------------------------------------

--1) NR_ENTRIES_ACT 
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ADD  
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)


GO

----reorg table HOMEPAGE.NR_ENTRIES_ACT;

GO

--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_BLG;

GO

--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_COM;

GO

--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_WIK;

GO

--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_PRF;

GO

--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_HP;

GO

--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_DGR;

GO

--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_FILE;

GO

--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ADD 
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_FRM;

GO

--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0), 
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0)
	
GO

--reorg table HOMEPAGE.NR_ENTRIES_EXTERNAL;

GO






-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 94
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------
-- Adding: JSON_META_DATA
----------------------------------------------

DROP TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE;

GO

----------------------------------------------------------------
-- ADDING BOARD_OBJECT_REFERENCE
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE (
	OBJECT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL,
	DISPLAY_NAME nvarchar(2048),
	IMAGE_NAME   nvarchar(2048),
	NAME nvarchar(512), 
	URL nvarchar(1024), 
	CONTENT nvarchar(4000),
	IMAGE_URL nvarchar(1024),
	SOURCE  nvarchar(36),
	SOURCE_TYPE  NUMERIC(5 ,0),
	CREATION_DATE DATETIME,
	MIME_TYPE nvarchar(36),
	AUTHOR_ID nvarchar(36),
	AUTHOR_DISPLAY_NAME nvarchar(256),
	JSON_META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE 
    ADD CONSTRAINT PK_BRD_OBJ_ID PRIMARY KEY(OBJECT_ID);

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_OBJ_ENTRY FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_AUTHOR_ID FOREIGN KEY (AUTHOR_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE INDEX  BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (ENTRY_ID);

CREATE INDEX  BRD_AUTHOR_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (AUTHOR_ID);    
GO

------------------------------------------------------------
--
------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SOURCE_TYPE;

------------------------------------------------
-- NR_SOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0) NOT NULL, -- numeric that is 1,2,3 etc.. 100, 101..
	EXTERNAL_ID nvarchar(256) NOT NULL,
	DISPLAY_NAME nvarchar(4000),
	IMAGE_URL nvarchar(2048),
	PUBLISHED DATETIME,
	UPDATED DATETIME,	
	IS_ENABLED NUMERIC(5,0),
	SUMMARY nvarchar (4000),
	ORGANIZATION_ID nvarchar(36),
	URL nvarchar(2048),
	URL_SSL nvarchar(2048)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD CONSTRAINT PK_SRC_TYPE_ID PRIMARY KEY(SOURCE_TYPE_ID);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNQ UNIQUE(SOURCE_TYPE);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_EXT_ID_UNQ UNIQUE(EXTERNAL_ID);

GO	


------------
--- START INSERT NR_SOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'int_activities_id', 'activities', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'int_blogs_id', 'blogs', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'int_communities_id', 'communities', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'int_wikis_id', 'wikis', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'int_profiles_id', 'profiles', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'int_homepage_id', 'homepage', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'int_dogear_id', 'dogear', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'int_files_id', 'files', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'int_forums_id', 'forums', null, null, null, 1, null, 'default', null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, URL)
VALUES ('default_c9cax4cc4x80bx51af2ddef2c', 100, 'default', 'default', null, null, null, 1, null, 'default', null);

------------
--- END INSERT NR_SOURCE_TYPE
------------

------------------------------------------------------
--[START]: perf defect 40892 
------------------------------------------------------
CREATE INDEX  NR_SRC_STORIES_ACT_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (EVENT_RECORD_UUID, ENTRY_ID); 

GO
    
CREATE INDEX NR_SRC_STORIES_BLG_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_COM_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_COM (EVENT_RECORD_UUID, ENTRY_ID);

GO

CREATE INDEX NR_SRC_STORIES_WIK_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (EVENT_RECORD_UUID, ENTRY_ID);

GO


CREATE INDEX NR_SRC_STORIES_PRF_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_HP_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_HP (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_DGR_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_FILE_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_FRM_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_FRM (EVENT_RECORD_UUID, ENTRY_ID);

GO
    
CREATE INDEX NR_SRC_STORIES_EXT_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (EVENT_RECORD_UUID, ENTRY_ID);

GO

------------------------------------------------------
--[END]: perf defect 40892 
------------------------------------------------------

---------------------------------------------------------------
-- Add the flag SCOPE to story table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT ADD SCOPE NUMERIC(5,0);
   
GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM ADD SCOPE NUMERIC(5,0);

GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK ADD SCOPE NUMERIC(5,0);

GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF  ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP  ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR  ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE  ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM  ADD SCOPE NUMERIC(5,0);

GO
    
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  ADD SCOPE NUMERIC(5,0); 

GO

-----------------------------------------------------
-- Renaming existing index
-----------------------------------------------------
DROP INDEX HP_UI_UNQ ON HOMEPAGE.HP_UI;

GO

CREATE UNIQUE INDEX HP_UI_PERSONID
	ON HOMEPAGE.HP_UI (PERSON_ID);
	
GO	

--------------------------------------------------------
-- Adding an index on EMD_EMAIL_PREFS TRANCHE_ID
--------------------------------------------------------
CREATE INDEX EMD_EMAIL_PREFS_TR
    ON HOMEPAGE.EMD_EMAIL_PREFS (TRANCHE_ID);
    
GO

----------------------------------------------------------
-- drop not null constraint
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ALTER COLUMN ITEM_ID nvarchar(36);

GO

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ALTER COLUMN ITEM_ID nvarchar(36);


GO

--------------------------------------------
-- Add IS_GADGET 
--------------------------------------------
ALTER TABLE HOMEPAGE.WIDGET ADD IS_GADGET NUMERIC(5,0) DEFAULT 0;

GO


UPDATE HOMEPAGE.WIDGET SET IS_GADGET = 0;

----------------------------------------------------
-- Adding OPERATION_ID to NR_ACTIONABLE_READERS
----------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD OPERATION_ID nvarchar(512);
   
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 95
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------
-- Drop table NR_SORUCE_TYPE
------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SOURCE_TYPE;

------------------------------------------------
-- NR_SOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0) NOT NULL, -- numeric that is 1,2,3 etc.. 100, 101..
	SOURCE nvarchar(36) NOT NULL,
	DISPLAY_NAME nvarchar(4000),
	IMAGE_URL nvarchar(2048),
	PUBLISHED DATETIME,
	UPDATED DATETIME,	
	IS_ENABLED NUMERIC(5,0),
	SUMMARY nvarchar (4000),
	ORGANIZATION_ID nvarchar(36),
	URL nvarchar(2048),
	URL_SSL nvarchar(2048)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD CONSTRAINT PK_SRC_TYPE_ID PRIMARY KEY(SOURCE_TYPE_ID);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNQ UNIQUE(SOURCE_TYPE);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_UNQ UNIQUE(SOURCE);
	
GO

------------
--- START INSERT NR_SOURCE_TYPE
------------
-- TODO find the right image url

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'activities', 'activities', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'blogs', 'blogs', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBlogs16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'communities', 'communities', '${connections}/resources/web/com.ibm.lconn.core.styles/images//iconCommunities16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'wikis', 'wikis', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconWikis16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'profiles', 'profiles', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'homepage', 'homepage', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconHome16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'dogear', 'dogear', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'files', 'files', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconFiles16.png', null, null, 1, null, 'default');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'forums', 'forums', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconForums16.png', null, null, 1, null, 'default');

------------
--- END INSERT NR_SOURCE_TYPE
------------

GO

--------------------------------------------
-- 48536 Remove unique index 
--------------------------------------------
DROP INDEX NR_TAGS_READER_STORY ON HOMEPAGE.NR_TAGS_READERS;

CREATE INDEX NR_TAGS_READER_STORY 		
	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID);
	

GO	

----------------------------------------------
-- start 48424 Create an index to speed up rollup retrievial
----------------------------------------------
CREATE INDEX NR_AGGREGATED_READERS_ROLL
	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO	

CREATE INDEX NR_RESPONSES_READERS_ROLL
	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_PROFILES_READERS_ROLL
	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_COMMUNITIES_READERS_ROLL
	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_ACTIVITIES_READERS_ROLL
	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_BLOGS_READERS_ROLL
	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_BOOKMARKS_READERS_ROLL
	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_FILES_READERS_ROLL
	ON HOMEPAGE.NR_FILES_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_FORUMS_READERS_ROLL
	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_WIKIS_READERS_ROLL
	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_TAGS_READERS_ROLL
	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_STATUS_UPDATE_READERS_ROLL
	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_EXTERNAL_READERS_ROLL
	ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_ACTIONABLE_READERS_ROLL
	ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_DISCOVERY_VIEW_ROLL 
	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

CREATE INDEX NR_PROFILES_VIEW_ROLL 
	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);	

GO	

----------------------------------------------
-- end 48424 Create an index to speed up rollup retrievial
----------------------------------------------

--------------------------------------------------
-- Add a pk to DELETED_STORIES_QUEUE
--------------------------------------------------
---------------------------------------------------------------------------------
-- ADDING QUARANTINE TABLE
---------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.DELETED_STORIES_QUEUE; 

CREATE TABLE HOMEPAGE.DELETED_STORIES_QUEUE (
	QUEUE_ID nvarchar(36) NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE 	nvarchar(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMERIC(5,0) NOT NULL,
	STATUS NUMERIC(5,0) DEFAULT 0 NOT NULL	
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE 
  	ADD CONSTRAINT PK_QUARANTINE PRIMARY KEY(QUEUE_ID);

CREATE INDEX DELETED_STORY_ID 
  	ON HOMEPAGE.DELETED_STORIES_QUEUE (STORY_ID);

GO

--------------------------------------------------------------------------
-- start: Adding unique index to the ITEM_ID field in all the NR_ENTRIES_XXX table LL 3.5 T5 (68821)
--------------------------------------------------------------------------
-- remove duplicated records wit dups item_id

--NR_ENTRIES_ACT
DELETE FROM HOMEPAGE.NR_SRC_STORIES_ACT WHERE ENTRY_ID IN (
	select NR_ENTRIES_ACT.ENTRY_ID
		from (
			SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
			FROM HOMEPAGE.NR_ENTRIES_ACT
			GROUP BY 	ITEM_ID
			) T,
			 HOMEPAGE.NR_ENTRIES_ACT NR_ENTRIES_ACT
		where 	NR_ENTRIES_ACT.ENTRY_ID < T.ENTRY_ID AND 
				NR_ENTRIES_ACT.ITEM_ID = T.ITEM_ID
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_ACT WHERE ENTRY_ID IN (
	select NR_ENTRIES_ACT.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_ACT
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_ACT NR_ENTRIES_ACT
	where 	NR_ENTRIES_ACT.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_ACT.ITEM_ID = T.ITEM_ID	
);

go

CREATE UNIQUE INDEX NR_ENTRIES_ACT_ITEM
    ON HOMEPAGE.NR_ENTRIES_ACT (ITEM_ID);

go

--NR_ENTRIES_BLG_ITEM
DELETE FROM HOMEPAGE.NR_SRC_STORIES_BLG WHERE ENTRY_ID IN (
	select NR_ENTRIES_BLG.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_BLG
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_BLG NR_ENTRIES_BLG
	where 	NR_ENTRIES_BLG.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_BLG.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_BLG WHERE ENTRY_ID IN (
	select NR_ENTRIES_BLG.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_BLG
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_BLG NR_ENTRIES_BLG
	where 	NR_ENTRIES_BLG.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_BLG.ITEM_ID = T.ITEM_ID	
);

go

CREATE UNIQUE INDEX NR_ENTRIES_BLG_ITEM
    ON HOMEPAGE.NR_ENTRIES_BLG (ITEM_ID);

go

--NR_ENTRIES_COM_ITEM
DELETE FROM HOMEPAGE.NR_SRC_STORIES_COM WHERE ENTRY_ID IN (
	select NR_ENTRIES_COM.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_COM
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_COM NR_ENTRIES_COM
	where 	NR_ENTRIES_COM.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_COM.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_COM WHERE ENTRY_ID IN (
	select NR_ENTRIES_COM.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_COM
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_COM NR_ENTRIES_COM
	where 	NR_ENTRIES_COM.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_COM.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_COM_ITEM
    ON HOMEPAGE.NR_ENTRIES_COM (ITEM_ID);

go

--NR_ENTRIES_WIK
DELETE FROM HOMEPAGE.NR_SRC_STORIES_WIK WHERE ENTRY_ID IN (
	select NR_ENTRIES_WIK.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_WIK
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_WIK NR_ENTRIES_WIK
	where 	NR_ENTRIES_WIK.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_WIK.ITEM_ID = T.ITEM_ID		
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_WIK WHERE ENTRY_ID IN (
	select NR_ENTRIES_WIK.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_WIK
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_WIK NR_ENTRIES_WIK
	where 	NR_ENTRIES_WIK.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_WIK.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_WIK_ITEM
    ON HOMEPAGE.NR_ENTRIES_WIK (ITEM_ID);

go

--NR_ENTRIES_PRF
DELETE FROM HOMEPAGE.NR_SRC_STORIES_PRF WHERE ENTRY_ID IN (
	select NR_ENTRIES_PRF.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_PRF
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_PRF NR_ENTRIES_PRF
	where 	NR_ENTRIES_PRF.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_PRF.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_PRF WHERE ENTRY_ID IN (
	select NR_ENTRIES_PRF.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_PRF
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_PRF NR_ENTRIES_PRF
	where 	NR_ENTRIES_PRF.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_PRF.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_PRF_ITEM
    ON HOMEPAGE.NR_ENTRIES_PRF (ITEM_ID);

go

--NR_ENTRIES_HP
DELETE FROM HOMEPAGE.NR_SRC_STORIES_HP WHERE ENTRY_ID IN (
	select NR_ENTRIES_HP.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_HP
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_HP NR_ENTRIES_HP
	where 	NR_ENTRIES_HP.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_HP.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_HP WHERE ENTRY_ID IN (
	select NR_ENTRIES_HP.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_HP
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_HP NR_ENTRIES_HP
	where 	NR_ENTRIES_HP.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_HP.ITEM_ID = T.ITEM_ID	
);

go

CREATE UNIQUE INDEX NR_ENTRIES_HP_ITEM
    ON HOMEPAGE.NR_ENTRIES_HP (ITEM_ID);

go

--NR_ENTRIES_DGR
DELETE FROM HOMEPAGE.NR_SRC_STORIES_DGR WHERE ENTRY_ID IN (
	select NR_ENTRIES_DGR.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_DGR
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_DGR NR_ENTRIES_DGR
	where 	NR_ENTRIES_DGR.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_DGR.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_DGR WHERE ENTRY_ID IN (
	select NR_ENTRIES_DGR.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_DGR
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_DGR NR_ENTRIES_DGR
	where 	NR_ENTRIES_DGR.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_DGR.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_DGR_ITEM
    ON HOMEPAGE.NR_ENTRIES_DGR (ITEM_ID);

go

--NR_ENTRIES_FILE
DELETE FROM HOMEPAGE.NR_SRC_STORIES_FILE WHERE ENTRY_ID IN (
	select NR_ENTRIES_FILE.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_FILE
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_FILE NR_ENTRIES_FILE
	where 	NR_ENTRIES_FILE.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_FILE.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_FILE WHERE ENTRY_ID IN (
	select NR_ENTRIES_FILE.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_FILE
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_FILE NR_ENTRIES_FILE
	where 	NR_ENTRIES_FILE.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_FILE.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_FILE_ITEM
    ON HOMEPAGE.NR_ENTRIES_FILE (ITEM_ID);

go

--NR_ENTRIES_FRM
DELETE FROM HOMEPAGE.NR_SRC_STORIES_FRM WHERE ENTRY_ID IN (
	select NR_ENTRIES_FRM.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_FRM
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_FRM NR_ENTRIES_FRM
	where 	NR_ENTRIES_FRM.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_FRM.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_FRM WHERE ENTRY_ID IN (
	select NR_ENTRIES_FRM.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_FRM
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_FRM NR_ENTRIES_FRM
	where 	NR_ENTRIES_FRM.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_FRM.ITEM_ID = T.ITEM_ID	
);

go


CREATE UNIQUE INDEX NR_ENTRIES_FRM_ITEM
    ON HOMEPAGE.NR_ENTRIES_FRM (ITEM_ID);

go

--NR_ENTRIES_EXTERNAL
DELETE FROM HOMEPAGE.NR_SRC_STORIES_EXTERNAL WHERE ENTRY_ID IN (
	select NR_ENTRIES_EXTERNAL.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_EXTERNAL
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_EXTERNAL NR_ENTRIES_EXTERNAL
	where 	NR_ENTRIES_EXTERNAL.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_EXTERNAL.ITEM_ID = T.ITEM_ID	
);

GO

DELETE FROM HOMEPAGE.NR_ENTRIES_EXTERNAL WHERE ENTRY_ID IN (
	select NR_ENTRIES_EXTERNAL.ENTRY_ID
	from (
		SELECT MAX(ENTRY_ID) ENTRY_ID, ITEM_ID
		FROM HOMEPAGE.NR_ENTRIES_EXTERNAL
		GROUP BY 	ITEM_ID
		) T,
		 HOMEPAGE.NR_ENTRIES_EXTERNAL NR_ENTRIES_EXTERNAL
	where 	NR_ENTRIES_EXTERNAL.ENTRY_ID < T.ENTRY_ID AND 
			NR_ENTRIES_EXTERNAL.ITEM_ID = T.ITEM_ID	
);

go
    
CREATE UNIQUE INDEX NR_ENTRIES_EXT_ITEM
    ON HOMEPAGE.NR_ENTRIES_EXTERNAL (ITEM_ID);

go
--------------------------------------------------------------------------
-- end: Adding index to the ITEM_ID field in all the NR_ENTRIES_XXX table LL 3.5 T5 (68821)
--------------------------------------------------------------------------


----------------------------------------------------------------
-- Adding NOTIFICATION SENT table
----------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('notification-sent', 19, '%notification-sent', 'notification-sent');

--------------------------------------------------------------------------
-- 19 HOMEPAGE.NR_NOTIFICATION_SENT_READERS
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NOTIFICATION_SENT_READERS (
	CATEGORY_READER_ID nvarchar(36)  DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME 	DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0),
	IS_BROADCAST NUMERIC(5,0),
	ORGANIZATION_ID nvarchar(36),
        CONSTRAINT   	CK_CAT19_TYPE
    			CHECK
    			(CATEGORY_TYPE = 19)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_NOTIFICATION_SENT_READERS 
    ADD CONSTRAINT PK_SENT_NOT_READ PRIMARY KEY(CATEGORY_READER_ID);

CREATE INDEX NOT_SENT_STORIES_IDX
    ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX NOT_SENT_STORIES_SIDX
    ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (STORY_ID);

CREATE INDEX NOT_SENT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ITEM_ID);

CREATE INDEX NOT_SENT_STORIES_DATE
    ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (CREATION_DATE ASC);

CREATE UNIQUE INDEX NR_NOT_SENT_READER_STORY 		
	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, STORY_ID);

CREATE INDEX NOT_SENT_STORIES_SRC_IDX
    ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
    
CREATE INDEX NOT_SENT_ROLL 
	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);    
    
GO


-------------------------------------------------------------------------------
-- [START] BOARD_ENTRIES and BOARD_COMMENTS
-------------------------------------------------------------------------------

-- BOARD_ENTRIES Remove HAS_ATTACHMENT from 
DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.BOARD_ENTRIES') and name like '%HAS%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.BOARD_ENTRIES DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD CONTENT_LOCALE  nvarchar(5);

GO


-- BOARD_COMMENTS Rename ITEM_CORRELATION_ID in ENTRY_ID
DROP TABLE HOMEPAGE.BOARD_COMMENTS;

GO

--------------------------------------
-- HOMEPAGE.BOARD_COMMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	ITEM_ID nvarchar(47),
	ENTRY_ID nvarchar(47),
	ITEM_URL nvarchar(2048),	
	CONTENT varbinary (MAX),
	UPDATE_DATE DATETIME,
	LAST_CONTRIBUTOR_ID nvarchar(36),
	CONTENT_LOCALE nvarchar(5),
	PUBLISHED_ORDER NUMERIC(5,0)
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_COM_ENTRY FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ENTRY_ID);

CREATE INDEX CREATION_DATE_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (CREATION_DATE ASC);
	
CREATE INDEX ITEM_CORR_CREATION_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (ENTRY_ID, CREATION_DATE ASC);
	
CREATE INDEX ITEM_ITEM_CORR_IDX
	ON HOMEPAGE.BOARD_COMMENTS (ITEM_ID ASC, ENTRY_ID ASC);	

CREATE UNIQUE INDEX BRD_COMM_ITEM_COR_PUB
    ON HOMEPAGE.BOARD_COMMENTS (ENTRY_ID, PUBLISHED_ORDER ASC);
	
GO

-------------------------------------------------------------------------------
-- [END] BOARD_ENTRIES and BOARD_COMMENTS
-------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------
-- start: Refactoring NR_SRC_STORIES_XXX and NR_ENTRIES_XXX 48151 table
---------------------------------------------------------------------
--Remove from STORIES table:
--ITEM_ATOM_URL as it is a duplicate of the same column in ENTRIES
--CONTAINER_ID as it is a duplicate of the same column in ENTRIES
--CONTAINER_NAME as it is a duplicate of the same column in ENTRIES
--CONTAINER_URL as it is a duplicate of the same column in ENTRIES
--ITEM_CORRELATION_ID
--ITEM_CORRELATION_NAME

--Also looks nice to remove from STORIES and add to ENTRIES table the item correlation information since it more item related then story:
--ITEM_CORRELATION_ID nvarchar(36)
--ITEM_CORRELATION_NAME nvarchar(256)
--TAGS nvarchar(1024) // TODO is already there?

---------------------------------------------------
-- [START] data lost fixing. Migrating LAST_DESC_COMMENT and PREV_DESC_COMMENT 
---------------------------------------------------

--1) NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_ACT SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_BLG SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_COM SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_WIK SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_PRF SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_HP SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_DGR SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_FILE SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_FRM SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO

--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL
	ADD	TMP_LAST_DESC_COMMENT nvarchar(4000),
	TMP_PREV_DESC_COMMENT nvarchar(4000);
GO

UPDATE HOMEPAGE.NR_ENTRIES_ACT SET TMP_LAST_DESC_COMMENT = LAST_DESC_COMMENT, TMP_PREV_DESC_COMMENT = PREV_DESC_COMMENT;
GO
	
---------------------------------------------------
-- [END]
---------------------------------------------------

------------------------------------------------------------
-- Removing from entries table:
-- PREV_RECOMMENDER_ID, LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,
-- BRIEF_DESC, N_ATTACHMENTS
------------------------------------------------------------

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_ACT') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_ACT
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;			
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_BLG') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_BLG			
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;			
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_COM') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_COM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_COM			
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;					
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_WIK') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_WIK			
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;					
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_PRF') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_PRF
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;								
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_HP') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_HP DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_HP			
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;			
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_DGR') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_DGR
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;								
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_FILE') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FILE	
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;					
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_FRM') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FRM			
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;			
GO

DECLARE @CONST_NAME as nvarchar(128), @DROP_STMT as nvarchar(2000)
SET @CONST_NAME = (select name from sys.default_constraints where parent_object_id=OBJECT_ID('HOMEPAGE.HOMEPAGE.NR_ENTRIES_EXTERNAL') and name like '%N_ATT%')
SET @DROP_STMT = N'ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL DROP CONSTRAINT ' + @CONST_NAME
EXEC (@DROP_STMT)
GO

ALTER TABLE 	HOMEPAGE.NR_ENTRIES_EXTERNAL	
	DROP COLUMN PREV_RECOMMENDER_ID,
	LAST_DESC_COMMENT,
	PREV_DESC_COMMENT,
	EVENT_TIME,
	LAST_RECOMMENDER_ID, 
	LAST_DATE_RECOMMENDER_ID, 
	PREV_DATE_RECOMMENDER_ID,
	BRIEF_DESC,
	MESSAGE,
	N_ATTACHMENTS;				
GO

------------------------------------------------------------
-- Adding ITEM_CORRELATION_ID and ITEM_CORRELATION_NAME
------------------------------------------------------------

--1) NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);
	
GO


--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);
GO



--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM 
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO



--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  
	ADD 
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256);	
GO


-------------------------------------------
-- Migrating them from STORIES table (ITEM_CORRELATION_ID)
--------------------------------------------
--1) NR_ENTRIES_ACT
UPDATE HOMEPAGE.NR_ENTRIES_ACT SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_ACT STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_ACT.ENTRY_ID = STORIES.ENTRY_ID  
);

GO 

--2) NR_ENTRIES_BLG
UPDATE HOMEPAGE.NR_ENTRIES_BLG SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_BLG STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_BLG.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--3) NR_ENTRIES_COM
UPDATE HOMEPAGE.NR_ENTRIES_COM SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_COM STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_COM.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--4) NR_ENTRIES_WIK
UPDATE HOMEPAGE.NR_ENTRIES_WIK SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_WIK STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_WIK.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--5) NR_ENTRIES_PRF
UPDATE HOMEPAGE.NR_ENTRIES_PRF SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_PRF STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_PRF.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--6) NR_ENTRIES_HP
UPDATE HOMEPAGE.NR_ENTRIES_HP SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_HP STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_HP.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--7) NR_ENTRIES_DGR
UPDATE HOMEPAGE.NR_ENTRIES_DGR SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_DGR STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_DGR.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--8) NR_ENTRIES_FILE
UPDATE HOMEPAGE.NR_ENTRIES_FILE SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_FILE STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_FILE.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--9) NR_ENTRIES_FRM
UPDATE HOMEPAGE.NR_ENTRIES_FRM SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_FRM STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_FRM.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--10) NR_ENTRIES_EXTERNAL
UPDATE HOMEPAGE.NR_ENTRIES_EXTERNAL SET ITEM_CORRELATION_ID = (
	SELECT DISTINCT ITEM_CORRELATION_ID
	FROM HOMEPAGE.NR_SRC_STORIES_EXTERNAL STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_EXTERNAL.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

-------------------------------------------
-- Migrating them from STORIES table (ITEM_CORRELATION_NAME)
--------------------------------------------
--1) NR_ENTRIES_ACT
UPDATE HOMEPAGE.NR_ENTRIES_ACT SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_ACT STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_ACT.ENTRY_ID = STORIES.ENTRY_ID  
);

GO 

--2) NR_ENTRIES_BLG
UPDATE HOMEPAGE.NR_ENTRIES_BLG SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_BLG STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_BLG.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--3) NR_ENTRIES_COM
UPDATE HOMEPAGE.NR_ENTRIES_COM SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_COM STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_COM.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--4) NR_ENTRIES_WIK
UPDATE HOMEPAGE.NR_ENTRIES_WIK SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_WIK STORIES 
	WHERE  HOMEPAGE.NR_ENTRIES_WIK.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--5) NR_ENTRIES_PRF
UPDATE HOMEPAGE.NR_ENTRIES_PRF SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_PRF STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_PRF.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--6) NR_ENTRIES_HP
UPDATE HOMEPAGE.NR_ENTRIES_HP SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_HP STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_HP.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--7) NR_ENTRIES_DGR
UPDATE HOMEPAGE.NR_ENTRIES_DGR SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_DGR STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_DGR.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--8) NR_ENTRIES_FILE
UPDATE HOMEPAGE.NR_ENTRIES_FILE SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_FILE STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_FILE.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--9) NR_ENTRIES_FRM
UPDATE HOMEPAGE.NR_ENTRIES_FRM SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_FRM STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_FRM.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

--10) NR_ENTRIES_EXTERNAL
UPDATE HOMEPAGE.NR_ENTRIES_EXTERNAL SET ITEM_CORRELATION_NAME = (
	SELECT DISTINCT ITEM_CORRELATION_NAME
	FROM HOMEPAGE.NR_SRC_STORIES_EXTERNAL STORIES 
	WHERE HOMEPAGE.NR_ENTRIES_EXTERNAL.ENTRY_ID = STORIES.ENTRY_ID  
);

GO

-----------------------------------------------------------------------
-- RENAME : TAGS => ITEM_TAGS, SCOPE => ITEM_SCOPE, CREATION_DATE => ITEM_CREATION_DATE, UPDATE_DATE => ITEM_UPDATE_DATE
-----------------------------------------------------------------------
--1) NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;
GO


--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;		
GO


--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;	
GO


--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;		
GO


--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;			
GO


--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;			
GO


--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;		
GO


--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;			
GO



--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM 
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;			
GO



--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  
	ADD 
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	ITEM_TAGS nvarchar (1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_CREATION_DATE DATETIME,
	ITEM_UPDATE_DATE DATETIME;			
GO



UPDATE HOMEPAGE.NR_ENTRIES_ACT SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_BLG SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_COM SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_WIK SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_PRF SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_HP SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_DGR SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_FILE SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_FRM SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO
UPDATE HOMEPAGE.NR_ENTRIES_EXTERNAL SET ITEM_TAGS = TAGS, ITEM_SCOPE = SCOPE, ITEM_UPDATE_DATE = UPDATE_DATE, ITEM_CREATION_DATE = CREATION_DATE, LAST_DESC_COMMENT = TMP_LAST_DESC_COMMENT, PREV_DESC_COMMENT = TMP_PREV_DESC_COMMENT;
GO

-- Prefix becuase there is an index on CREATION_DATE
DROP INDEX SRC_STORIES_EXT_DATE ON HOMEPAGE.NR_ENTRIES_EXTERNAL;
GO

--1) NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;	
GO



--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;	
GO



--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;		
GO


--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;		
GO


--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;	
GO

--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;		
GO


--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;		
GO


--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;		
GO



--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM 
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;	
GO


--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  
	DROP COLUMN TAGS,
	TMP_LAST_DESC_COMMENT,
	TMP_PREV_DESC_COMMENT,
	SCOPE,
	UPDATE_DATE,
	CREATION_DATE;			
GO


---------------------------------------------
-- DROP FROM STORIES TABLE UNUSED COLUMNS
---------------------------------------------
--MESSAGE

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			
	DROP COLUMN SCOPE,
	MESSAGE;		
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE	
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	
	DROP COLUMN SCOPE,
	MESSAGE;			
GO

-- Adding: ITEM_TAGS, ITEM_SCOPE, ITEM_UPDATE_DATE, ITEM_ID, ITEM_NAME, ITEM_URL	
-- Adding: NUM_RECIPIENTS, FIRST_RECIPIENT_ID, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL (to support notification stories)
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);		
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);				
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);				
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);				
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);							
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);		
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);							
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE	
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);					
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);				
GO

ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	
	ADD ITEM_TAGS nvarchar(1024),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024);		
GO

-----------------------------------------------------------
-- Increase to be 4000 the brief desc in the STORIES table
-----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT ALTER COLUMN BRIEF_DESC nvarchar(2048);		
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG ALTER COLUMN BRIEF_DESC nvarchar(2048);			
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM ALTER COLUMN BRIEF_DESC nvarchar(2048);			
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK ALTER COLUMN BRIEF_DESC nvarchar(2048);		
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF ALTER COLUMN BRIEF_DESC nvarchar(2048);					
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP ALTER COLUMN BRIEF_DESC nvarchar(2048);	
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR ALTER COLUMN BRIEF_DESC nvarchar(2048);				
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE ALTER COLUMN BRIEF_DESC nvarchar(2048);				
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM ALTER COLUMN BRIEF_DESC nvarchar(2048);		
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL ALTER COLUMN BRIEF_DESC nvarchar(2048);	
GO

---------------------------------------------------------------
-- Populate: (ITEM_TAGS, ITEM_SCOPE, ITEM_UPDATE_DATE, ITEM_ID, ITEM_NAME, ITEM_URL)
---------------------------------------------------------------


--  [start] HOMEPAGE.NR_SRC_STORIES_ACT
UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_ACT.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_ACT  inner join HOMEPAGE.NR_ENTRIES_ACT ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_ACT.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_ACT.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_ACT

--  [start] HOMEPAGE.NR_SRC_STORIES_BLG
UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_BLG.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_BLG  inner join HOMEPAGE.NR_ENTRIES_BLG ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_BLG.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_BLG.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_BLG

--  [start] HOMEPAGE.NR_SRC_STORIES_COM
UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_COM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_COM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_COM  inner join HOMEPAGE.NR_ENTRIES_COM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_COM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_COM.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_COM

--  [start] HOMEPAGE.NR_SRC_STORIES_DGR
UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_DGR.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_DGR  inner join HOMEPAGE.NR_ENTRIES_DGR ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_DGR.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_DGR.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_DGR

--  [start] HOMEPAGE.NR_SRC_STORIES_EXTERNAL
UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_EXTERNAL  inner join HOMEPAGE.NR_ENTRIES_EXTERNAL ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_EXTERNAL.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_EXTERNAL.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_EXTERNAL

--  [start] HOMEPAGE.NR_SRC_STORIES_FILE
UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FILE.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FILE  inner join HOMEPAGE.NR_ENTRIES_FILE ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FILE.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FILE.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_FILE

--  [start] HOMEPAGE.NR_SRC_STORIES_FRM
UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_FRM.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_FRM  inner join HOMEPAGE.NR_ENTRIES_FRM ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_FRM.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_FRM.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_FRM

--  [start] HOMEPAGE.NR_SRC_STORIES_HP
UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_HP  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_HP.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_HP  inner join HOMEPAGE.NR_ENTRIES_HP ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_HP.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_HP.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_HP

--  [start] HOMEPAGE.NR_SRC_STORIES_PRF
UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_PRF.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_PRF  inner join HOMEPAGE.NR_ENTRIES_PRF ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_PRF.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_PRF.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_PRF

--  [start] HOMEPAGE.NR_SRC_STORIES_WIK
UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '0..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '0..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '1..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '1..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '2..f' ;
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '2..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '3..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '3..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '4..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '4..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '5..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '5..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '6..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '6..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '7..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '7..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '8..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '8..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < '9..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= '9..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'a..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'a..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'b..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'b..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'c..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'c..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'd..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'd..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'e..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'e..f' AND HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID < 'f..f';
GO

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK  
 	SET 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_TAGS = ENTRIES.ITEM_TAGS, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_SCOPE = ENTRIES.ITEM_SCOPE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_UPDATE_DATE = ENTRIES.ITEM_UPDATE_DATE, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_ID = ENTRIES.ITEM_ID, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_NAME = ENTRIES.ITEM_NAME, 
		 HOMEPAGE.NR_SRC_STORIES_WIK.ITEM_URL = ENTRIES.ITEM_URL 
	FROM 	 HOMEPAGE.NR_SRC_STORIES_WIK  inner join HOMEPAGE.NR_ENTRIES_WIK ENTRIES 
		 ON ENTRIES.ENTRY_ID = HOMEPAGE.NR_SRC_STORIES_WIK.ENTRY_ID AND   HOMEPAGE.NR_SRC_STORIES_WIK.STORY_ID >= 'f..f';
GO

--  [end] HOMEPAGE.NR_SRC_STORIES_WIK


  
----------------------------------------------------
-- Fixing a wrong index
-----------------------------------------------------
--DROP INDEX HOMEPAGE.SRC_STORIES_EXT_DATE;

CREATE INDEX SRC_STORIES_EXT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CREATION_DATE DESC);

GO

-------------------------------------------------------------------------------------
-- INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
-- VALUES ('status_update_x8b0bx51af2ddef2cd', 11, '%status_updates', 'status_updates');
-------------------------------------------------------------------------------------
UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET 
	CATEGORY_TYPE_NAME = '%status_updates', 
	CATEGORY_TYPE_DESC = 'status_updates'
WHERE CATEGORY_TYPE=11;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 96
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------
-- Add a column in the SOURCE_TYPE table storing the 
---------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
	ADD IMAGE_URL_SSL nvarchar(2048);
GO


DELETE FROM HOMEPAGE.NR_SOURCE_TYPE;

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'activities', 'activities', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'blogs', 'blogs', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBlogs16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'communities', 'communities', '${connections}/resources/web/com.ibm.lconn.core.styles/images//iconCommunities16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'wikis', 'wikis', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconWikis16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'profiles', 'profiles', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconProfiles16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'homepage', 'homepage', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconHome16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'dogear', 'dogear', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconBookmarks16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'files', 'files', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconFiles16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY, ORGANIZATION_ID, IMAGE_URL_SSL)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'forums', 'forums', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconForums16.png', null, null, 1, null, 'default', '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconActivities16.png');

GO

---------------------------------------------------------------------
-- Add the following columns  in stories and entries tables
---------------------------------------------------------------------
--* ITEM_AUTHOR_UUID nvarchar 36
--* ITEM_AUTHOR_DISPLAYNAME nvarchar 256
--* ITEM_CORRELATION_AUTHOR_UUID nvarchar 36
--* ITEM_CORRELATION_AUTHOR_NAME nvarchar 256

-- [ENTRIES]

--1) NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
	;
GO



--2) NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--3) NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--4) NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--5) NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--6) NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--7) NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--8) NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--9) NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


--10) NR_ENTRIES_EXTERNAL
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL
	ADD ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000);
GO


-- [STORIES]



----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
--	META_TEMPLATE -> reduce to 3328
--	R_META_TEMPLATE -> reduce to  3328

--	PRIMARY_ACTION_URL -> reduce to 768 
--	SECONDARY_ACTION_URL -> reduce to 768 

--	ACTIVITY_META_DATA_1 -> reduce to 3584
--	ACTIVITY_META_DATA_2 -> reduce to 3584


------------------------------
-- i) COMMIT all the work
-- ii) enable xp_cmdshell
-----------------------------
COMMIT;


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE

---------------------------------
-- Move the data
---------------------------------


-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_ACT *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_ACT
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_ACT;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_ACT (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
	CONSTRAINT   	CK_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
    ADD CONSTRAINT PK_ACT_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);    

CREATE INDEX NR_SRC_STORIES_ACT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_ACT(CREATION_DATE DESC);

CREATE INDEX SRC_ACT_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (CONTAINER_ID);

CREATE INDEX SRC_ACT_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_ACT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ENTRY_ID);
    
CREATE INDEX  NR_SRC_STORIES_ACT_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (EVENT_RECORD_UUID, ENTRY_ID);

GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME	
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_ACT' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_ACT *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_BLG *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_BLG
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_BLG;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_BLG (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
    ADD CONSTRAINT PK_BLG_STORY_ID PRIMARY KEY (STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID);  
	
CREATE INDEX NR_SRC_STORIES_BLG_DATE
	ON HOMEPAGE.NR_SRC_STORIES_BLG(CREATION_DATE DESC);

CREATE INDEX SRC_BLG_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (CONTAINER_ID);

CREATE INDEX SRC_BLG_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_BLG_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_BLG_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (EVENT_RECORD_UUID, ENTRY_ID);  

GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME	
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_BLG' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_BLG *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_COM *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_COM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_COM;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_COM (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
    ADD CONSTRAINT PK_COM_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);
	
CREATE INDEX NR_SRC_STORIES_COM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_COM (CREATION_DATE DESC);

CREATE INDEX SRC_COM_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (CONTAINER_ID);

CREATE INDEX SRC_COM_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_COM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (ENTRY_ID);

CREATE INDEX NR_SRC_STORIES_COM_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_COM (EVENT_RECORD_UUID, ENTRY_ID);

GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME	
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_COM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_COM *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_WIK *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_WIK
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_WIK;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_WIK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_WIK (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
    ADD CONSTRAINT PK_WIK_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID);
	
CREATE INDEX NR_SRC_STORIES_WIK_DATE
	ON HOMEPAGE.NR_SRC_STORIES_WIK(CREATION_DATE DESC);

CREATE INDEX SRC_WIK_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (CONTAINER_ID);

CREATE INDEX SRC_WIK_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_WIK_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ENTRY_ID);    

CREATE INDEX NR_SRC_STORIES_WIK_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (EVENT_RECORD_UUID, ENTRY_ID);
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_WIK' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_WIK *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_PRF *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_PRF
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_PRF;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_PRF
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_PRF (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
    ADD CONSTRAINT PK_PRF_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);     

CREATE INDEX NR_SRC_STORIES_PRF_DATE
	ON HOMEPAGE.NR_SRC_STORIES_PRF(CREATION_DATE DESC);

CREATE INDEX SRC_PRF_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (CONTAINER_ID);

CREATE INDEX SRC_PRF_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_PRF_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_PRF_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (EVENT_RECORD_UUID, ENTRY_ID); 
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_PRF' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_PRF *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_HP *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_HP
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_HP;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_HP
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_HP (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
    ADD CONSTRAINT PK_HP_STORY_ID PRIMARY KEY (STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID);
	
CREATE INDEX NR_SRC_STORIES_HP_DATE
	ON HOMEPAGE.NR_SRC_STORIES_HP(CREATION_DATE DESC);

CREATE INDEX SRC_HP_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (CONTAINER_ID);

CREATE INDEX SRC_HP_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_HP_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_HP_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_HP (EVENT_RECORD_UUID, ENTRY_ID); 
    
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_HP' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_HP *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_DGR *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_DGR
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_DGR;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_DGR
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_DGR (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
    ADD CONSTRAINT PK_DGR_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID);     

CREATE INDEX NR_SRC_STORIES_DGR_DATE
	ON HOMEPAGE.NR_SRC_STORIES_DGR(CREATION_DATE DESC);

CREATE INDEX SRC_DGR_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (CONTAINER_ID);

CREATE INDEX SRC_DGR_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_DGR_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_DGR_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (EVENT_RECORD_UUID, ENTRY_ID); 
    
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_DGR' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_DGR *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_FILE *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_FILE
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_FILE;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_FILE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FILE (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
    ADD CONSTRAINT PK_FILE_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);
	
CREATE INDEX NR_SRC_STORIES_FILE_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FILE(CREATION_DATE DESC);

CREATE INDEX SRC_FILE_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (CONTAINER_ID);

CREATE INDEX SRC_FILE_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_FILE_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_FILE_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (EVENT_RECORD_UUID, ENTRY_ID);  
    
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FILE' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_FILE *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_FRM *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_FRM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_FRM;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_FRM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FRM  (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 
    ADD CONSTRAINT PK_FRM_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID); 
	
CREATE INDEX NR_SRC_STORIES_FRM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FRM (CREATION_DATE DESC);

CREATE INDEX SRC_FRM_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (CONTAINER_ID);

CREATE INDEX SRC_FRM_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_CORRELATION_ID);

CREATE INDEX NR_SRC_STORIES_FRM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_FRM_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_FRM (EVENT_RECORD_UUID, ENTRY_ID);  
    
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_FRM' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_FRM *********************
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_EXTERNAL *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

-- back up
CREATE TABLE HOMEPAGE.TMP_SRC (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(1536),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(4000),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(4000),
	ACTIVITY_META_DATA_2 nvarchar(4000),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(1024), 
	SECONDARY_ACTION_URL nvarchar(1024),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),	
) ON [PRIMARY]
GO

--set integrity for HOMEPAGE.TMP_SRC all immediate unchecked; 
--reorg table HOMEPAGE.TMP_SRC;

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	from HOMEPAGE.NR_SRC_STORIES_EXTERNAL
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.TMP_SRC' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL;
GO

COMMIT;

BEGIN TRANSACTION
GO

-- restoring
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_EXTERNAL
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	CONSTRAINT   	CK_SRC100_TYPE
    				CHECK
    				(SOURCE_TYPE >= 100)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
    ADD CONSTRAINT PK_EXT_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
  	ADD CONSTRAINT FK_ENTRY_ID_EXT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_EXTERNAL (ENTRY_ID);    

CREATE INDEX SRC_STORIES_EXT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CREATION_DATE DESC);

CREATE INDEX SRC_EXT_CONTAINER_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CONTAINER_ID);

CREATE INDEX SRC_EXT_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ITEM_CORRELATION_ID);
    
CREATE INDEX SRC_STORIES_EXT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ENTRY_ID);
    
CREATE INDEX NR_SRC_STORIES_EXT_ER_UUID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (EVENT_RECORD_UUID, ENTRY_ID);  
    
GO    

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	select 	
			STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
			ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE,
			TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT,
			SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED,
			ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL,
			' ' ITEM_AUTHOR_UUID, ' ' ITEM_AUTHOR_DISPLAYNAME, ' ' ITEM_CORRELATION_AUTHOR_UUID, ' ' ITEM_CORRELATION_AUTHOR_NAME
	FROM 	HOMEPAGE.TMP_SRC
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SRC_STORIES_EXTERNAL' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

DROP TABLE HOMEPAGE.TMP_SRC;
GO

COMMIT;
-----------------------------------------------------------------------
-- [end] ************ HOMEPAGE.NR_SRC_STORIES_EXTERNAL *********************
-----------------------------------------------------------------------

----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------

BEGIN TRANSACTION
GO

--------------------------------------------------------------------
--------------------------------------------------------------------
-- [START] SAVED READERS TABLE
--------------------------------------------------------------------
--------------------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories
UPDATE HOMEPAGE.NR_CATEGORY_TYPE SET 
	CATEGORY_TYPE_ID = 'saved_readers',  
	CATEGORY_TYPE_NAME = '%saved_readers', 
	CATEGORY_TYPE_DESC = 'saved_readers'
	WHERE CATEGORY_TYPE = 13;
GO
	
CREATE TABLE HOMEPAGE.NR_SAVED_READERS (
	CATEGORY_READER_ID nvarchar(36)  DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36) NOT NULL,
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME DATETIME,
	NOTE_TEXT nvarchar(4000),
	NOTE_UPDATE_DATE DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0),
	IS_BROADCAST NUMERIC(5,0),
	ORGANIZATION_ID nvarchar(36),
	OPERATION_ID nvarchar(512),
	ACTOR_UUID nvarchar(36),
	CONSTRAINT   	CK_CAT_SAVED_TYPE
    				CHECK
    				(CATEGORY_TYPE = 13)	
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_SAVED_READERS 
    ADD CONSTRAINT PK_SAVED_READERS PRIMARY KEY (CATEGORY_READER_ID);
    
CREATE INDEX SAVED_READERS_STORIES_IDX
    ON HOMEPAGE.NR_SAVED_READERS (READER_ID, CREATION_DATE ASC);

CREATE INDEX SAVED_READERS_SIDX
    ON HOMEPAGE.NR_SAVED_READERS (STORY_ID);

CREATE INDEX SAVED_READERS_ITEM_ID
    ON HOMEPAGE.NR_SAVED_READERS (ITEM_ID);

CREATE UNIQUE INDEX SAVED_READERS_STORY
    ON HOMEPAGE.NR_SAVED_READERS (READER_ID, STORY_ID);

CREATE INDEX SAVED_READERS_IDX
    ON HOMEPAGE.NR_SAVED_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE);
    
CREATE INDEX SAVED_READERS_ROLL
	ON HOMEPAGE.NR_SAVED_READERS (READER_ID, ROLLUP_ENTRY_ID, CREATION_DATE DESC, USE_IN_ROLLUP);

GO

----------------------------------------------------------------------	
--	Move all the saved stories from actionable to SAVED_READERS
----------------------------------------------------------------------
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	SELECT 	CATEGORY_READER_ID,
			READER_ID, CATEGORY_TYPE, SOURCE, CONTAINER_ID, ITEM_ID, ROLLUP_ENTRY_ID, RESOURCE_TYPE, CREATION_DATE, STORY_ID, SOURCE_TYPE,
			USE_IN_ROLLUP, IS_NETWORK, IS_FOLLOWER, EVENT_TIME, NOTE_TEXT, NOTE_UPDATE_DATE, IS_STORY_COMM, IS_BROADCAST, ORGANIZATION_ID, OPERATION_ID
	FROM HOMEPAGE.NR_ACTIONABLE_READERS WHERE CATEGORY_TYPE = 13
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER
GO

------------------------------
-- i) COMMIT all the work
-- ii) enable xp_cmdshell
-----------------------------
COMMIT;


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE

---------------------------------
-- Move the data
---------------------------------

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_SAVED_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-----------------------------------
-- Disable xp_cmdshell
----------------------------------

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 0
RECONFIGURE

----------------------------------
-----------------------------------

BEGIN TRANSACTION
GO

DELETE FROM HOMEPAGE.NR_ACTIONABLE_READERS WHERE CATEGORY_TYPE = 13;
GO

-- Alter category type constraint in the NR_ACTIONABLE_READERS
ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS DROP CONSTRAINT CK_CAT_ACTION_TYPE;
GO

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD CONSTRAINT CK_CAT_ACTION_TYPE 
	CHECK (CATEGORY_TYPE >= 14 AND CATEGORY_TYPE <= 16);
GO


--------------------------------------------------------------------
--------------------------------------------------------------------
-- [END] SAVED READERS TABLE
--------------------------------------------------------------------
--------------------------------------------------------------------

----------------------------------------------------------------
----------------------------------------------------------------
-- [START] Adding ACTOR_UUID in READER tables
----------------------------------------------------------------
----------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_AGGREGATED_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_FILES_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_TAGS_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_DISCOVERY_VIEW ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_PROFILES_VIEW ADD ACTOR_UUID nvarchar(36);
GO

ALTER TABLE HOMEPAGE.NR_NOTIFICATION_SENT_READERS ADD ACTOR_UUID nvarchar(36);
GO
----------------------------------------------------------------
----------------------------------------------------------------
-- [END] Adding ACTOR_UUID in READER tables
----------------------------------------------------------------
----------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 97
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------------------------
--Update "profiles-wall-message" to "profiles-message-wall" in NR_BOARD table in a fixup (BOARD_TYPE column).
-----------------------------------------------------------------------------------------------------------------
UPDATE HOMEPAGE.BOARD SET BOARD_TYPE = 'profiles-message-wall' WHERE BOARD_TYPE = 'profiles-wall-message';
GO

-----------------------------------------------------------------------------------------------------------------
-- [start] Add an unique constraint on NR_NETWORK table
-----------------------------------------------------------------------------------------------------------------
DELETE FROM HOMEPAGE.NR_NETWORK WHERE NETWORK_ID IN (
	select NR_NETWORK.NETWORK_ID
	from (
		SELECT MAX(NETWORK_ID) NETWORK_ID, PERSON_ID, COLLEAGUE_ID 
		FROM HOMEPAGE.NR_NETWORK
		GROUP BY 	PERSON_ID, COLLEAGUE_ID
		) T,
		 HOMEPAGE.NR_NETWORK NR_NETWORK
	where 	NR_NETWORK.NETWORK_ID < T.NETWORK_ID AND 
			NR_NETWORK.PERSON_ID = T.PERSON_ID AND
			NR_NETWORK.COLLEAGUE_ID = T.COLLEAGUE_ID		
);

GO

DROP INDEX COLL_PERSON_IDX ON HOMEPAGE.NR_NETWORK;
GO

CREATE UNIQUE INDEX COLL_PERSON_IDX 
	ON HOMEPAGE.NR_NETWORK (COLLEAGUE_ID, PERSON_ID);
GO

-----------------------------------------------------------------------------------------------------------------
-- [end] Add an unique constraint on NR_NETWORK table
-----------------------------------------------------------------------------------------------------------------

------------------------------------------------------------
-- [start] NEWS dropping existing indexes
------------------------------------------------------------
DROP INDEX NR_AGGREGATED_READERS_IDX  ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGGREGATED_READERS_STORY_ID ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGGREGATED_READERS_ITEM_ID ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGGREGATED_READERS_DATE ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGG_READERS_UNQ ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGG_READERS  ON HOMEPAGE.NR_AGGREGATED_READERS;
DROP INDEX NR_AGGREGATED_READERS_ROLL ON HOMEPAGE.NR_AGGREGATED_READERS;
GO

DROP INDEX RESPONSES_STORIES_IDX ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX RESPONSES_STORIES_SIDX ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX RESPONSES_STORIES_ITEM_ID ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX NR_RESPONSES_STORIES_DATE  ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX NR_RESP_READER_STORY ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX RESPONSES_STORIES_SRC_IDX ON HOMEPAGE.NR_RESPONSES_READERS;
DROP INDEX NR_RESPONSES_READERS_ROLL ON HOMEPAGE.NR_RESPONSES_READERS;
GO

DROP INDEX PROFILES_STORIES_IDX ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX PROFILES_STORIES_SIDX ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX PROFILES_STORIES_ITEM_ID ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX NR_PROFILES_STORIES_DATE ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX PROFILES_STORIES_SRC_IDX ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX NR_PRO_READER_STORY ON HOMEPAGE.NR_PROFILES_READERS;
DROP INDEX NR_PROFILES_READERS_ROLL ON HOMEPAGE.NR_PROFILES_READERS;
GO

DROP INDEX COMMUNITIES_STORIES_IDX  ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX COMMUNITIES_STORIES_SIDX  ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX COMMUNITIES_STORIES_ITEM_ID  ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX NR_COMMUNITIES_STORIES_DATE   ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX NR_COM_READER_STORY  ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX COMMUNITIES_STORIES_SRC_IDX   ON HOMEPAGE.NR_COMMUNITIES_READERS;
DROP INDEX NR_COMMUNITIES_READERS_ROLL  ON HOMEPAGE.NR_COMMUNITIES_READERS;
GO

DROP INDEX ACTIVITIES_STORIES_IDX ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX ACTIVITIES_STORIES_SIDX ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX ACTIVITIES_STORIES_ITEM_ID ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX NR_ACTIVITIES_STORIES_DATE ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX NR_ACT_READER_STORY ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX ACTIVITIES_STORIES_SRC_IDX  ON HOMEPAGE.NR_ACTIVITIES_READERS;
DROP INDEX NR_ACTIVITIES_READERS_ROLL ON HOMEPAGE.NR_ACTIVITIES_READERS;
GO

DROP INDEX BLOGS_STORIES_IDX ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX BLOGS_STORIES_SIDX ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX BLOGS_STORIES_ITEM_ID ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX NR_BLOGS_STORIES_DATE ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX NR_BLG_READER_STORY ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX BLOGS_STORIES_SRC_IDX  ON HOMEPAGE.NR_BLOGS_READERS;
DROP INDEX NR_BLOGS_READERS_ROLL ON HOMEPAGE.NR_BLOGS_READERS;
GO

DROP INDEX BOOKMARKS_STORIES_IDX  ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX BOOKMARKS_STORIES_SIDX  ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX BOOKMARKS_STORIES_ITEM_ID  ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX NR_BOOKMARKS_STORIES_DATE  ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX NR_BOOK_READER_STORY  ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX BOOKMARKS_STORIES_SRC_IDX   ON HOMEPAGE.NR_BOOKMARKS_READERS;
DROP INDEX NR_BOOKMARKS_READERS_ROLL  ON HOMEPAGE.NR_BOOKMARKS_READERS;
GO

DROP INDEX FILES_STORIES_IDX  ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX FILES_STORIES_SIDX  ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX FILES_STORIES_ITEM_ID  ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX NR_FILES_STORIES_DATE  ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX NR_FILES_READER_STORY  ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX FILES_STORIES_SRC_IDX   ON HOMEPAGE.NR_FILES_READERS;
DROP INDEX NR_FILES_READERS_ROLL  ON HOMEPAGE.NR_FILES_READERS;
GO

DROP INDEX FORUMS_STORIES_IDX ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX FORUMS_STORIES_SIDX ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX FORUMS_STORIES_ITEM_ID ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX NR_FORUMS_STORIES_DATE ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX NR_FORUMS_READER_STORY ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX FORUMS_STORIES_SRC_IDX  ON HOMEPAGE.NR_FORUMS_READERS;
DROP INDEX NR_FORUMS_READERS_ROLL ON HOMEPAGE.NR_FORUMS_READERS;
GO

DROP INDEX WIKIS_STORIES_IDX ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX WIKIS_STORIES_SIDX ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX WIKIS_STORIES_ITEM_ID ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX NR_WIKIS_STORIES_DATE ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX NR_WIKIS_READER_STORY ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX WIKIS_STORIES_SRC_IDX ON HOMEPAGE.NR_WIKIS_READERS;
DROP INDEX NR_WIKIS_READERS_ROLL ON HOMEPAGE.NR_WIKIS_READERS;
GO

DROP INDEX TAGS_STORIES_IDX ON HOMEPAGE.NR_TAGS_READERS;
DROP INDEX TAGS_STORIES_SIDX ON HOMEPAGE.NR_TAGS_READERS;
DROP INDEX TAGS_STORIES_ITEM_ID ON HOMEPAGE.NR_TAGS_READERS;
DROP INDEX NR_TAGS_STORIES_DATE ON HOMEPAGE.NR_TAGS_READERS;
DROP INDEX NR_TAGS_READER_STORY  ON HOMEPAGE.NR_TAGS_READERS;		
DROP INDEX TAGS_STORIES_SRC_IDX ON HOMEPAGE.NR_TAGS_READERS;
DROP INDEX NR_TAGS_READERS_ROLL ON HOMEPAGE.NR_TAGS_READERS;
GO

DROP INDEX SU_STORIES_IDX  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
DROP INDEX SU_STORIES_SIDX  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
DROP INDEX SU_STORIES_ITEM_ID  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
DROP INDEX SU_STORIES_SRC_IDX  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
DROP INDEX SU_STORIES_READER_STORY  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
DROP INDEX NR_STATUS_UPDATE_READERS_ROLL  ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
GO

DROP INDEX EXT_STORIES_IDX ON HOMEPAGE.NR_EXTERNAL_READERS;
DROP INDEX EXT_STORIES_SIDX ON HOMEPAGE.NR_EXTERNAL_READERS;
DROP INDEX EXT_STORIES_ITEM_ID ON HOMEPAGE.NR_EXTERNAL_READERS; 
DROP INDEX EXT_STORIES_SRC_IDX ON HOMEPAGE.NR_EXTERNAL_READERS;
DROP INDEX EXT_STORIES_READER_STORY ON HOMEPAGE.NR_EXTERNAL_READERS;
DROP INDEX NR_EXTERNAL_READERS_ROLL ON HOMEPAGE.NR_EXTERNAL_READERS;
GO

DROP INDEX ACTION_READER_STORIES_IDX  ON HOMEPAGE.NR_ACTIONABLE_READERS;
DROP INDEX ACTION_READER_SIDX  ON HOMEPAGE.NR_ACTIONABLE_READERS;
DROP INDEX ACTION_READER_ITEM_ID  ON HOMEPAGE.NR_ACTIONABLE_READERS;
DROP INDEX ACTION_STORIES_SRC_IDX  ON HOMEPAGE.NR_ACTIONABLE_READERS;
DROP INDEX ACTION_READER_STORY  ON HOMEPAGE.NR_ACTIONABLE_READERS;
DROP INDEX NR_ACTIONABLE_READERS_ROLL  ON HOMEPAGE.NR_ACTIONABLE_READERS;
GO

DROP INDEX DISCOVERY_STORIES_IDX  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_SIDX  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_ITEM  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_STORIES_DATE  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_READER_STORY  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_STORIES_SRC_IDX  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX DISCOVERY_STORIES_COM_IDX  ON HOMEPAGE.NR_DISCOVERY_VIEW;
DROP INDEX NR_DISCOVERY_VIEW_ROLL   ON HOMEPAGE.NR_DISCOVERY_VIEW;
GO

DROP INDEX PROFILES_VIEW_IDX ON HOMEPAGE.NR_PROFILES_VIEW;
DROP INDEX PROFILES_SIDX ON HOMEPAGE.NR_PROFILES_VIEW;
DROP INDEX PROFILES_ITEM ON HOMEPAGE.NR_PROFILES_VIEW;
DROP INDEX PROFILES_STORIES_DATE ON HOMEPAGE.NR_PROFILES_VIEW;
DROP INDEX PROFILES_READER_STORY ON HOMEPAGE.NR_PROFILES_VIEW;
DROP INDEX NR_PROFILES_VIEW_ROLL  ON HOMEPAGE.NR_PROFILES_VIEW;
GO

DROP INDEX NOT_SENT_STORIES_IDX ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NOT_SENT_STORIES_SIDX ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NOT_SENT_STORIES_ITEM_ID ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NOT_SENT_STORIES_DATE ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NR_NOT_SENT_READER_STORY ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NOT_SENT_STORIES_SRC_IDX ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
DROP INDEX NOT_SENT_ROLL  ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
GO

DROP INDEX SAVED_READERS_STORIES_IDX ON HOMEPAGE.NR_SAVED_READERS;
DROP INDEX SAVED_READERS_SIDX ON HOMEPAGE.NR_SAVED_READERS;
DROP INDEX SAVED_READERS_ITEM_ID ON HOMEPAGE.NR_SAVED_READERS;
DROP INDEX SAVED_READERS_IDX ON HOMEPAGE.NR_SAVED_READERS;
DROP INDEX SAVED_READERS_STORY ON HOMEPAGE.NR_SAVED_READERS;
DROP INDEX SAVED_READERS_ROLL ON HOMEPAGE.NR_SAVED_READERS;
GO



------------------------------------------------------------
-- [end] NEWS dropping existing indexes
------------------------------------------------------------

------------------------------------------------------------
-- [start] NEWS replacing existing indexes
------------------------------------------------------------

--  [start indexes] NR_AGGREGATED_READERS
CREATE  INDEX AGGREGATED_READERS_STR_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (STORY_ID); 
GO

CREATE  INDEX AGGREGATED_READERS_ITM_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (ITEM_ID); 
GO

CREATE  INDEX AGGREGATED_READERS_CD_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX AGGREGATED_READERS_SRC_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX AGGREGATED_READERS_ACT_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX AGGREGATED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX AGGREGATED_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_AGGREGATED_READERS

--  [start indexes] NR_RESPONSES_READERS
CREATE  INDEX RESPONSES_READERS_STR_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (STORY_ID); 
GO

CREATE  INDEX RESPONSES_READERS_ITM_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (ITEM_ID); 
GO

CREATE  INDEX RESPONSES_READERS_CD_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX RESPONSES_READERS_SRC_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX RESPONSES_READERS_ACT_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX RESPONSES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX RESPONSES_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_RESPONSES_READERS

--  [start indexes] NR_PROFILES_READERS
CREATE  INDEX PROFILES_READERS_STR_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (STORY_ID); 
GO

CREATE  INDEX PROFILES_READERS_ITM_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (ITEM_ID); 
GO

CREATE  INDEX PROFILES_READERS_CD_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX PROFILES_READERS_SRC_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX PROFILES_READERS_ACT_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX PROFILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX PROFILES_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_PROFILES_READERS

--  [start indexes] NR_COMMUNITIES_READERS
CREATE  INDEX COMM_READERS_STR_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (STORY_ID); 
GO

CREATE  INDEX COMM_READERS_ITM_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (ITEM_ID); 
GO

CREATE  INDEX COMM_READERS_CD_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX COMM_READERS_SRC_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX COMM_READERS_ACT_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX COMM_READERS_RLL_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX COMM_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_COMMUNITIES_READERS

--  [start indexes] NR_ACTIVITIES_READERS
CREATE  INDEX ACTIVITIES_READERS_STR_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (STORY_ID); 
GO

CREATE  INDEX ACTIVITIES_READERS_ITM_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (ITEM_ID); 
GO

CREATE  INDEX ACTIVITIES_READERS_CD_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX ACTIVITIES_READERS_SRC_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX ACTIVITIES_READERS_ACT_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX ACTIVITIES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX ACTIVITIES_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_ACTIVITIES_READERS

--  [start indexes] NR_BLOGS_READERS
CREATE  INDEX BLOGS_READERS_STR_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (STORY_ID); 
GO

CREATE  INDEX BLOGS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (ITEM_ID); 
GO

CREATE  INDEX BLOGS_READERS_CD_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX BLOGS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX BLOGS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX BLOGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX BLOGS_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_BLOGS_READERS

--  [start indexes] NR_BOOKMARKS_READERS
CREATE  INDEX BOOKMARKS_READERS_STR_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (STORY_ID); 
GO

CREATE  INDEX BOOKMARKS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (ITEM_ID); 
GO

CREATE  INDEX BOOKMARKS_READERS_CD_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX BOOKMARKS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX BOOKMARKS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX BOOKMARKS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX BOOKMARKS_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_BOOKMARKS_READERS

--  [start indexes] NR_FILES_READERS
CREATE  INDEX FILES_READERS_STR_IX 
 	ON HOMEPAGE.NR_FILES_READERS (STORY_ID); 
GO

CREATE  INDEX FILES_READERS_ITM_IX 
 	ON HOMEPAGE.NR_FILES_READERS (ITEM_ID); 
GO

CREATE  INDEX FILES_READERS_CD_IX 
 	ON HOMEPAGE.NR_FILES_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX FILES_READERS_SRC_IX 
 	ON HOMEPAGE.NR_FILES_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX FILES_READERS_ACT_IX 
 	ON HOMEPAGE.NR_FILES_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX FILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FILES_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX FILES_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_FILES_READERS

--  [start indexes] NR_FORUMS_READERS
CREATE  INDEX FORUMS_READERS_STR_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (STORY_ID); 
GO

CREATE  INDEX FORUMS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (ITEM_ID); 
GO

CREATE  INDEX FORUMS_READERS_CD_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX FORUMS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX FORUMS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX FORUMS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX FORUMS_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_FORUMS_READERS

--  [start indexes] NR_WIKIS_READERS
CREATE  INDEX WIKIS_READERS_STR_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (STORY_ID); 
GO

CREATE  INDEX WIKIS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (ITEM_ID); 
GO

CREATE  INDEX WIKIS_READERS_CD_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX WIKIS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX WIKIS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX WIKIS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX WIKIS_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_WIKIS_READERS

--  [start indexes] NR_TAGS_READERS
CREATE  INDEX TAGS_READERS_STR_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (STORY_ID); 
GO

CREATE  INDEX TAGS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (ITEM_ID); 
GO

CREATE  INDEX TAGS_READERS_CD_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX TAGS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX TAGS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX TAGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE INDEX TAGS_READERS_RDR_STR 
 	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_TAGS_READERS

--  [start indexes] NR_STATUS_UPDATE_READERS
CREATE  INDEX STATUS_READERS_STR_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (STORY_ID); 
GO

CREATE  INDEX STATUS_READERS_ITM_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ITEM_ID); 
GO

CREATE  INDEX STATUS_READERS_CD_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX STATUS_READERS_SRC_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX STATUS_READERS_ACT_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX STATUS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX STATUS_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_STATUS_UPDATE_READERS

--  [start indexes] NR_EXTERNAL_READERS
CREATE  INDEX EXTERNAL_READERS_STR_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (STORY_ID); 
GO

CREATE  INDEX EXTERNAL_READERS_ITM_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (ITEM_ID); 
GO

CREATE  INDEX EXTERNAL_READERS_CD_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX EXTERNAL_READERS_SRC_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX EXTERNAL_READERS_ACT_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX EXTERNAL_READERS_RLL_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX EXTERNAL_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_EXTERNAL_READERS

--  [start indexes] NR_ACTIONABLE_READERS
CREATE  INDEX ACTIONABLE_READERS_STR_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (STORY_ID); 
GO

CREATE  INDEX ACTIONABLE_READERS_ITM_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (ITEM_ID); 
GO

CREATE  INDEX ACTIONABLE_READERS_CD_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX ACTIONABLE_READERS_SRC_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX ACTIONABLE_READERS_ACT_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX ACTIONABLE_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX ACTIONABLE_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_ACTIONABLE_READERS

--  [start indexes] NR_DISCOVERY_VIEW
CREATE  INDEX DISCOVERY_VIEW_STR_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (STORY_ID); 
GO

CREATE  INDEX DISCOVERY_VIEW_ITM_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ITEM_ID); 
GO

CREATE  INDEX DISCOVERY_VIEW_CD_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX DISCOVERY_VIEW_SRC_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX DISCOVERY_VIEW_ACT_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX DISCOVERY_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX DISCOVERY_VIEW_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_DISCOVERY_VIEW

--  [start indexes] NR_PROFILES_VIEW
CREATE  INDEX PROFILES_VIEW_STR_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (STORY_ID); 
GO

CREATE  INDEX PROFILES_VIEW_ITM_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (ITEM_ID); 
GO

CREATE  INDEX PROFILES_VIEW_CD_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX PROFILES_VIEW_SRC_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX PROFILES_VIEW_ACT_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX PROFILES_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX PROFILES_VIEW_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_PROFILES_VIEW

--  [start indexes] NR_NOTIFICATION_SENT_READERS
CREATE  INDEX NOTIFICA_READERS_STR_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (STORY_ID); 
GO

CREATE  INDEX NOTIFICA_READERS_ITM_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ITEM_ID); 
GO

CREATE  INDEX NOTIFICA_READERS_CD_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX NOTIFICA_READERS_SRC_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX NOTIFICA_READERS_ACT_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX NOTIFICA_READERS_RLL_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX NOTIFICA_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_NOTIFICATION_SENT_READERS

--  [start indexes] NR_SAVED_READERS
CREATE  INDEX SAVED_READERS_STR_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (STORY_ID); 
GO

CREATE  INDEX SAVED_READERS_ITM_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (ITEM_ID); 
GO

CREATE  INDEX SAVED_READERS_CD_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (STORY_ID, CREATION_DATE DESC); 
GO

CREATE  INDEX SAVED_READERS_SRC_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX SAVED_READERS_ACT_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (READER_ID, CREATION_DATE DESC, ACTOR_UUID, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE  INDEX SAVED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (USE_IN_ROLLUP, READER_ID, CREATION_DATE DESC, STORY_ID, IS_BROADCAST, ROLLUP_ENTRY_ID, SOURCE_TYPE); 
GO

CREATE UNIQUE INDEX SAVED_READERS_UNQ_RDR_STR 
 	ON HOMEPAGE.NR_SAVED_READERS (READER_ID, STORY_ID); 
GO

--  [end indexes] NR_SAVED_READERS

------------------------------------------------------------
-- [end] NEWS replacing existing indexes
------------------------------------------------------------

----------------------------------------------------------------
-- HOMEPAGE.NR_ENTRIES
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES (
	ENTRY_ID nvarchar(36) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_CREATION_DATE DATETIME NOT NULL,
	ITEM_UPDATE_DATE DATETIME NOT NULL,
	ITEM_TAGS nvarchar(1024),
	N_COMMENTS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMERIC(5,0) DEFAULT 0 NOT NULL,
	LAST_COMMENT_ID nvarchar(36),
	LAST_DATE_COMMENT DATETIME,
	LAST_AUTHOR_COMMENT nvarchar(36),
	PREV_COMMENT_ID nvarchar(36),
	PREV_DATE_COMMENT DATETIME,
	PREV_AUTHOR_COMMENT nvarchar(36),
	TARGET_SUBJECT_ID nvarchar(36),
	ITEM_ATOM_URL nvarchar(2048),
	PREVIEW_IMAGE_URL nvarchar(2048),
	JSON_META_DATA nvarchar(4000),
	ITEM_SCOPE NUMERIC(5,0),
	IS_LAST_COMMENT_PUBLIC NUMERIC(5,0),
	IS_PREV_COMMENT_PUBLIC NUMERIC(5,0),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_CORRELATION_NAME nvarchar(256),
	LAST_DESC_COMMENT nvarchar(4000),
	PREV_DESC_COMMENT nvarchar(4000),
	LAST_UPDATE_DATE_COMMENT DATETIME, 
	PREV_UPDATE_DATE_COMMENT DATETIME,
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256),
	BRIEF_DESC nvarchar (4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES
    ADD CONSTRAINT PK_ENTRY_ID PRIMARY KEY(ENTRY_ID);

CREATE INDEX NR_ENTRIES_CONT
    ON HOMEPAGE.NR_ENTRIES (CONTAINER_ID);

CREATE UNIQUE INDEX NR_ENTRIES_ITEM
    ON HOMEPAGE.NR_ENTRIES (ITEM_ID);

GO

----------------------------------------------------------------
-- HOMEPAGE.NR_STORIES
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID nvarchar(36) NOT NULL,
	EVENT_NAME nvarchar(256) NOT NULL,
	SOURCE nvarchar(36),
	CONTAINER_ID nvarchar(256),	
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	ITEM_NAME nvarchar(256),
	ITEM_URL nvarchar(2048),
	ITEM_ATOM_URL nvarchar(2048),
	ITEM_ID nvarchar(36),
	ITEM_CORRELATION_ID nvarchar(36),
	ITEM_TAGS nvarchar(1024),
	CREATION_DATE DATETIME NOT NULL,
	BRIEF_DESC nvarchar(4000),
	ACTOR_UUID nvarchar(36),
	EVENT_RECORD_UUID nvarchar(36) NOT NULL,
	TAGS nvarchar(1024),
	META_TEMPLATE nvarchar(3328) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE nvarchar(1024),
	R_META_TEMPLATE nvarchar(3328),
	R_TEXT_META_TEMPLATE nvarchar(1024),
	IS_COMMUNITY_STORY NUMERIC(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME nvarchar(256),
	HAS_ATTACHMENT NUMERIC(5,0) DEFAULT 0,
	SOURCE_TYPE NUMERIC(5,0),
	ENTRY_ID nvarchar(36),
	EVENT_TIME DATETIME,
	VERB nvarchar (128),
	ACTIVITY_META_DATA_1 nvarchar(3584),
	ACTIVITY_META_DATA_2 nvarchar(3584),
	IS_META_DATA_TRUNCATED  NUMERIC(5,0),
	ITEM_SCOPE NUMERIC(5,0),
	ITEM_UPDATE_DATE DATETIME,
	FIRST_RECIPIENT_ID nvarchar(36),
	NUM_RECIPIENTS NUMERIC(5,0), 
	PRIMARY_ACTION_URL nvarchar(768), 
	SECONDARY_ACTION_URL nvarchar(768),
	ITEM_AUTHOR_UUID nvarchar (36),
	ITEM_AUTHOR_DISPLAYNAME nvarchar (256),
	ITEM_CORRELATION_AUTHOR_UUID nvarchar (36),
	ITEM_CORRELATION_AUTHOR_NAME nvarchar (256)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT PK_STORY_ID PRIMARY KEY(STORY_ID);

ALTER TABLE HOMEPAGE.NR_STORIES
  	ADD CONSTRAINT FK_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES (ENTRY_ID);    

CREATE INDEX NR_STORIES_DATE
	ON HOMEPAGE.NR_STORIES (CREATION_DATE DESC);

CREATE INDEX STORY_CONTAINED_ID
    ON HOMEPAGE.NR_STORIES (CONTAINER_ID);

CREATE INDEX STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_STORIES (ITEM_CORRELATION_ID);

CREATE INDEX NR_STORIES_EIDX
    ON HOMEPAGE.NR_STORIES (ENTRY_ID);

CREATE INDEX NR_STORIES_ER_UUID
    ON HOMEPAGE.NR_STORIES (EVENT_RECORD_UUID, ENTRY_ID);
    
CREATE INDEX NR_STORY_CD_IDX 
	ON HOMEPAGE.NR_STORIES (CREATION_DATE ASC, STORY_ID);    

GO




------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_ACT
------------------------------------------------------------
------------------------------
-- i) COMMIT all the work
-- ii) enable xp_cmdshell
-----------------------------
COMMIT;


EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE
EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE

---------------------------------
-- Move the data
---------------------------------


-----------------------------------------------------------------------
-- [start] ************ HOMEPAGE.NR_SRC_STORIES_ACT *********************
-----------------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_ACT
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_ACT
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories

------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_BLG
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_BLG
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_BLG
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_COM
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_COM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_COM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_WIK
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_WIK
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_WIK
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_PRF
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_PRF
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_PRF
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_HP
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_HP
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_HP
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_DGR
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_DGR
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_DGR
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_FILE
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_FILE
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_FILE
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_FRM
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_FRM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_FRM
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories
------------------------------------------------------------
-- HOMEPAGE.NR_SRC_STORIES_EXTERNAL
------------------------------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
 	ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID, ITEM_NAME, ITEM_URL, ITEM_CREATION_DATE,
	ITEM_UPDATE_DATE, ITEM_TAGS, N_COMMENTS, N_RECOMMANDATIONS, LAST_COMMENT_ID, LAST_DATE_COMMENT, LAST_AUTHOR_COMMENT,
	PREV_COMMENT_ID, PREV_DATE_COMMENT, PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID, ITEM_ATOM_URL, PREVIEW_IMAGE_URL,
	JSON_META_DATA, ITEM_SCOPE, IS_LAST_COMMENT_PUBLIC, IS_PREV_COMMENT_PUBLIC, ITEM_CORRELATION_ID, ITEM_CORRELATION_NAME,
	LAST_DESC_COMMENT, PREV_DESC_COMMENT, LAST_UPDATE_DATE_COMMENT, PREV_UPDATE_DATE_COMMENT, ITEM_AUTHOR_UUID,
	ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME, BRIEF_DESC 
  FROM HOMEPAGE.NR_ENTRIES_EXTERNAL
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_ENTRIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;

-------------------------------------
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
 SELECT 
  	 STORY_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_NAME, ITEM_URL, ITEM_ATOM_URL,
  	 ITEM_ID, ITEM_CORRELATION_ID, ITEM_TAGS, CREATION_DATE, BRIEF_DESC, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
 	 TEXT_META_TEMPLATE, R_META_TEMPLATE, R_TEXT_META_TEMPLATE, IS_COMMUNITY_STORY, ITEM_CORRELATION_NAME, HAS_ATTACHMENT, 
 	 SOURCE_TYPE, ENTRY_ID, EVENT_TIME, VERB, ACTIVITY_META_DATA_1, ACTIVITY_META_DATA_2, IS_META_DATA_TRUNCATED, 
 	 ITEM_SCOPE, ITEM_UPDATE_DATE, FIRST_RECIPIENT_ID, NUM_RECIPIENTS, PRIMARY_ACTION_URL, SECONDARY_ACTION_URL, 
 	 ITEM_AUTHOR_UUID, ITEM_AUTHOR_DISPLAYNAME, ITEM_CORRELATION_AUTHOR_UUID, ITEM_CORRELATION_AUTHOR_NAME
  FROM HOMEPAGE.NR_SRC_STORIES_EXTERNAL
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_STORIES' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] stories










---------------------------------------------------------------------------------
BEGIN TRANSACTION
GO
-------------------------------------------
-- [START] Migrating them from STORIES table (BRIEF_DESC)
--------------------------------------------

--  HOMEPAGE.NR_ENTRIES
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID < '0..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '0..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '1..f' 
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '1..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '2..f' 
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '2..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '3..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '3..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '4..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '4..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '5..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '5..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '6..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '6..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '7..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '7..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '8..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '8..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < '9..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= '9..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'a..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'a..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'b..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'b..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'c..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'c..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'd..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'd..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'e..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'e..f' AND HOMEPAGE.NR_ENTRIES.ENTRY_ID < 'f..f'
); 
GO
UPDATE HOMEPAGE.NR_ENTRIES  SET BRIEF_DESC = ( 
  			SELECT MAX (BRIEF_DESC) 
  			FROM HOMEPAGE.NR_STORIES STORIES 
  			WHERE HOMEPAGE.NR_ENTRIES.ENTRY_ID = STORIES.ENTRY_ID   AND    HOMEPAGE.NR_ENTRIES.ENTRY_ID >= 'f..f' 
); 
GO

-------------------------------------------
-- [END Migrating them from STORIES table (BRIEF_DESC)
--------------------------------------------


-------------------------------------------------------------------
-- [START] ADDING INDEX FROM TAPSTAGE RALLY
-------------------------------------------------------------------
CREATE INDEX TAB_INST_TAB_ID 
	ON HOMEPAGE.HP_TAB_INST (TAB_ID);
GO	
	
CREATE INDEX BRD_ENTRIES_ITEM
	ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID, SL_IS_DELETED);
GO	
	
CREATE INDEX HP_UI 
	ON HOMEPAGE.HP_UI (LAST_VISIT ASC);
GO
-------------------------------------------------------------------
-- [END] ADDING INDEX FROM TAPSTAGE RALLY
-------------------------------------------------------------------	

-----------------------------------------------------------------------------------------
-- [START] MOVING DATA FROM NR_COMM_STORIES TO NR_COMMUNITIES_READERS
-----------------------------------------------------------------------------------------
--------- [start]  MOVING DATA FROM NR_COMM_STORIES TO NR_COMMUNITIES_READERS
COMMIT;

--------- [end] stories
BEGIN TRANSACTION
GO

CREATE VIEW HOMEPAGE.TMP_VIEW AS (
	SELECT
		COMMUNITY_ID READER_ID, 3 CATEGORY_TYPE, ' ' SOURCE, CONTAINER_ID, ITEM_ID, 
		RESOURCE_TYPE, CREATION_DATE, STORY_ID, SOURCE_TYPE, 0 USE_IN_ROLLUP, 
		0 IS_NETWORK, 0 IS_FOLLOWER, CREATION_DATE EVENT_TIME,
		' ' ROLLUP_ENTRY_ID, COMM_STORY_ID CATEGORY_READER_ID, 1 IS_STORY_COMM, 
		0 IS_BROADCAST, ' ' ORGANIZATION_ID, ' ' ACTOR_UUID	
	FROM HOMEPAGE.NR_COMM_STORIES
);
GO

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.TMP_VIEW TO HOMEPAGEUSER;
GO

COMMIT;

BEGIN TRANSACTION
GO

declare @backup_command varchar(8000), @format_command varchar(8000), @bulk_insert_command varchar(8000) 
declare @format_file varchar(8000), @data_file varchar(8000)
set @format_file = 'C:\format.fmt'
set @data_file = 'C:\data.dat'

declare @in_view varchar(8000), @out_table varchar(8000)
set @in_view = 'HOMEPAGE.HOMEPAGE.TMP_VIEW' -- The view name need also to be specified with the database name and the schema name
set @out_table = 'HOMEPAGE.NR_COMMUNITIES_READERS' -- Schema name and table name

-- create the format file
set @format_command = 'bcp '+@in_view+' format nul -T -n -f "'+@format_file+'"'
EXEC master..xp_cmdshell @format_command
-- backup the data
set @backup_command = 'bcp '+@in_view+' out "'+@data_file+'" -n -S '+@@servername+' -U HOMEPAGEUSER -P $(password)'
EXEC master..xp_cmdshell @backup_command
--insert back the record
set @bulk_insert_command = 'BULK INSERT '+@out_table+' FROM "'+@data_file+'" WITH (DATAFILETYPE="native", FORMATFILE="'+@format_file+'")'
EXEC (@bulk_insert_command) 
GO

COMMIT;

BEGIN TRANSACTION
GO

DROP VIEW HOMEPAGE.TMP_VIEW;
GO

COMMIT;
--------- [end] MOVING DATA FROM NR_COMM_STORIES TO NR_COMMUNITIES_READERS

---------------------------------------------------------------------------------
BEGIN TRANSACTION
GO

----------------------------------------------------------------------
-- [END] MOVING DATA FROM NR_COMM_STORIES TO NR_COMMUNITIES_READERS
----------------------------------------------------------------------

-----------------------------------------------
--  Recommendations widget is editable  [Work Item 52621]
-----------------------------------------------
UPDATE HOMEPAGE.WIDGET SET WIDGET_SYSTEM = 1 WHERE WIDGET_TITLE = '%widget.sand.recommend.name';
GO

---------------------------------------------------
-- [start] Dropping old STORIES and ENTRIES tables
---------------------------------------------------
DROP TABLE HOMEPAGE.NR_SRC_STORIES_ACT;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_BLG;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_COM;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_WIK;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_PRF;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_HP;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_DGR;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_FILE;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_FRM;
GO
DROP TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL;
GO

DROP TABLE HOMEPAGE.NR_ENTRIES_ACT;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_BLG;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_COM;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_WIK;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_PRF;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_HP;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_DGR;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_FILE;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_FRM;
GO
DROP TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL;
GO
---------------------------------------------------
-- [end] Dropping old STORIES and ENTRIES tables
---------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GO

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE40b2 FOR SEARCH 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 34215: Implement and unit test changes to DAO layer for per-document seedlist retrieval

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD ATOM_ID NVARCHAR(256) NULL
GO

CREATE INDEX SR_INDEX_DOCS_ACT_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(ACTION)
GO

CREATE INDEX SR_INDEX_DOCS_ACS_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(SERVICE,ATOM_ID,CRAWLING_VERSION)
GO

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT ID_ACT_CHECK
	CHECK (ACTION >= 0 AND ACTION < 4) 
GO

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT IGNORE_ACT_CHECK
	CHECK (ACTION <> 3 OR RESUME_POINT IS NULL) 
GO

--END  34215: Implement and unit test changes to DAO layer for per-document seedlist retrieval

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

----------------------------------------
--  SR_GLOBAL_SAND_PROPS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS(
	GSP_ID			NVARCHAR(36) NOT NULL,
	GSP_NAME		NVARCHAR(36) NOT NULL,
	GSP_VALUE		NVARCHAR(36) NOT NULL,
	GSP_TYPE        NUMERIC(5,0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
	ADD CONSTRAINT PK_GSP_ID PRIMARY KEY (GSP_ID)
GO

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
	ADD CONSTRAINT UNIQUE_GSP_NAME UNIQUE (GSP_NAME)
GO
	
ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS		
	ADD CONSTRAINT GSP_TYPE_CHECK
	CHECK (GSP_TYPE >=0 AND GSP_TYPE < 4);
GO


--END 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 40252: SPR#WDWU8AAA3P : search cluster nodes will insert dup scheduler task when scheduler table is empty

----------------------------------------
--  HOMEPAGE.LOTUSCONNECTIONSTASK
----------------------------------------

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK
GO    


ALTER TABLE HOMEPAGE.LOTUSCONNECTIONSTASK
    ADD CONSTRAINT UNIQUE_LCT_NAME UNIQUE (NAME)
GO    


--END 40252: SPR#WDWU8AAA3P : search cluster nodes will insert dup scheduler task when scheduler table is empty


--START 40269: PERF, homepage db,  this read sql needs index on sr_index_docs

----------------------------------------
--  HOMEPAGE.SR_INDEX_DOCS
----------------------------------------


CREATE INDEX SR_INDEX_DOCS_LLT4_IDX ON HOMEPAGE.SR_INDEX_DOCS(UPDATE_TIME ASC, ACTION DESC, CRAWLING_VERSION, SERVICE)
GO

--END  40269: PERF, homepage db,  this read sql needs index on sr_index_docs


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 91
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD

DELETE FROM HOMEPAGE.SR_FILESCONTENT
GO

DELETE FROM HOMEPAGE.SR_FACET_DOCS
GO

DELETE FROM HOMEPAGE.SR_INDEX_DOCS
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
ADD FS_LOCAL_PATH NVARCHAR(256) NOT NULL
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
ADD PROCESSOR NVARCHAR(36)
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
ADD PROCESSOR_STATE VARBINARY(MAX)
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
ADD CONTENT_LOCATION NVARCHAR(256) NOT NULL
GO

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
ADD IS_READY NUMERIC(5,0) NOT NULL
GO
	
--END 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD  


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 95
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

DROP TABLE HOMEPAGE.SR_FACET_DOCS
GO

--46592: Rename FILESCONTENT_ID in HOMEPAGE.SR_INDEX_DOCS to FILE_COMPONENT_UUID

DROP TABLE HOMEPAGE.SR_INDEX_DOCS
GO

CREATE TABLE HOMEPAGE.SR_INDEX_DOCS(
	DOCUMENT_ID NVARCHAR(36) NOT NULL,
	DOCUMENT VARBINARY(MAX) NOT NULL,
	CRAWLING_VERSION NUMERIC(19,0) NOT NULL,
	ACTION NUMERIC(5,0) NOT NULL,
	UPDATE_TIME  DATETIME NOT NULL,
	RESUME_POINT NVARCHAR(256),
	SERVICE NVARCHAR(36) NOT NULL,
	FILES_REF_ID NVARCHAR(36),
	ATOM_ID  NVARCHAR(256)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS
	ADD CONSTRAINT PK_INDEX_DOCS_ID PRIMARY KEY (DOCUMENT_ID)
GO	

CREATE INDEX SR_INDEX_DOCS_CRAWL_VERSION_IDX
	ON HOMEPAGE.SR_INDEX_DOCS (CRAWLING_VERSION)
GO

CREATE INDEX SR_INDEX_DOCS_RPS_IDX
    ON HOMEPAGE.SR_INDEX_DOCS (RESUME_POINT,SERVICE)
GO

CREATE INDEX SR_INDEX_DOCS_ACT_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(ACTION)
GO

CREATE INDEX SR_INDEX_DOCS_ACS_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(SERVICE,ATOM_ID,CRAWLING_VERSION)
GO

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT ID_ACT_CHECK
	CHECK (ACTION >= 0 AND ACTION < 4)
GO

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT IGNORE_ACT_CHECK
	CHECK (ACTION <> 3 OR RESUME_POINT IS NULL) 
GO

--START 40269: PERF, homepage db,  this read sql needs index on sr_index_docs
CREATE INDEX SR_INDEX_DOCS_LLT4_IDX ON HOMEPAGE.SR_INDEX_DOCS(UPDATE_TIME ASC, ACTION DESC, CRAWLING_VERSION, SERVICE)
GO


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 96
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--51089: [4.0] New Index On SR_INDEX_DOCS

CREATE INDEX SR_INDEX_DOCS_FRID_IDX 
	ON HOMEPAGE.SR_INDEX_DOCS(FILES_REF_ID ASC, SERVICE ASC, UPDATE_TIME DESC)
GO

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 97
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 97 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 59;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;