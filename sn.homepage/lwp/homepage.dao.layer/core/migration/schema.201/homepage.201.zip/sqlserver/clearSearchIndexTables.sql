-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO
-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
GO

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
GO

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
GO

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
GO

DELETE FROM HOMEPAGE.SR_STATS;
GO

DELETE FROM HOMEPAGE.SR_STRING_STATS;
GO

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
GO

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
GO


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------



