-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 201
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 201 FOR HP
------------------------------------------------

--{include.hp-fixup201.sql}

------------------------------------------------
-- INCLUDE FIX UP 201 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 201 -----------------------------------
---------------------------------------------------------------------------------

-- 78715 - New columns on NR_SOURCE_TYPE table.
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
ADD IS_DIGEST_ENABLED NUMERIC(5,0)  NOT NULL DEFAULT 0,
    DEFAULT_DIGEST_FREQUENCY NUMERIC(5,0)  NOT NULL DEFAULT 0,
    IS_DIGEST_LOCKED NUMERIC(5,0) NOT NULL DEFAULT 0;
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES
  ALTER COLUMN N_COMMENTS NUMERIC(10,0);
GO

ALTER TABLE HOMEPAGE.NR_ENTRIES
  ALTER COLUMN N_RECOMMANDATIONS NUMERIC(10,0);
GO


---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 201 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 201 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 74517: Create script that creates DB table that hold document type labels

----------------------------------------
-- SR_ECM_DOCUMENT_TYPE_LABELS
----------------------------------------


CREATE TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS(
        PROPERTIES_ID NVARCHAR(36) NOT NULL,
        DOCUMENT_TYPE_ID  NVARCHAR(256) NOT NULL,
        LOCALE NVARCHAR(10) NOT NULL,
        PROPERTIES NVARCHAR(MAX) NOT NULL
)
ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS
    ADD CONSTRAINT PK_PROPERTIES_ID PRIMARY KEY (PROPERTIES_ID);
GO


--END 74517: Create script that creates DB table that hold document type labels

--START Defect 80084: Rename IS_CURRENT Field to STATUS.

DROP INDEX SR_FILESCONTENT_IS_CURRENT_IDX ON HOMEPAGE.SR_FILESCONTENT;

EXEC sp_rename 'HOMEPAGE.SR_FILESCONTENT.IS_CURRENT','STATUS'; 
GO

CREATE INDEX SR_FILESCONTENT_STATUS_IDX 
	ON HOMEPAGE.SR_FILESCONTENT(STATUS);

--END Defect 80084: Rename IS_CURRENT Field to STATUS.


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 200
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 201 , RELEASEVER = '4.5.0.0'
WHERE   DBSCHEMAVER = 200;
------------------------------------------------------------------------------------------------

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 201
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

COMMIT
