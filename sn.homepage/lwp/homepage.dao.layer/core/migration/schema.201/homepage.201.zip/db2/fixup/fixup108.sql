-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 108
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 108 FOR HP
------------------------------------------------

--{include.hp-fixup108.sql}

------------------------------------------------
-- INCLUDE FIX UP 108 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 108 -----------------------------------
---------------------------------------------------------------------------------


--74350: Comment of comment in Activity entry still appears in response after parent comment is deleted 
CREATE INDEX HOMEPAGE.STORIES_ITEM_ENTRY_CORR_ID
    ON HOMEPAGE.NR_STORIES (ENTRY_CORRELATION_ID); 

COMMIT;    

--74742: [Performance] AS crawling / indexing is extremely slow 
CREATE INDEX HOMEPAGE.NR_AS_SEEDLIST_IDX 
	ON HOMEPAGE.NR_AS_SEEDLIST (UPDATE_DATE DESC, STORY_ID, IS_DELETED, IS_VISIBLE);  
	
COMMIT;	
	
CREATE UNIQUE INDEX HOMEPAGE.NR_NETWORK_PER_COL_IDX
	ON HOMEPAGE.NR_NETWORK (PERSON_ID, COLLEAGUE_ID);	
	
COMMIT;	
    
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 108 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 108 FOR SEARCH
------------------------------------------------

--{include.search-fixup108.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 108
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 108, RELEASEVER = '4.0.0.0' 
WHERE   DBSCHEMAVER = 107; 

------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 108
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
