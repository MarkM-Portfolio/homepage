-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2012 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 201
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 201 FOR HP
------------------------------------------------

--{include.hp-fixup201.sql}

------------------------------------------------
-- INCLUDE FIX UP 201 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 201 -----------------------------------
---------------------------------------------------------------------------------

-- 78715 - New columns on NR_SOURCE_TYPE table.
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
ADD (IS_DIGEST_ENABLED NUMBER(5,0) DEFAULT 0 NOT NULL,
     DEFAULT_DIGEST_FREQUENCY NUMBER(5,0)  DEFAULT 0 NOT NULL,
     IS_DIGEST_LOCKED NUMBER(5,0) DEFAULT 0 NOT NULL);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES
MODIFY (N_COMMENTS NUMBER(10,0),
		N_RECOMMANDATIONS NUMBER(10,0));
COMMIT;
	
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 201 -------------------------------------
---------------------------------------------------------------------------------

 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 201 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 74517: Create script that creates DB table that hold document type labels

----------------------------------------
--  SR_ECM_DOCUMENT_TYPE_PROPS
----------------------------------------


CREATE TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS(
	PROPERTIES_ID VARCHAR2(36) NOT NULL,
	DOCUMENT_TYPE_ID VARCHAR2(256) NOT NULL,
	LOCALE VARCHAR2(10) NOT NULL,	
	PROPERTIES CLOB NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.SR_ECM_DOCUMENT_TYPE_PROPS
         ADD (CONSTRAINT "PK_PROPERTIES_ID" PRIMARY KEY ("PROPERTIES_ID")
         USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

--END 74517: Create script that creates DB table that hold document type labels

--START Defect 80084: Rename IS_CURRENT Field to STATUS.

DROP INDEX  HOMEPAGE.SR_FILESCONTENT_IS_CURRENT_IDX;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	RENAME COLUMN IS_CURRENT TO STATUS;

CREATE INDEX "HOMEPAGE"."SR_FILESCONTENT_STATUS_IDX" 
	ON HOMEPAGE.SR_FILESCONTENT(STATUS) TABLESPACE "HOMEPAGEINDEXTABSPACE"; 
 
--END Defect 80084: Rename IS_CURRENT Field to STATUS.
         
         

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 201
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 201 , RELEASEVER = '4.5.0.0'
WHERE   DBSCHEMAVER = 200;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 201
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
