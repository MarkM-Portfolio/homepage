-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
COMMIT;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_STRING_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------



QUIT;

