-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 80 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36),
	EVENT_NAME VARCHAR2(256) NOT NULL,
	CONTAINER_ID VARCHAR2(256),	
	ITEM_ID VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),	
	CREATION_DATE TIMESTAMP NOT NULL,
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD (CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

COMMIT;

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID VARCHAR2(36) NOT NULL,
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	PERSON_ID VARCHAR2(36) NOT NULL,	
	REPLYTO_ADDRESS_ID VARCHAR2(36) NOT NULL,
	LAST_UPDATE TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD (CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_ID FOREIGN KEY (REPLYTO_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.REPLYTO_ADDRESS_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ADDRESS_ID) TABLESPACE "HPNTINDEXTABSPACE";



COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_NOTIFICATION
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ADD NOTIFICATION_SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 1 WHERE NOTIFICATION_SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 2 WHERE NOTIFICATION_SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 3 WHERE NOTIFICATION_SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 4 WHERE NOTIFICATION_SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 5 WHERE NOTIFICATION_SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 6 WHERE NOTIFICATION_SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 7 WHERE NOTIFICATION_SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 7 WHERE NOTIFICATION_SOURCE = 'bookmarks';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 8 WHERE NOTIFICATION_SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 9 WHERE NOTIFICATION_SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_REPLYTO
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_REPLYTO
	ADD SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 80 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------------
-- [start] 49953 -  At migration time we lose some informations regarding few stories.
--------------------------------------------------------------------------------------------
-- Before to start migration we need to sanitize the source name of the following source
-- tag.activities
-- tag.blogs
-- tag.communities
-- tag.files
-- tag.homepage
-- tag.profiles
-- tag.wikis
--------------------------------------------------------------------------------------------
UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

--------------------------------

-- HOMEPAGE.NR_RESPONSES_STORIES
UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;


-- HOMEPAGE.NR_PROFILES_STORIES
UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_PROFILES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_COMMUNITIES_STORIES
UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_COMMUNITIES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_ACTIVITIES_STORIES
UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_BLOGS_STORIES
UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_BLOGS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_BOOKMARKS_STORIES
UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_BOOKMARKS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_FILES_STORIES
UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_FILES_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_FORUMS_STORIES
UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_FORUMS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_WIKIS_STORIES
UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_WIKIS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-- HOMEPAGE.NR_TAGS_STORIES
UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_TAGS_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

-----------------------------------

-- HOMEPAGE.NR_COMM_PERSON_STORIES
UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

--HOMEPAGE.NR_NEWS_DISCOVERY
UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

--HOMEPAGE.NR_NEWS_SAVED
UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'activities' WHERE SOURCE = 'tag.activities';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'blogs' WHERE SOURCE = 'tag.blogs';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'communities' WHERE SOURCE = 'tag.communities';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'files' WHERE SOURCE = 'tag.files';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'homepage' WHERE SOURCE = 'tag.homepage';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'profiles' WHERE SOURCE = 'tag.profiles';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'wikis' WHERE SOURCE = 'tag.wikis';
commit;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'dogear' WHERE SOURCE = 'tag.dogear';
commit;

--------------------------------------------------------------------------------------------
-- [end] 49953 -  At migration time we lose some informations regarding few stories.
--------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- [START] PMR 48211,L6Q,000: Fixing Entries in following reletionship after migration
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.TMP_FOLLOWS AS ( 
   SELECT  NR_SUBSCRIPTION.PERSON_ID PERSON_ID, TEMP.CONTAINER_ID FOLLOWED_CONTAINER, RESOURCE_ID
    FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, HOMEPAGE.NR_RESOURCE NR_RESOURCE,
            ( 
            SELECT NR_SOURCE.CONTAINER_ID, NR_SOURCE.SOURCE_ID 
            FROM HOMEPAGE.NR_SOURCE NR_SOURCE, HOMEPAGE.PERSON PERSON 
            WHERE SOURCE = 'profiles' AND PERSON.PERSON_ID = NR_SOURCE.CONTAINER_ID 
            ) TEMP 
    WHERE   IS_EXPLICIT = 0 AND IS_ACTIVE = 1 AND NR_SUBSCRIPTION.SOURCE_ID = TEMP.SOURCE_ID AND TEMP.CONTAINER_ID = NR_RESOURCE.CONTAINER_ID
);
COMMIT;

DELETE FROM HOMEPAGE.NR_FOLLOWS FOLLOWS WHERE EXISTS 
	(SELECT 1 FROM HOMEPAGE.TMP_FOLLOWS TMP_FOLLOWS WHERE FOLLOWS.PERSON_ID = TMP_FOLLOWS.PERSON_ID AND FOLLOWS.RESOURCE_ID = TMP_FOLLOWS.RESOURCE_ID );
COMMIT;

DROP VIEW HOMEPAGE.TMP_FOLLOWS;
COMMIT;
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- [END] PMR 48211,L6Q,000: Fixing Entries in following reletionship after migration
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- PRE sanitize sql as we start from a 3.0.1 and we need to migrate it to 4.0

DROP INDEX HOMEPAGE.NR_ATT_STORY_ID;
DROP INDEX HOMEPAGE.NR_REC_STORY_ID;
DROP INDEX HOMEPAGE.NR_RECOMMENDER_STORY_ID;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT DROP CONSTRAINT PK_ATTACHMENT;
ALTER TABLE HOMEPAGE.NR_RECOMMENDATION DROP CONSTRAINT PK_RECOMMENDATION;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 			RENAME TO NR_ATTACHMENT_301;
ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 		RENAME TO NR_RECOMMENDATION_301;


commit;
-------------------------------------------------------
-- RENAMING NATIONWIDE specific table
-------------------------------------------------------

----------------------------------------------------------------
-- SPR #DMCE8ECKYM
----------------------------------------------------------------
-- #1 - Community Forum icon in news stories displays the Community icon
-- When you migrate 2.5.0x content that includes a community with community forum content, 
-- the story icon used in the 3.0.1 system appears to be misleading (Community icon currently  instead of Forum icon). 
-- See screenshot below as an example. This is not a ship stop if fix not included.
UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

-- #4 - Status Updates \ People I'm Following - should also include status by people in My Network
-- If you are networked with a user in 2.5.0.3, their latest status should be present in the "People I'm Following" view in 3.0.1 when migrated.
-- The default behaviour is that any network colleague making a status update automatically appears in your People I'm Following view.
-- This is not a ship stop if fix not included, but we should be including all relevant data in the migration process.
UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET IS_FOLLOW_NEWS = 1 WHERE IS_NETWORK_NEWS = 1;

COMMIT;

-- #5 - Icon for Following a person is the Homepage icon instead of Profiles icon
-- In LC 2.5.0.3, you will see a story for adding a user to your Homepage Watchlist. This story has a Homepage icon when migrated to LC 3.0.1
-- Ideally this story should have a "Profiles" icon in LC 3.0.1, as this is now a profiles story - profiles.person.followed
UPDATE HOMEPAGE.NR_STORIES  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;


UPDATE HOMEPAGE.NR_NEWS_SAVED  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;


--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------
-- CREATING A PARTITIONED TABLES
--------------------------------------------------------------

------------------------------------------------
-- 1) NR_SOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE_NAME VARCHAR2(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	SOURCE_TYPE_DESC VARCHAR2(256) NOT NULL
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD (CONSTRAINT "PK_SRC_TYPE_ID" PRIMARY KEY("SOURCE_TYPE_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNIQUE UNIQUE(SOURCE_TYPE);

ALTER TABLE "HOMEPAGE"."NR_SOURCE_TYPE" ENABLE ROW MOVEMENT;

-------------------------------------------------
-- 2) ADDING SOURCE TYPE COLUMNS TO EXISTING TABLES
-------------------------------------------------

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_SOURCE
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE
	ADD SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_SAVED
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_DISCOVERY
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESOURCE
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_COMM_STORIES
	SET SOURCE_TYPE = 3;
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_PERSON_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;


-- categories tables
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESPONSES_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_PROFILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMMUNITIES_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_ACTIVITIES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BLOGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BOOKMARKS_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FILES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FORUMS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_WIKIS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_TAGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_TAGS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

-------------------------------------------------
-- 3) ADDING PARTITIONED TABLES
-------------------------------------------------

----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_ACT (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
    ADD (CONSTRAINT "PK_ACT_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_ACT(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT ENABLE ROW MOVEMENT;
    
----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_SRC_STORIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_BLG (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
    ADD (CONSTRAINT "PK_BLG_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_DATE
	ON HOMEPAGE.NR_SRC_STORIES_BLG(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG ENABLE ROW MOVEMENT;

----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_SRC_STORIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_COM (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
    ADD (CONSTRAINT "PK_COM_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_COM (CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM ENABLE ROW MOVEMENT;    
    
----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_SRC_STORIES_WIK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_WIK (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
    ADD (CONSTRAINT "PK_WIK_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_DATE
	ON HOMEPAGE.NR_SRC_STORIES_WIK(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK ENABLE ROW MOVEMENT;    
    
----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_SRC_STORIES_PRF
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_PRF (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
    ADD (CONSTRAINT "PK_PRF_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_DATE
	ON HOMEPAGE.NR_SRC_STORIES_PRF(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_SRC_STORIES_HP
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_HP (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
    ADD (CONSTRAINT "PK_HP_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_DATE
	ON HOMEPAGE.NR_SRC_STORIES_HP(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_SRC_STORIES_DGR
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_DGR (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
    ADD (CONSTRAINT "PK_DGR_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_DATE
	ON HOMEPAGE.NR_SRC_STORIES_DGR(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_SRC_STORIES_FILE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FILE (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
    ADD (CONSTRAINT "PK_FILE_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FILE(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE ENABLE ROW MOVEMENT;

----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_SRC_STORIES_FRM 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FRM  (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 
    ADD (CONSTRAINT "PK_FRM_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FRM (CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM ENABLE ROW MOVEMENT;    

---------------------------------------------------------------------------------
-- 4) RUNNING DATA MIGRATION
---------------------------------------------------------------------------------

------------
--- START INSERT NR_SOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('blogs________0f1xc9caxcc4x8b0bx51af2', 2, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('communities____f1xc9caxcc48b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('wikis________dfdxc9cax4cc4xb0bx51af2', 4, '%wikis', 'wikis');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('profiles____________fdfdc98b0bx51af2', 5, '%profiles', 'profiles');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('homepage_0f1xc9cax4cc4x8cdb0bx51f2dd', 6, '%homepage', 'homepage');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('dogear_0f1xc9cax4cc4x8cdb0bx51f2d', 7, '%dogear', 'dogear');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('files____________fdfdc9cax8b0bx51af2', 8, '%files', 'files');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('forums____________fdfdc9cax80bx51af2', 9, '%forums', 'forums');
------------
--- END INSERT NR_SOURCE_TYPE
------------

COMMIT;

--------------------------------------------------------------------------------
-- START MIGRATING OLD DATA FROM THE NR_STORIES TABLE TO THE PARTITIONED TABLES
--------------------------------------------------------------------------------

-- PARTITIONING MAIN TABLE
ALTER TABLE HOMEPAGE.NR_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;    

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_STORIES_CONTENT (THIS IS BASED ON A JOIN WITH NR_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 1 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'activities'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 2 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'blogs'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 3 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'communities'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 4 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'wikis'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 5 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'profiles'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 6 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'homepage'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 7 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'dogear'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 8 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'files'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 9 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'forums'
);
COMMIT;

-- COPYING BACK THE DATA
-- 1) NR_SRC_STORIES_ACT
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 1;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_ACT VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--2) HOMEPAGE.NR_SRC_STORIES_BLG
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 2;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_BLG VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--3) HOMEPAGE.NR_SRC_STORIES_COM
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 3;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_COM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--4) HOMEPAGE.NR_SRC_STORIES_WIK
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 4;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_WIK VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--5) HOMEPAGE.NR_SRC_STORIES_PRF
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 5;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_PRF VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--6) HOMEPAGE.NR_SRC_STORIES_HP
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 6;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_HP VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--7) HOMEPAGE.NR_SRC_STORIES_DGR
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 7;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_DGR VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/	

commit;

--8) HOMEPAGE.NR_SRC_STORIES_FILE
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 8;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FILE VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--9) HOMEPAGE.NR_SRC_STORIES_FRM
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 9;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FRM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;
	
---------------------------------------------------------------------------------
-- DROPPING OLD TABLE TO CREATE A NEW VIEW
---------------------------------------------------------------------------------
--ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP CONSTRAINT "FK_COMM_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES DROP CONSTRAINT "FK_ORGP_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES DROP CONSTRAINT "FK_FCP_STORY_ID";

--ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT "FK_RESP_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT "FK_PROF_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT "FK_COM_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT "FK_ACT_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT "FK_BLOGS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT "FK_BOOKS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT "FK_FILES_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT "FK_FORUMS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT "FK_WIKIS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT "FK_TAGS_STORY_ID";
COMMIT;

DROP TABLE HOMEPAGE.NR_STORIES;
COMMIT;

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE SOURCE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_STORIES AS (
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FRM
);




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 80 FOR SEARCH
------------------------------------------------

--{include.search-fixup80.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 80
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 80 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 59;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
