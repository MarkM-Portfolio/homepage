-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 


------------------------------------------------
-- INCLUDE PREDBXFER40 FOR SEARCH
------------------------------------------------

{include.search-postdbxfer40.sql}

------------------------------------------------
-- INCLUDE PREDBXFER35 FOR NEWS
------------------------------------------------

{include.news-postdbxfer40.sql}

------------------------------------------------
-- INCLUDE PREDBXFER35 FOR HP
------------------------------------------------

{include.hp-postdbxfer40.sql}


COMMIT;

QUIT;