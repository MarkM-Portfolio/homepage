-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

ALTER TABLE HOMEPAGE.LOGINNAME
	ADD CONSTRAINT FK_PERSON_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID)
GO


ALTER TABLE HOMEPAGE.USER_WIDGET_PREF
    ADD CONSTRAINT FK_USER_ID FOREIGN KEY (USER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID)
GO

ALTER TABLE HOMEPAGE.USER_WIDGET_PREF
    ADD CONSTRAINT FK_WIDGET_ID FOREIGN KEY (WIDGET_ID)
	REFERENCES HOMEPAGE.WIDGET (WIDGET_ID)
GO

ALTER TABLE HOMEPAGE.PREREQ 
	ADD CONSTRAINT FK_PREREQ_WIDGET FOREIGN KEY (WIDGET_ID)
	REFERENCES HOMEPAGE.WIDGET (WIDGET_ID)
	ON DELETE CASCADE
GO

CREATE UNIQUE INDEX USERID_WIDGET_UNIQUE
	ON HOMEPAGE.USER_WIDGET_PREF (USER_ID ASC, WIDGET_ID ASC)
GO

COMMIT;
