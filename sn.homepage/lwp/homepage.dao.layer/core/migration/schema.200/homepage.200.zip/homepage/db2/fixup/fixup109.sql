-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 109 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.OH2P_CLIENTCFG;

CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID VARCHAR(128) NOT NULL, 
	CLIENTID VARCHAR(256) NOT NULL, 
	CLIENTSECRET VARCHAR(256), 
	DISPLAYNAME VARCHAR(256) NOT NULL, 
	REDIRECTURI VARCHAR(2048), 
	ENABLED SMALLINT
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID);

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 109 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 109 -----------------------------------
---------------------------------------------------------------------------------

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_ACT_CD_VIS_IDX  
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ACTOR_UUID, CREATION_DATE DESC, IS_VISIBLE); 
COMMIT;

DROP INDEX HOMEPAGE.STORIES_CONTAINER_URL_IDX;
COMMIT;

-------------------------------------------------------------------------
--75925: Duplicate entries in mobile/homepage/StatusUpdates
-------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK ALTER COLUMN BRIEF_DESC SET DATA TYPE VARCHAR(4000);
COMMIT;

CREATE INDEX HOMEPAGE.NR_STATUS_UPDATE_IX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID, UPDATE_DATE ASC, CREATION_DATE ASC, ITEM_ID, ACTOR_UUID);
COMMIT;


--76074: Fixup109.sql - add indexes based on performance and dev activities
DROP INDEX HOMEPAGE.NR_SL_UD_DELTED_IX;
COMMIT;

DROP INDEX HOMEPAGE.NR_SL_UD_VISIBLE_IX;
COMMIT;

DROP INDEX HOMEPAGE.NR_AS_SEEDLIST_IDX;
COMMIT;

CREATE INDEX HOMEPAGE.NR_SL_UD_STR
	ON HOMEPAGE.NR_AS_SEEDLIST (UPDATE_DATE ASC, STORY_ID);
COMMIT;

-- Index for deletion service
DROP INDEX HOMEPAGE.COMM_READERS_DEL_SERV_IX;
COMMIT;

DROP INDEX HOMEPAGE.DISCOVERY_VIEW_DEL_SERV_IX;
COMMIT;

DROP INDEX HOMEPAGE.PROFILES_VIEW_DEL_SERV_IX;
COMMIT;

CREATE  INDEX HOMEPAGE.COMM_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (CREATION_DATE DESC, IS_BROADCAST); 
COMMIT;

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (CREATION_DATE DESC, IS_BROADCAST); 
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE DESC, IS_BROADCAST); 
COMMIT;


-------------------------------------------------------------------------

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 109 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 109 FOR SEARCH
------------------------------------------------

--{include.search-fixup109.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 109
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 109, RELEASEVER = '4.0.0.0' 
WHERE   DBSCHEMAVER = 108; 

------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
