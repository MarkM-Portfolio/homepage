-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

----------------------------------------------------
-- 1) START ADDING INDEXES FOR HOMEPAGE TABLES
----------------------------------------------------
CREATE INDEX "HOMEPAGE"."TAB_INST_UI_ID_IDX" 
	ON "HOMEPAGE"."HP_TAB_INST"("UI_ID") TABLESPACE "HPNTINDEXTABSPACE";	


CREATE INDEX "HOMEPAGE"."HP_WIDGET_INST_TAB_INST_ID_IDX"
	ON "HOMEPAGE"."HP_WIDGET_INST"("TAB_INST_ID") TABLESPACE "HPNTINDEXTABSPACE";

----------------------------------------------------
-- END ADDING INDEXES FOR HOMEPAGE TABLES
----------------------------------------------------

-------------------------------------------------------------------
-- 2) START ADDING INDEXES FOR NEWS REPOSITORY 
-------------------------------------------------------------------
-- NEW REPOSITORY INDEXES
CREATE INDEX "HOMEPAGE"."NR_NEWS_RECORDS_READER_IDX"
	ON HOMEPAGE.NR_NEWS_RECORDS("READER_ID") TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX "HOMEPAGE"."NR_NEWS_RECORDS_ACTOR_IDX"
	ON HOMEPAGE.NR_NEWS_RECORDS("ACTOR_UUID") TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX "HOMEPAGE"."NR_NEWS_RECORDS_SOURCE_IDX"
	ON HOMEPAGE.NR_NEWS_RECORDS("SOURCE") TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX "HOMEPAGE"."NR_NEWS_RECORDS_CONTAINER_IDX"
	ON HOMEPAGE.NR_NEWS_RECORDS("CONTAINER_ID") TABLESPACE "NEWSINDEXTABSPACE";
	
CREATE INDEX "HOMEPAGE"."NR_NEWS_RECORDS_DATE_IDX"
	ON HOMEPAGE.NR_NEWS_RECORDS("CREATION_DATE" DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_NEWS_RECORDS_EVENT_IDX
	ON HOMEPAGE.NR_NEWS_RECORDS("EVENT_RECORD_UUID") TABLESPACE "NEWSINDEXTABSPACE";	
-------------------------------------------------------------------
-- END ADDING INDEXES FOR NEWS REPOSITORY 
-------------------------------------------------------------------


COMMIT;

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;