-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

------------------------------------------------
-- INCLUDE UPGRADE30 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- a) increase the tabspace  PAGESIZE size
CREATE BUFFERPOOL NT16KBP IMMEDIATE SIZE 16000 AUTOMATIC PAGESIZE 16K;

-- HOMEPAGE NOTIFICATION HPNT16TABSPACE
CREATE SYSTEM TEMPORARY TABLESPACE HPNT16TMPTABSPACE
	PAGESIZE 16K MANAGED BY SYSTEM 
	USING ( 'HPNT16TMPTABSPACE' ) 
	EXTENTSIZE 8 PREFETCHSIZE AUTOMATIC
	BUFFERPOOL NT16KBP
	FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE HPNT16TABSPACE 
	PAGESIZE 16K MANAGED BY DATABASE
	USING (FILE 'HPNT16TABSPACE' 12800)
	EXTENTSIZE 8
	PREFETCHSIZE AUTOMATIC
	BUFFERPOOL NT16KBP
	AUTORESIZE YES
	INCREASESIZE 20 M
	MAXSIZE NONE;	

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE30 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 34
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Need to create a new tabspace

-- NEWS4KBP ---------------------------------------------------------------
CREATE BUFFERPOOL NEWS4KBP IMMEDIATE SIZE 16000 AUTOMATIC PAGESIZE 4K;

-- NEWS 4K TABLETABLESPACE 
CREATE SYSTEM TEMPORARY TABLESPACE NEWS4TMPTABSPACE
        PAGESIZE 4K MANAGED BY SYSTEM 
        USING ( 'NEWS4TMPTABSPACE' ) 
        EXTENTSIZE 16 PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS4KBP
        FILE SYSTEM CACHING;
              
CREATE LARGE TABLESPACE NEWS4TABSPACE 
        PAGESIZE 4K MANAGED BY DATABASE
        USING (FILE 'NEWS4TABSPACE' 12800)
        EXTENTSIZE 16
        PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS4KBP
        AUTORESIZE YES
        INCREASESIZE 40 M
        MAXSIZE NONE; 

-- NEWS8KBP ----------------------------------------------------------
CREATE BUFFERPOOL NEWS8KBP IMMEDIATE SIZE 16000 AUTOMATIC PAGESIZE 8K;

-- NEWS 8K TABLETABLESPACE 
CREATE SYSTEM TEMPORARY TABLESPACE NEWS8TMPTABSPACE
        PAGESIZE 8K MANAGED BY SYSTEM 
        USING ( 'NEWS8TMPTABSPACE' ) 
        EXTENTSIZE 16 PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS8KBP
        FILE SYSTEM CACHING;
              
CREATE LARGE TABLESPACE NEWS8TABSPACE 
        PAGESIZE 8K MANAGED BY DATABASE
        USING (FILE 'NEWS8TABSPACE' 12800)
        EXTENTSIZE 16
        PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS8KBP
        AUTORESIZE YES
        INCREASESIZE 40 M
        MAXSIZE NONE;
           
-- NEWS32KBP ----------------------------------------------------------
CREATE BUFFERPOOL NEWS32KBP IMMEDIATE SIZE 16000 AUTOMATIC PAGESIZE 32K;

-- NEWS 32K TABLETABLESPACE
CREATE SYSTEM TEMPORARY TABLESPACE NEWS32TMPTABSPACE
        PAGESIZE 32K MANAGED BY SYSTEM 
        USING ( 'NEWS32TMPTABSPACE' ) 
        EXTENTSIZE 16 PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS32KBP
        FILE SYSTEM CACHING;
              
CREATE LARGE TABLESPACE NEWS32TABSPACE 
        PAGESIZE 32K MANAGED BY DATABASE
        USING (FILE 'NEWS32TABSPACE' 12800)
        EXTENTSIZE 16
        PREFETCHSIZE AUTOMATIC
        BUFFERPOOL NEWS32KBP
        AUTORESIZE YES
        INCREASESIZE 40 M
        MAXSIZE NONE;

-- NEWSCONTBFP
CREATE BUFFERPOOL NEWSCONTBFP IMMEDIATE SIZE 1000 AUTOMATIC PAGESIZE 4K;

-- NEWSCONT4KTABSPACE
CREATE LARGE TABLESPACE NEWSCONT4KTABSPACE 
	PAGESIZE 4K  MANAGED BY DATABASE
	USING (FILE 'NEWSCONT_TABSPACE' 12800) 
	EXTENTSIZE 8 
	PREFETCHSIZE 8 
	BUFFERPOOL NEWSCONTBFP;
	   
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;