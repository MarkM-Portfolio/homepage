-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- *****************************************************************  

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 83
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 83 FOR HP
------------------------------------------------

--{include.hp-fixup83.sql}

------------------------------------------------
-- INCLUDE FIX UP 83 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------
-- START: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD TMP_DOMAIN_AFFINITY VARCHAR(MAX);

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET TMP_DOMAIN_AFFINITY = DOMAIN_AFFINITY;

GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD DOMAIN_AFFINITY VARCHAR(MAX);

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET DOMAIN_AFFINITY = TMP_DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN TMP_DOMAIN_AFFINITY;

GO

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

GO

--------------------------------------------------------------------------------------
-- END: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
-- START: ADDING ENTRY_ID
--------------------------------------------------------------------------------------

-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD ENTRY_ID nvarchar(36);

CREATE INDEX NR_SRC_STORIES_ACT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);
	
GO

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_BLG_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ENTRY_ID);      

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID); 
	
GO

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_COM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (ENTRY_ID); 

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);
	
GO

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_WIK_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID);
	
GO

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_PRF_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
	
GO

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_HP_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID); 
	
GO

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_DGR_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID); 
	
GO
    
-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_FILE_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);
	
GO

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD ENTRY_ID nvarchar(36);
	
CREATE INDEX NR_SRC_STORIES_FRM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID); 
	
GO

--------------------------------------------------------------------------------------
-- FIXING BOARD TABLES
-------------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_RECOMMENDATIONS;

DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

DROP TABLE HOMEPAGE.BOARD_COMMENTS;

DROP TABLE HOMEPAGE.BOARD_READERS;

DROP TABLE HOMEPAGE.BOARD_ENTRIES;

GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMERIC (5,0),
	CATEGORY_TYPE NUMERIC (5,0),
	SOURCE nvarchar(36),
	SOURCE_TYPE NUMERIC (5,0),
	ITEM_ID nvarchar(36),
	ITEM_URL nvarchar(2048),
	CONTAINER_ID nvarchar(256),
	CONTAINER_NAME nvarchar(256),
	CONTAINER_URL nvarchar(2048),
	CREATION_DATE DATETIME NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE DATETIME NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID nvarchar(36),
	N_COMMENTS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_COMMUNITY_STORY NUMERIC (5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMERIC (5,0) DEFAULT 0,
	TARGET_SUBJECT_ID nvarchar(256),
	TAGS nvarchar(1024),
	SL_IS_UPDATED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMERIC (5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE DATETIME NOT NULL, -- this field is used by the seedlist
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID);

CREATE INDEX NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC);
  
CREATE INDEX NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC);

CREATE UNIQUE INDEX NEWS_BRD_ITEM
    ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID);     
GO

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID nvarchar(36) NOT NULL,
	IS_READER_COMM NUMERIC (5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL,
	IS_NETWORK_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMERIC (5,0) DEFAULT 0 NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID);

CREATE INDEX NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);
GO

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID nvarchar(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID nvarchar(36),
	CREATION_DATE DATETIME NOT NULL,
	ITEM_ID nvarchar(47),
	ITEM_CORRELATION_ID nvarchar(47),
	ITEM_URL nvarchar(2048),	
	CONTENT varbinary (MAX)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID);   
GO

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID nvarchar(47) NOT NULL,
	ENTRY_ID nvarchar(47) NOT NULL, -- 47
	SOURCE_TYPE NUMERIC (5,0) NOT NULL,
	ATTACHMENT_TYPE NUMERIC (5,0),
	CREATION_DATE DATETIME,
	NAME nvarchar(2048),
	DESCRIPTION nvarchar(4000),	
	TARGET_ID  nvarchar(256),
	TARGET_URL nvarchar(2048),
	META_DATA nvarchar(4000)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID);     
GO

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID nvarchar(47) NOT NULL, --primary key
	RECOMMENDER_ID nvarchar(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID nvarchar(47) NOT NULL,
	SOURCE_TYPE NUMERIC (5,0) NOT NULL, 
	CREATION_DATE DATETIME
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID);
    
CREATE UNIQUE INDEX BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID);
GO

GO



------------------------------------------------------
-- CREATE VIEW NR_ENTRIES
------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_ENTRIES AS (
    SELECT * FROM HOMEPAGE.NR_ENTRIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FRM
);
GO



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 60 FOR SEARCH
------------------------------------------------

--{include.search-fixup83.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 83
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 83 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 82;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 83
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

