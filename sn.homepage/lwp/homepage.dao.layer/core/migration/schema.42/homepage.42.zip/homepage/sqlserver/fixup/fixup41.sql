-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 41 
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 41 FOR HP
------------------------------------------------

--
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                              
--                                                                                                                       
--                                                                   
-- Copyright IBM Corp. 2007, 2008  All Rights Reserved.              
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or       
-- disclosure restricted by GSA ADP Schedule Contract with           
-- IBM Corp.                                                         
--                                                                   
-- ***************************************************************** 

-- 5724-S68

-----------------------------------------------------------------------------------
-- PERSON
-----------------------------------------------------------------------------------
-- select * 
-- from HOMEPAGE.PERSON 
-- where LAST_UPDATE > ?
CREATE INDEX PERSON_LAST_UPDATE
    ON HOMEPAGE.PERSON (LAST_UPDATE DESC);

-----------------------------------------------------------------------------------
-- NT_NOTIFICATION
-----------------------------------------------------------------------------------
-- select N.NOTIFICATION_ID, N.NOTIFICATION_SOURCE AS SOURCE, N.NOTIFICATION_TYPE AS TYPE, N.DATETIME_STAMP, P1.PERSON_ID, N.SENDER_ID,
--        N.SUBJECT, N.MESSAGE, N.CONTAINER_NAME, N.CONTAINER_URL, N.ITEM_NAME, N.ITEM_URL, P2.PERSON_ID AS FIRST_RECIPIENT_PERSON_ID,
--         P2.EXID AS FIRST_RECIPIENT_EXID, P2.DISPLAYNAME AS FIRST_RECIPIENT_DISPLAY_NAME, N.NUM_RECIPIENTS
-- from HOMEPAGE.NT_NOTIFICATION N, HOMEPAGE.PERSON P1, HOMEPAGE.PERSON P2 
-- where P1.PERSON_ID = ? AND P2.PERSON_ID = N.FIRST_RECIPIENT_ID AND N.SENDER_ID = P1.PERSON_ID AND N.IS_DELETED = 0 
-- order by N.DATETIME_STAMP DESC
CREATE INDEX NT_NOTIFICATION_IDX
    ON HOMEPAGE.NT_NOTIFICATION (DATETIME_STAMP DESC, FIRST_RECIPIENT_ID, SENDER_ID);

CREATE INDEX NT_FIRST_RECIPIENT_PER
    ON HOMEPAGE.NT_NOTIFICATION (FIRST_RECIPIENT_ID);

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 33 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- NR_FOLLOWS
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_RESOURCE.SOURCE, HOMEPAGE.NR_RESOURCE.CONTAINER_ID, HOMEPAGE.NR_RESOURCE.CONTAINER_NAME, HOMEPAGE.NR_RESOURCE.CONTAINER_URL, 
--        HOMEPAGE.NR_RESOURCE.CATEGORY_TYPE, HOMEPAGE.NR_RESOURCE.RESOURCE_TYPE FROM HOMEPAGE.NR_FOLLOWS INNER JOIN HOMEPAGE.NR_RESOURCE ON 
--        HOMEPAGE.NR_FOLLOWS.RESOURCE_ID = HOMEPAGE.NR_RESOURCE.RESOURCE_ID 
--WHERE   HOMEPAGE.NR_FOLLOWS.PERSON_ID = ? 
--ORDER BY HOMEPAGE.NR_RESOURCE.CONTAINER_NAME
CREATE INDEX NR_FOLLOWS_IDX
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID, PERSON_ID);

CREATE INDEX NR_FOLLOWS_PERS
    ON HOMEPAGE.NR_FOLLOWS (PERSON_ID);

-- SELECT PERSON_ID 
-- FROM HOMEPAGE.NR_FOLLOWS 
-- WHERE RESOURCE_ID = ?
CREATE INDEX NR_FOLLOWS_RES
    ON HOMEPAGE.NR_FOLLOWS (RESOURCE_ID);

-----------------------------------------------------------------------------------
-- NR_NETWORK
-----------------------------------------------------------------------------------
-- SELECT COLLEAGUE_ID 
-- FROM HOMEPAGE.NR_NETWORK 
-- WHERE PERSON_ID = ?
CREATE INDEX NR_NETWORK_PERS
    ON HOMEPAGE.NR_NETWORK (PERSON_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
-----------------------------------------------------------------------------------
CREATE INDEX NR_NEWS_SC_ITEM_COR
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_CORRELATION_ID);

-----------------------------------------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
-----------------------------------------------------------------------------------
--SELECT  HOMEPAGE.NR_NEWS_STATUS_COMMENT.NEWS_STATUS_COMMENT_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ACTOR_UUID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.CREATION_DATE,
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.BRIEF_DESC, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_ID, HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID, 
--        HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_URL, HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID FROM HOMEPAGE.NR_NEWS_STATUS_COMMENT, 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE   HOMEPAGE.NR_NEWS_STATUS_COMMENT.ITEM_CORRELATION_ID = HOMEPAGE.NR_NEWS_STATUS_NETWORK.ITEM_ID AND 
--        HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID = ? 
--ORDER BY HOMEPAGE.NR_NEWS_STATUS_NETWORK.NEWS_STATUS_NETWORK_ID
CREATE INDEX NR_NEWS_STATUS_NETWORK_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (ITEM_ID);

--SELECT  NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK WHERE READER_ID=? AND IS_FOLLOW_NEWS = 1 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_FOLLOW_NEWS);

CREATE INDEX NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID, IS_NETWORK_NEWS);

-- *
--SELECT NEWS_STATUS_NETWORK_ID, READER_ID, ACTOR_UUID, BRIEF_DESC, ITEM_URL, ITEM_ID, EVENT_NAME, TARGET_SUBJECT_ID, IS_WALL_POST, 
--        CREATION_DATE, UPDATE_DATE, N_COMMENTS, IS_NETWORK_NEWS, IS_FOLLOW_NEWS 
--FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK 
--WHERE READER_ID=? ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE DESC, READER_ID);


-----------------------------------------------------------------------------------
-- NR_NEWS_SAVED
-----------------------------------------------------------------------------------
-- SELECT * 
-- FROM HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? AND CREATION_DATE >= ?

-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, 
--         TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE READER_ID = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY


-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, READER_ID, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, 
--         ENTRY_ATOM_URL, CREATION_DATE, IS_CONTAINER, BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, 
--         META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
-- FROM    HOMEPAGE.NR_NEWS_SAVED 
-- WHERE   READER_ID = ? AND SOURCE = ? 
-- ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_SAVED_READER
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID);

CREATE INDEX NR_NEWS_SAVED_READER_SRC
    ON HOMEPAGE.NR_NEWS_SAVED (CREATION_DATE DESC, READER_ID, SOURCE);

-----------------------------------------------------------------------------------
-- NR_NEWS_DISCOVERY
-----------------------------------------------------------------------------------
-- SELECT  NEWS_RECORDS_ID, EVENT_NAME, SOURCE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ENTRY_NAME, ENTRY_URL, ENTRY_ATOM_URL, CREATION_DATE, 
--        BRIEF_DESC, IS_BRIEF_DESC_RTL, ACTOR_UUID, EVENT_RECORD_UUID, TAGS, META_TEMPLATE, TEXT_META_TEMPLATE, ITEM_ID, 
--        ITEM_CORRELATION_ID, N_COMMENTS, N_RECOMMANDATIONS, GROUP_TYPE, NEWS_STORY_ID 
--FROM    HOMEPAGE.NR_NEWS_DISCOVERY 
--WHERE   SOURCE = ? 
--ORDER BY CREATION_DATE DESC FETCH FIRST 20 ROWS ONLY
CREATE INDEX NR_NEWS_DISCOVERY_CREAT
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC);

CREATE INDEX NR_NEWS_DISCOVERY_CREAT_SOURCE
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, SOURCE);

-----------------------------------------------------------------------------------
-- NR_FOLLOWED_STORIES
-----------------------------------------------------------------------------------
-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES 
-- WHERE READER_ID = ?
CREATE INDEX NR_FOLLOWED_STORIES_READER
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID);

-- SELECT DISTINCT STORY_ID 
-- FROM HOMEPAGE.NR_FOLLOWED_STORIES WHERE 
-- READER_ID = ? AND CATEGORY_TYPE = ?
CREATE INDEX NR_FOLLOWED_STORIES_READER_CAT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CATEGORY_TYPE);

CREATE INDEX NR_FS_READER_CONT
    ON HOMEPAGE.NR_FOLLOWED_STORIES (CREATION_DATE ASC, READER_ID, CONTAINER_ID);

CREATE INDEX NR_FOLLOWED_STORIES_STORY_ID
    ON HOMEPAGE.NR_FOLLOWED_STORIES (STORY_ID);

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE INDEX NR_NEWS_COMMENT_CONTENT_ID
    ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT (NEWS_STATUS_COMMENT_ID);

----------------------------------------------------------------------
-- NR_RESOURCE
----------------------------------------------------------------------
-- SELECT  * 
-- FROM    HOMEPAGE.NR_RESOURCE 
-- WHERE   RESOURCE_TYPE = ? AND CONTAINER_ID = ?
CREATE INDEX NR_RESOURCE_TYPE_CONT
    ON HOMEPAGE.NR_RESOURCE (RESOURCE_TYPE, CONTAINER_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_FOLLOW 
----------------------------------------------------------------------
CREATE INDEX NR_COMM_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (PERSON_ID);

CREATE INDEX NR_COMM_FOLLOW_COM_ID
    ON HOMEPAGE.NR_COMM_FOLLOW (COMMUNITY_ID);     

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_FOLLOW
----------------------------------------------------------------------
CREATE INDEX NR_ORGPERSON_FOLLOW_PERSON_ID
    ON HOMEPAGE.NR_ORGPERSON_FOLLOW (PERSON_ID);

----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_STORIES
----------------------------------------------------------------------
CREATE INDEX NR_COMM_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_STORIES (STORY_ID);

CREATE INDEX NR_COMM_STORIES_COM_ID
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID);    

----------------------------------------------------------------------
-- HOMEPAGE.NR_ORGPERSON_STORIES
----------------------------------------------------------------------
CREATE INDEX NR_ORGPERSON_STORIES_STORY_ID
    ON HOMEPAGE.NR_ORGPERSON_STORIES (STORY_ID);

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 33 FOR SEARCH
------------------------------------------------

--{include.search-fixup41.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 41
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 41 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 40;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 41
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
