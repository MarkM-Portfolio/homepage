-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 56 FOR HP
------------------------------------------------

-- {include.hp-fixup56.sql}

------------------------------------------------
-- INCLUDE FIX UP 56 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE INDEX HOMEPAGE.NR_SC_UDATE
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (UPDATE_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;   
   
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_ITEM_C
    ON HOMEPAGE.NR_NEWS_DISCOVERY (ITEM_CORRELATION_ID) TABLESPACE NEWSINDEXTABSPACE;   
   
COMMIT;

-- SPR #RSTR8A5Q7R
-- Slow query on Homepage nr_news_status_network table: Oracle
CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_IDX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID) TABLESPACE  NEWSINDEXTABSPACE;

COMMIT;

--SPR #MAKN8A8DXJ SVT: 
--Homepage News Feed (Filter Responses and People) is very slow
CREATE INDEX HOMEPAGE.NR_EVENT_READER 
	ON HOMEPAGE.NR_NEWS_SAVED (READER_ID,EVENT_RECORD_UUID) TABLESPACE  NEWSINDEXTABSPACE;

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 56 FOR SEARCH
------------------------------------------------

--{include.search-fixup56.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 56
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 56 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 55;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 56
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
