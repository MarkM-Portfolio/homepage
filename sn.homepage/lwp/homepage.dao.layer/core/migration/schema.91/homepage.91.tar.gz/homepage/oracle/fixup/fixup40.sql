-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 40
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 40 FOR HP
------------------------------------------------

--{include.hp-fixup40.sql}

------------------------------------------------
-- INCLUDE FIX UP 40 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-------------------------------------------------------------------------------
-- START: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------
-- DROP FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP CONSTRAINT FK_F_STORY_ID;

DELETE FROM HOMEPAGE.NR_STORIES_CONTENT;
COMMIT;

DELETE FROM HOMEPAGE.NR_ORGPERSON_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_COMM_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_FOLLOWED_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_STORIES;
COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_DISCOVERY;
COMMIT;

DELETE FROM HOMEPAGE.NR_NEWS_SAVED;
COMMIT;

-- PUT BACK FK
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT FK_F_STORY_ID FOREIGN KEY (STORY_ID)
    REFERENCES HOMEPAGE.NR_STORIES (STORY_ID);

-------------------------------------------------------------------------------
-- END: PEOPLE TAGS CLEANUP (basically all the stories)
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

---------------------------------------------------------------------
-- START: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------
CREATE VIEW HOMEPAGE.DUPLICATED_CONTAINERS AS (
    select CONTAINER_ID, count(RESOURCE_TYPE) RESOURCE_COUNT
    from HOMEPAGE.NR_RESOURCE NR_RESOURCE
    group by CONTAINER_ID
    having  count(RESOURCE_TYPE) > 1
);

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES AS (
    SELECT  NR_RESOURCE.RESOURCE_ID, NR_RESOURCE.SOURCE, NR_RESOURCE.CONTAINER_ID, NR_RESOURCE.CONTAINER_NAME, 
            NR_RESOURCE.CONTAINER_URL, NR_RESOURCE.CATEGORY_TYPE, NR_RESOURCE.RESOURCE_TYPE, NR_RESOURCE.LAST_UPDATE
    FROM    HOMEPAGE.DUPLICATED_CONTAINERS DUPLICATED_CONTAINERS, HOMEPAGE.NR_RESOURCE NR_RESOURCE
    WHERE   DUPLICATED_CONTAINERS.CONTAINER_ID = NR_RESOURCE.CONTAINER_ID
);

CREATE VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE AS (
    SELECT CONTAINER_ID, MAX(RESOURCE_ID) MAX_RESOURCE_ID
    FROM HOMEPAGE.DUPLICATED_RESOURCES
    GROUP BY CONTAINER_ID
);

-- CLEANUP RECORDS: WE NEED TO REMOVE ALL THE RECORDS WITH MAX_RESOURCE_ID
-- A) REMOVE RECORDS FROM THE FOLLOWS TABLE TO DON'T BREAK FK CONSTRAINTS 
DELETE  FROM HOMEPAGE.NR_FOLLOWS 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
COMMIT;

-- B) REMOVE RECORDS FROM THE MASTER TABLE 
DELETE  FROM HOMEPAGE.NR_RESOURCE 
        WHERE RESOURCE_ID  IN   (
                                SELECT MAX_RESOURCE_ID
                                FROM HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE
                                );
COMMIT;

----------------------------------
-- REMOVE TMP VIEWS
----------------------------------
DROP VIEW HOMEPAGE.DUPLICATED_CONTAINERS;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES;
DROP VIEW HOMEPAGE.DUPLICATED_RESOURCES_TO_REMOVE;


-------------------------------------------
-- ADDING UNIQUE CONSTRAINTS
-------------------------------------------
-- RESOURCE_TYPE NOT NULL
-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--    MODIFY RESOURCE_TYPE 
--    NOT NULL;

--REORG TABLE HOMEPAGE.NR_RESOURCE USE NEWS4TMPTABSPACE; 

-- UNIQUE CONSTRAINT
-- ** moved to 39
--ALTER TABLE HOMEPAGE.NR_RESOURCE
--	ADD CONSTRAINT UNIQUE_RES UNIQUE (CONTAINER_ID, RESOURCE_TYPE);
	
---------------------------------------------------------------------
-- END: CLEANING UP DUPLICATED RECORDS
---------------------------------------------------------------------


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

------------------------------------------------------------
-- START: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-- NR_NEWS_SAVED
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_RESOURCE
ALTER TABLE HOMEPAGE.NR_RESOURCE
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_FOLLOWED_STORIES
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_COMM_STORIES
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    MODIFY CONTAINER_ID 
    VARCHAR2(256);

-- NR_ORGPERSON_STORIES
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    MODIFY CONTAINER_ID 
    VARCHAR2(256);


------------------------------------------------------------
-- END: FIXING CONTAINER_ID AND INCREASE IT TO 256
------------------------------------------------------------

-------------------------------------------------------------------------
-- START: INIT EMD_TRANCHE
-------------------------------------------------------------------------

-- EMD_TRANCHE 1
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_1_KwZTaR7aAiPFw4L08CyRW', 'tranche_1_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 2
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_2_KwZTaR7aAiPFw4L08CyRW','tranche_2_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 3
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_3_KwZTaR7aAiPFw4L08CyRW','tranche_3_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 4
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 4, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_4_KwZTaR7aAiPFw4L08CyRW','tranche_4_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 5
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_5_KwZTaR7aAiPFw4L08CyRW','tranche_5_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 6
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 6, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_6_KwZTaR7aAiPFw4L08CyRW','tranche_6_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 7
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_7_KwZTaR7aAiPFw4L08CyRW','tranche_7_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 8
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_8_KwZTaR7aAiPFw4L08CyRW','tranche_8_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 9
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 9, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_9_KwZTaR7aAiPFw4L08CyRW','tranche_9_5oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 10
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 10, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_10_wZTaR7aAiPFw4L08CyRW','tranche_10_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 11
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_11_wZTaR7aAiPFw4L08CyRW','tranche_11_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 12
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 12, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_12_wZTaR7aAiPFw4L08CyRW','tranche_12_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 13
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 13, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_13_wZTaR7aAiPFw4L08CyRW','tranche_13_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 14
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 14, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_14_wZTaR7aAiPFw4L08CyRW','tranche_14_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 15
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 15, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_15_wZTaR7aAiPFw4L08CyRW','tranche_15_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 16
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 16, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_16_wZTaR7aAiPFw4L08CyRW','tranche_16_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 17
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 17, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_17_wZTaR7aAiPFw4L08CyRW','tranche_17_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 18
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 18, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_18_wZTaR7aAiPFw4L08CyRW','tranche_18_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 19
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 19, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_19_wZTaR7aAiPFw4L08CyRW','tranche_19_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);

-- EMD_TRANCHE 20
INSERT INTO HOMEPAGE.EMD_TRANCHE
		(TRANCHE_ID, SEQ_NUMBER, LAST_PROCESSED_DAILY, LAST_PROCESSED_WEEKLY, IS_LOCKED)
VALUES          ('tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 20, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,0);

INSERT INTO HOMEPAGE.EMD_TRANCHE_INFO
                (TRANCHE_INFO_ID, TRANCHE_ID, COUNT_PROCESSED_DAILY, COUNT_PROCESSED_WEEKLY, AVG_EXEC_TIME_DAILY_MIN, AVG_EXEC_TIME_WEEKLY_MIN, DOMAIN_AFFINITY, N_USERS)
VALUES          ('tranche_info_20_wZTaR7aAiPFw4L08CyRW','tranche_20_oPldKwZTaR7aAiPFw4L08CyRW', 0, 0, 0, 0,' ',0);


-------------------------------------------------------------------------
-- END: INIT EMD_TRANCHE
-------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 40 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------


UPDATE  HOMEPAGE.SR_SANDTASKDEF SET SAND_TASK_SERVICES='evidence-graph-manageremployees-tags-taggedby-communitymembership'
WHERE SAND_TASK_ID='fd44131a-5075-4bcb-85a9-9e501bd010fb';


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 40
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 40 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 39;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 39
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
