-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 88 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- Insert a "fake" system admin user in PERSON table
---------------------------------------------------------
INSERT INTO HOMEPAGE.PERSON
		(PERSON_ID,DISPLAYNAME,EXID,STATE) 
VALUES  ('00000000-0000-0000-0000-000000000000','%system_admin','00000000-0000-0000-0000-000000000000',0);
COMMIT;

----------------------------------------------------------------------
-- RENAME REPLYTO COLUMNS - DROP AND CREATE THE TABLES
----------------------------------------------------------------------
    	
DROP TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT;

DROP TABLE HOMEPAGE.NT_REPLYTO; 

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_NOTIFICATION_ID VARCHAR(36) NOT NULL,
	SOURCE VARCHAR(36),
	EVENT_NAME VARCHAR(256) NOT NULL,
	CONTAINER_ID VARCHAR(256),	
	ITEM_ID VARCHAR(36),
	ITEM_CORRELATION_ID VARCHAR(36),	
	CREATION_DATE TIMESTAMP NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT,
	SOURCE_TYPE SMALLINT
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.NT_REPLYTO
    	ADD CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_NOTIFICATION_ID);
    	
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID VARCHAR(36) NOT NULL,
	REPLYTO_NOTIFICATION_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,	
	REPLYTO_ID VARCHAR(36) NOT NULL,
	LAST_UPDATE TIMESTAMP
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_NOT_ID FOREIGN KEY (REPLYTO_NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_NOTIFICATION_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.REPLYTO_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NT_REPLYTO TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NT_REPLYTO_RECIPIENT TO USER LCUSER;

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 88 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- FIX CONSTRAINT ON SOURCE_TYPE FOR NR_ENTRIES_EXTERNAL
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL DROP CONSTRAINT CK_ENT_SRC10_TYPE;

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD CONSTRAINT CK_ENT_SRC100_TYPE
    													CHECK
    													(SOURCE_TYPE >= 100);
COMMIT;

-----------------------------------------------
-- ADD ROLLUP_ENTRY_ID FOREIGN KEY TO READER TABLES
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_PROFILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_BLOGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_FILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_FORUMS_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_WIKIS_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_TAGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD ROLLUP_ENTRY_ID VARCHAR(36);
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 88 FOR SEARCH
------------------------------------------------

--{include.search-fixup88.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 87
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 88 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 87;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
