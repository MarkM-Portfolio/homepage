-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 49 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 49 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CREATE INDEX EMD_RES_PREF_PER_ID
    ON HOMEPAGE.EMD_RESOURCE_PREF (PERSON_ID);
GO    

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
ADD UPDATE_DATE DATETIME; 
GO

--------------------------------------------------------------------------------------------------
--------------- START: UPDATE CONTENT FOR NR_NEWS_STATUS_CONTENT ---------------------------------
--------------------------------------------------------------------------------------------------

-- 1) fixup49 CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT   SET CREATION_DATE = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.CREATION_DATE)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

-- 2) fixup49 UPDATE_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT   SET UPDATE_DATE = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.UPDATE_DATE)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

-- 3) fixup49 TARGET_SUBJECT_ID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT   SET TARGET_SUBJECT_ID = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.TARGET_SUBJECT_ID)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

-- 4) fixup49  ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT   SET  ACTOR_UUID = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.ACTOR_UUID)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

-- 5) fixup49  ITEM_URL
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT   SET  ITEM_URL = 
    (
        SELECT  DISTINCT(NR_NEWS_STATUS_NETWORK.ITEM_URL)
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
        WHERE   NR_NEWS_STATUS_NETWORK.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
    );

--------------------------------------------------------------------------------------------------
--------------- END: UPDATE CONTENT FOR NR_NEWS_STATUS_CONTENT -----------------------------------
--------------------------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 49 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

CREATE INDEX SR_INDEX_DOCS_RPS_IDX
    ON HOMEPAGE.SR_INDEX_DOCS (RESUME_POINT,SERVICE);
GO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 49
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 49 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 48;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 49
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
