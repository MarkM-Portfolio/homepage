-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 46
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 46 FOR HP
------------------------------------------------

--{include.hp-fixup46.sql}

------------------------------------------------
-- INCLUDE FIX UP 46 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
------------------------------------------------------------------------------------
-- 1) ENFORCE A UNIQUE FIELD ON READER_ID, STORY_ID TO AVOID THE USE OF DISTINCT
------------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT COMM_PER_READER_ID, STORY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
-- GROUP BY COMM_PER_READER_ID, STORY_ID
-- HAVING count(*) > 1

-- CREATE A TEMP DUP TABLE
CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

COMMIT;

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PER_STORY_ID, 
            T2.COMM_PER_READER_ID, 
            T2.CONTAINER_ID, 
            T2.ITEM_ID, 
            T2.RESOURCE_TYPE, 
            T2.CATEGORY_TYPE, 
            T2.CREATION_DATE, 
            T2.SOURCE, 
            T2.STORY_ID
    FROM (
            SELECT  COMM_PER_READER_ID, STORY_ID, MAX(COMM_PER_STORY_ID) COMM_PER_STORY_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES
            GROUP BY COMM_PER_READER_ID, STORY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_STORIES T2
    WHERE T1.COMM_PER_STORY_ID = T2.COMM_PER_STORY_ID;

COMMIT;

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_STORIES
    WHERE COMM_PER_STORY_ID IN (
    SELECT  NR_COMM_PERSON_STORIES.COMM_PER_STORY_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_STORIES NR_COMM_PERSON_STORIES,  HOMEPAGE.TMP_COMM_PERSON_STORIES TMP_COMM_PERSON_STORIES
    WHERE   NR_COMM_PERSON_STORIES.COMM_PER_READER_ID = TMP_COMM_PERSON_STORIES.COMM_PER_READER_ID AND
            NR_COMM_PERSON_STORIES.STORY_ID = TMP_COMM_PERSON_STORIES.STORY_ID
);

COMMIT;

-- CREATE THE UNIQUE CONSTRAINTS
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT UNIQUE_COMM_PERSON UNIQUE (COMM_PER_READER_ID, STORY_ID);

COMMIT;

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_STORIES (
    COMM_PER_STORY_ID, 
    COMM_PER_READER_ID, 
    CONTAINER_ID, 
    ITEM_ID, 
    RESOURCE_TYPE, 
    CATEGORY_TYPE, 
    CREATION_DATE, 
    SOURCE, 
    STORY_ID
    )
    SELECT  COMM_PER_STORY_ID, 
            COMM_PER_READER_ID, 
            CONTAINER_ID, 
            ITEM_ID, 
            RESOURCE_TYPE, 
            CATEGORY_TYPE, 
            CREATION_DATE, 
            SOURCE, 
            STORY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_STORIES;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_STORIES use NEWS4TMPTABSPACE;

------------------------------------------------------------------------------------
-- 2) REMOVE NOT NULL CONSTRAINTS FROM EMD_EMAIL_PREFS
------------------------------------------------------------------------------------
-- SEND_DIRECTED
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN SEND_DIRECTED DROP NOT NULL;

-- LANG
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN LANG DROP NOT NULL;

-- USE_TEXT_EMAIL
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN USE_TEXT_EMAIL DROP NOT NULL;

reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 3) NR_COMM_FOLLOW 
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_COMM UNIQUE (PERSON_ID, COMMUNITY_ID);

reorg table HOMEPAGE.NR_COMM_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 4) NR_COMM_PERSON_FOLLOW
-----------------------------------------------------------------------------------
-- Just to check dups records
-- SELECT PERSON_ID, PERSON_COMMUNITY_ID, COUNT(*)
-- FROM  HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW
-- GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
-- HAVING count(*) > 1

CREATE TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	PERSON_COMMUNITY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

COMMIT;

-- INSERT A SIGNLE DUPLICATED RECORD TO SAVE
INSERT INTO HOMEPAGE.TMP_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID, 
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    -- DUPS RECORDS TO SAVE
    SELECT  T2.COMM_PERSON_FOLLOW_ID, 
            T2.PERSON_ID, 
            T2.PERSON_COMMUNITY_ID
    FROM (
            SELECT  PERSON_ID, PERSON_COMMUNITY_ID, MAX(COMM_PERSON_FOLLOW_ID) COMM_PERSON_FOLLOW_ID
            FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW COMM_PERSON_FOLLOW
            GROUP BY PERSON_ID, PERSON_COMMUNITY_ID
            HAVING COUNT(*) > 1
        ) T1, HOMEPAGE.NR_COMM_PERSON_FOLLOW T2
    WHERE T1.COMM_PERSON_FOLLOW_ID = T2.COMM_PERSON_FOLLOW_ID;

COMMIT;

-- REMOVE ALL THE DUPS RECORDS FROM THE ORIGINAL TABLE
DELETE FROM HOMEPAGE.NR_COMM_PERSON_FOLLOW
    WHERE   COMM_PERSON_FOLLOW_ID IN (
    SELECT  NR_COMM_PERSON_FOLLOW.COMM_PERSON_FOLLOW_ID
    FROM    HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW,  HOMEPAGE.TMP_COMM_PERSON_FOLLOW TMP_COMM_PERSON_FOLLOW
    WHERE   NR_COMM_PERSON_FOLLOW.PERSON_ID = TMP_COMM_PERSON_FOLLOW.PERSON_ID AND
            NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = TMP_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID
);

COMMIT;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT UNIQUE_PERS_P_COMM UNIQUE (PERSON_ID, PERSON_COMMUNITY_ID);

COMMIT;

-- COPYING BACK THE SINGLE RECORDS
INSERT INTO HOMEPAGE.NR_COMM_PERSON_FOLLOW (
    COMM_PERSON_FOLLOW_ID,
    PERSON_ID, 
    PERSON_COMMUNITY_ID
    )
    SELECT  COMM_PERSON_FOLLOW_ID, 
            PERSON_ID, 
            PERSON_COMMUNITY_ID
    FROM    HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

COMMIT;

-- REMOVE THE TEMP TABLE
DROP TABLE HOMEPAGE.TMP_COMM_PERSON_FOLLOW;

COMMIT;

reorg table HOMEPAGE.NR_COMM_PERSON_FOLLOW use NEWS4TMPTABSPACE;

-----------------------------------------------------------------------------------
-- 5) ADDING NR_NEWS_DISCOVERY_CREAT_IS_COM
-----------------------------------------------------------------------------------
CREATE INDEX HOMEPAGE.NR_NEWS_DISCOVERY_CREAT_IS_COM
    ON HOMEPAGE.NR_NEWS_DISCOVERY (CREATION_DATE DESC, IS_COMMUNITY_STORY);

reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_NEWS_DISCOVERY;

-----------------------------------------------------------------------------------
-- 6) ADDING TO NR_NEWS_STATUS_NETWORK 
-- CREATION_DATE
-- ACTOR_UUID
-- TARGET_SUBJECT_ID
-- ITEM_URL
-----------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN ACTOR_UUID VARCHAR(36);
    
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN CREATION_DATE TIMESTAMP;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN TARGET_SUBJECT_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
    ADD COLUMN ITEM_URL  VARCHAR(2048);        

reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;

COMMIT;

-- ACTOR_UUID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT NR_NEWS_STATUS_CONTENT SET ACTOR_UUID = (
    SELECT DISTINCT(ACTOR_UUID)
    FROM (
        SELECT  ACTOR_UUID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- CREATION_DATE
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET CREATION_DATE = (
    SELECT DISTINCT(CREATION_DATE)
    FROM (
        SELECT  CREATION_DATE, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- TARGET_SUBJECT_ID
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT  NR_NEWS_STATUS_CONTENT SET TARGET_SUBJECT_ID = (
    SELECT DISTINCT(TARGET_SUBJECT_ID)
    FROM (
        SELECT  TARGET_SUBJECT_ID, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;

-- ITEM_URL
UPDATE HOMEPAGE.NR_NEWS_STATUS_CONTENT NR_NEWS_STATUS_CONTENT SET ITEM_URL = (
    SELECT DISTINCT(ITEM_URL)
    FROM (
        SELECT  ITEM_URL, ITEM_ID
        FROM    HOMEPAGE.NR_NEWS_STATUS_NETWORK NR_NEWS_STATUS_NETWORK
    ) TMP
    WHERE TMP.ITEM_ID = NR_NEWS_STATUS_CONTENT.ITEM_ID
);

COMMIT;


CREATE INDEX HOMEPAGE.NR_NEWS_SC_ITEM_ID
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (ITEM_ID);

CREATE INDEX HOMEPAGE.NR_NEWS_SC_CD
    ON HOMEPAGE.NR_NEWS_STATUS_CONTENT (CREATION_DATE ASC);

COMMIT;

reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;

------------------------------------------------------------------------
-- 7) DROPPING UN-USED INDEXES FROM NR_FOLLOWED_STORIES TABLE
------------------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_FOLLOWED_STORIES_READER;

DROP INDEX HOMEPAGE.NR_FS_READER_CONT;

DROP INDEX HOMEPAGE.NR_FOLLOWED_STORIES_STORY_ID;

reorg indexes all for table HOMEPAGE.NR_FOLLOWED_STORIES;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 46 FOR SEARCH
------------------------------------------------

--{include.search-fixup46.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 46
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 46 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 45;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 46
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
