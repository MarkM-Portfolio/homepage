-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

------------------------------------------------
-- INCLUDE UPGRADE30 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 23;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START HOMEPAGE ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- PERSON
------------------------------------------------

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN IS_ACTIVE SMALLINT DEFAULT 1;

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN USER_MAIL_LOWER VARCHAR(256);

UPDATE HOMEPAGE.PERSON SET USER_MAIL_LOWER =  lower(USER_MAIL);

COMMIT;

ALTER TABLE HOMEPAGE.PERSON
	ADD COLUMN DISPLAYNAME_LOWER VARCHAR(256);	

UPDATE HOMEPAGE.PERSON SET DISPLAYNAME_LOWER =  lower(DISPLAYNAME);

COMMIT;

-- DROP SNCORE_PERSON
DROP VIEW HOMEPAGE.SNCORE_PERSON;
	
CREATE INDEX HOMEPAGE.PERSON_USER_MAIL_LWR
    ON HOMEPAGE.PERSON(USER_MAIL_LOWER ASC);

CREATE INDEX HOMEPAGE.PERSON_DISPLAYNAME_LWR
    ON HOMEPAGE.PERSON(DISPLAYNAME_LOWER ASC);

runstats on table HOMEPAGE.PERSON with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.HP_TAB with distribution and detailed indexes all allow write access;

------------------------------------------------
-- SNCORE_PERSON
------------------------------------------------

CREATE VIEW HOMEPAGE.SNCORE_PERSON (SNC_INTERNAL_ID, SNC_IDKEY, SNC_EMAIL_LOWER, SNC_DISPLAY_NAME) 
    AS SELECT PERSON_ID, EXID, USER_MAIL_LOWER, DISPLAYNAME FROM HOMEPAGE.PERSON;		


------------------------------------------------
-- HP_TAB
------------------------------------------------

ALTER TABLE HOMEPAGE.HP_TAB
	ADD COLUMN ENABLED SMALLINT DEFAULT 1;

---------------------------------------------------------------------------------
---------------- END UPDATE HOMEPAGE DATABASE ----------------    
--------------------------------------------------------------


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 30;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE30 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 30
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- NR_NEWS_RECORDS
------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD COLUMN ITEM_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_RECORDS
	ADD COLUMN ITEM_CORRELATION_ID VARCHAR(36);

---------------------------------------------------------------------------------
------------------------ END NEWS -----------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 30
------------------------------------------------------------------------------------------------

-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 3.0.0
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 30 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 23;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 31
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


---------------------------------------------------------------------------------
------------------------ START NEWS ---------------------------------------------
---------------------------------------------------------------------------------


---------------------------------------------------------------
-- TO MANAGE PARTECIPATION: IMPLICIT SUBSCRIPTION
---------------------------------------------------------------

------------------------------------------------
-- NR_GROUP_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP_TYPE (
	GROUP_TYPE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL,
	GROUP_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
    ADD CONSTRAINT "PK_GROUP_TYPE_ID" PRIMARY KEY("GROUP_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_TYPE 
	ADD CONSTRAINT GROUP_TYPE_UNIQUE UNIQUE(GROUP_TYPE);

------------------------------------------------
-- NR_GROUP
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP (
	GROUP_ID VARCHAR(36) NOT NULL,
	GROUP_NAME VARCHAR(256) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP 
    ADD CONSTRAINT "PK_GROUP_ID" PRIMARY KEY("GROUP_ID");

ALTER TABLE HOMEPAGE.NR_GROUP
	ADD CONSTRAINT "FK_GROUP_TYPE" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

------------------------------------------------
-- NR_PERSON_SOURCE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PERSON_SOURCE (
	PARTICIPATION_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE 
    ADD CONSTRAINT "PK_PART_PER_ID" PRIMARY KEY("PARTICIPATION_ID");

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_READER_PER_ID" FOREIGN KEY ("READER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_SOURCE_PER_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_PERSON_SOURCE
	ADD CONSTRAINT "FK_GROUP_TYPE_PER" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

------------------------------------------------
-- NR_GROUP_SOURCE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_GROUP_SOURCE (
	PARTICIPATION_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	GROUP_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE 
    ADD CONSTRAINT "PK_PART_GRP_ID" PRIMARY KEY("PARTICIPATION_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_READER_GRP_ID" FOREIGN KEY ("READER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_SOURCE_GRP_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_GROUP_SOURCE
	ADD CONSTRAINT "FK_GROUP_TYPE_GRP" FOREIGN KEY ("GROUP_TYPE")
	REFERENCES HOMEPAGE.NR_GROUP_TYPE("GROUP_TYPE");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY_TYPE 
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY_TYPE (
	CATEGORY_TYPE_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE_NAME VARCHAR(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE_DESC VARCHAR(256) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
    ADD CONSTRAINT "PK_CAT_TYPE_ID" PRIMARY KEY("CATEGORY_TYPE_ID");

ALTER TABLE HOMEPAGE.NR_CATEGORY_TYPE 
	ADD CONSTRAINT CAT_TYPE_UNIQUE UNIQUE(CATEGORY_TYPE);

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_CATEGORY
--------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_CATEGORY (
	CATEGORY_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	CATEGORY_NAME VARCHAR(36) NOT NULL, -- this is externalized
	CATEGORY_TYPE SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_CATEGORY
    ADD CONSTRAINT "PK_CATEGORY_ID" PRIMARY KEY("CATEGORY_ID");

ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT "FK_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");
	
ALTER TABLE HOMEPAGE.NR_CATEGORY
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_SOURCE_WATCHED
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_WATCHED (
	SOURCE_ID VARCHAR(36) NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(36) NOT NULL,
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	ENTRY_ID VARCHAR(36),
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	IS_ACL SMALLINT NOT NULL,
	IS_PRIVATE SMALLINT,
	LAST_UPDATE TIMESTAMP,
	IS_CNAME_RTL SMALLINT NOT NULL DEFAULT 0,
	IS_ENAME_RTL SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_SOURCE_WATCHED 
    ADD CONSTRAINT "PK_SRC_WATCHED_ID" PRIMARY KEY("SOURCE_ID");

--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- NR_FOLLOW
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_ID VARCHAR(36) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT "PK_FOLLOW_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_ID" FOREIGN KEY ("CATEGORY_ID")
	REFERENCES HOMEPAGE.NR_CATEGORY("CATEGORY_ID");


--------------------------------------------------------
-- TO MANAGE FOLLOW: WATCHLIST
-- HOMEPAGE.NR_FOLLOW_GROUP
--------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW_GROUP (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_ID VARCHAR(36) NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP 
    ADD CONSTRAINT "PK_FOLLOW_GRP_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_PERSON_GRP_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_FGSOURCE_GRP_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW_GROUP
	ADD CONSTRAINT "FK_CATEGORY_GRP_ID" FOREIGN KEY ("CATEGORY_ID")
	REFERENCES HOMEPAGE.NR_CATEGORY("CATEGORY_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_TOP_UPDATES
---------------------------------------------------------

-- SCRIPT to simulate a new design for the news table --
CREATE TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES 
    ADD CONSTRAINT "PK_TOP_UPDATES_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE..NR_NEWS_SAVED
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_SAVED (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED 
    ADD CONSTRAINT "PK_SAVED_ID" PRIMARY KEY("NEWS_RECORDS_ID");    

---------------------------------------------------------
-- TO MANAGE THE NEWS
-- HOMEPAGE.NR_NEWS_DISCOVERY
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_DISCOVERY (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	-- READER_ID VARCHAR(36), re remove it because it is a discovery table
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL,
	-- IS_SAVED SMALLINT NOT NULL, we cannot save a discovery
	-- IS_TOP_STORY SMALLINT NOT NULL, re remove it because it is a discovery table
	-- IS_PUBLIC SMALLINT NOT NULL, this is always public
	-- IS_MAILED SMALLINT NOT NULL, never used
	-- TIME_STAMP TIMESTAMP NOT NULL, never used
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	-- IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY 
    ADD CONSTRAINT "PK_DISCOVERY_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_WATCHLIST
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_WATCHLIST (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	SOURCE_ID VARCHAR(36), -- reader_id in this context is replaced by source_id
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST 
    ADD CONSTRAINT "PK_WATCHLIST_ID" PRIMARY KEY("NEWS_RECORDS_ID");

---------------------------------------------------------
-- TO MANAGE THE NEWS
--  HOMEPAGE.NR_NEWS_STATUS_NETWORK
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_RECORDS_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	READER_ID VARCHAR(36),
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	-- ENTRY_ID VARCHAR(36), -- REMOVED
	ENTRY_NAME VARCHAR(256),
	ENTRY_URL VARCHAR(2048),
	ENTRY_ATOM_URL VARCHAR(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	-- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
	-- IS_SAVED SMALLINT NOT NULL,
	-- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
	-- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
	-- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
	-- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
	BRIEF_DESC VARCHAR(512),
	IS_BRIEF_DESC_RTL SMALLINT NOT NULL,
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	RELATED_COMM_UUID VARCHAR(36),
	RELATED_COMM_NAME VARCHAR(256),
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	IS_CONTAINER SMALLINT NOT NULL DEFAULT 0,
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0, -- NEW
	GROUP_TYPE SMALLINT NOT NULL DEFAULT 0, -- NEW
	NEWS_STORY_ID VARCHAR(36) NOT NULL -- NEW
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK 
    ADD CONSTRAINT "PK_STATUS_ID" PRIMARY KEY("NEWS_RECORDS_ID");

----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
-- HOMEPAGE.NR_NEWS_STORY
----------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STORY (
	NEWS_STORY_ID VARCHAR(36) NOT NULL,
	CONTENT CLOB NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STORY 
    ADD CONSTRAINT "PK_NEWS_STORY_ID" PRIMARY KEY("NEWS_STORY_ID");

----------------------------------------------------------------------------
-- TO MANAGE NEW STORY and COMMENTS
-- HOMEPAGE.NR_NEWS_COMMENT
----------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT (
	COMMENT_ID VARCHAR(36) NOT NULL,
	NEWS_STORY_ID VARCHAR(36) NOT NULL,
	COMMENT VARCHAR(4096) DEFAULT '' NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT 
    ADD CONSTRAINT "PK_COMMENT_ID" PRIMARY KEY("COMMENT_ID");

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT
	ADD CONSTRAINT "FK_NEWS_STORY_ID" FOREIGN KEY ("NEWS_STORY_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STORY("NEWS_STORY_ID");

COMMIT;

-- GIVING GRANTS TO THE NEW TABLES --
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_PERSON_SOURCE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_GROUP_SOURCE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY_TYPE TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_CATEGORY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_SOURCE_WATCHED TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW_GROUP TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_TOP_UPDATES TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_SAVED TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_DISCOVERY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_WATCHLIST TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STORY TO USER LCUSER;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT TO USER LCUSER;


------------------------------------- RUN STATS ---------------------------------

runstats on table HOMEPAGE.NR_GROUP_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_PERSON_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_GROUP_SOURCE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_CATEGORY_TYPE with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_CATEGORY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_SOURCE_WATCHED with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_FOLLOW_GROUP with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_TOP_UPDATES with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_SAVED with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_DISCOVERY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_WATCHLIST with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STATUS_NETWORK with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_STORY with distribution and detailed indexes all allow write access;
runstats on table HOMEPAGE.NR_NEWS_COMMENT with distribution and detailed indexes all allow write access;


--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------

------------------------------------- MIGRATION DATA ---------------------------------


--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_TOP_UPDATES
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_TOP_STORY = 1 AND READER_ID IS NOT NULL;

COMMIT;

--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_SAVED
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_SAVED
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED, removed as we use a special table to store saved records
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_SAVED = 1;    

COMMIT;

--------------------------------------------------------------------------------------
-- Moving data from the old NR_NEWS_RECORDS to the new table NR_NEWS_TOP_UPDATES
--------------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_NEWS_DISCOVERY
( 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID VARCHAR(36), -- REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX SMALLINT NOT NULL, never used -- REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY SMALLINT NOT NULL, we remove it as it is already a top story table -- REMOVED
            -- IS_PUBLIC SMALLINT NOT NULL, top updates are never public -- REMOVED
            -- IS_MAILED SMALLINT NOT NULL, never used -- REMOVED
            -- TIME_STAMP TIMESTAMP NOT NULL, never used -- REMOVED
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID, -- NEW
            ITEM_CORRELATION_ID, -- NEW
            N_COMMENTS, --N_COMMENTS, -- NEW
            N_RECOMMANDATIONS, --N_RECOMMANDATIONS, -- NEW
            GROUP_TYPE, --GROUP_TYPE, -- NEW
            NEWS_STORY_ID-- NEWS_STORY_ID -- NEW

)
    SELECT 
            NEWS_RECORDS_ID,
            EVENT_NAME,
            -- READER_ID,
            SOURCE,
            CONTAINER_ID,
            CONTAINER_NAME,
            CONTAINER_URL,
            -- ENTRY_ID, REMOVED
            ENTRY_NAME,
            ENTRY_URL,
            ENTRY_ATOM_URL,
            CREATION_DATE,
            -- IS_INBOX, REMOVED
            -- IS_SAVED,
            -- IS_TOP_STORY, we are inserting top stories
            -- IS_PUBLIC,
            -- IS_MAILED,
            -- TIME_STAMP,
            BRIEF_DESC,
            IS_BRIEF_DESC_RTL,
            ACTOR_UUID,
            EVENT_RECORD_UUID,
            RELATED_COMM_UUID,
            RELATED_COMM_NAME,
            TAGS,
            META_TEMPLATE,
            TEXT_META_TEMPLATE,
            -- IS_CONTAINER,
            ITEM_ID,
            ITEM_CORRELATION_ID,
            0,
            0,
            0,
            NEWS_RECORDS_ID
    FROM    HOMEPAGE.NR_NEWS_RECORDS
    WHERE   HOMEPAGE.NR_NEWS_RECORDS.IS_PUBLIC = 1 AND READER_ID IS NULL AND IS_CONTAINER=0;

COMMIT;

-----------------------------------------------------------------------------------------------------------------
-- WATCHLIST
-----------------------------------------------------------------------------------------------------------------

-- INSERTING CATEGORY_TYPE (profiles and tag)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles_c9cax4cc4x8b0bx51af2ddef2cd', 1, '%profile', 'profiles');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('tags_0f1xc9cax4cc4x8b0bx51af2ddef2cd', 2, '%tag', 'tag');

COMMIT;

-- CREATE FOR EACH USERS A DEFAULT CATEGORY FOR EACH CATEGORY TYPE. 
-- THIS TABLE WILL HAVE HAS RESULTS N_USERS X CATEGORY_TYPES RECORDS
INSERT INTO HOMEPAGE.NR_CATEGORY 
    (
        CATEGORY_ID,
        PERSON_ID,
        CATEGORY_NAME,
        CATEGORY_TYPE
    )
    SELECT
        '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || PERSON.PERSON_ID),2,LENGTH(PERSON.PERSON_ID)-2) CATEGORY_ID,
        PERSON.PERSON_ID, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME, 
        NR_CATEGORY_TYPE.CATEGORY_TYPE
    FROM HOMEPAGE.PERSON PERSON, HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE;

COMMIT;

-- SELECT THE PROFILES SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;

COMMIT;

-- SELECT THE TAG SOURCE
INSERT INTO HOMEPAGE.NR_SOURCE_WATCHED
    (
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
    )
SELECT 
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_ID,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        IS_ACL,
        IS_PRIVATE,
        LAST_UPDATE,
        IS_CNAME_RTL,
        IS_ENAME_RTL
FROM HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;

COMMIT;

-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,LENGTH(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles' AND NR_SOURCE.CONTAINER_NAME IS NULL;

COMMIT;

-- CREATE THE RELETIONSHIP FOR TAGS SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_ID    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
         '-' || SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,LENGTH(NR_SUBSCRIPTION.PERSON_ID)-2) CATEGORY_ID
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'tag' AND NR_SOURCE.CONTAINER_NAME IS NOT NULL;

COMMIT;

-- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
-- INSERTING PROFILES STORIES
-- 1 profile status update
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

-- 2 where actor uuid is specified        
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   READER_ID IS NULL AND
        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

-- INSERTING TAGS STORIES
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE_WATCHED.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE_WATCHED NR_SOURCE_WATCHED
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE_WATCHED.CONTAINER_ID;

COMMIT;

UPDATE 	HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING='collection.name;htmlURL'
WHERE 	TEMPLATE_ID='collection-7jEWoKkWx8ucNTo6Z7AndhRFh';

------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 31
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 31 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 30;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Missing fk for NR_NEWS_WATCHLIST
ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT "FK_F_WSOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");
	
-- REMOVING NR_FOLLOW_GROUP table
DROP TABLE HOMEPAGE.NR_FOLLOW_GROUP;

-- REFACTORING THE NR_FOLLOW table; 
DROP TABLE HOMEPAGE.NR_FOLLOW;

-- REMOVING NR_CATEGORY table
DROP TABLE HOMEPAGE.NR_CATEGORY;

------------------------------------------------
-- NR_FOLLOW
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT "PK_FOLLOW_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO USER LCUSER;

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		1
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles';

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		2
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
        NR_SOURCE.SOURCE = 'tag';        

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- 1) UPDATE THE TOP UPDATES TABLE. Adding SOURCE_ID and CATEGORY_TYPE attributes
ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD COLUMN SOURCE_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NR_NEWS_TOP_UPDATES
	ADD COLUMN CATEGORY_TYPE SMALLINT;

REORG TABLE	HOMEPAGE.NR_NEWS_TOP_UPDATES;
	
-- 2) REMOVE IS_ACL FROM NR_SOURCE TABLE
DROP INDEX HOMEPAGE.NR_SOURCE_IX_UNIQUE;

DROP INDEX HOMEPAGE.NR_SOURCE_CONTAINER_NAME_IDX;

ALTER TABLE HOMEPAGE.NR_SOURCE
DROP COLUMN IS_ACL;

REORG TABLE HOMEPAGE.NR_SOURCE;

CREATE UNIQUE INDEX HOMEPAGE.NR_SOURCE_IX_UNIQUE
	ON HOMEPAGE.NR_SOURCE("SOURCE" ASC, "CONTAINER_ID" ASC, "ENTRY_ID" ASC);

CREATE INDEX HOMEPAGE.NR_SOURCE_CONTAINER_NAME_IDX
  	ON HOMEPAGE.NR_SOURCE(SOURCE ASC, CONTAINER_NAME ASC, ENTRY_ID ASC);

-- 3) UPDATE THE FK FOR SOURCE_ID AND REMOVE NR_SOURCE_WATCHED
-- NR_NEWS_WATCHLIST
DELETE FROM HOMEPAGE.NR_NEWS_WATCHLIST;

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
DROP FOREIGN KEY "FK_F_WSOURCE_ID";

ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT "FK_F_WSOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

REORG TABLE HOMEPAGE.NR_NEWS_WATCHLIST;

-- 	NR_FOLLOW
DELETE FROM HOMEPAGE.NR_FOLLOW;

ALTER TABLE HOMEPAGE.NR_FOLLOW
DROP FOREIGN KEY "FK_F_SOURCE_ID";

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE("SOURCE_ID");

REORG TABLE HOMEPAGE.NR_FOLLOW;

DROP TABLE HOMEPAGE.NR_SOURCE_WATCHED;	

-- 4) ADDING THE TABLE TO MANAGE NEWS STATUS NETWORK

DROP TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK;

------------------------------------------------
-- NR_NEWS_STATUS_NETWORK
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK (
	NEWS_STATUS_NETWORK_ID VARCHAR(36) NOT NULL,
	READER_ID VARCHAR(36),
	ACTOR_UUID VARCHAR(36) NOT NULL,
	BRIEF_DESC VARCHAR(500),
	ITEM_URL VARCHAR(2048),
	ITEM_ID  VARCHAR(36),
	EVENT_NAME VARCHAR(36),
	TARGET_SUBJECT_ID VARCHAR(36),
	IS_WALL_POST  SMALLINT NOT NULL DEFAULT 0,
	CREATION_DATE TIMESTAMP,
	UPDATE_DATE TIMESTAMP,
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0,
	IS_NETWORK_NEWS SMALLINT NOT NULL DEFAULT 0,
	IS_FOLLOW_NEWS SMALLINT NOT NULL DEFAULT 0
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK
  	ADD CONSTRAINT "PK_NEWS_STATUS_ID" PRIMARY KEY("NEWS_STATUS_NETWORK_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_NETWORK TO USER LCUSER;  	    

------------------------------------------------
-- NR_NEWS_STATUS_COMMENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT (
	NEWS_STATUS_COMMENT_ID VARCHAR(36) NOT NULL,
	ACTOR_UUID VARCHAR(36) NOT NULL,
	CREATION_DATE TIMESTAMP,
	BRIEF_DESC VARCHAR(500),
	ITEM_ID  VARCHAR(36),
	ITEM_CORRELATION_ID VARCHAR(36),
	ITEM_URL VARCHAR(2048)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_COMMENT
  	ADD CONSTRAINT "PK_NEWS_COMMENT_ID" PRIMARY KEY("NEWS_STATUS_COMMENT_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_COMMENT TO USER LCUSER;  	    

------------------------------------------------
-- NR_NEWS_STATUS_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT (
	NEWS_STATUS_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	ITEM_ID  VARCHAR(36)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_CONTENT
  	ADD CONSTRAINT "PK_S_CONTENT_ID" PRIMARY KEY("NEWS_STATUS_CONTENT_ID");    

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_STATUS_CONTENT TO USER LCUSER; 

------------------------------------------------
-- NR_NEWS_COMMENT_CONTENT
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT (
	NEWS_COMMENT_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M) NOT NULL,
	NEWS_STATUS_COMMENT_ID  VARCHAR(36)
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "PK_C_CONTENT_ID" PRIMARY KEY("NEWS_COMMENT_CONTENT_ID");    

ALTER TABLE HOMEPAGE.NR_NEWS_COMMENT_CONTENT
  	ADD CONSTRAINT "FK_C_COMMENT_ID" FOREIGN KEY ("NEWS_STATUS_COMMENT_ID")
	REFERENCES HOMEPAGE.NR_NEWS_STATUS_COMMENT("NEWS_STATUS_COMMENT_ID");

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_NEWS_COMMENT_CONTENT TO USER LCUSER;
	
----------------------------------------------------
----------------------------------------------------
-- MIGRATION
----------------------------------------------------
----------------------------------------------------

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		1
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles';

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		2
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
        NR_SOURCE.SOURCE = 'tag';

-- POPULATE THE NEW TABLE NR_NEWS_WATCHLIST WHERE WE LINK A STORY TO A SOURCE AND NOT ANYMORE TO A SOURCE_ID
-- INSERTING PROFILES STORIES
-- 1 profile status update
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND NR_NEWS_RECORDS.ACTOR_UUID IS NULL AND
        (NR_NEWS_RECORDS.SOURCE='profiles' AND NR_NEWS_RECORDS.IS_CONTAINER = 1 AND NR_NEWS_RECORDS.CONTAINER_ID IS NOT NULL) AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;

COMMIT;

-- 2 where actor uuid is specified        
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE   READER_ID IS NULL AND
        (NR_NEWS_RECORDS.IS_PUBLIC = 1 AND ACTOR_UUID IS NOT NULL) AND
        NR_NEWS_RECORDS.ACTOR_UUID = NR_SOURCE.CONTAINER_ID;

COMMIT;

-- INSERTING TAGS STORIES
INSERT INTO HOMEPAGE.NR_NEWS_WATCHLIST 
    (
        NEWS_RECORDS_ID,
        EVENT_NAME,
        SOURCE_ID,
        SOURCE,
        CONTAINER_ID,
        CONTAINER_NAME,
        CONTAINER_URL,
        ENTRY_NAME,
        ENTRY_URL,
        ENTRY_ATOM_URL,
        CREATION_DATE,
        BRIEF_DESC,
        IS_BRIEF_DESC_RTL,
        ACTOR_UUID,
        EVENT_RECORD_UUID,
        RELATED_COMM_UUID,
        RELATED_COMM_NAME,
        TAGS,
        META_TEMPLATE,
        TEXT_META_TEMPLATE,
        IS_CONTAINER,
        ITEM_ID,
        ITEM_CORRELATION_ID,
        N_COMMENTS,
        N_RECOMMANDATIONS,
        GROUP_TYPE,
        NEWS_STORY_ID
    )
SELECT 
        NR_NEWS_RECORDS.NEWS_RECORDS_ID,
        NR_NEWS_RECORDS.EVENT_NAME,
        NR_SOURCE.SOURCE_ID,
        NR_NEWS_RECORDS.SOURCE,
        NR_NEWS_RECORDS.CONTAINER_ID,
        NR_NEWS_RECORDS.CONTAINER_NAME,
        NR_NEWS_RECORDS.CONTAINER_URL,
        --NR_NEWS_RECORDS.ENTRY_ID,
        NR_NEWS_RECORDS.ENTRY_NAME,
        NR_NEWS_RECORDS.ENTRY_URL,
        NR_NEWS_RECORDS.ENTRY_ATOM_URL,
        NR_NEWS_RECORDS.CREATION_DATE,
        --NR_NEWS_RECORDS.IS_INBOX,
        --NR_NEWS_RECORDS.IS_SAVED,
        --NR_NEWS_RECORDS.IS_TOP_STORY,
        --NR_NEWS_RECORDS.IS_PUBLIC,
        --NR_NEWS_RECORDS.IS_MAILED,
        --NR_NEWS_RECORDS.TIME_STAMP,
        NR_NEWS_RECORDS.BRIEF_DESC,
        NR_NEWS_RECORDS.IS_BRIEF_DESC_RTL,
        NR_NEWS_RECORDS.ACTOR_UUID,
        NR_NEWS_RECORDS.EVENT_RECORD_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_UUID,
        NR_NEWS_RECORDS.RELATED_COMM_NAME,
        NR_NEWS_RECORDS.TAGS,
        NR_NEWS_RECORDS.META_TEMPLATE,
        NR_NEWS_RECORDS.TEXT_META_TEMPLATE,
        NR_NEWS_RECORDS.IS_CONTAINER,
        NR_NEWS_RECORDS.ITEM_ID,
        NR_NEWS_RECORDS.ITEM_CORRELATION_ID,
        0,
        0,
        0,
        NR_NEWS_RECORDS.NEWS_RECORDS_ID
FROM    HOMEPAGE.NR_NEWS_RECORDS NR_NEWS_RECORDS, HOMEPAGE.NR_SOURCE NR_SOURCE
WHERE   NR_NEWS_RECORDS.READER_ID IS NULL AND
        NR_NEWS_RECORDS.IS_CONTAINER = 1 AND
        NR_NEWS_RECORDS.SOURCE LIKE 'tag%' AND
        NR_NEWS_RECORDS.CONTAINER_ID = NR_SOURCE.CONTAINER_ID;
  	
COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



------------------------------------------------
-- INCLUDE UPGRADE30 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 30-32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

------------------------------------------------
-- HOMEPAGE.SR_FILESCONTENT
------------------------------------------------

-- SPR# MPML7UVM9X
-- Missing index on SR_FILESCONTENT causes full table scan
-- CREATE INDEX HOMEPAGE.SR_FILESCONTENT_IS_CURRENT_IDX 
--	ON HOMEPAGE.SR_FILESCONTENT(IS_CURRENT);

------------------------------------------------
-- HOMEPAGE.SR_FILECONTENTTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FILECONTENTTASKDEF (
	FILECONTENT_TASK_ID VARCHAR(36) NOT NULL,	
	TASK_ID VARCHAR(36) NOT NULL,
	FILE_CONTENT_TASK_SERVICES VARCHAR(256) NOT NULL,
	CONTENT_FAILURES_ONLY SMALLINT NOT NULL	
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "PK_FC_TASK_ID" PRIMARY KEY ("FILECONTENT_TASK_ID");

ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_FC" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_FILECONTENTTASKDEF
	ADD CONSTRAINT "FK_FC_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_BACKUPTASKDEF
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_BACKUPTASKDEF (
	BACKUP_TASK_ID VARCHAR(36) NOT NULL,	
	TASK_ID VARCHAR(36) NOT NULL,
	TYPE VARCHAR(36) NOT NULL,
	SCRIPT VARCHAR(256)
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "PK_BKUP_TASK_ID" PRIMARY KEY ("BACKUP_TASK_ID");	

ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_BKP" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_BACKUPTASKDEF
	ADD CONSTRAINT "FK_BKUP_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_ALLTASKSDEF
------------------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
);

------------------------------------------------
-- HOMEPAGE.SR_INDEX_MANAGEMENT
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_MANAGEMENT (
	NODE_ID VARCHAR(36) NOT NULL,
	LAST_CRAWLING_VERSION BIGINT NOT NULL,
	OUT_OF_DATE SMALLINT NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
	ADD CONSTRAINT "PK_INDEX_MGMT_ID" PRIMARY KEY ("NODE_ID");
	
------------------------------------------------
-- HOMEPAGE.SR_RESUME_TOKENS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_RESUME_TOKENS (
	TOKEN_ID VARCHAR(36) NOT NULL,
	NODE_ID VARCHAR(36) NOT NULL,
	TOKEN VARCHAR(256) NOT NULL,
	SERVICE VARCHAR(36) NOT NULL
)
IN HOMEPAGETABSPACE;


ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT "PK_TOKEN_ID" PRIMARY KEY ("TOKEN_ID");


ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS
	ADD CONSTRAINT "FK_RT_IDX_MGMT_ID" FOREIGN KEY ("NODE_ID")
	REFERENCES HOMEPAGE.SR_INDEX_MANAGEMENT("NODE_ID") ON DELETE CASCADE;

------------------------------------------------
-- HOMEPAGE.SR_INDEX_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_INDEX_DOCS(
	DOCUMENT_ID VARCHAR(36) NOT NULL,
	DOCUMENT BLOB NOT NULL,
	CRAWLING_VERSION BIGINT NOT NULL,
	ACTION SMALLINT NOT NULL,
	UPDATE_TIME  TIMESTAMP NOT NULL,
	RESUME_POINT VARCHAR(256),
	SERVICE VARCHAR(36) NOT NULL,
	FILESCONTENT_ID VARCHAR(36)
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS
	ADD CONSTRAINT "PK_INDEX_DOCS_ID" PRIMARY KEY ("DOCUMENT_ID");

CREATE INDEX HOMEPAGE.SR_INDEX_CRAWL_VERSION_IDX
	ON HOMEPAGE.SR_INDEX_DOCS (CRAWLING_VERSION);

------------------------------------------------
-- HOMEPAGE.SR_FACET_DOCS
------------------------------------------------

CREATE TABLE HOMEPAGE.SR_FACET_DOCS(
	FACET_ID VARCHAR(36) NOT NULL,
	DOCUMENT_ID VARCHAR(36) NOT NULL,
	FACET BLOB NOT NULL,
	CRAWLING_VERSION BIGINT NOT NULL
)
IN HOMEPAGETABSPACE;
	
ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT "PK_FACET_DOCS_ID" PRIMARY KEY ("FACET_ID");
	
-- This statement will be included in FIXUP32
--ALTER TABLE HOMEPAGE.SR_FACET_DOCS
--	ADD CONSTRAINT "FK_IDX_DOC_ID" FOREIGN KEY ("DOCUMENT_ID") 
--	REFERENCES  HOMEPAGE.SR_INDEX_DOCS("DOCUMENT_ID") ON DELETE CASCADE;

CREATE INDEX HOMEPAGE.SR_FACET_DOCS_PARENT_IDX
		ON HOMEPAGE.SR_FACET_DOCS (DOCUMENT_ID);


------------------------------------------
-- START GRANTS
------------------------------------------

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FILECONTENTTASKDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_DOCS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FACET_DOCS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_RESUME_TOKENS TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_BACKUPTASKDEF TO USER LCUSER;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_INDEX_MANAGEMENT TO USER LCUSER;

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--SPR #JJOL82AEP2
DELETE FROM HOMEPAGE.SR_FACET_DOCS WHERE DOCUMENT_ID NOT IN (SELECT DOCUMENT_ID FROM HOMEPAGE.SR_INDEX_DOCS);

ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT "FK_IDX_DOC_ID" FOREIGN KEY ("DOCUMENT_ID") 
	REFERENCES  HOMEPAGE.SR_INDEX_DOCS("DOCUMENT_ID") ON DELETE CASCADE;	

----------------------------------------
--  SR_SANDTASKDEF
----------------------------------------

CREATE TABLE HOMEPAGE.SR_SANDTASKDEF (
    SAND_TASK_ID VARCHAR(36) NOT NULL,
    TASK_ID VARCHAR(36) NOT NULL,
	SAND_TASK_SERVICES VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "PK_ST_TASK_ID" PRIMARY KEY ("SAND_TASK_ID");

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_ST" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "FK_ST_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED) VALUES('ea789e87-c262-484b-92f4-d60af4bef3d4','nightly-sand-task','0 15 1 * * ?','0 0 1 * * ?','SaNDTask',1);

INSERT INTO HOMEPAGE.SR_SANDTASKDEF(SAND_TASK_ID,TASK_ID,SAND_TASK_SERVICES) VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fb','ea789e87-c262-484b-92f4-d60af4bef3d4','evidence-graph-manageremployees-tags-taggedby');

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_SANDTASKDEF TO USER LCUSER;


----------------------------------------
--  SR_ALLTASKSDEF
----------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''			AS	SAND_TASK_SERVICES,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
        ''                 AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
)
UNION
(
        SELECT T9.TASK_ID                               AS      PARENT_TASK_ID,
        T9.TASK_NAME                                    AS      PARENT_TASK_NAME,
        T9.INTERVAL                                             AS      PARENT_TASK_INTERVAL,
        T9.STARTBY                                              AS      PARENT_TASK_STARTBY,
        T9.TASK_TYPE                                    AS      PARENT_TASK_TYPE,
        T9.ENABLED                                              AS      PARENT_TASK_ENABLED,
        ''                                                              AS      INDEXING_TASK_SERVICES,
        0                                                               AS      INDEXING_TASK_OPTIMIZE,
        ''                                                              AS      INDEXING_TASK_ID,
        ''                                                              AS      OPTIMIZE_TASK_ID,
        ''                                              AS      FILECONTENT_TASK_ID,
        ''                                              AS      FILE_CONTENT_TASK_SERVICES,
        0                                               AS      CONTENT_FAILURES_ONLY,
        T10.SAND_TASK_ID                  AS      SAND_TASK_ID,
	T10.SAND_TASK_SERVICES			AS	SAND_TASK_SERVICES,
        ''                                                              AS      BACKUP_TASK_ID,
        ''                                                              AS      BACKUP_TASK_TYPE,
        ''                                                              AS      BACKUP_TASK_SCRIPT,
        T10.SAND_TASK_ID                  AS      CHILDTASK_PK
        FROM   HOMEPAGE.SR_TASKDEF T9,HOMEPAGE.SR_SANDTASKDEF T10
        WHERE  T9.TASK_ID=T10.TASK_ID
);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO USER LCUSER;

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 33
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------


----------------------------------------
--  SR_INDEXINGTASKDEF
----------------------------------------

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=LOWER(INDEXING_TASK_SERVICES);

UPDATE HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES='all_configured' 
WHERE INDEXING_TASK_ID='315a416c-78e2-4cf4-bcb2-69eb8d3a2583';

UPDATE  HOMEPAGE.SR_INDEXINGTASKDEF SET INDEXING_TASK_SERVICES=INDEXING_TASK_SERVICES || '-forums'
WHERE   INDEXING_TASK_SERVICES LIKE '%communities%' AND INDEXING_TASK_SERVICES NOT LIKE '%forums%';

----------------------------------------
--  SR_RESUME_TOKENS
----------------------------------------


CREATE TABLE HOMEPAGE.TMP_SR_RESUME_TOKENS(
	TOKEN_ID VARCHAR(36) NOT NULL,
	NODE_ID VARCHAR(36) NOT NULL,
	TOKEN VARCHAR(256),
	SERVICE VARCHAR(36) NOT NULL
)
IN HOMEPAGETABSPACE;

INSERT INTO HOMEPAGE.TMP_SR_RESUME_TOKENS(
	SELECT TOKEN_ID,NODE_ID,TOKEN,SERVICE FROM HOMEPAGE.SR_RESUME_TOKENS
);

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS 
DROP COLUMN TOKEN;

ALTER TABLE HOMEPAGE.SR_RESUME_TOKENS 
ADD COLUMN TOKEN VARCHAR(256);

RUNSTATS ON TABLE "HOMEPAGE"."SR_RESUME_TOKENS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_RESUME_TOKENS" FOR INDEXES ALL;

reorg table HOMEPAGE.SR_RESUME_TOKENS use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_RESUME_TOKENS;

UPDATE HOMEPAGE.SR_RESUME_TOKENS 
SET TOKEN=( SELECT TMP.TOKEN 
			 FROM HOMEPAGE.TMP_SR_RESUME_TOKENS TMP
			 WHERE  TMP.TOKEN_ID=HOMEPAGE.SR_RESUME_TOKENS.TOKEN_ID
			);

DROP TABLE HOMEPAGE.TMP_SR_RESUME_TOKENS;

----------------------------------------
--  SR_FEEDBACK
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK (
	ID VARCHAR(36) NOT NULL,
	PERSON_ID  VARCHAR(36) NOT NULL,
	CLIENT_ID VARCHAR(256) NOT NULL,
	ACTION VARCHAR(256) NOT NULL,
	FEEDBACK_TIME	TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ITEM_ID  VARCHAR(256) NOT NULL 
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT "PK_FEEDBACK_ID" PRIMARY KEY ("ID");	
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK
	ADD CONSTRAINT "FK_SRFB_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");
	
CREATE INDEX HOMEPAGE.SR_FEEDBACK_CLIENT_IDX
		ON HOMEPAGE.SR_FEEDBACK (CLIENT_ID);

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK TO USER LCUSER;


----------------------------------------
--  SR_FEEDBACK_CONTEXT
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT (
	CONTEXT_ID VARCHAR(36) NOT NULL,
	ID VARCHAR(36) NOT NULL,
	TYPE  VARCHAR(256) NOT NULL,
	TYPE_VALUE VARCHAR(256) NOT NULL,
	WEIGHT VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;


ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT "PK_FBK_CTXT_ID" PRIMARY KEY ("CONTEXT_ID");	

ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT
	ADD CONSTRAINT "FK_FBK_CTXT_ID" FOREIGN KEY ("ID")
	REFERENCES HOMEPAGE.SR_FEEDBACK("ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_CONTEXT";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_CONTEXT" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_CONTEXT TO USER LCUSER;

----------------------------------------
--  SR_FEEDBACK_PARAMETERS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS (
	PARAMETERS_ID VARCHAR(36) NOT NULL,
	ID VARCHAR(36) NOT NULL,
	PARAM  VARCHAR(256) NOT NULL,
	PARAM_VALUE VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT "PK_FBK_PARAMS_ID" PRIMARY KEY ("PARAMETERS_ID");
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS
	ADD CONSTRAINT "FK_FBK_PARAMS_ID" FOREIGN KEY ("ID")
	REFERENCES HOMEPAGE.SR_FEEDBACK("ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_PARAMETERS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FEEDBACK_PARAMETERS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_FEEDBACK_PARAMETERS TO USER LCUSER;

----------------------------------------
--  SR_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STATS(
	STAT_ID		VARCHAR(36) NOT NULL,
	STAT_KEY 	VARCHAR(256) NOT NULL,
	STAT_TYPE	SMALLINT NOT NULL,
	UPDATED		TIMESTAMP NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT "PK_SR_STAT_ID" PRIMARY KEY ("STAT_ID");

ALTER TABLE HOMEPAGE.SR_STATS
	ADD CONSTRAINT "UNIQUE_STAT_KEY" UNIQUE ("STAT_KEY");


RUNSTATS ON TABLE "HOMEPAGE"."SR_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STATS TO USER LCUSER;

----------------------------------------
--  SR_STRING_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_STRING_STATS(
	STRING_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	STAT_VALUE			VARCHAR(256)  NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT "PK_STR_STAT_ID" PRIMARY KEY ("STRING_STAT_ID");

ALTER TABLE HOMEPAGE.SR_STRING_STATS
	ADD CONSTRAINT "FK_STR_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_STRING_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_STRING_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_STRING_STATS TO USER LCUSER;

----------------------------------------
--  SR_NUMBER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_NUMBER_STATS(
	NUMBER_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	STAT_VALUE			BIGINT NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT "PK_NUM_STAT_ID" PRIMARY KEY ("NUMBER_STAT_ID");


ALTER TABLE HOMEPAGE.SR_NUMBER_STATS
	ADD CONSTRAINT "FK_NUM_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_NUMBER_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_NUMBER_STATS" FOR INDEXES ALL;
	
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_NUMBER_STATS TO USER LCUSER;


----------------------------------------
--  SR_TIMER_STATS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_TIMER_STATS(
	TIMER_STAT_ID		VARCHAR(36) NOT NULL,
	STAT_ID				VARCHAR(36) NOT NULL,
	AVERAGE				BIGINT NOT NULL,
	MINIMUM				BIGINT NOT NULL,
	MAXIMUM				BIGINT NOT NULL,
	COUNTER				INTEGER	NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT "PK_TMR_STAT_ID" PRIMARY KEY ("TIMER_STAT_ID");	
	
ALTER TABLE HOMEPAGE.SR_TIMER_STATS
	ADD CONSTRAINT "FK_TMR_STAT_ID" FOREIGN KEY ("STAT_ID")
	REFERENCES HOMEPAGE.SR_STATS("STAT_ID") ON DELETE CASCADE;

RUNSTATS ON TABLE "HOMEPAGE"."SR_TIMER_STATS";
RUNSTATS ON TABLE "HOMEPAGE"."SR_TIMER_STATS" FOR INDEXES ALL;

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_TIMER_STATS TO USER LCUSER;
	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 35
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 36 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 35;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;