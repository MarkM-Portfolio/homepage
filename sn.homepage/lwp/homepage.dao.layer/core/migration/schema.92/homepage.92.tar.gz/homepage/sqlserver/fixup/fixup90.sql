-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 90 FOR HP
------------------------------------------------

--
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON ADD ORGANIZATION_ID nvarchar(36);
ALTER TABLE HOMEPAGE.PERSON ADD COMMUNITY_INTERNAL_ONLY NUMERIC(5 ,0);
GO

-------------------------------------------------------------
-- START: OA updates scripts
-------------------------------------------------------------
INSERT INTO HOMEPAGE.OH_PROVIDER (ID, NAME, DESCRIPTION, REQUESTTOKENURL, AUTHORIZEURL, ACCESSTOKENURL, BASEURL, MANAGEURL, REGISTERURL, CREATEED) 
VALUES ( '00000000-0000-0000-0000-000000000000', 'connectionsProvider', 'IBM Connections OAuth Provider', 'provider/requestToken', 'provider/authorize', 'provider/accessToken', '', 'provider/manageAccess?serviceProvider=connectionsProvider', 'provider/register?serviceProvider=connectionsProvider', CURRENT_TIMESTAMP);

GO

CREATE INDEX OH_CONTEXT_USER_IDX 			ON HOMEPAGE.OH_CONTEXT (USERID);
CREATE INDEX OH_CONTEXT_CLIENT_USER_IDX 	ON HOMEPAGE.OH_CONTEXT (CLIENTID,USERID);
CREATE INDEX OH_CLIENT_USERNAME_IDX 		ON HOMEPAGE.OH_CLIENT (USERNAME);

GO


-- DROP UNIQUE INDEXES
DROP INDEX APP_PROVIDER_IDX ON HOMEPAGE.OH_APPLICATION;

DROP INDEX CLIENT_PROVIDER_IDX ON HOMEPAGE.OH_CLIENT;
DROP INDEX CLIENT_TOKEN_IDX ON HOMEPAGE.OH_CLIENT;	

DROP INDEX CONTEXT_CLIENT_IDX ON HOMEPAGE.OH_CONTEXT;
DROP INDEX CONTEXT_TOKEN_IDX ON HOMEPAGE.OH_CONTEXT;

DROP INDEX ACL_CONTEXT_IDX ON HOMEPAGE.OH_OAUTHACL;
DROP INDEX ACL_APP_IDX ON HOMEPAGE.OH_OAUTHACL;

GO

-- RECREATE
CREATE INDEX APP_PROVIDER_IDX 				ON HOMEPAGE.OH_APPLICATION (PROVIDERID);

CREATE INDEX CLIENT_PROVIDER_IDX 			ON HOMEPAGE.OH_CLIENT (PROVIDERID);
CREATE INDEX CLIENT_TOKEN_IDX 				ON HOMEPAGE.OH_CLIENT (TOKENID);	

CREATE INDEX CONTEXT_CLIENT_IDX 			ON HOMEPAGE.OH_CONTEXT (CLIENTID);
CREATE INDEX CONTEXT_TOKEN_IDX 				ON HOMEPAGE.OH_CONTEXT (TOKENID);

CREATE INDEX ACL_CONTEXT_IDX 				ON HOMEPAGE.OH_OAUTHACL (CONTEXTID);
CREATE INDEX ACL_APP_IDX 					ON HOMEPAGE.OH_OAUTHACL (AUTHORIZEDAPPID);

GO

-------------------------------------------------------------
-- END START: OA updates scripts
-------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 90 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.NR_COMM_SETTINGS;

-----------------------------------------------
-- HOMEPAGE.NR_COMM_SETTINGS
-----------------------------------------------

CREATE TABLE HOMEPAGE.NR_COMM_SETTINGS (
	COMM_ID nvarchar(36) NOT NULL,
	MICROBLOGGING_WRITE_ACL NUMERIC(5 ,0),
	FLAGS nvarchar(36)
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS
    ADD CONSTRAINT PK_COMM_ID PRIMARY KEY(COMM_ID);


GO 

-----------------------------------------------------
-- NR_PROFILES_VIEW
-----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PROFILES_VIEW (
	CATEGORY_READER_ID nvarchar(36)  DEFAULT ' ' NOT NULL,
	READER_ID nvarchar(36),
	CATEGORY_TYPE NUMERIC(5,0) NOT NULL,
	SOURCE nvarchar(36) NOT NULL,
	CONTAINER_ID nvarchar(256),
	ITEM_ID nvarchar(36),
	ROLLUP_ENTRY_ID nvarchar(36),
	RESOURCE_TYPE NUMERIC(5,0) NOT NULL,
	CREATION_DATE DATETIME NOT NULL,
	STORY_ID nvarchar(36) NOT NULL,
	SOURCE_TYPE NUMERIC(5,0),
	USE_IN_ROLLUP NUMERIC(5,0),
	IS_NETWORK	NUMERIC(5,0),
	IS_FOLLOWER	NUMERIC(5,0),
	EVENT_TIME 	DATETIME,
	IS_STORY_COMM NUMERIC(5 ,0),
	IS_BROADCAST NUMERIC(5 ,0),
	ORGANIZATION_ID nvarchar(36),
	CONSTRAINT   	CK_CAT18_TYPE
    				CHECK
    				(CATEGORY_TYPE = 18)
)
ON [PRIMARY]
GO
ALTER TABLE HOMEPAGE.NR_PROFILES_VIEW 
    ADD CONSTRAINT PK_PROFILES_VIEW PRIMARY KEY(CATEGORY_READER_ID);

CREATE INDEX PROFILES_VIEW_IDX
    ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, CREATION_DATE ASC);

CREATE INDEX PROFILES_SIDX
    ON HOMEPAGE.NR_PROFILES_VIEW (STORY_ID);

CREATE INDEX PROFILES_ITEM
    ON HOMEPAGE.NR_PROFILES_VIEW (ITEM_ID);

CREATE INDEX PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE ASC);

CREATE UNIQUE INDEX PROFILES_READER_STORY 		
	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, STORY_ID); 



---------------------------------------------------------------------------------
-- Adding a new category for profiles view
---------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles-view', 18, '%profiles', 'profiles');

---------------------------------------------------------------------------------
-- Adding IS_BROADCAST to ALL the readers table
---------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  ORGANIZATION_ID nvarchar(36);
GO
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  ORGANIZATION_ID nvarchar(36);

GO
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  IS_BROADCAST NUMERIC(5,0);
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  ORGANIZATION_ID nvarchar(36);

GO

-------------------------------------------------------------------------------
-- ADDING ACTIVITY_META_DATA_1 and ACTIVITY_META_DATA_2
-------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_1 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_2 nvarchar(4000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  IS_META_DATA_TRUNCATED NUMERIC(5,0);
GO

-------------------------------------------------------------------
-- REMOVING NR_ORGPERSON_FOLLOW AND NR_ORGPERSON_STORIES
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
DROP TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW;
GO

-------------------------------------------------------------------
-- Add to: NR_ENTRIES_* the column SCOPE
-------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_ACT			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_BLG			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_COM			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_WIK			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_PRF			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_HP			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_DGR			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FILE		ADD  SCOPE NUMERIC(5,0);	
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FRM			ADD  SCOPE NUMERIC(5,0);
GO
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_EXTERNAL	ADD  SCOPE NUMERIC(5,0);
GO
---------------------------------
-- CONVERT BLOB to CLOB
---------------------------------
-- TODO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 90 FOR SEARCH
------------------------------------------------

--{include.search-fixup90.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 90
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 90 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 89 OR DBSCHEMAVER = 69;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

