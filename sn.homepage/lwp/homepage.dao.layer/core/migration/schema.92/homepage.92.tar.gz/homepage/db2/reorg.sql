-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- to create a new baseline
connect to HOMEPAGE;

-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- to create a new baseline

reorg table HOMEPAGE.HOMEPAGE_SCHEMA use TEMPSPACE1;
reorg table HOMEPAGE.PERSON use TEMPSPACE1;
reorg table HOMEPAGE.LOGINNAME use TEMPSPACE1;
reorg table HOMEPAGE.PREREQ use TEMPSPACE1;
reorg table HOMEPAGE.WIDGET use TEMPSPACE1;

reorg table HOMEPAGE.HP_UI use TEMPSPACE1;
reorg table HOMEPAGE.HP_TAB use TEMPSPACE1;
reorg table HOMEPAGE.HP_TAB_INST use TEMPSPACE1;
reorg table HOMEPAGE.HP_WIDGET_INST use TEMPSPACE1;
reorg table HOMEPAGE.HP_WIDGET_TAB use TEMPSPACE1;

reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;

reorg table HOMEPAGE.MT_METRIC_STAT use TEMPSPACE1;

reorg table HOMEPAGE.OH_TOKEN use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.OH_PROVIDER use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.OH_CLIENT use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.OH_CONTEXT use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.OH_APPLICATION use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.OH_OAUTHACL use HPNT16TMPTABSPACE;

-------------------------------------------------------

reorg indexes all for table HOMEPAGE.NT_NOTIFICATION;
reorg indexes all for table HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

reorg indexes all for table HOMEPAGE.PERSON;
reorg indexes all for table HOMEPAGE.LOGINNAME;
reorg indexes all for table HOMEPAGE.PREREQ;
reorg indexes all for table HOMEPAGE.WIDGET;

reorg indexes all for table HOMEPAGE.HP_UI;
reorg indexes all for table HOMEPAGE.HP_TAB;
reorg indexes all for table HOMEPAGE.HP_TAB_INST;
reorg indexes all for table HOMEPAGE.HP_WIDGET_INST;
reorg indexes all for table HOMEPAGE.HP_WIDGET_TAB;

reorg indexes all for table HOMEPAGE.MT_METRIC_STAT;

-- NEW SECTION 3.5
reorg table HOMEPAGE.NT_REPLYTO use HPNT16TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NT_REPLYTO;

reorg table HOMEPAGE.NT_REPLYTO_RECIPIENT use HPNT16TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NT_REPLYTO_RECIPIENT;

reorg indexes all for table HOMEPAGE.OH_TOKEN;
reorg indexes all for table HOMEPAGE.OH_PROVIDER;
reorg indexes all for table HOMEPAGE.OH_CLIENT;
reorg indexes all for table HOMEPAGE.OH_CONTEXT;
reorg indexes all for table HOMEPAGE.OH_APPLICATION;
reorg indexes all for table HOMEPAGE.OH_OAUTHACL;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE 
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--NEWS

-- to create a new baseline


reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;

reorg table HOMEPAGE.NR_SOURCE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SUBSCRIPTION use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_RECORDS use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_TEMPLATE use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_SCHEDULER_LMGR use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_LMPR use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_TASK use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_TREG use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_NEWS_SAVED use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_NEWS_COMMENT_CONTENT use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_COMMENT use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_NETWORK use NEWSTMPTABSPACE;


reorg table HOMEPAGE.NR_NETWORK use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_COMM_STORIES use NEWS4TMPTABSPACE;

reorg table HOMEPAGE.NR_COMM_FOLLOW use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_FOLLOWS use NEWS4TMPTABSPACE;	
reorg table HOMEPAGE.NR_RESOURCE use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_RESOURCE_TYPE use NEWS4TMPTABSPACE;

reorg table HOMEPAGE.NR_COMM_PERSON_FOLLOW use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.NR_AGGREGATED_READERS use NEWS4TMPTABSPACE;

reorg table HOMEPAGE.EMD_FREQUENCY_TYPE use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.EMD_RESOURCE_PREF use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.EMD_TRANCHE use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;
reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

reorg table HOMEPAGE.NR_COMM_SETTINGS use NEWS4TMPTABSPACE;

-------------------------------------------------------



reorg indexes all for table HOMEPAGE.NR_SOURCE;
reorg indexes all for table HOMEPAGE.NR_SUBSCRIPTION;
reorg indexes all for table HOMEPAGE.NR_NEWS_RECORDS;
reorg indexes all for table HOMEPAGE.NR_TEMPLATE;

reorg indexes all for table HOMEPAGE.NR_SCHEDULER_LMGR;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_LMPR;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_TASK;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_TREG;

reorg indexes all for table HOMEPAGE.NR_NEWS_SAVED;
reorg indexes all for table HOMEPAGE.NR_NEWS_DISCOVERY;

reorg indexes all for table HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_COMMENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_NETWORK;

reorg indexes all for table HOMEPAGE.NR_NETWORK;
reorg indexes all for table HOMEPAGE.NR_STORIES_CONTENT;
reorg indexes all for table HOMEPAGE.NR_COMM_STORIES;

reorg indexes all for table HOMEPAGE.NR_COMM_FOLLOW;
reorg indexes all for table HOMEPAGE.NR_FOLLOWS;	
reorg indexes all for table HOMEPAGE.NR_RESOURCE;
reorg indexes all for table HOMEPAGE.NR_RESOURCE_TYPE;

reorg indexes all for table HOMEPAGE.NR_COMM_PERSON_FOLLOW;
reorg indexes all for table HOMEPAGE.NR_AGGREGATED_READERS;

reorg indexes all for table HOMEPAGE.EMD_FREQUENCY_TYPE;
reorg indexes all for table HOMEPAGE.EMD_RESOURCE_PREF;
reorg indexes all for table HOMEPAGE.EMD_TRANCHE;
reorg indexes all for table HOMEPAGE.EMD_TRANCHE_INFO;
reorg indexes all for table HOMEPAGE.EMD_EMAIL_PREFS;

reorg indexes all for table HOMEPAGE.NR_COMM_SETTINGS;

reorg table HOMEPAGE.NR_RESPONSES_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_RESPONSES_READERS;
reorg table HOMEPAGE.NR_PROFILES_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_PROFILES_READERS;
reorg table HOMEPAGE.NR_COMMUNITIES_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_COMMUNITIES_READERS;
reorg table HOMEPAGE.NR_ACTIVITIES_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_ACTIVITIES_READERS;
reorg table HOMEPAGE.NR_BLOGS_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_BLOGS_READERS;
reorg table HOMEPAGE.NR_BOOKMARKS_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_BOOKMARKS_READERS;
reorg table HOMEPAGE.NR_FILES_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_FILES_READERS;
reorg table HOMEPAGE.NR_FORUMS_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_FORUMS_READERS;
reorg table HOMEPAGE.NR_WIKIS_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_WIKIS_READERS;
reorg table HOMEPAGE.NR_TAGS_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_TAGS_READERS;

reorg table  HOMEPAGE.NR_STATUS_UPDATE_READERS use NEWS4TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_STATUS_UPDATE_READERS;

reorg table HOMEPAGE.NR_SRC_STORIES_ACT use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_ACT;

reorg table HOMEPAGE.NR_SRC_STORIES_BLG use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_BLG;

reorg table HOMEPAGE.NR_SRC_STORIES_COM use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_COM;

reorg table HOMEPAGE.NR_SRC_STORIES_WIK use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_WIK;

reorg table HOMEPAGE.NR_SRC_STORIES_PRF use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_PRF;

reorg table HOMEPAGE.NR_SRC_STORIES_HP use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_HP;

reorg table HOMEPAGE.NR_SRC_STORIES_DGR use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_DGR;

reorg table HOMEPAGE.NR_SRC_STORIES_FILE use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_FILE;

reorg table HOMEPAGE.NR_SRC_STORIES_FRM use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_FRM;

reorg table HOMEPAGE.NR_SRC_STORIES_EXTERNAL  use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_EXTERNAL;



--------------------------------------------------------------
-- NEW TABLES FOR 3.5
--------------------------------------------------------------
reorg table HOMEPAGE.NR_RECOMMENDATION;
reorg indexes all for table HOMEPAGE.NR_RECOMMENDATION;
reorg table HOMEPAGE.NR_ATTACHMENT;
reorg indexes all for table HOMEPAGE.NR_ATTACHMENT;

-- BOARD
reorg table HOMEPAGE.BOARD_ENTRIES;
reorg indexes all for table  HOMEPAGE.BOARD_ENTRIES;

reorg table HOMEPAGE.BOARD_COMMENTS;   
reorg indexes all for table  HOMEPAGE.BOARD_COMMENTS;

reorg table HOMEPAGE.BOARD_OBJECT_REFERENCE;
reorg indexes all for table  HOMEPAGE.BOARD_OBJECT_REFERENCE;

reorg table HOMEPAGE.BOARD_RECOMMENDATIONS;
reorg indexes all for table  HOMEPAGE.BOARD_RECOMMENDATIONS;

reorg table HOMEPAGE.BOARD_CURRENT_STATUS;
reorg indexes all for table  HOMEPAGE.BOARD_CURRENT_STATUS;

reorg table HOMEPAGE.BOARD;
reorg indexes all for table  HOMEPAGE.BOARD;

reorg table HOMEPAGE.NR_ENTRIES_ACT;
reorg table HOMEPAGE.NR_ENTRIES_BLG;
reorg table HOMEPAGE.NR_ENTRIES_COM;
reorg table HOMEPAGE.NR_ENTRIES_WIK;
reorg table HOMEPAGE.NR_ENTRIES_PRF;
reorg table HOMEPAGE.NR_ENTRIES_HP;
reorg table HOMEPAGE.NR_ENTRIES_DGR;
reorg table HOMEPAGE.NR_ENTRIES_FILE;
reorg table HOMEPAGE.NR_ENTRIES_FRM;
reorg table HOMEPAGE.NR_ENTRIES_EXTERNAL;

reorg indexes all for table HOMEPAGE.NR_ENTRIES_ACT;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_BLG;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_COM;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_WIK;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_PRF;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_HP;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_DGR;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_FILE;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_FRM;
reorg indexes all for table HOMEPAGE.NR_ENTRIES_EXTERNAL;

-------------------------
reorg table HOMEPAGE.NR_ACTIONABLE_READERS;
reorg indexes all for table HOMEPAGE.NR_ACTIONABLE_READERS;

reorg table HOMEPAGE.NR_DISCOVERY_VIEW;
reorg table HOMEPAGE.NR_PROFILES_VIEW;
reorg indexes all for table HOMEPAGE.NR_DISCOVERY_VIEW;
reorg indexes all for table HOMEPAGE.NR_PROFILES_VIEW;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS 
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- to create a new baseline

-- SEARCH
reorg table HOMEPAGE.SR_INDEXINGTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_OPTIMIZETASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_TASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_FILESCONTENT use TEMPSPACE1;
reorg table HOMEPAGE.SR_MIGTASKDEFINFO use TEMPSPACE1;
reorg table HOMEPAGE.SR_FILECONTENTTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_INDEX_DOCS use TEMPSPACE1;
reorg table HOMEPAGE.SR_FACET_DOCS use TEMPSPACE1;
reorg table HOMEPAGE.SR_RESUME_TOKENS use TEMPSPACE1;
reorg table HOMEPAGE.SR_BACKUPTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_INDEX_MANAGEMENT use TEMPSPACE1;
reorg table HOMEPAGE.SR_SANDTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK_CONTEXT use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK_PARAMETERS use TEMPSPACE1;
reorg table HOMEPAGE.SR_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_STRING_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_NUMBER_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_TIMER_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_GLOBAL_SAND_PROPS use TEMPSPACE1;

reorg table HOMEPAGE.LOTUSCONNECTIONSLMGR use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSLMPR use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSTASK use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSTREG use TEMPSPACE1;

-------------------------------------------------------


-- SEARCH
reorg indexes all for table HOMEPAGE.SR_INDEXINGTASKDEF;
reorg indexes all for table HOMEPAGE.SR_OPTIMIZETASKDEF;
reorg indexes all for table HOMEPAGE.SR_TASKDEF;
reorg indexes all for table HOMEPAGE.SR_FILESCONTENT;
reorg indexes all for table HOMEPAGE.SR_MIGTASKDEFINFO;
reorg indexes all for table HOMEPAGE.SR_FILECONTENTTASKDEF;
reorg indexes all for table HOMEPAGE.SR_INDEX_DOCS;
reorg indexes all for table HOMEPAGE.SR_FACET_DOCS;
reorg indexes all for table HOMEPAGE.SR_RESUME_TOKENS;
reorg indexes all for table HOMEPAGE.SR_BACKUPTASKDEF;
reorg indexes all for table HOMEPAGE.SR_INDEX_MANAGEMENT;
reorg indexes all for table HOMEPAGE.SR_SANDTASKDEF;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK_CONTEXT;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK_PARAMETERS;
reorg indexes all for table HOMEPAGE.SR_STATS;
reorg indexes all for table HOMEPAGE.SR_STRING_STATS;
reorg indexes all for table HOMEPAGE.SR_NUMBER_STATS;
reorg indexes all for table HOMEPAGE.SR_TIMER_STATS;
reorg indexes all for table HOMEPAGE.SR_GLOBAL_SAND_PROPS;

reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSLMGR;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSLMPR;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSTASK;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSTREG;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE 
-----------------------------------------------------------------------------------------------------------


COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 
