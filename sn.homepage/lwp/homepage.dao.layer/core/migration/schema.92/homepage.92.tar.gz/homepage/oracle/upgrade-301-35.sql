-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

------------------------------------------------
-- INCLUDE UPGRADE35 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36),
	EVENT_NAME VARCHAR2(256) NOT NULL,
	CONTAINER_ID VARCHAR2(256),	
	ITEM_ID VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),	
	CREATION_DATE TIMESTAMP NOT NULL,
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD (CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

COMMIT;

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID VARCHAR2(36) NOT NULL,
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	PERSON_ID VARCHAR2(36) NOT NULL,	
	REPLYTO_ADDRESS_ID VARCHAR2(36) NOT NULL,
	LAST_UPDATE TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD (CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_ID FOREIGN KEY (REPLYTO_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.REPLYTO_ADDRESS_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ADDRESS_ID) TABLESPACE "HPNTINDEXTABSPACE";



COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_NOTIFICATION
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ADD NOTIFICATION_SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 1 WHERE NOTIFICATION_SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 2 WHERE NOTIFICATION_SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 3 WHERE NOTIFICATION_SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 4 WHERE NOTIFICATION_SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 5 WHERE NOTIFICATION_SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 6 WHERE NOTIFICATION_SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 7 WHERE NOTIFICATION_SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 8 WHERE NOTIFICATION_SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NT_NOTIFICATION
	SET NOTIFICATION_SOURCE_TYPE = 9 WHERE NOTIFICATION_SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NT_REPLYTO
--------------------------------------------
ALTER TABLE HOMEPAGE.NT_REPLYTO
	ADD SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NT_REPLYTO
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;    

 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
-- SPR #JSTH8EZJXT - Removing dups records from HP_UI table and others issues like EMD delviery locks
---------------------------------------------------------------------------------

DELETE FROM HOMEPAGE.HP_WIDGET_INST WHERE WIDGET_INST_ID IN 
(
	SELECT HP_WIDGET_INST.WIDGET_INST_ID
	FROM HOMEPAGE.HP_WIDGET_INST HP_WIDGET_INST,
		(
			SELECT  	HP_TAB_INST.TAB_INST_ID
			FROM 	HOMEPAGE.HP_TAB_INST HP_TAB_INST,
					(
						SELECT UI_ID 
						FROM HOMEPAGE.HP_UI HP_UI 
						INNER JOIN (
								SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
								GROUP BY PERSON_ID 
								HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
						WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	) TMP_UI
			WHERE	HP_TAB_INST.UI_ID = TMP_UI.UI_ID
		) TMP_TAB_INST
	WHERE HP_WIDGET_INST.TAB_INST_ID = TMP_TAB_INST.TAB_INST_ID
);

COMMIT;

DELETE FROM HOMEPAGE.HP_TAB_INST WHERE TAB_INST_ID IN 
(
	SELECT  HP_TAB_INST.TAB_INST_ID
	FROM HOMEPAGE.HP_TAB_INST HP_TAB_INST,
		(
			SELECT UI_ID 
			FROM HOMEPAGE.HP_UI HP_UI 
			INNER JOIN (
					SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
					GROUP BY PERSON_ID 
					HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
			WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	) TMP_UI
	WHERE	HP_TAB_INST.UI_ID = TMP_UI.UI_ID
);

COMMIT;

DELETE FROM HOMEPAGE.HP_UI WHERE UI_ID IN
(
	SELECT UI_ID 
	FROM HOMEPAGE.HP_UI HP_UI 
	INNER JOIN (
			SELECT PERSON_ID,MAX(LAST_VISIT) AS MAX_LAST_VISIT 	FROM HOMEPAGE.HP_UI 
			GROUP BY PERSON_ID 
			HAVING COUNT(*) > 1) T ON HP_UI.PERSON_ID = T.PERSON_ID
	WHERE HP_UI.LAST_VISIT < T.MAX_LAST_VISIT	
);

COMMIT;

DROP INDEX HOMEPAGE.HP_UI_PERSON_ID_INDEX;

CREATE UNIQUE INDEX HOMEPAGE.HP_UI_UNQ
	ON HOMEPAGE.HP_UI (PERSON_ID) TABLESPACE "HPNTINDEXTABSPACE";

COMMIT;

---------------------------------------------------------------------------------
--------------------------------------------------------------------------------- 
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 86
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON
	ADD PROF_TYPE VARCHAR2(128);

-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- START: OAUTH TABLES
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: OAUTH Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

------------------------------------------------
-- TOKEN
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_TOKEN (
	ID VARCHAR2(36) NOT NULL,
	TOKEN VARCHAR2(1024) NOT NULL,
	SECRET VARCHAR2(1024)NOT NULL,
	EXPIRATION TIMESTAMP,
	CREATED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_TOKEN 
    ADD (CONSTRAINT PK_OH_TOKEN_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");
    
ALTER TABLE HOMEPAGE.OH_TOKEN ENABLE ROW MOVEMENT;    

------------------------------------------------
-- PROVIDER
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_PROVIDER (
	ID VARCHAR2(36) NOT NULL,
	NAME VARCHAR2(256) NOT NULL,
	DESCRIPTION VARCHAR2(1024),
	REQUESTTOKENURL VARCHAR2(512) NOT NULL,
	AUTHORIZEURL VARCHAR2(512) NOT NULL,
	ACCESSTOKENURL VARCHAR2(512) NOT NULL,
	BASEURL VARCHAR2(512),
	MANAGEURL VARCHAR2(512),	
	REGISTERURL VARCHAR2(512),	
	SIGNMETHOD VARCHAR2(32),
	VERSION VARCHAR2(8),
	CREATEED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_PROVIDER
    ADD (CONSTRAINT PK_PROVIDER_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

CREATE UNIQUE INDEX HOMEPAGE.PRVD_NAME_UNIQUE 
	ON HOMEPAGE.OH_PROVIDER (NAME);

ALTER TABLE HOMEPAGE.OH_PROVIDER ENABLE ROW MOVEMENT;	
	
------------------------------------------------
-- CLIENT
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_CLIENT (
	ID VARCHAR2(36) NOT NULL,
	NAME VARCHAR2(256) NOT NULL,
	TOKENID VARCHAR2(36) NOT NULL,
	PROVIDERID VARCHAR2(36) NOT NULL,
	DESCRIPTION VARCHAR2(1024),
	CALLBACKURL VARCHAR2(512),
	USERNAME VARCHAR2(256) NOT NULL,
	CREATEED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_CLIENT
    ADD (CONSTRAINT PK_CLIENT_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

CREATE UNIQUE INDEX HOMEPAGE.CLNT_NAME_UNIQUE
	ON HOMEPAGE.OH_CLIENT (NAME);

ALTER TABLE HOMEPAGE.OH_CLIENT
	ADD CONSTRAINT FK_CLIENT_PRO_ID FOREIGN KEY (PROVIDERID)
	REFERENCES HOMEPAGE.OH_PROVIDER(ID);

ALTER TABLE HOMEPAGE.OH_CLIENT
	ADD CONSTRAINT FK_CLIENT_TOKEN_ID FOREIGN KEY (TOKENID)
	REFERENCES HOMEPAGE.OH_TOKEN(ID);

CREATE UNIQUE INDEX HOMEPAGE.CLIENT_PROVIDER_IDX
    ON HOMEPAGE.OH_CLIENT (PROVIDERID);

CREATE UNIQUE INDEX HOMEPAGE.CLIENT_TOKEN_IDX
    ON HOMEPAGE.OH_CLIENT (TOKENID);	

ALTER TABLE HOMEPAGE.OH_CLIENT ENABLE ROW MOVEMENT;
    
------------------------------------------------
-- CONTEXT
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_CONTEXT (
	ID VARCHAR2(36) NOT NULL,
	CLIENTID VARCHAR2(36) NOT NULL,
	USERID VARCHAR2(256),
	CALLBACKURL VARCHAR2(1024),
	REQUESTAUTHURL VARCHAR2(1024),
	TOKENID VARCHAR2(36) NOT NULL,
	CREATED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP,
	SESSIONHANDLE VARCHAR2(256),
	REFERER VARCHAR2(512),
	EXPIRATION TIMESTAMP,
	AUTHORIZED NUMBER(5,0),
	COMPLETED NUMBER(5,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_CONTEXT
    ADD (CONSTRAINT PK_CONTEXT_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.OH_CONTEXT
	ADD CONSTRAINT FK_CNTXT_CLIENT_ID FOREIGN KEY (CLIENTID)
	REFERENCES HOMEPAGE.OH_CLIENT(ID);

ALTER TABLE HOMEPAGE.OH_CONTEXT
	ADD CONSTRAINT FK_CNTXT_TOKEN_ID FOREIGN KEY (TOKENID)
	REFERENCES HOMEPAGE.OH_TOKEN(ID);

CREATE UNIQUE INDEX HOMEPAGE.CONTEXT_CLIENT_IDX
    ON HOMEPAGE.OH_CONTEXT (CLIENTID);

CREATE UNIQUE INDEX HOMEPAGE.CONTEXT_TOKEN_IDX
    ON HOMEPAGE.OH_CONTEXT (TOKENID);

ALTER TABLE HOMEPAGE.OH_CONTEXT ENABLE ROW MOVEMENT;

------------------------------------------------
-- APPLICATION
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_APPLICATION (
	ID VARCHAR2(36) NOT NULL,
	NAME VARCHAR2(256) NOT NULL,
	DESCRIPTION VARCHAR2(1024),
	BASEURL VARCHAR2(512) NOT NULL,
	SECUREBASEURL VARCHAR2(512),
	PROVIDERID VARCHAR2(36) NOT NULL,
	CREATEED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_APPLICATION
    ADD (CONSTRAINT PK_APP_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

CREATE UNIQUE INDEX HOMEPAGE.APP_NAME_UNIQUE
	ON HOMEPAGE.OH_APPLICATION (NAME);

ALTER TABLE HOMEPAGE.OH_APPLICATION
	ADD CONSTRAINT FK_APP_PROVIDER_ID FOREIGN KEY (PROVIDERID)
	REFERENCES HOMEPAGE.OH_PROVIDER(ID);

CREATE UNIQUE INDEX HOMEPAGE.APP_PROVIDER_IDX
    ON HOMEPAGE.OH_APPLICATION (PROVIDERID);

ALTER TABLE HOMEPAGE.OH_APPLICATION ENABLE ROW MOVEMENT;

------------------------------------------------
-- OAUTHACL
------------------------------------------------
CREATE TABLE HOMEPAGE.OH_OAUTHACL (
	ID VARCHAR2(36) NOT NULL,
	CONTEXTID VARCHAR2(36) NOT NULL,
	AUTHORIZETYPE NUMBER(5,0),
	AUTHORIZEDAPPID VARCHAR2(36),
	CREATED TIMESTAMP NOT NULL,
	MODIFIED TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH_OAUTHACL
    ADD (CONSTRAINT PK_OAUTHACL_ID PRIMARY KEY(ID)  USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.OH_OAUTHACL
	ADD CONSTRAINT FK_ACL_CONTEXT_ID FOREIGN KEY (CONTEXTID)
	REFERENCES HOMEPAGE.OH_CONTEXT(ID);

ALTER TABLE HOMEPAGE.OH_OAUTHACL
	ADD CONSTRAINT FK_ACL_APP_ID FOREIGN KEY (AUTHORIZEDAPPID)
	REFERENCES HOMEPAGE.OH_APPLICATION(ID);

CREATE UNIQUE INDEX HOMEPAGE.ACL_CONTEXT_IDX
    ON HOMEPAGE.OH_OAUTHACL (CONTEXTID);

CREATE UNIQUE INDEX HOMEPAGE.ACL_APP_IDX
    ON HOMEPAGE.OH_OAUTHACL (AUTHORIZEDAPPID);

ALTER TABLE HOMEPAGE.OH_OAUTHACL ENABLE ROW MOVEMENT;     
    
   
	
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END OAUTH Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- END: OAUTH TABLES
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------
-------------------------------------------------------------------------	
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- Adding column to trace the LAST_ACTIONABLE_VISIT
---------------------------------------------------------
ALTER TABLE HOMEPAGE.HP_UI
	ADD LAST_ACTIONABLE_VISIT TIMESTAMP;

UPDATE HOMEPAGE.HP_UI SET LAST_ACTIONABLE_VISIT = CURRENT_TIMESTAMP;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------
-- Insert a "fake" system admin user in PERSON table
---------------------------------------------------------
INSERT INTO HOMEPAGE.PERSON
		(PERSON_ID,DISPLAYNAME,EXID,STATE) 
VALUES ('00000000-0000-0000-0000-000000000000','%system_admin','00000000-0000-0000-0000-000000000000',0);
COMMIT;

----------------------------------------------------------------------
-- RENAME REPLYTO COLUMNS - DROP AND CREATE THE TABLES
----------------------------------------------------------------------
    	
DROP TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT;

DROP TABLE HOMEPAGE.NT_REPLYTO; 

----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO (
	REPLYTO_NOTIFICATION_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36),
	EVENT_NAME VARCHAR2(256) NOT NULL,
	CONTAINER_ID VARCHAR2(256),	
	ITEM_ID VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),	
	CREATION_DATE TIMESTAMP NOT NULL,
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0),
	SOURCE_TYPE NUMBER(5,0)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO
    ADD (CONSTRAINT PK_REPLYTO PRIMARY KEY(REPLYTO_NOTIFICATION_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO ENABLE ROW MOVEMENT;
    
----------------------------------------------------------------------
-- HOMEPAGE.NT_REPLYTO_RECIPIENT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT (
	REPLYTO_RECIPIENT_ID VARCHAR2(36) NOT NULL,
	REPLYTO_NOTIFICATION_ID VARCHAR2(36) NOT NULL,
	PERSON_ID VARCHAR2(36) NOT NULL,	
	REPLYTO_ID VARCHAR2(36) NOT NULL,
	LAST_UPDATE TIMESTAMP
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD (CONSTRAINT REPLYTO_RECIP_ID PRIMARY KEY(REPLYTO_RECIPIENT_ID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_NOT_ID FOREIGN KEY (REPLYTO_NOTIFICATION_ID)
	REFERENCES HOMEPAGE.NT_REPLYTO (REPLYTO_NOTIFICATION_ID);

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT
    ADD CONSTRAINT FK_REPLYTO_PER_ID FOREIGN KEY (PERSON_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.REPLYTO_IDX
    ON HOMEPAGE.NT_REPLYTO_RECIPIENT (REPLYTO_ID) TABLESPACE "HPNTINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NT_REPLYTO_RECIPIENT ENABLE ROW MOVEMENT;

COMMIT;


COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE HOMEPAGE.PERSON ADD CREATION_DATE TIMESTAMP;
UPDATE 		HOMEPAGE.PERSON SET CREATION_DATE = LAST_UPDATE;
COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start HP FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ALTER TABLE 	HOMEPAGE.PERSON			ADD  ORGANIZATION_ID VARCHAR2(36);
ALTER TABLE 	HOMEPAGE.PERSON			ADD  COMMUNITY_INTERNAL_ONLY NUMBER(5 ,0);
COMMIT;

-------------------------------------------------------------
-- START: OA updates scripts
-------------------------------------------------------------
INSERT INTO HOMEPAGE.OH_PROVIDER (ID, NAME, DESCRIPTION, REQUESTTOKENURL, AUTHORIZEURL, ACCESSTOKENURL, BASEURL, MANAGEURL, REGISTERURL, CREATEED) 
VALUES ( '00000000-0000-0000-0000-000000000000', 'connectionsProvider', 'IBM Connections OAuth Provider', 'provider/requestToken', 'provider/authorize', 'provider/accessToken', '', 'provider/manageAccess?serviceProvider=connectionsProvider', 'provider/register?serviceProvider=connectionsProvider', CURRENT_TIMESTAMP);

COMMIT;

CREATE INDEX HOMEPAGE.OH_CONTEXT_USER_IDX 			ON HOMEPAGE.OH_CONTEXT (USERID)				TABLESPACE "HPNTINDEXTABSPACE";
CREATE INDEX HOMEPAGE.OH_CONTEXT_CLIENT_USER_IDX 	ON HOMEPAGE.OH_CONTEXT (CLIENTID,USERID)	TABLESPACE "HPNTINDEXTABSPACE";
CREATE INDEX HOMEPAGE.OH_CLIENT_USERNAME_IDX 		ON HOMEPAGE.OH_CLIENT (USERNAME)			TABLESPACE "HPNTINDEXTABSPACE";

COMMIT;


-- DROP UNIQUE INDEXES
DROP INDEX HOMEPAGE.APP_PROVIDER_IDX;

DROP INDEX HOMEPAGE.CLIENT_PROVIDER_IDX;
DROP INDEX HOMEPAGE.CLIENT_TOKEN_IDX;	

DROP INDEX HOMEPAGE.CONTEXT_CLIENT_IDX;
DROP INDEX HOMEPAGE.CONTEXT_TOKEN_IDX;

DROP INDEX HOMEPAGE.ACL_CONTEXT_IDX;
DROP INDEX HOMEPAGE.ACL_APP_IDX;

COMMIT;

-- RECREATE
CREATE INDEX HOMEPAGE.APP_PROVIDER_IDX 				ON HOMEPAGE.OH_APPLICATION (PROVIDERID)		TABLESPACE "HPNTINDEXTABSPACE";

CREATE INDEX HOMEPAGE.CLIENT_PROVIDER_IDX 			ON HOMEPAGE.OH_CLIENT (PROVIDERID)			TABLESPACE "HPNTINDEXTABSPACE";
CREATE INDEX HOMEPAGE.CLIENT_TOKEN_IDX 				ON HOMEPAGE.OH_CLIENT (TOKENID)				TABLESPACE "HPNTINDEXTABSPACE";	

CREATE INDEX HOMEPAGE.CONTEXT_CLIENT_IDX 			ON HOMEPAGE.OH_CONTEXT (CLIENTID)			TABLESPACE "HPNTINDEXTABSPACE";
CREATE INDEX HOMEPAGE.CONTEXT_TOKEN_IDX 			ON HOMEPAGE.OH_CONTEXT (TOKENID)			TABLESPACE "HPNTINDEXTABSPACE";

CREATE INDEX HOMEPAGE.ACL_CONTEXT_IDX 				ON HOMEPAGE.OH_OAUTHACL (CONTEXTID)			TABLESPACE "HPNTINDEXTABSPACE";
CREATE INDEX HOMEPAGE.ACL_APP_IDX 					ON HOMEPAGE.OH_OAUTHACL (AUTHORIZEDAPPID)	TABLESPACE "HPNTINDEXTABSPACE";

COMMIT;

-------------------------------------------------------------
-- END START: OA updates scripts
-------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE35 FOR NEWS 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 80
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- PRE sanitize sql as we start from a 3.0.1 and we need to migrate it to 4.0

DROP INDEX HOMEPAGE.NR_ATT_STORY_ID;
DROP INDEX HOMEPAGE.NR_REC_STORY_ID;
DROP INDEX HOMEPAGE.NR_RECOMMENDER_STORY_ID;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT DROP CONSTRAINT PK_ATTACHMENT;
ALTER TABLE HOMEPAGE.NR_RECOMMENDATION DROP CONSTRAINT PK_RECOMMENDATION;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 			RENAME TO NR_ATTACHMENT_301;
ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 		RENAME TO NR_RECOMMENDATION_301;


commit;
-------------------------------------------------------
-- RENAMING NATIONWIDE specific table
-------------------------------------------------------

----------------------------------------------------------------
-- SPR #DMCE8ECKYM
----------------------------------------------------------------
-- #1 - Community Forum icon in news stories displays the Community icon
-- When you migrate 2.5.0x content that includes a community with community forum content, 
-- the story icon used in the 3.0.1 system appears to be misleading (Community icon currently  instead of Forum icon). 
-- See screenshot below as an example. This is not a ship stop if fix not included.
UPDATE HOMEPAGE.NR_STORIES SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED SET SOURCE = 'forums' WHERE EVENT_NAME LIKE '%forum%';

COMMIT;

-- #4 - Status Updates \ People I'm Following - should also include status by people in My Network
-- If you are networked with a user in 2.5.0.3, their latest status should be present in the "People I'm Following" view in 3.0.1 when migrated.
-- The default behaviour is that any network colleague making a status update automatically appears in your People I'm Following view.
-- This is not a ship stop if fix not included, but we should be including all relevant data in the migration process.
UPDATE HOMEPAGE.NR_NEWS_STATUS_NETWORK SET IS_FOLLOW_NEWS = 1 WHERE IS_NETWORK_NEWS = 1;

COMMIT;

-- #5 - Icon for Following a person is the Homepage icon instead of Profiles icon
-- In LC 2.5.0.3, you will see a story for adding a user to your Homepage Watchlist. This story has a Homepage icon when migrated to LC 3.0.1
-- Ideally this story should have a "Profiles" icon in LC 3.0.1, as this is now a profiles story - profiles.person.followed
UPDATE HOMEPAGE.NR_STORIES  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;


UPDATE HOMEPAGE.NR_NEWS_SAVED  SET SOURCE = 'profiles' WHERE EVENT_NAME = 'profiles.person.followed';

COMMIT;


--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------
-- CREATING A PARTITIONED TABLES
--------------------------------------------------------------

------------------------------------------------
-- 1) NR_SOURCE_TYPE
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE_NAME VARCHAR2(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	SOURCE_TYPE_DESC VARCHAR2(256) NOT NULL
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD (CONSTRAINT "PK_SRC_TYPE_ID" PRIMARY KEY("SOURCE_TYPE_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNIQUE UNIQUE(SOURCE_TYPE);

ALTER TABLE "HOMEPAGE"."NR_SOURCE_TYPE" ENABLE ROW MOVEMENT;

-------------------------------------------------
-- 2) ADDING SOURCE TYPE COLUMNS TO EXISTING TABLES
-------------------------------------------------

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_SOURCE
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE
	ADD SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_SOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_SAVED
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_SAVED
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_NEWS_DISCOVERY
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESOURCE
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_RESOURCE
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_RESOURCE
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_COMM_STORIES
	SET SOURCE_TYPE = 3;
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMM_PERSON_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;


-- categories tables
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_RESPONSES_STORIES
--------------------------------------------
ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_RESPONSES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_PROFILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_PROFILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_COMMUNITIES_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_ACTIVITIES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_ACTIVITIES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BLOGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_BLOGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_BOOKMARKS_STORIES (never used)
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	
	
--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FILES_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FILES_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_FILES_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_FORUMS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_FORUMS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_WIKIS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_WIKIS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_TAGS_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_TAGS_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_TAGS_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;

-------------------------------------------------
-- 3) ADDING PARTITIONED TABLES
-------------------------------------------------

----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_SRC_STORIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_ACT (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
    ADD (CONSTRAINT "PK_ACT_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_DATE
	ON HOMEPAGE.NR_SRC_STORIES_ACT(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_ACT_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT ENABLE ROW MOVEMENT;
    
----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_SRC_STORIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_BLG (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
    ADD (CONSTRAINT "PK_BLG_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_DATE
	ON HOMEPAGE.NR_SRC_STORIES_BLG(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_BLG_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG ENABLE ROW MOVEMENT;

----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_SRC_STORIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_COM (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
    ADD (CONSTRAINT "PK_COM_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_COM (CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_COM_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_COM (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM ENABLE ROW MOVEMENT;    
    
----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_SRC_STORIES_WIK
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_WIK (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
    ADD (CONSTRAINT "PK_WIK_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_DATE
	ON HOMEPAGE.NR_SRC_STORIES_WIK(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_WIK_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK ENABLE ROW MOVEMENT;    
    
----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_SRC_STORIES_PRF
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_PRF (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
    ADD (CONSTRAINT "PK_PRF_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_DATE
	ON HOMEPAGE.NR_SRC_STORIES_PRF(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_PRF_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_SRC_STORIES_HP
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_HP (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
    ADD (CONSTRAINT "PK_HP_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_DATE
	ON HOMEPAGE.NR_SRC_STORIES_HP(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_HP_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_HP (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_SRC_STORIES_DGR
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_DGR (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
    ADD (CONSTRAINT "PK_DGR_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_DATE
	ON HOMEPAGE.NR_SRC_STORIES_DGR(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_DGR_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR ENABLE ROW MOVEMENT;    

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_SRC_STORIES_FILE
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FILE (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
    ADD (CONSTRAINT "PK_FILE_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FILE(CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FILE_STORIES_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE ENABLE ROW MOVEMENT;

----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_SRC_STORIES_FRM 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_FRM  (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL, -- NEW
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	SOURCE_TYPE NUMBER(5,0),
	CONSTRAINT   	CK_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 
    ADD (CONSTRAINT "PK_FRM_STORY_ID" PRIMARY KEY("STORY_ID") USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_DATE
	ON HOMEPAGE.NR_SRC_STORIES_FRM (CREATION_DATE DESC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_CONTAINED_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_ITEM_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.SRC_FRM_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_FRM  (ITEM_CORRELATION_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_SIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM ENABLE ROW MOVEMENT;    

---------------------------------------------------------------------------------
-- 4) RUNNING DATA MIGRATION
---------------------------------------------------------------------------------

------------
--- START INSERT NR_SOURCE_TYPE
------------

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, '%activities', 'activities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('blogs________0f1xc9caxcc4x8b0bx51af2', 2, '%blogs', 'blogs');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('communities____f1xc9caxcc48b0bx51af2', 3, '%communities', 'communities');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('wikis________dfdxc9cax4cc4xb0bx51af2', 4, '%wikis', 'wikis');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('profiles____________fdfdc98b0bx51af2', 5, '%profiles', 'profiles');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('homepage_0f1xc9cax4cc4x8cdb0bx51f2dd', 6, '%homepage', 'homepage');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('dogear_0f1xc9cax4cc4x8cdb0bx51f2d', 7, '%dogear', 'dogear');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('files____________fdfdc9cax8b0bx51af2', 8, '%files', 'files');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC)
VALUES ('forums____________fdfdc9cax80bx51af2', 9, '%forums', 'forums');
------------
--- END INSERT NR_SOURCE_TYPE
------------

COMMIT;

--------------------------------------------------------------------------------
-- START MIGRATING OLD DATA FROM THE NR_STORIES TABLE TO THE PARTITIONED TABLES
--------------------------------------------------------------------------------

-- PARTITIONING MAIN TABLE
ALTER TABLE HOMEPAGE.NR_STORIES
	ADD  SOURCE_TYPE NUMBER(5,0);

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 1 WHERE SOURCE = 'activities';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 2 WHERE SOURCE = 'blogs';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 3 WHERE SOURCE = 'communities';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 4 WHERE SOURCE = 'wikis';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 5 WHERE SOURCE = 'profiles';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 6 WHERE SOURCE = 'homepage';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 7 WHERE SOURCE = 'dogear';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 8 WHERE SOURCE = 'files';
COMMIT;

UPDATE HOMEPAGE.NR_STORIES
	SET SOURCE_TYPE = 9 WHERE SOURCE = 'forums';
COMMIT;    

--------------------------------------------
-- ADDING SOURCE_TYPE - NR_STORIES_CONTENT (THIS IS BASED ON A JOIN WITH NR_STORIES
--------------------------------------------	
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD  SOURCE_TYPE NUMBER(5,0);
COMMIT;	

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 1 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'activities'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 2 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'blogs'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 3 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'communities'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 4 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'wikis'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 5 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'profiles'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 6 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'homepage'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 7 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'dogear'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 8 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'files'
);
COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT SET SOURCE_TYPE = 9 WHERE STORY_ID IN (
	SELECT 	NR_STORIES.STORY_ID
	FROM 	HOMEPAGE.NR_STORIES NR_STORIES, HOMEPAGE.NR_STORIES_CONTENT NR_STORIES_CONTENT
	WHERE 	NR_STORIES.STORY_ID = NR_STORIES_CONTENT.STORY_ID AND SOURCE = 'forums'
);
COMMIT;

-- COPYING BACK THE DATA
-- 1) NR_SRC_STORIES_ACT
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 1;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_ACT VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--2) HOMEPAGE.NR_SRC_STORIES_BLG
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 2;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_BLG VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--3) HOMEPAGE.NR_SRC_STORIES_COM
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 3;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_COM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--4) HOMEPAGE.NR_SRC_STORIES_WIK
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 4;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_WIK VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--5) HOMEPAGE.NR_SRC_STORIES_PRF
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 5;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_PRF VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--6) HOMEPAGE.NR_SRC_STORIES_HP
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 6;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_HP VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--7) HOMEPAGE.NR_SRC_STORIES_DGR
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 7;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_DGR VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/	

commit;

--8) HOMEPAGE.NR_SRC_STORIES_FILE
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 8;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FILE VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;

--9) HOMEPAGE.NR_SRC_STORIES_FRM
DECLARE  CURSOR s_cur IS  SELECT *  FROM HOMEPAGE.NR_STORIES WHERE SOURCE_TYPE = 9;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;

BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FRM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

commit;
	
---------------------------------------------------------------------------------
-- DROPPING OLD TABLE TO CREATE A NEW VIEW
---------------------------------------------------------------------------------
--ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP CONSTRAINT "FK_COMM_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES DROP CONSTRAINT "FK_ORGP_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES DROP CONSTRAINT "FK_FCP_STORY_ID";

--ALTER TABLE HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT "FK_RESP_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT "FK_PROF_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT "FK_COM_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT "FK_ACT_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT "FK_BLOGS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT "FK_BOOKS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT "FK_FILES_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT "FK_FORUMS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT "FK_WIKIS_STORY_ID";
--ALTER TABLE HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT "FK_TAGS_STORY_ID";
COMMIT;

DROP TABLE HOMEPAGE.NR_STORIES;
COMMIT;

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE SOURCE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_STORIES AS (
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_SRC_STORIES_FRM
);




-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 81
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------
-- 1) ADDING NEW COLUMN TO THE NR_COMM_FOLLOW TABLE (FROM FIXUP 58)
--------------------------------------------------------------

--ALTER TABLE HOMEPAGE.NR_COMM_FOLLOW
--	ADD COMMUNITY_NAME VARCHAR2(256);

COMMIT;
--------------------------------------------------------------
-- 2) ADDING NEW COLUMN (HAS_ATTACHMENT) TO THE STORIES TABLES
--------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;
	
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0;

COMMIT;

----------------------------------------------------------------
-- 3) ADDING TABLE FOR PROFILES STORIES COMMENTS 
----------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT (
	NEWS_COMMENT_ID VARCHAR2(36) NOT NULL,
	ACTOR_UUID VARCHAR2(36) NOT NULL,
	CREATION_DATE TIMESTAMP,
	BRIEF_DESC VARCHAR2(500),
	STORY_ID  VARCHAR2(36),
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ITEM_ID  VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),
	ITEM_URL VARCHAR2(2048),
	CONTENT BLOB
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT 
    ADD (CONSTRAINT PK_NR_NEWS_PRF_COMMENT_ID PRIMARY KEY(NEWS_COMMENT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT FK_STORY_ID FOREIGN KEY (STORY_ID)
	REFERENCES HOMEPAGE.NR_SRC_STORIES_PRF (STORY_ID);

CREATE INDEX HOMEPAGE.NR_NEWS_PRF_COMMENT_STORY_ID
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (STORY_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_NEWS_PRF_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (CREATION_DATE ASC) TABLESPACE "NEWSINDEXTABSPACE";        	  	   

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT ENABLE ROW MOVEMENT;    

COMMIT;

----------------------------------------------------------------
-- 4) ADDING NR_ATTACHMENT - CAN RELATE TO ANY STORIES TABLE
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ATTACHMENT (
	ATTACHMENT_ID VARCHAR2(36) NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMBER(5,0),
	CREATION_DATE TIMESTAMP,
	FILE_NAME VARCHAR2(2048),
	FILE_DESC VARCHAR2(4000),	
	FILE_ID  VARCHAR2(128),
	REPO_ID VARCHAR2(128)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 
    ADD (CONSTRAINT PK_ATTACHMENT PRIMARY KEY(ATTACHMENT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ATT_STORY_ID
    ON HOMEPAGE.NR_ATTACHMENT (STORY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_ATTACHMENT ENABLE ROW MOVEMENT;    

COMMIT;

----------------------------------------------------------------
-- 5) ADDING NR_RECOMMENDATION - CAN RELATE TO ANY STORY TABLE
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_RECOMMENDATION  (
	RECOMMENDATION_ID VARCHAR2(36) NOT NULL, --primary key
	RECOMMENDER_ID VARCHAR2(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	STORY_ID VARCHAR2(36) NOT NULL, 
	SOURCE_TYPE NUMBER(5,0) NOT NULL, 
	CREATION_DATE TIMESTAMP
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 
    ADD (CONSTRAINT PK_RECOMMENDATION PRIMARY KEY(RECOMMENDATION_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_REC_STORY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (STORY_ID) TABLESPACE "NEWSINDEXTABSPACE";
    
CREATE UNIQUE INDEX HOMEPAGE.NR_RECOMMENDER_STORY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID, STORY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION ENABLE ROW MOVEMENT;    

COMMIT;

   
    


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 82
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) HOMEPAGE.NR_ENTRIES_ACT
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_ACT (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC1_TYPE
    				CHECK
    				(SOURCE_TYPE = 1)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
    ADD (CONSTRAINT PK_ACT_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_ACT_CONT
    ON HOMEPAGE.NR_ENTRIES_ACT (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_ACT_SRC
    ON HOMEPAGE.NR_ENTRIES_ACT (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 2) HOMEPAGE.NR_ENTRIES_BLG
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_BLG (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC2_TYPE
    				CHECK
    				(SOURCE_TYPE = 2)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
    ADD (CONSTRAINT PK_BLG_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_BLG_CONT
    ON HOMEPAGE.NR_ENTRIES_BLG (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_BLG_SRC
    ON HOMEPAGE.NR_ENTRIES_BLG (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";
    

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 3) HOMEPAGE.NR_ENTRIES_COM
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_COM (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC3_TYPE
    				CHECK
    				(SOURCE_TYPE = 3)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
    ADD (CONSTRAINT PK_COM_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_COM_CONT
    ON HOMEPAGE.NR_ENTRIES_COM (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_COM_SRC
    ON HOMEPAGE.NR_ENTRIES_COM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 4) HOMEPAGE.NR_ENTRIES_WIK
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_WIK (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC4_TYPE
    				CHECK
    				(SOURCE_TYPE = 4)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
    ADD (CONSTRAINT PK_WIK_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_WIK_CONT
    ON HOMEPAGE.NR_ENTRIES_WIK (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_WIK_SRC
    ON HOMEPAGE.NR_ENTRIES_WIK (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 5) HOMEPAGE.NR_ENTRIES_PRF
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_PRF (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC5_TYPE
    				CHECK
    				(SOURCE_TYPE = 5)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
    ADD (CONSTRAINT PK_PRF_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_PRF_CONT
    ON HOMEPAGE.NR_ENTRIES_PRF (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_PRF_SRC
    ON HOMEPAGE.NR_ENTRIES_PRF (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 6) HOMEPAGE.NR_ENTRIES_HP
----------------------------------------------------------------------    
CREATE TABLE HOMEPAGE.NR_ENTRIES_HP (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC6_TYPE
    				CHECK
    				(SOURCE_TYPE = 6)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
    ADD (CONSTRAINT PK_HP_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_HP_CONT
    ON HOMEPAGE.NR_ENTRIES_HP (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_HP_SRC
    ON HOMEPAGE.NR_ENTRIES_HP (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 7) HOMEPAGE.NR_ENTRIES_DGR
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_DGR (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC7_TYPE
    				CHECK
    				(SOURCE_TYPE = 7)
)
TABLESPACE "NEWSREGTABSPACE"; 


ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
    ADD (CONSTRAINT PK_DGR_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_DGR_CONT
    ON HOMEPAGE.NR_ENTRIES_DGR (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_DGR_SRC
    ON HOMEPAGE.NR_ENTRIES_DGR (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 8) HOMEPAGE.NR_ENTRIES_FILE
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FILE (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC8_TYPE
    				CHECK
    				(SOURCE_TYPE = 8)
)
TABLESPACE "NEWSREGTABSPACE"; 


ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
    ADD (CONSTRAINT PK_FILE_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_FILE_CONT
    ON HOMEPAGE.NR_ENTRIES_FILE (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_FILE_SRC
    ON HOMEPAGE.NR_ENTRIES_FILE (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

    
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------------
-- 9) HOMEPAGE.NR_ENTRIES_FRM
----------------------------------------------------------------------      
CREATE TABLE HOMEPAGE.NR_ENTRIES_FRM (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONSTRAINT   	CK_ENT_SRC9_TYPE
    				CHECK
    				(SOURCE_TYPE = 9)
)
TABLESPACE "NEWSREGTABSPACE"; 


ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
    ADD (CONSTRAINT PK_FRM_ENTRY_ID PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_FRM_CONT
    ON HOMEPAGE.NR_ENTRIES_FRM (CONTAINER_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_ENTRIES_FRM_SRC
    ON HOMEPAGE.NR_ENTRIES_FRM (SOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";


ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ENABLE ROW MOVEMENT;

COMMIT;

----------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE ADDING TABLE FOR PROFILES STORIES COMMENTS 
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT;

CREATE TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT (
	NEWS_COMMENT_ID VARCHAR2(36) NOT NULL,
	ACTOR_UUID VARCHAR2(36) NOT NULL,
	CREATION_DATE TIMESTAMP,
	UPDATE_DATE TIMESTAMP,
	BRIEF_DESC VARCHAR2(500),
	ENTRY_ID  VARCHAR2(36),
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ITEM_ID  VARCHAR2(36),
	ITEM_CORRELATION_ID VARCHAR2(36),
	ITEM_URL VARCHAR2(2048),
	TARGET_SUBJECT_ID VARCHAR2(36),
	CONTENT BLOB
)
LOB (CONTENT) STORE AS (TABLESPACE NEWSLOBTABSPACE 
STORAGE (INITIAL 1M)
CHUNK 4000
NOCACHE NOLOGGING)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD (CONSTRAINT PK_PRF_COMMENT_ID PRIMARY KEY(NEWS_COMMENT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT
  	ADD CONSTRAINT FK_ENTRY_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
  	
CREATE INDEX HOMEPAGE.PRF_COMMENT_ENTRY_ID
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_NEWS_PRF_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_PRF_COMMENT (UPDATE_DATE ASC) TABLESPACE "NEWSINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT ENABLE ROW MOVEMENT;


----------------------------------------------------------------
-- DROPPING AND RECREATE NR_RECOMMENDATION - CAN RELATE TO ANY ENTRY TABLE
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_RECOMMENDATION;

CREATE TABLE HOMEPAGE.NR_RECOMMENDATION  (
	RECOMMENDATION_ID VARCHAR2(36) NOT NULL, --primary key
	RECOMMENDER_ID VARCHAR2(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID VARCHAR2(36) NOT NULL, 
	SOURCE_TYPE NUMBER(5,0) NOT NULL, 
	CREATION_DATE TIMESTAMP
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION 
    ADD (CONSTRAINT PK_RECOMMENDATION PRIMARY KEY(RECOMMENDATION_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION
  	ADD CONSTRAINT FK_RECOMMENDER_ID FOREIGN KEY (RECOMMENDER_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);
    
CREATE INDEX HOMEPAGE.NR_REC_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NR_RECCOMANDER_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID) TABLESPACE "NEWSINDEXTABSPACE";
    
CREATE UNIQUE INDEX HOMEPAGE.NR_RECOMMENDER_ENTRY_ID
    ON HOMEPAGE.NR_RECOMMENDATION (RECOMMENDER_ID, ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.NR_RECOMMENDATION ENABLE ROW MOVEMENT;


---------------------------------------------------------------
-- DROPPING AND RECREATING RE-CREATE HOMEPAGE.NR_ATTACHMENT
---------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ATTACHMENT;

CREATE TABLE HOMEPAGE.NR_ATTACHMENT (
	ATTACHMENT_ID VARCHAR2(36) NOT NULL,
	ENTRY_ID VARCHAR2(36) NOT NULL, -- 47
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMBER(5,0),
	CREATION_DATE TIMESTAMP,
	NAME VARCHAR2(2048),
	DESCRIPTION VARCHAR2(4000),	
	TARGET_ID  VARCHAR2(256),
	TARGET_URL VARCHAR2(2048),
	META_DATA VARCHAR2(4000)
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_ATTACHMENT 
    ADD (CONSTRAINT PK_ATTACHMENT PRIMARY KEY(ATTACHMENT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ATT_ENTRY_ID
    ON HOMEPAGE.NR_ATTACHMENT (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";    

COMMIT;

ALTER TABLE HOMEPAGE.NR_ATTACHMENT ENABLE ROW MOVEMENT;


---------------------------------------------------------------
-- Adding flag for debug purpose on PERSON_COMM table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
	ADD IS_READER_COMM NUMBER(5,0) DEFAULT 0 NOT NULL;
	

UPDATE HOMEPAGE.NR_COMM_PERSON_FOLLOW 
	SET 		IS_READER_COMM = 1 
	WHERE 		PERSON_COMMUNITY_ID NOT IN (
		SELECT 	NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID
		FROM 	HOMEPAGE.NR_COMM_PERSON_FOLLOW NR_COMM_PERSON_FOLLOW, 
				HOMEPAGE.PERSON PERSON
		WHERE 	NR_COMM_PERSON_FOLLOW.PERSON_COMMUNITY_ID = PERSON.PERSON_ID );
		
COMMIT;	

---------------------------------------------------------------
-- Adding flag for debug purpose on NR_COMM_PERSON_STORIES table
---------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD IS_STORY_COMM NUMBER(5,0);

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET IS_STORY_COMM = 1 WHERE COMM_PER_READER_ID NOT IN (
	SELECT PERSON_ID
	FROM HOMEPAGE.PERSON PERSON
);

COMMIT;

UPDATE HOMEPAGE.NR_COMM_PERSON_STORIES SET IS_STORY_COMM = 0 WHERE IS_STORY_COMM IS NULL;

COMMIT;
---------------------------------------------------------------
---------------------------------------------------------------	
-- SEEDLIST AND BOARD TABLES	
---------------------------------------------------------------
---------------------------------------------------------------

---------------------------------------------------------------	
-- All tose tables are going to be stored into a dedicated table space
---------------------------------------------------------------
-- HOMEPAGE BOARD TABLETABLESPACE
CREATE TEMPORARY TABLESPACE "BOARDTMPTABSPACE"
	TEMPFILE 'BOARDTMPTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON;
	
CREATE SMALLFILE TABLESPACE "BOARDREGTABSPACE"
	DATAFILE 'BOARDREGTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON 
	NEXT 40M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;
	
CREATE SMALLFILE TABLESPACE "BOARDINDEXTABSPACE"
	DATAFILE 'BOARDINDEXTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON 
	NEXT 40M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;

CREATE 	TABLESPACE "BOARDLOBTABSPACE"
        DATAFILE 'BOARDLOBTABSPACE'
        SIZE 400M REUSE AUTOEXTEND ON
        NEXT 40M MAXSIZE UNLIMITED;	 
	
--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMBER(5,0),
	CATEGORY_TYPE NUMBER(5,0),
	SOURCE VARCHAR2(36),
	SOURCE_TYPE NUMBER(5,0),
	STORY_ID VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID VARCHAR2(36),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL ,
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0,
	TARGET_SUBJECT_ID VARCHAR2(256),
	IS_NETWORK_NEWS NUMBER(5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMBER(5,0) DEFAULT 0 NOT NULL,
	TAGS VARCHAR2(1024),
	SL_IS_UPDATED NUMBER(5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMBER(5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used by the seedlist
	CONTENT BLOB NOT NULL
)
LOB (CONTENT) STORE AS (TABLESPACE BOARDLOBTABSPACE 
STORAGE (INITIAL 1M)
CHUNK 4000
NOCACHE NOLOGGING)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD (CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";
  
CREATE INDEX HOMEPAGE.NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_ENTRIES ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID VARCHAR2(36) NOT NULL,
	IS_READER_COMM NUMBER(5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD (CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX HOMEPAGE.NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID) TABLESPACE "BOARDINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_READERS ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID VARCHAR2(36),
	CREATION_DATE TIMESTAMP NOT NULL,
	ITEM_ID VARCHAR2(47),
	ITEM_CORRELATION_ID VARCHAR2(47),
	ITEM_URL VARCHAR2(2048),	
	CONTENT BLOB
)
LOB (CONTENT) STORE AS (TABLESPACE BOARDLOBTABSPACE 
STORAGE (INITIAL 1M)
CHUNK 4000
NOCACHE NOLOGGING)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD (CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID) TABLESPACE "BOARDINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_COMMENTS ENABLE ROW MOVEMENT;

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID VARCHAR2(47) NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL, -- 47
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMBER(5,0),
	CREATION_DATE TIMESTAMP,
	NAME VARCHAR2(2048),
	DESCRIPTION VARCHAR2(4000),	
	TARGET_ID  VARCHAR2(256),
	TARGET_URL VARCHAR2(2048),
	META_DATA VARCHAR2(4000)
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD (CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";
	
COMMIT;

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID VARCHAR2(47) NOT NULL, --primary key
	RECOMMENDER_ID VARCHAR2(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID VARCHAR2(47) NOT NULL,
	SOURCE_TYPE NUMBER(5,0) NOT NULL, 
	CREATION_DATE TIMESTAMP
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD (CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

CREATE INDEX HOMEPAGE.BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS ENABLE ROW MOVEMENT;


  
    


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 83
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------
-- START: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR2 TO BE CLOB 
--------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD TMP_DOMAIN_AFFINITY CLOB;

COMMIT;

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET TMP_DOMAIN_AFFINITY = DOMAIN_AFFINITY;

COMMIT;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN DOMAIN_AFFINITY;

COMMIT;

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD DOMAIN_AFFINITY CLOB;

COMMIT;

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET DOMAIN_AFFINITY = TMP_DOMAIN_AFFINITY;

COMMIT;

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN TMP_DOMAIN_AFFINITY;

COMMIT;

--reorg table HOMEPAGE.EMD_TRANCHE_INFO use NEWS4TMPTABSPACE;

COMMIT;

--------------------------------------------------------------------------------------
-- END: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR2 TO BE CLOB 
--------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
-- START: ADDING ENTRY_ID
--------------------------------------------------------------------------------------

-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD ENTRY_ID VARCHAR2(36);

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID); 
	
COMMIT;

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";      

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID); 
	
COMMIT;

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);  
	
COMMIT;

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID);
	
COMMIT;

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";  

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);
	
COMMIT;

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";   

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID); 
	
COMMIT;

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE"; 

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID);
	
COMMIT;
    
-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID); 
	
COMMIT;

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD ENTRY_ID VARCHAR2(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (ENTRY_ID) TABLESPACE "NEWSINDEXTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID); 
	
COMMIT;

--------------------------------------------------------------------------------------
-- FIXING BOARD TABLES
-------------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_RECOMMENDATIONS;

DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

DROP TABLE HOMEPAGE.BOARD_COMMENTS;

DROP TABLE HOMEPAGE.BOARD_READERS;

DROP TABLE HOMEPAGE.BOARD_ENTRIES;

COMMIT;

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE NUMBER(5,0),
	CATEGORY_TYPE NUMBER(5,0),
	SOURCE VARCHAR2(36),
	SOURCE_TYPE NUMBER(5,0),
	ITEM_ID VARCHAR(36) NOT NULL,
	ITEM_URL VARCHAR(2048) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CREATION_DATE TIMESTAMP NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID VARCHAR2(36),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECOMMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL ,
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0,
	TARGET_SUBJECT_ID VARCHAR2(256),
	TAGS VARCHAR2(1024),
	SL_IS_UPDATED NUMBER(5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_IS_DELETED NUMBER(5,0) DEFAULT 0 NOT NULL, -- this field is used by the seedlist
	SL_UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used by the seedlist
	CONTENT BLOB NOT NULL
)
LOB (CONTENT) STORE AS (TABLESPACE BOARDLOBTABSPACE 
STORAGE (INITIAL 1M)
CHUNK 4000
NOCACHE NOLOGGING)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD (CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";
  
CREATE INDEX HOMEPAGE.NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";

CREATE UNIQUE INDEX HOMEPAGE.NEWS_BRD_ITEM
    ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID) TABLESPACE "BOARDINDEXTABSPACE";    

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_ENTRIES ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID VARCHAR2(36) NOT NULL,
	IS_READER_COMM NUMBER(5,0) DEFAULT 0 NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL,
	IS_NETWORK_NEWS NUMBER(5,0) DEFAULT 0 NOT NULL,
	IS_FOLLOW_NEWS NUMBER(5,0) DEFAULT 0 NOT NULL
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD (CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX HOMEPAGE.NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID) TABLESPACE "BOARDINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_READERS ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID VARCHAR2(36),
	CREATION_DATE TIMESTAMP NOT NULL,
	ITEM_ID VARCHAR2(47),
	ITEM_CORRELATION_ID VARCHAR2(47),
	ITEM_URL VARCHAR2(2048),	
	CONTENT BLOB
)
LOB (CONTENT) STORE AS (TABLESPACE BOARDLOBTABSPACE 
STORAGE (INITIAL 1M)
CHUNK 4000
NOCACHE NOLOGGING)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD (CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID) TABLESPACE "BOARDINDEXTABSPACE";

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_COMMENTS ENABLE ROW MOVEMENT;

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID VARCHAR2(47) NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL, -- 47
	SOURCE_TYPE NUMBER(5,0) NOT NULL,
	ATTACHMENT_TYPE NUMBER(5,0),
	CREATION_DATE TIMESTAMP,
	NAME VARCHAR2(2048),
	DESCRIPTION VARCHAR2(4000),	
	TARGET_ID  VARCHAR2(256),
	TARGET_URL VARCHAR2(2048),
	META_DATA VARCHAR2(4000)
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD (CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";
	
COMMIT;

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS ENABLE ROW MOVEMENT;

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID VARCHAR2(47) NOT NULL, --primary key
	RECOMMENDER_ID VARCHAR2(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID VARCHAR2(47) NOT NULL,
	SOURCE_TYPE NUMBER(5,0) NOT NULL, 
	CREATION_DATE TIMESTAMP
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD (CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

CREATE INDEX HOMEPAGE.BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS ENABLE ROW MOVEMENT;



------------------------------------------------------
-- CREATE VIEW NR_ENTRIES
------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_ENTRIES AS (
    SELECT * FROM HOMEPAGE.NR_ENTRIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FRM
);


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------
-- START [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-- Dropping the constraints
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT 	DROP CONSTRAINT FK_ENTRY_ID_ACT;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG 	DROP CONSTRAINT FK_ENTRY_ID_BLG;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM 	DROP CONSTRAINT FK_ENTRY_ID_COM;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK 	DROP CONSTRAINT FK_ENTRY_ID_WIK;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF 	DROP CONSTRAINT FK_ENTRY_ID_PRF;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP 		DROP CONSTRAINT FK_ENTRY_ID_HP;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR 	DROP CONSTRAINT FK_ENTRY_ID_DGR;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE 	DROP CONSTRAINT FK_ENTRY_ID_FILE;
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM 	DROP CONSTRAINT FK_ENTRY_ID_FRM;

COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_ACT SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_BLG SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_COM SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_WIK SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_PRF SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_HP SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_DGR SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_FILE SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

UPDATE HOMEPAGE.NR_SRC_STORIES_FRM SET ENTRY_ID = ITEM_ID WHERE ITEM_ID IS NOT NULL;
COMMIT;

-----------------------------------------------------------------------------------------------
-- END [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-- STARTING DATA MIGRATION FROM THE NR_STORIES TABLE TO THE NR_ENTRIES TABLE
-----------------------------------------------------------------------------------------------
-- 1 NR_ENTRIES_ACT
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_ACT (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_ACT.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_ACT.SOURCE,
				NR_SRC_STORIES_ACT.SOURCE_TYPE,
				NR_SRC_STORIES_ACT.CONTAINER_ID,
				NR_SRC_STORIES_ACT.CONTAINER_NAME,
				NR_SRC_STORIES_ACT.CONTAINER_URL,
				NR_SRC_STORIES_ACT.ITEM_ID,
				NR_SRC_STORIES_ACT.ITEM_NAME,
				NR_SRC_STORIES_ACT.ITEM_URL,			
				NR_SRC_STORIES_ACT.CREATION_DATE,
				NR_SRC_STORIES_ACT.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_ACT.TAGS,
				NR_SRC_STORIES_ACT.N_COMMENTS,
				NR_SRC_STORIES_ACT.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_ACT.BRIEF_DESC,
				NR_SRC_STORIES_ACT.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_ACT,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_ACT
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_ACT.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_ACT
								);
COMMIT;


-- 2 NR_ENTRIES_BLG
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_BLG (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_BLG.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_BLG.SOURCE,
				NR_SRC_STORIES_BLG.SOURCE_TYPE,
				NR_SRC_STORIES_BLG.CONTAINER_ID,
				NR_SRC_STORIES_BLG.CONTAINER_NAME,
				NR_SRC_STORIES_BLG.CONTAINER_URL,
				NR_SRC_STORIES_BLG.ITEM_ID,
				NR_SRC_STORIES_BLG.ITEM_NAME,
				NR_SRC_STORIES_BLG.ITEM_URL,			
				NR_SRC_STORIES_BLG.CREATION_DATE,
				NR_SRC_STORIES_BLG.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_BLG.TAGS,
				NR_SRC_STORIES_BLG.N_COMMENTS,
				NR_SRC_STORIES_BLG.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_BLG.BRIEF_DESC,
				NR_SRC_STORIES_BLG.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_BLG NR_SRC_STORIES_BLG,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_BLG
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_BLG.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_BLG
								);
COMMIT;

-- 3 HOMEPAGE.NR_ENTRIES_COM
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_COM (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_COM.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_COM.SOURCE,
				NR_SRC_STORIES_COM.SOURCE_TYPE,
				NR_SRC_STORIES_COM.CONTAINER_ID,
				NR_SRC_STORIES_COM.CONTAINER_NAME,
				NR_SRC_STORIES_COM.CONTAINER_URL,
				NR_SRC_STORIES_COM.ITEM_ID,
				NR_SRC_STORIES_COM.ITEM_NAME,
				NR_SRC_STORIES_COM.ITEM_URL,			
				NR_SRC_STORIES_COM.CREATION_DATE,
				NR_SRC_STORIES_COM.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_COM.TAGS,
				NR_SRC_STORIES_COM.N_COMMENTS,
				NR_SRC_STORIES_COM.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_COM.BRIEF_DESC,
				NR_SRC_STORIES_COM.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_COM NR_SRC_STORIES_COM,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_COM
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_COM.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_COM
								);
COMMIT;

-- 4 NR_ENTRIES_WIK
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_WIK (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_WIK.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_WIK.SOURCE,
				NR_SRC_STORIES_WIK.SOURCE_TYPE,
				NR_SRC_STORIES_WIK.CONTAINER_ID,
				NR_SRC_STORIES_WIK.CONTAINER_NAME,
				NR_SRC_STORIES_WIK.CONTAINER_URL,
				NR_SRC_STORIES_WIK.ITEM_ID,
				NR_SRC_STORIES_WIK.ITEM_NAME,
				NR_SRC_STORIES_WIK.ITEM_URL,			
				NR_SRC_STORIES_WIK.CREATION_DATE,
				NR_SRC_STORIES_WIK.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_WIK.TAGS,
				NR_SRC_STORIES_WIK.N_COMMENTS,
				NR_SRC_STORIES_WIK.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_WIK.BRIEF_DESC,
				NR_SRC_STORIES_WIK.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_WIK NR_SRC_STORIES_WIK,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_WIK
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_WIK.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_WIK
								);
COMMIT;

-- 5 NR_ENTRIES_PRF
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_PRF (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_PRF.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_PRF.SOURCE,
				NR_SRC_STORIES_PRF.SOURCE_TYPE,
				NR_SRC_STORIES_PRF.CONTAINER_ID,
				NR_SRC_STORIES_PRF.CONTAINER_NAME,
				NR_SRC_STORIES_PRF.CONTAINER_URL,
				NR_SRC_STORIES_PRF.ITEM_ID,
				NR_SRC_STORIES_PRF.ITEM_NAME,
				NR_SRC_STORIES_PRF.ITEM_URL,			
				NR_SRC_STORIES_PRF.CREATION_DATE,
				NR_SRC_STORIES_PRF.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_PRF.TAGS,
				NR_SRC_STORIES_PRF.N_COMMENTS,
				NR_SRC_STORIES_PRF.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_PRF.BRIEF_DESC,
				NR_SRC_STORIES_PRF.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_PRF NR_SRC_STORIES_PRF,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_PRF
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_PRF.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_PRF
								);
COMMIT;

-- 6 NR_ENTRIES_HP
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_HP (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_HP.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_HP.SOURCE,
				NR_SRC_STORIES_HP.SOURCE_TYPE,
				NR_SRC_STORIES_HP.CONTAINER_ID,
				NR_SRC_STORIES_HP.CONTAINER_NAME,
				NR_SRC_STORIES_HP.CONTAINER_URL,
				NR_SRC_STORIES_HP.ITEM_ID,
				NR_SRC_STORIES_HP.ITEM_NAME,
				NR_SRC_STORIES_HP.ITEM_URL,			
				NR_SRC_STORIES_HP.CREATION_DATE,
				NR_SRC_STORIES_HP.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_HP.TAGS,
				NR_SRC_STORIES_HP.N_COMMENTS,
				NR_SRC_STORIES_HP.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_HP.BRIEF_DESC,
				NR_SRC_STORIES_HP.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_HP NR_SRC_STORIES_HP,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_HP
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_HP.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_HP
								);
COMMIT;

-- 7 NR_ENTRIES_DGR
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_DGR (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_DGR.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_DGR.SOURCE,
				NR_SRC_STORIES_DGR.SOURCE_TYPE,
				NR_SRC_STORIES_DGR.CONTAINER_ID,
				NR_SRC_STORIES_DGR.CONTAINER_NAME,
				NR_SRC_STORIES_DGR.CONTAINER_URL,
				NR_SRC_STORIES_DGR.ITEM_ID,
				NR_SRC_STORIES_DGR.ITEM_NAME,
				NR_SRC_STORIES_DGR.ITEM_URL,			
				NR_SRC_STORIES_DGR.CREATION_DATE,
				NR_SRC_STORIES_DGR.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_DGR.TAGS,
				NR_SRC_STORIES_DGR.N_COMMENTS,
				NR_SRC_STORIES_DGR.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_DGR.BRIEF_DESC,
				NR_SRC_STORIES_DGR.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_DGR NR_SRC_STORIES_DGR,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_DGR
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_DGR.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_DGR
								);
COMMIT;

-- 8 NR_ENTRIES_FILE
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_FILE (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_FILE.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_FILE.SOURCE,
				NR_SRC_STORIES_FILE.SOURCE_TYPE,
				NR_SRC_STORIES_FILE.CONTAINER_ID,
				NR_SRC_STORIES_FILE.CONTAINER_NAME,
				NR_SRC_STORIES_FILE.CONTAINER_URL,
				NR_SRC_STORIES_FILE.ITEM_ID,
				NR_SRC_STORIES_FILE.ITEM_NAME,
				NR_SRC_STORIES_FILE.ITEM_URL,			
				NR_SRC_STORIES_FILE.CREATION_DATE,
				NR_SRC_STORIES_FILE.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_FILE.TAGS,
				NR_SRC_STORIES_FILE.N_COMMENTS,
				NR_SRC_STORIES_FILE.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_FILE.BRIEF_DESC,
				NR_SRC_STORIES_FILE.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_FILE NR_SRC_STORIES_FILE,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_FILE
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_FILE.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FILE
								);
COMMIT;

-- 9 NR_ENTRIES_FRM
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM ADD ITEM_ATOM_URL VARCHAR2(2048);
COMMIT;

INSERT INTO HOMEPAGE.NR_ENTRIES_FRM (
	ENTRY_ID,
	SOURCE,
	SOURCE_TYPE,
	CONTAINER_ID,
	CONTAINER_NAME,
	CONTAINER_URL,
	ITEM_ID,
	ITEM_NAME,
	ITEM_URL,
	CREATION_DATE,
	UPDATE_DATE,
	TAGS,
	N_COMMENTS,
	N_RECCOMANDATIONS,
	N_ATTACHMENTS,
	BRIEF_DESC,
	ITEM_ATOM_URL
)
	SELECT *
	FROM (
		SELECT 	NR_SRC_STORIES_FRM.ITEM_ID ENTRY_ID,
				NR_SRC_STORIES_FRM.SOURCE,
				NR_SRC_STORIES_FRM.SOURCE_TYPE,
				NR_SRC_STORIES_FRM.CONTAINER_ID,
				NR_SRC_STORIES_FRM.CONTAINER_NAME,
				NR_SRC_STORIES_FRM.CONTAINER_URL,
				NR_SRC_STORIES_FRM.ITEM_ID,
				NR_SRC_STORIES_FRM.ITEM_NAME,
				NR_SRC_STORIES_FRM.ITEM_URL,			
				NR_SRC_STORIES_FRM.CREATION_DATE,
				NR_SRC_STORIES_FRM.CREATION_DATE UPDATE_DATE,
				NR_SRC_STORIES_FRM.TAGS,
				NR_SRC_STORIES_FRM.N_COMMENTS,
				NR_SRC_STORIES_FRM.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_SRC_STORIES_FRM.BRIEF_DESC,
				NR_SRC_STORIES_FRM.ITEM_ATOM_URL
		FROM 	HOMEPAGE.NR_SRC_STORIES_FRM NR_SRC_STORIES_FRM,
			(
				SELECT 	ITEM_ID, MAX(STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_SRC_STORIES_FRM
				WHERE 	ENTRY_ID IS NOT NULL
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_SRC_STORIES_FRM.STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FRM
								);
COMMIT;

-----------------------------------------------------------------------------------------------
-- START [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------
-- Putting back the constraints
-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);

COMMIT;	

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID);

COMMIT;

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);

COMMIT;

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID); 

COMMIT;

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID); 

COMMIT;

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID);

COMMIT;

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID);

COMMIT;

-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);

COMMIT;

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID);

COMMIT;
-----------------------------------------------------------------------------------------------
-- END [1\2] BUG: During fixup84.sql we lose data. We need to fix 84 as there is no way to recover the data after
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
-- END DATA MIGRATION
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------

-- DROPPING VIEW NR_ENTRIES 
DROP VIEW HOMEPAGE.NR_ENTRIES; 

--  DROPPING VIEW NR_STORIES
DROP VIEW HOMEPAGE.NR_STORIES;

COMMIT;

-----------------------------------------------------------------------
-- REFACTORING STORIES TABLE
-----------------------------------------------------------------------
-- DROPPING OLD COLUNNS FOR STORY TABLE: ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS
-- 1 NR_SRC_STORIES_ACT
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS); 
COMMIT;

--2 NR_SRC_STORIES_BLG
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS); 
COMMIT;

--3 NR_SRC_STORIES_COM
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS);
COMMIT;

--4 NR_SRC_STORIES_WIK
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS); 
COMMIT;

--5 NR_SRC_STORIES_PRF
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS);
COMMIT;

--6 NR_SRC_STORIES_HP
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS); 
COMMIT;

--7 NR_SRC_STORIES_DGR
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS);
COMMIT;

--8 NR_SRC_STORIES_FILE
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS); 
COMMIT;

--9 NR_SRC_STORIES_FRM
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM DROP (ITEM_ID, ITEM_NAME, ITEM_URL, N_COMMENTS, N_RECOMMANDATIONS);
COMMIT;
--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------
-- EMD FIX - ADDING UNIQUE CONSTRAINT
--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------

---------------------------------------------------------------------------------------------------------------------------
-- TO REMOVE ALL DUPLICATED RECORDS - WE NEED TO EXECUTE THIS QUERY N_TIME IN A PARTITIONED WAY TO DON'T GET FULL THE LOG.
-- THIS IS THE NOT PARTITIONED QUERIES
---------------------------------------------------------------------------------------------------------------------------
-- Sanitize first the table:
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF WHERE RESOURCE_PREF_ID NOT IN (
	SELECT TEMP.RESOURCE_PREF_ID
	FROM (
		SELECT 	MAX(RESOURCE_PREF_ID) RESOURCE_PREF_ID, PERSON_ID, RESOURCE_TYPE  
		FROM  	HOMEPAGE.EMD_RESOURCE_PREF
		GROUP BY 	PERSON_ID, RESOURCE_TYPE
	)  TEMP
);

COMMIT;

-- Add unique constraint:
CREATE UNIQUE INDEX HOMEPAGE.EMD_RESOURCE_PREF_UNQ
	ON HOMEPAGE.EMD_RESOURCE_PREF (PERSON_ID, RESOURCE_TYPE) TABLESPACE "NEWSINDEXTABSPACE";

COMMIT;

---------------------------------------------------------------------------------
-- ADDING QUARANTINE TABLE
---------------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.DELETED_STORIES_QUEUE (
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE 	VARCHAR2(36) NOT NULL, -- this is externalized
	SOURCE_TYPE NUMBER(5,0) NOT NULL	
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE 
  	ADD (CONSTRAINT PK_QUARANTINE PRIMARY KEY(STORY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

COMMIT;


ALTER TABLE "HOMEPAGE"."DELETED_STORIES_QUEUE" ENABLE ROW MOVEMENT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 85
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------------------
-- 1) ADD COLUMN TO THE EMD_EMAIL_PREFS TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS ADD REPLYTO_ENABLED NUMBER(5,0) DEFAULT 1 NOT NULL;

COMMIT;

-----------------------------------------------------------------------------------------------
-- 2) ADD COLUMNS TO THE EMD_TRANCHE TABLE
-----------------------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.EMD_TRANCHE ADD (
	IS_LOCKED_DAILY NUMBER(5,0) DEFAULT 0 NOT NULL,
	IS_LOCKED_WEEKLY NUMBER(5,0) DEFAULT 0 NOT NULL,
	LAST_STARTED_DAILY TIMESTAMP,
	LAST_STARTED_WEEKLY TIMESTAMP,
	LAST_EXEC_TIME_DAILY_MIN  NUMBER(10 ,0),
	LAST_EXEC_TIME_WEEKLY_MIN  NUMBER(10 ,0),
	LAST_RUNNER_DAILY VARCHAR2(256),
	LAST_RUNNER_WEEKLY VARCHAR2(256)
);

COMMIT;

---------------------------------------------------------------------------------
-- 3) MODIFY QUARANTINE TABLE
---------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.DELETED_STORIES_QUEUE ADD STATUS NUMBER(5,0) DEFAULT 0 NOT NULL;

COMMIT;

--------------------------------------------------------------------------------
-- 4) RENAMING TABLES
--------------------------------------------------------------------------------
DROP VIEW HOMEPAGE.NR_FOLLOWED_STORIES;

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_RESPONSES_STORIES DROP CONSTRAINT CK_CAT1_TYPE;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_STORIES RENAME TO NR_RESPONSES_READERS;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CONSTRAINT CK_CAT1_TYPE CHECK (CATEGORY_TYPE = 1);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_PROFILES_STORIES DROP CONSTRAINT CK_CAT2_TYPE;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_STORIES RENAME TO NR_PROFILES_READERS;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CONSTRAINT CK_CAT2_TYPE CHECK (CATEGORY_TYPE = 2);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_STORIES DROP CONSTRAINT CK_CAT3_TYPE;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_STORIES RENAME TO NR_COMMUNITIES_READERS;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CONSTRAINT CK_CAT3_TYPE CHECK (CATEGORY_TYPE = 3);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_STORIES DROP CONSTRAINT CK_CAT4_TYPE;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_STORIES RENAME TO NR_ACTIVITIES_READERS;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CONSTRAINT CK_CAT4_TYPE CHECK (CATEGORY_TYPE = 4);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_BLOGS_STORIES DROP CONSTRAINT CK_CAT5_TYPE;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_STORIES RENAME TO NR_BLOGS_READERS;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CONSTRAINT CK_CAT5_TYPE CHECK (CATEGORY_TYPE = 5);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_STORIES DROP CONSTRAINT CK_CAT6_TYPE;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_STORIES RENAME TO NR_BOOKMARKS_READERS;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CONSTRAINT CK_CAT6_TYPE CHECK (CATEGORY_TYPE = 6);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_FILES_STORIES DROP CONSTRAINT CK_CAT7_TYPE;
ALTER TABLE 	HOMEPAGE.NR_FILES_STORIES RENAME TO NR_FILES_READERS;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CONSTRAINT CK_CAT7_TYPE CHECK (CATEGORY_TYPE = 7);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_FORUMS_STORIES DROP CONSTRAINT CK_CAT8_TYPE;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_STORIES RENAME TO NR_FORUMS_READERS;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CONSTRAINT CK_CAT8_TYPE CHECK (CATEGORY_TYPE = 8);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_WIKIS_STORIES DROP CONSTRAINT CK_CAT9_TYPE;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_STORIES RENAME TO NR_WIKIS_READERS;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CONSTRAINT CK_CAT9_TYPE CHECK (CATEGORY_TYPE = 9);

COMMIT;

ALTER TABLE 	HOMEPAGE.NR_TAGS_STORIES DROP CONSTRAINT CK_CAT10_TYPE;
ALTER TABLE 	HOMEPAGE.NR_TAGS_STORIES RENAME TO NR_TAGS_READERS;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CONSTRAINT CK_CAT10_TYPE CHECK (CATEGORY_TYPE = 10);

COMMIT;

ALTER TABLE  HOMEPAGE.NR_RESPONSES_READERS ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_PROFILES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_COMMUNITIES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_ACTIVITIES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_BLOGS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_BOOKMARKS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_FILES_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_FORUMS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_WIKIS_READERS  ENABLE ROW MOVEMENT;
ALTER TABLE  HOMEPAGE.NR_TAGS_READERS  ENABLE ROW MOVEMENT;

COMMIT;

--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE CATEGORIES READERS TABLE
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
);

COMMIT;


  	


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 86
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- The field to store the latest contributor
-- The latest contributor is equal to the latest comment creator or if no comments are provided
-- is equal to the status update creator (actor_uuid)
ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD LAST_CONTRIBUTOR_ID VARCHAR2(36);

-- The field to store the latest updated date for a comment
-- If a comment is not updated it is equal to the creation date
ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD UPDATE_DATE TIMESTAMP;

COMMIT;	

-------------------------------------------------------
-- HOMEPAGE.BOARD_CURRENT_STATUS 
-- table to store the history of current status updates
-------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_CURRENT_STATUS  (
	CURRENT_STATUS_ID VARCHAR2(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID VARCHAR2(36) NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL,
	CURRENT_STATUS_SET TIMESTAMP NOT NULL
)
TABLESPACE "NEWSREGTABSPACE"; 

ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS 
    ADD (CONSTRAINT PK_CUR_ST_ID PRIMARY KEY (CURRENT_STATUS_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS
	ADD CONSTRAINT FK_CUR_ST_ACTOR_ID FOREIGN KEY (ACTOR_UUID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_CURRENT_STATUS
	ADD CONSTRAINT FK_CUR_ST_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES(ENTRY_ID);

CREATE INDEX HOMEPAGE.CURRENT_STATUS_INDEX 
	ON HOMEPAGE.BOARD_CURRENT_STATUS	(ACTOR_UUID ASC, CURRENT_STATUS_SET ASC, CURRENT_STATUS_ID ASC, ENTRY_ID ASC) TABLESPACE "NEWSINDEXTABSPACE";

CREATE UNIQUE INDEX HOMEPAGE.ACTOR_ENTRY 
	ON HOMEPAGE.BOARD_CURRENT_STATUS (ACTOR_UUID) TABLESPACE "NEWSINDEXTABSPACE";



COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- UPDATING SOURCE_TYPE TABLE
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE
	ADD IS_ENABLE NUMBER(5,0);

COMMIT;
	
UPDATE HOMEPAGE.NR_SOURCE_TYPE SET IS_ENABLE = 1;

COMMIT;

----------------------------------------------------------------------
-- [START] INDEX CLEANUP
----------------------------------------------------------------------

-----------------------------------------------
-- FIXING INDEXES ON COMM_STORIES TABLE
-----------------------------------------------
DROP INDEX  HOMEPAGE.NR_COMM_STORIES_COM_ID;

CREATE INDEX HOMEPAGE.NR_COMM_STORIES_CDATE
    ON HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE; 

CREATE INDEX HOMEPAGE.NR_COM_STORY_ID			ON	HOMEPAGE.NR_COMM_STORIES (COMMUNITY_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

COMMIT;

-- DROPPING UNUSED INDEXES FOR READERS TABLES
DROP INDEX  HOMEPAGE.RESPONSES_STORIES_CIDX;
DROP INDEX  HOMEPAGE.PROFILES_STORIES_CIDX;
DROP INDEX  HOMEPAGE.COMMUNITIES_STORIES_CIDX;
DROP INDEX  HOMEPAGE.ACTIVITIES_STORIES_CIDX;
DROP INDEX  HOMEPAGE.BLOGS_STORIES_CIDX;
DROP INDEX  HOMEPAGE.BOOKMARKS_STORIES_CIDX;
DROP INDEX  HOMEPAGE.FILES_STORIES_CIDX;
DROP INDEX  HOMEPAGE.FORUMS_STORIES_CIDX;
DROP INDEX  HOMEPAGE.WIKIS_STORIES_CIDX;
DROP INDEX  HOMEPAGE.TAGS_STORIES_CIDX;

-- ADDING INDEXES used to retrieve the evidence and delete records
CREATE INDEX HOMEPAGE.NR_RESP_READER_STORY 		ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_PRO_READER_STORY 		ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_COM_READER_STORY 		ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_ACT_READER_STORY 		ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_BLG_READER_STORY 		ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_BOOK_READER_STORY 		ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_FILES_READER_STORY 	ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_FORUMS_READER_STORY 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_WIKIS_READER_STORY 	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
CREATE INDEX HOMEPAGE.NR_TAGS_READER_STORY 		ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;



COMMIT;

-- DROPPING UNUSED INDEXES FOR ENTRIES TABLES
DROP INDEX  HOMEPAGE.NR_ENTRIES_ACT_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_BLG_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_COM_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_WIK_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_PRF_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_HP_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_DGR_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_FILE_SRC;
DROP INDEX  HOMEPAGE.NR_ENTRIES_FRM_SRC;

-- DROPPING UNUSED INDEXES FOR STORIES TABLES
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_ACT_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_BLG_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_COM_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_WIK_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_PRF_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_HP_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_DGR_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_FILE_SIDX;
DROP INDEX  HOMEPAGE.NR_SRC_STORIES_FRM_SIDX;




----------------------------------------------------------------------
-- [END] INDEX CLEANUP
----------------------------------------------------------------------

---------------------------------------------------------
-- [START] EMD INIT DATA
---------------------------------------------------------
UPDATE HOMEPAGE.EMD_TRANCHE	SET 	
		IS_LOCKED = 0,
		IS_LOCKED_DAILY = 0,
		IS_LOCKED_WEEKLY = 0;
---------------------------------------------------------
-- [END] EMD INIT DATA
---------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_STORIES TABLES 
--------------------------------------------------------
-- Adding to story table:
-- i) MESSAGE
-- ii) EVENT_TIME
--- iii) VERB
--------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);

COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);


COMMIT;

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD MESSAGE VARCHAR2(4000)
	ADD EVENT_TIME TIMESTAMP
	ADD VERB VARCHAR2 (128);
	

COMMIT;	
--------------------------------------------------------
-- [END] UPDATING NR_STORIES TABLES
--------------------------------------------------------

--------------------------------------------------------
-- [START] UPDATING NR_ENTRIES TABLES ADDING
--------------------------------------------------------
--  FIRST: we need to move it do a bigger table space
-- i) Adding preview URL
-- ii) Adding status update column
-- iii) Adding JSON_META_DATA column
-- iv) Event time
--------------------------------------------------------
------------------------------------------------------------------------------------
-- CREATING NEW TABLES (Those new tables will also have the new required fields)
-- Which are: MESSAGE, PREVIEW_IMAGE_URL, JSON_META_DATA
--	MESSAGE VARCHAR2(4000),
--	PREVIEW_IMAGE_URL VARCHAR2(2048),
--	JSON_META_DATA VARCHAR2(4000),
--	EVENT_TIME TIMESTAMP,
------------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_COM
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_HP
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM
	ADD MESSAGE VARCHAR2(4000)
	ADD PREVIEW_IMAGE_URL VARCHAR2(2048)
	ADD JSON_META_DATA VARCHAR2 (4000)
	ADD EVENT_TIME TIMESTAMP;

COMMIT;

--------------------------------------------------------
-- [END] UPDATING NR_ENTRIES TABLES
--------------------------------------------------------


---------------------------------------------
-- Adding VERB and USE_IN_ROLLUP columns to the readers tables
---------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;
	

COMMIT;

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;
	
COMMIT;

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_FILES_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;	

COMMIT;

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

ALTER TABLE HOMEPAGE.NR_TAGS_READERS
	ADD  		USE_IN_ROLLUP 		NUMBER(5,0)
	ADD			IS_NETWORK			NUMBER(5,0)
	ADD			IS_FOLLOWER			NUMBER(5,0)
	ADD			EVENT_TIME 			TIMESTAMP;

COMMIT;

-----------------------------------------------------------
-- ADDING A NR_STATUS_UPDATE_READER
-----------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories (we don't need to add source here as they already exist)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('status_update_x8b0bx51af2ddef2cd', 11, '%status_update', 'status_update');

--------------------------------------------------------------------------
-- 11) HOMEPAGE.NR_STATUS_UPDATE_READERS
--------------------------------------------------------------------------	
CREATE TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS (
	FOLLOWED_STORY_ID VARCHAR2(36) NOT NULL,
	READER_ID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	USE_IN_ROLLUP NUMBER(5,0),
	IS_NETWORK	NUMBER(5,0),
	IS_FOLLOWER	NUMBER(5,0),
	EVENT_TIME TIMESTAMP,
   	CONSTRAINT  CK_CAT11_TYPE
    			CHECK
    			(CATEGORY_TYPE = 11)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS 
    ADD (CONSTRAINT PK_SU_READERS PRIMARY KEY(FOLLOWED_STORY_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
    
CREATE INDEX HOMEPAGE.SU_STORIES_IDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SU_STORIES_SIDX
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SU_STORIES_ITEM_ID
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SU_STORIES_READER_STORY
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;	

COMMIT;


ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS  		ENABLE ROW MOVEMENT;

---------------------------------------------------------
-- [START] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------
----------------------------------------------------------
-- Adding ACTIVITY_META_DATA to NR_STORIES_CONTENT table
----------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD ACTIVITY_META_DATA CLOB
	LOB (ACTIVITY_META_DATA) STORE AS (TABLESPACE NEWSLOBTABSPACE 
	STORAGE (INITIAL 1M)
	CHUNK 4000
	NOCACHE NOLOGGING);
	

COMMIT;
----------------------------------------------------------

---------------------------------------------------------------------------------
-- INSERTING THIRD PARTY CATEGORIES AND SOURCES
---------------------------------------------------------------------------------
-- Adding a new category (used from UI rendering) and source (used a source of stories from component)
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('ext_9cax4cc4x8b0bx51af2ddef2cd', 12, '%external', 'external');

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, SOURCE_TYPE_NAME, SOURCE_TYPE_DESC, IS_ENABLE)
VALUES ('ext_____fdfdc9cax80bx51af2', 100, '%external', 'external', 0);

---------------------------------------------------------
-- 12) ADDING A NR_EXTERNAL_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_EXTERNAL_READERS (
	FOLLOWED_STORY_ID VARCHAR2(36) NOT NULL,
	READER_ID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	USE_IN_ROLLUP NUMBER(5,0),
	IS_NETWORK	NUMBER(5,0),
	IS_FOLLOWER	NUMBER(5,0),
	EVENT_TIME TIMESTAMP,
   	CONSTRAINT  CK_CAT12_TYPE
    			CHECK
    			(CATEGORY_TYPE = 12)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS 
    ADD (CONSTRAINT PK_EXT_STORIES PRIMARY KEY(FOLLOWED_STORY_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
    
CREATE INDEX HOMEPAGE.EXT_STORIES_IDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.EXT_STORIES_SIDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.EXT_STORIES_ITEM_ID
    ON HOMEPAGE.NR_EXTERNAL_READERS (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.EXT_STORIES_READER_STORY
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;    


ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS  ENABLE ROW MOVEMENT;

--------------------------------------------------------------
-- ADDING A NR_ENTRIES_EXTERNAL TABLE
--------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  (
	ENTRY_ID VARCHAR2(36) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	CONTAINER_ID VARCHAR2(256),
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ID VARCHAR2(36) NOT NULL,
	ITEM_NAME VARCHAR2(256),
	ITEM_URL VARCHAR2(2048),
	CREATION_DATE TIMESTAMP NOT NULL,
	UPDATE_DATE TIMESTAMP NOT NULL,
	TAGS VARCHAR2(1024),
	N_COMMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_RECCOMANDATIONS NUMBER(5,0) DEFAULT 0 NOT NULL,
	N_ATTACHMENTS NUMBER(5,0) DEFAULT 0 NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	LAST_RECOMMENDER_ID VARCHAR2(36),
	LAST_DATE_RECOMMENDER_ID TIMESTAMP,
	PREV_RECOMMENDER_ID VARCHAR2(36),
	PREV_DATE_RECOMMENDER_ID TIMESTAMP,
	LAST_COMMENT_ID VARCHAR2(36),
	LAST_DATE_COMMENT TIMESTAMP,
	LAST_DESC_COMMENT VARCHAR2(256),
	LAST_AUTHOR_COMMENT VARCHAR2(36),
	PREV_COMMENT_ID VARCHAR2(36),
	PREV_DATE_COMMENT TIMESTAMP,
	PREV_DESC_COMMENT VARCHAR2(256),
	PREV_AUTHOR_COMMENT VARCHAR2(36),
	TARGET_SUBJECT_ID VARCHAR2(36),
	ITEM_ATOM_URL VARCHAR2(2048),
	MESSAGE VARCHAR2(4000),
	PREVIEW_IMAGE_URL VARCHAR2(2048),
	JSON_META_DATA VARCHAR2(4000),
	EVENT_TIME TIMESTAMP,
	CONSTRAINT   	CK_ENT_SRC10_TYPE
    				CHECK
    				(SOURCE_TYPE = 10)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL 
    ADD (CONSTRAINT PK_EXT_ENTRY_ID PRIMARY KEY(ENTRY_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_ENTRIES_EXT_CONT
    ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CONTAINER_ID) TABLESPACE NEWSINDEXTABSPACE;
    
COMMIT;


ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL  ENABLE ROW MOVEMENT;

----------------------------------------------------
-- ADDING A NR_SRC_STORIES_EXTERNAL TABLE
----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_CORRELATION_ID VARCHAR2(36),
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0,
	SOURCE_TYPE NUMBER(5,0),
	ENTRY_ID VARCHAR2(36),
	MESSAGE VARCHAR2(4000),
	EVENT_TIME TIMESTAMP,
	VERB VARCHAR2 (128),	
	CONSTRAINT   	CK_SRC100_TYPE
    				CHECK
    				(SOURCE_TYPE >= 10)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
    ADD (CONSTRAINT PK_EXT_STORY_ID PRIMARY KEY(STORY_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL
  	ADD CONSTRAINT FK_ENTRY_ID_EXT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_EXTERNAL (ENTRY_ID);    

CREATE INDEX HOMEPAGE.SRC_STORIES_EXT_DATE
	ON HOMEPAGE.NR_ENTRIES_EXTERNAL (CREATION_DATE DESC) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SRC_EXT_CONTAINER_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (CONTAINER_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.SRC_EXT_ITEM_CORR_ID
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ITEM_CORRELATION_ID) TABLESPACE NEWSINDEXTABSPACE;
    
CREATE INDEX HOMEPAGE.SRC_STORIES_EXT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_EXTERNAL (ENTRY_ID) TABLESPACE NEWSINDEXTABSPACE;  


ALTER TABLE HOMEPAGE.NR_SRC_STORIES_EXTERNAL  ENABLE ROW MOVEMENT;

---------------------------------------------------------
-- [END] THIRD PARTY EVENTS HANDLING CHANGES
---------------------------------------------------------


---------------------------------------------------------
-- [START] ACTIONABLE
---------------------------------------------------------
-- Adding four new categories for ui rendering of actianable stories
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_saved_stories_4cc4x8b0bx', 13, '%actionable_saved_stories', 'actionable_saved_stories');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_directed_notification_bx', 14, '%actionable_directed_notification', 'actionable_directed_notification');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_todo_______cax4cc4x8b0bx', 15, '%actionable_todo', 'actionable_todo');

INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('actionable_action_required__4x8b0bx', 16, '%actionable_action_required', 'actionable_action_required');

COMMIT;


---------------------------------------------------------
-- ADDING NR_ACTIONABLE_READERS READER TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_READERS (
	ACTIONABLE_READER_ID VARCHAR2(36) NOT NULL,
	READER_ID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	USE_IN_ROLLUP NUMBER(5,0),
	IS_NETWORK	NUMBER(5,0),
	IS_FOLLOWER	NUMBER(5,0),
	EVENT_TIME TIMESTAMP,
	NOTE_TEXT VARCHAR2(4000),
	NOTE_UPDATE_DATE TIMESTAMP,
	CONSTRAINT   	CK_CAT_ACTION_TYPE
    				CHECK
    				(CATEGORY_TYPE >= 13 AND CATEGORY_TYPE <= 16)	
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS 
    ADD (CONSTRAINT PK_ACTION_STORIES PRIMARY KEY (ACTIONABLE_READER_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
    
CREATE INDEX HOMEPAGE.ACTION_READER_STORIES_IDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.ACTION_READER_SIDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.ACTION_READER_ITEM_ID
    ON HOMEPAGE.NR_ACTIONABLE_READERS (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE UNIQUE INDEX HOMEPAGE.ACTION_READER_STORY
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;  

    

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ENABLE ROW MOVEMENT;

COMMIT;

---------------------------------------------------------
-- ADDING NR_ACTIONABLE_STORIES TABLE
---------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_ACTIONABLE_STORIES (
	STORY_ID VARCHAR2(36) NOT NULL,
	EVENT_NAME VARCHAR2(256) NOT NULL,
	SOURCE VARCHAR2(36),
	CONTAINER_ID VARCHAR2(256),	
	CONTAINER_NAME VARCHAR2(256),
	CONTAINER_URL VARCHAR2(2048),
	ITEM_ATOM_URL VARCHAR2(2048),
	ITEM_CORRELATION_ID VARCHAR2(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR2(512),
	ACTOR_UUID VARCHAR2(36),
	EVENT_RECORD_UUID VARCHAR2(36) NOT NULL,
	TAGS VARCHAR2(1024),
	META_TEMPLATE VARCHAR2(4000) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR2(1024),
	R_META_TEMPLATE VARCHAR2(4000),
	R_TEXT_META_TEMPLATE VARCHAR2(1024),
	IS_COMMUNITY_STORY NUMBER(5,0) DEFAULT 0,
	ITEM_CORRELATION_NAME VARCHAR2(256),
	HAS_ATTACHMENT NUMBER(5,0) DEFAULT 0,
	SOURCE_TYPE NUMBER(5,0),
	ENTRY_ID VARCHAR2(36),
	MESSAGE VARCHAR2(4000),
	EVENT_TIME TIMESTAMP,
	VERB VARCHAR2 (128),
	CONSTRAINT   	CK_SRC_ACTION_TYPE
    				CHECK
    				(SOURCE_TYPE >= 1 AND SOURCE_TYPE <= 10 )
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_STORIES
    ADD (CONSTRAINT PK_ACTION_STORY_ID PRIMARY KEY(STORY_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.ACTION_CONTAINER_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (CONTAINER_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.ACTION_ITEM_CORR_ID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ITEM_CORRELATION_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.ACTION_ACT_ENTRYID
    ON HOMEPAGE.NR_ACTIONABLE_STORIES (ENTRY_ID) TABLESPACE NEWSINDEXTABSPACE;    



ALTER TABLE HOMEPAGE.NR_ACTIONABLE_STORIES ENABLE ROW MOVEMENT;

COMMIT;
	
---------------------------------------------------------
-- [END] ACTIONABLE
---------------------------------------------------------

DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 88
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------
-- FIX CONSTRAINT ON SOURCE_TYPE FOR NR_ENTRIES_EXTERNAL
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL DROP CONSTRAINT CK_ENT_SRC10_TYPE;

ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL ADD CONSTRAINT CK_ENT_SRC100_TYPE
    													CHECK
    													(SOURCE_TYPE >= 100);
COMMIT;

-----------------------------------------------
-- ADD ROLLUP_ENTRY_ID FOREIGN KEY TO READER TABLES
-----------------------------------------------
ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_PROFILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_BLOGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_FILES_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_FORUMS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_WIKIS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_TAGS_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

ALTER TABLE HOMEPAGE.NR_ACTIONABLE_READERS ADD ROLLUP_ENTRY_ID VARCHAR2(36);
COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-----------------------------------------------------------------------------------
-- Remove NR_NEWS_PRF_COMMENT
-----------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_PRF_COMMENT;

COMMIT;


-----------------------------------------------------------------------------------
-- Rename all the PK in the reader tables to be CATEGORY_READER_ID;
-----------------------------------------------------------------------------------
-- 1
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS DROP CONSTRAINT PK_RESP_STORIES;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_RESPONSES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD (CONSTRAINT PK_RESP_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_RESP_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_RESP_READER_STORY 		
	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 2
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS DROP CONSTRAINT PK_PROF_STORIES;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_PROFILES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD (CONSTRAINT PK_PROF_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_PRO_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_PRO_READER_STORY 		
	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 3
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS DROP CONSTRAINT PK_COMM_STORIES;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_COMMUNITIES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD (CONSTRAINT PK_COMM_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_COM_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_COM_READER_STORY 		
	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 4
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS DROP CONSTRAINT PK_ACT_STORIES;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_ACTIVITIES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD (CONSTRAINT PK_ACT_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_ACT_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_ACT_READER_STORY 		
	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 5
ALTER TABLE		HOMEPAGE.NR_BLOGS_READERS DROP CONSTRAINT PK_BLOGS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_BLOGS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD (CONSTRAINT PK_BLOGS_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_BLG_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_BLG_READER_STORY 		
	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 6
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS  DROP CONSTRAINT PK_BOOKS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_BOOKMARKS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD (CONSTRAINT PK_BOOKS_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_BOOK_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_BOOK_READER_STORY 		
	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 7
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS DROP CONSTRAINT PK_FILES_STORIES;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_FILES_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD (CONSTRAINT PK_FILES_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_FILES_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_FILES_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_FILES_READER_STORY 		
	ON HOMEPAGE.NR_FILES_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 8
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS DROP CONSTRAINT PK_FORUMS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_FORUMS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD (CONSTRAINT PK_FORUMS_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_FORUMS_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_FORUMS_READER_STORY 	
	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 9
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS DROP CONSTRAINT PK_WIKIS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_WIKIS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD (CONSTRAINT PK_WIKIS_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_WIKIS_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_WIKIS_READER_STORY 		
	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 10
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS DROP CONSTRAINT PK_TAGS_STORIES;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_TAGS_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD (CONSTRAINT PK_TAGS_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.NR_TAGS_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.NR_TAGS_READER_STORY 		
	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
	
COMMIT;

-- 11 NR_STATUS_UPDATE_READERS
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS DROP CONSTRAINT PK_SU_READERS;
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_STATUS_UPDATE_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD (CONSTRAINT PK_SU_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.SU_STORIES_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.SU_STORIES_READER_STORY
    ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
    
COMMIT;

-- 12 NR_EXTERNAL_READERS
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS DROP CONSTRAINT PK_EXT_STORIES;
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_EXTERNAL_READERS SET CATEGORY_READER_ID = FOLLOWED_STORY_ID;
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD (CONSTRAINT PK_EXT_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS DROP COLUMN FOLLOWED_STORY_ID;

ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

DROP INDEX HOMEPAGE.EXT_STORIES_READER_STORY;

CREATE UNIQUE INDEX HOMEPAGE.EXT_STORIES_READER_STORY
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;
    
COMMIT;

-- 13-16 ACTIONABLE TABLES
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS DROP CONSTRAINT PK_ACTION_STORIES;
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL;
UPDATE 			HOMEPAGE.NR_ACTIONABLE_READERS SET CATEGORY_READER_ID = ACTIONABLE_READER_ID;
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD (CONSTRAINT PK_ACTION_READERS PRIMARY KEY(CATEGORY_READER_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS DROP COLUMN ACTIONABLE_READER_ID;

ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS ADD IS_STORY_COMM NUMBER(5 ,0);

COMMIT;

-------------------------------------------------------------------
-- Remove NR_ACTIONABLE_STORIES
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ACTIONABLE_STORIES; 
COMMIT;

-------------------------------------------------------------------
-- TODO: Remove the 4 categories type, leave just one category (16)
-------------------------------------------------------------------

-------------------------------------------------------------------
-- TODO: Rename COMM_PERSON_STORIES to be HOMEPAGE.NR_AGGREGATED_READERS. Make it compatible withe other table
-------------------------------------------------------------------
-- Add a category type: aggregated_readers
CREATE TABLE HOMEPAGE.NR_AGGREGATED_READERS (
	CATEGORY_READER_ID VARCHAR2(36) DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR2(36) NOT NULL,
	CATEGORY_TYPE NUMBER(5 ,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	ROLLUP_ENTRY_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5 ,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5 ,0),
	USE_IN_ROLLUP NUMBER(5 ,0),
	IS_NETWORK	NUMBER(5 ,0),
	IS_FOLLOWER	NUMBER(5 ,0),
	EVENT_TIME 	TIMESTAMP,
	IS_STORY_COMM NUMBER(5 ,0)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_AGGREGATED_READERS
    ADD (CONSTRAINT PK_AGG_READERS PRIMARY KEY(CATEGORY_READER_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.NR_AGGREGATED_READERS_IDX
    ON HOMEPAGE.NR_AGGREGATED_READERS (CREATION_DATE ASC, READER_ID);

CREATE INDEX HOMEPAGE.NR_AGGREGATED_READERS_STORY_ID
    ON HOMEPAGE.NR_AGGREGATED_READERS (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.NR_AGGREGATED_READERS_ITEM_ID
    ON HOMEPAGE.NR_AGGREGATED_READERS (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.NR_AGGREGATED_READERS_DATE
    ON HOMEPAGE.NR_AGGREGATED_READERS (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE UNIQUE INDEX HOMEPAGE.NR_AGG_READERS_UNQ
     ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE; 


ALTER TABLE HOMEPAGE.NR_AGGREGATED_READERS ENABLE ROW MOVEMENT;

COMMIT;

-------------------------------------------------------------------    
-- MIGRATION FROM: NR_COMM_PERSON_STORIES -> NR_AGGREGATED_READERS
-------------------------------------------------------------------  
INSERT INTO HOMEPAGE.NR_AGGREGATED_READERS
	SELECT 	COMM_PER_STORY_ID,
			COMM_PER_READER_ID,
			CATEGORY_TYPE,
			SOURCE,
			CONTAINER_ID,
			ITEM_ID,
			' ' ROLLUP_ENTRY_ID,
			RESOURCE_TYPE,
			CREATION_DATE,
			STORY_ID,
			SOURCE_TYPE,
			USE_IN_ROLLUP,
			IS_NETWORK,
			IS_FOLLOWER,
			EVENT_TIME,
			IS_STORY_COMM
	FROM 	HOMEPAGE.NR_COMM_PERSON_STORIES;

COMMIT;

-- DROPPING PREV. TABLE
DROP TABLE HOMEPAGE.NR_COMM_PERSON_STORIES;

-------------------------------------------------------------------
-- Remove N_COMMENTS and N_RECOMMANDATIONS from BOARD_ENTRIES
-------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.BOARD_ENTRIES DROP COLUMN N_COMMENTS;
COMMIT;
ALTER TABLE 	HOMEPAGE.BOARD_ENTRIES DROP COLUMN N_RECOMMANDATIONS;
COMMIT;



-------------------------------------------------------------------
-- BOARD_OBJECT_REFERENCE 
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

CREATE TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE (
	OBJECT_ID VARCHAR2(47) NOT NULL,
	ENTRY_ID VARCHAR2(47) NOT NULL,
	DISPLAY_NAME VARCHAR2(2048),
	IMAGE_NAME   VARCHAR2(2048),
	NAME VARCHAR2(1024),
	URL VARCHAR2(2048),
	CONTENT VARCHAR2(4000),
	IMAGE_URL VARCHAR2(2048),
	SOURCE  VARCHAR2(36),
	SOURCE_TYPE  NUMBER(5 ,0),
	CREATION_DATE TIMESTAMP,
	MIME_TYPE VARCHAR2(36),
	AUTHOR_ID VARCHAR2(36),
	AUTHOR_DISPLAY_NAME VARCHAR2(256)	
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE 
    ADD (CONSTRAINT PK_BRD_OBJ_ID PRIMARY KEY(OBJECT_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_OBJ_ENTRY FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ADD CONSTRAINT FK_BRD_AUTHOR_ID FOREIGN KEY (AUTHOR_ID)
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE INDEX HOMEPAGE.BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (ENTRY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.BRD_AUTHOR_IDX
    ON HOMEPAGE.BOARD_OBJECT_REFERENCE (AUTHOR_ID) TABLESPACE NEWSINDEXTABSPACE;



ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE ENABLE ROW MOVEMENT;

COMMIT;

-----------------------------------------------
-- UPDATE PERSON
-----------------------------------------------
ALTER TABLE HOMEPAGE.PERSON
	ADD THEME_ID VARCHAR2(36);

ALTER TABLE HOMEPAGE.PERSON
	ADD COMM_VISIBILITY NUMBER(5 ,0);	

ALTER TABLE HOMEPAGE.PERSON
	ADD MEMBER_TYPE NUMBER(5 ,0) DEFAULT 0;

UPDATE HOMEPAGE.PERSON SET MEMBER_TYPE = 0;

COMMIT;

ALTER TABLE HOMEPAGE.PERSON 
	MODIFY MEMBER_TYPE NUMBER(5 ,0) NOT NULL;
 
COMMIT;

UPDATE HOMEPAGE.PERSON SET MEMBER_TYPE = 2 WHERE PERSON_ID = '00000000-0000-0000-0000-000000000000';

COMMIT;

-----------------------------------------------
-- HOMEPAGE.NR_COMM_SETTINGS
-----------------------------------------------

CREATE TABLE HOMEPAGE.NR_COMM_SETTINGS (
	COMM_ID VARCHAR2(36) NOT NULL,
	MICROBLOGGING_WRITE_ACL NUMBER(5 ,0),
	FLAGS VARCHAR2(36)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS
    ADD (CONSTRAINT PK_COMM_ID PRIMARY KEY(COMM_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS ENABLE ROW MOVEMENT;


--------------------------------------------------------------------------
-- 17 HOMEPAGE.NR_DISCOVERY_VIEW
--------------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_DISCOVERY_VIEW (
	CATEGORY_READER_ID VARCHAR2(36)  DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR2(36),
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	ROLLUP_ENTRY_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	USE_IN_ROLLUP NUMBER(5,0),
	IS_NETWORK	NUMBER(5,0),
	IS_FOLLOWER	NUMBER(5,0),
	EVENT_TIME TIMESTAMP,
	IS_STORY_COMM NUMBER(5 ,0),
	CONSTRAINT   CK_CAT17_TYPE
    			CHECK
    			(CATEGORY_TYPE = 17)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_DISCOVERY_VIEW 
    ADD (CONSTRAINT PK_DISCOVERY_VIEW PRIMARY KEY(CATEGORY_READER_ID)   USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.DISCOVERY_STORIES_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE ASC)  TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.DISCOVERY_SIDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (STORY_ID)  TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.DISCOVERY_ITEM
    ON HOMEPAGE.NR_DISCOVERY_VIEW (ITEM_ID)  TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.DISCOVERY_STORIES_DATE
    ON HOMEPAGE.NR_DISCOVERY_VIEW (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE UNIQUE INDEX HOMEPAGE.DISCOVERY_READER_STORY 		
	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, STORY_ID)  TABLESPACE NEWSINDEXTABSPACE;   



INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('discovery-view', 17, '%discovery', 'discovery');

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 90
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.NR_COMM_SETTINGS;

-----------------------------------------------
-- HOMEPAGE.NR_COMM_SETTINGS
-----------------------------------------------

CREATE TABLE HOMEPAGE.NR_COMM_SETTINGS (
	COMM_ID VARCHAR2(36) NOT NULL,
	MICROBLOGGING_WRITE_ACL NUMBER(5 ,0),
	FLAGS VARCHAR2(36)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS
    ADD (CONSTRAINT PK_COMM_ID PRIMARY KEY(COMM_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_COMM_SETTINGS ENABLE ROW MOVEMENT;



COMMIT; 

-----------------------------------------------------
-- NR_PROFILES_VIEW
-----------------------------------------------------
CREATE TABLE HOMEPAGE.NR_PROFILES_VIEW (
	CATEGORY_READER_ID VARCHAR2(36)  DEFAULT ' ' NOT NULL,
	READER_ID VARCHAR2(36),
	CATEGORY_TYPE NUMBER(5,0) NOT NULL,
	SOURCE VARCHAR2(36) NOT NULL,
	CONTAINER_ID VARCHAR2(256),
	ITEM_ID VARCHAR2(36),
	ROLLUP_ENTRY_ID VARCHAR2(36),
	RESOURCE_TYPE NUMBER(5,0) NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0),
	USE_IN_ROLLUP NUMBER(5,0),
	IS_NETWORK	NUMBER(5,0),
	IS_FOLLOWER	NUMBER(5,0),
	EVENT_TIME TIMESTAMP,
	IS_STORY_COMM NUMBER(5 ,0),
	IS_BROADCAST NUMBER(5 ,0),
	ORGANIZATION_ID VARCHAR2(36),
	CONSTRAINT   	CK_CAT18_TYPE
    				CHECK
    				(CATEGORY_TYPE = 18)
)
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_PROFILES_VIEW 
    ADD (CONSTRAINT PK_PROFILES_VIEW PRIMARY KEY(CATEGORY_READER_ID)  USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

CREATE INDEX HOMEPAGE.PROFILES_VIEW_IDX
    ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.PROFILES_SIDX
    ON HOMEPAGE.NR_PROFILES_VIEW (STORY_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.PROFILES_ITEM
    ON HOMEPAGE.NR_PROFILES_VIEW (ITEM_ID) TABLESPACE NEWSINDEXTABSPACE;

CREATE INDEX HOMEPAGE.PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE ASC) TABLESPACE NEWSINDEXTABSPACE;

CREATE UNIQUE INDEX HOMEPAGE.PROFILES_READER_STORY 		
	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, STORY_ID) TABLESPACE NEWSINDEXTABSPACE;   

ALTER TABLE HOMEPAGE.NR_PROFILES_VIEW ENABLE ROW MOVEMENT;



---------------------------------------------------------------------------------
-- Adding a new category for profiles view
---------------------------------------------------------------------------------
INSERT INTO HOMEPAGE.NR_CATEGORY_TYPE (CATEGORY_TYPE_ID, CATEGORY_TYPE, CATEGORY_TYPE_NAME, CATEGORY_TYPE_DESC)
VALUES ('profiles-view', 18, '%profiles', 'profiles');

---------------------------------------------------------------------------------
-- Adding IS_BROADCAST to ALL the readers table
---------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_AGGREGATED_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_RESPONSES_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_PROFILES_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_COMMUNITIES_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIVITIES_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_BLOGS_READERS			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_BOOKMARKS_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_FILES_READERS			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_FORUMS_READERS			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_WIKIS_READERS			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_TAGS_READERS			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_STATUS_UPDATE_READERS	ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_EXTERNAL_READERS		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_ACTIONABLE_READERS 		ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  IS_BROADCAST NUMBER(5,0);
ALTER TABLE 	HOMEPAGE.NR_DISCOVERY_VIEW			ADD  ORGANIZATION_ID VARCHAR2(36);

COMMIT;

-------------------------------------------------------------------------------
-- ADDING ACTIVITY_META_DATA_1 and ACTIVITY_META_DATA_2
-------------------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_ACT			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_BLG			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_COM			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_WIK			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_PRF			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_HP			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_DGR			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FILE		ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_FRM			ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_1 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  ACTIVITY_META_DATA_2 RAW(2000);
ALTER TABLE 	HOMEPAGE.NR_SRC_STORIES_EXTERNAL	ADD  IS_META_DATA_TRUNCATED  NUMBER(5,0);
COMMIT;


-------------------------------------------------------------------
-- REMOVING NR_ORGPERSON_FOLLOW AND NR_ORGPERSON_STORIES
-------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_ORGPERSON_STORIES;
DROP TABLE HOMEPAGE.NR_ORGPERSON_FOLLOW;
COMMIT;

-------------------------------------------------------------------
-- Add to: NR_ENTRIES_* the column SCOPE
-------------------------------------------------------------------
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_ACT			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_BLG			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_COM			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_WIK			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_PRF			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_HP			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_DGR			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FILE		ADD  SCOPE NUMBER(5,0);	
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_FRM			ADD  SCOPE NUMBER(5,0);
COMMIT;
ALTER TABLE 	HOMEPAGE.NR_ENTRIES_EXTERNAL	ADD  SCOPE NUMBER(5,0);
COMMIT;

---------------------------------
-- CONVERT BLOB to CLOB
---------------------------------
-- TODO
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start NEWS FIXUP 92
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------
-- [START] Changing definition for SOURCE_TYPE table
----------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_SOURCE_TYPE;

CREATE TABLE HOMEPAGE.NR_SOURCE_TYPE (
	SOURCE_TYPE_ID VARCHAR2(36) NOT NULL,
	SOURCE_TYPE NUMBER(5,0) NOT NULL, -- numeric that is 1,2,3 etc.. 100, 101..
	EXTERNAL_ID VARCHAR2(256) NOT NULL,
	DISPLAY_NAME VARCHAR2(4000),
	IMAGE_URL VARCHAR2(2048),
	PUBLISHED TIMESTAMP,
	UPDATED VARCHAR2(256),	
	IS_ENABLED NUMBER(5,0),
	SUMMARY VARCHAR2 (4000)
)	
TABLESPACE "NEWSREGTABSPACE";

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
  	ADD (CONSTRAINT PK_SRC_TYPE_ID PRIMARY KEY(SOURCE_TYPE_ID) USING INDEX TABLESPACE "NEWSINDEXTABSPACE");

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_TYPE_UNQ UNIQUE(SOURCE_TYPE);

ALTER TABLE HOMEPAGE.NR_SOURCE_TYPE 
	ADD CONSTRAINT SRC_EXT_ID_UNQ UNIQUE(EXTERNAL_ID);
	
ALTER TABLE "HOMEPAGE"."NR_SOURCE_TYPE" ENABLE ROW MOVEMENT;	
	
-- Update also the init data 

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('activities_c9cax4cc4x80bx51af2ddef2c', 1, 'int_activities_id', 'activities', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('blogs_c9cax4cc4x80bx51af2ddef2c', 2, 'int_blogs_id', 'blogs', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('communities_c9cax4cc4x80bx51af2d', 3, 'int_communities_id', 'communities', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('wikis_c9cax4cc4x80bx51af2ddef2c', 4, 'int_wikis_id', 'wikis', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('profiles_c9cax4cc4x80bx51af2ddef2c', 5, 'int_profiles_id', 'profiles', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('homepage_c9cax4cc4x80bx51af2ddef2c', 6, 'int_homepage_id', 'homepage', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('dogear_c9cax4cc4x80bx51af2ddef2c', 7, 'int_dogear_id', 'dogear', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('files_c9cax4cc4x80bx51af2ddef2c', 8, 'int_files_id', 'files', null, null, null, 1, null);

INSERT INTO HOMEPAGE.NR_SOURCE_TYPE (SOURCE_TYPE_ID, SOURCE_TYPE, EXTERNAL_ID, DISPLAY_NAME, IMAGE_URL, PUBLISHED, UPDATED, IS_ENABLED, SUMMARY)
VALUES ('forums_c9cax4cc4x80bx51af2ddef2c', 9, 'int_forums_id', 'forums', null, null, null, 1, null);
	
	
----------------------------------------------------------------
-- [END] Changing definition for SOURCE_TYPE table
----------------------------------------------------------------

------------------------------------------------------
-- [START] Adding indexes to the readers tables
------------------------------------------------------

--DISCOVERY VIEW READERS:
CREATE INDEX HOMEPAGE.DISCOVERY_STORIES_SRC_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, SOURCE_TYPE)  TABLESPACE NEWSINDEXTABSPACE;
    
CREATE INDEX HOMEPAGE.DISCOVERY_STORIES_COM_IDX
    ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, CREATION_DATE DESC, IS_STORY_COMM)  TABLESPACE NEWSINDEXTABSPACE;

--EXTERNAL READERS
CREATE INDEX HOMEPAGE.EXT_STORIES_SRC_IDX
    ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE)  TABLESPACE NEWSINDEXTABSPACE;

--RESPONSES READERS
CREATE INDEX HOMEPAGE.RESPONSES_STORIES_SRC_IDX
    ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE)  TABLESPACE NEWSINDEXTABSPACE;

--ACTIONABLE READERS
CREATE INDEX HOMEPAGE.ACTION_STORIES_SRC_IDX
    ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, CREATION_DATE DESC, SOURCE_TYPE)  TABLESPACE NEWSINDEXTABSPACE;
    
------------------------------------------------------
-- [END] Adding indexes to the readers tables
-----------------------------------------------------
    
------------------------------------------
-- Dropping HOMEPAGE.BOARD_READERS
-------------------------------------------
DROP TABLE HOMEPAGE.BOARD_READERS;

----------------------------------------------------------------------------------------------
-- [START] This is a list of indexes to speed up seedlist performance and profiles API
----------------------------------------------------------------------------------------------

-----------------------
-- BOARD_ENTRIES
-----------------------
DROP INDEX HOMEPAGE.NEWS_BRD_UPDATE;
--DROP INDEX HOMEPAGE.NEWS_BRD_ITEM;

COMMIT;

-- Oracle doesn't support this INCLUDE
--CREATE UNIQUE INDEX HOMEPAGE.ITEM_ID_IDX
--   ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID ASC) INCLUDE (CONTAINER_ID);

--COMMIT;

CREATE INDEX HOMEPAGE.CREATION_ITEM_IDX 
	ON HOMEPAGE.BOARD_ENTRIES (CREATION_DATE DESC, ITEM_ID DESC) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;
   
-----------------------
-- PERSON
-----------------------

-- Oracle doesn't support this INCLUDE
--CREATE UNIQUE INDEX HOMEPAGE.PERSON_IDX   
--	ON HOMEPAGE.PERSON (PERSON_ID) INCLUDE (USER_MAIL, DISPLAYNAME);

--COMMIT;

---------------------
-- BOARD_COMMENTS
---------------------
CREATE INDEX HOMEPAGE.CREATION_DATE_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (CREATION_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

CREATE INDEX HOMEPAGE.ITEM_CORR_CREATION_IDX 
	ON HOMEPAGE.BOARD_COMMENTS (ITEM_CORRELATION_ID, CREATION_DATE ASC) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

CREATE INDEX HOMEPAGE.ITEM_ITEM_CORR_IDX
	ON HOMEPAGE.BOARD_COMMENTS (ITEM_ID ASC, ITEM_CORRELATION_ID ASC) TABLESPACE "BOARDINDEXTABSPACE";
   
----------------------
-- NR_NETWORK
----------------------
CREATE INDEX HOMEPAGE.COLL_PERSON_IDX 
	ON HOMEPAGE.NR_NETWORK (COLLEAGUE_ID, PERSON_ID) TABLESPACE "BOARDINDEXTABSPACE";

COMMIT;

----------------------------------------------------------------------------------------------
-- [END] This is a list of indexes to speed up seedlist performance and profiles API
----------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------
-- 1) HOMEPAGE.BOARD
-------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD  (
	BOARD_ID VARCHAR2(36) NOT NULL,
	BOARD_CONTAINER_ID VARCHAR2(36) NOT NULL,
	BOARD_TYPE VARCHAR2(64) NOT NULL,
	BOARD_OWNER_ASSOC_ID VARCHAR2(36) NOT NULL,
	BOARD_OWNER_ASSOC_TYPE VARCHAR2(64) NOT NULL,
	CREATED TIMESTAMP NOT NULL,
	CREATED_BY VARCHAR2(36) NOT NULL,
	LASTUPDATE TIMESTAMP NOT NULL,
	LASTUPDATE_BY VARCHAR2(36) NOT NULL,
	IS_ENABLED NUMBER(5, 0) DEFAULT 1 NOT NULL,
	VISIBILITY VARCHAR2(36),
	EDITABILITY VARCHAR2(36)		
)
TABLESPACE "BOARDREGTABSPACE";

ALTER TABLE HOMEPAGE.BOARD 
	ADD (CONSTRAINT BOARD_PK PRIMARY KEY (BOARD_ID) USING INDEX TABLESPACE "BOARDINDEXTABSPACE");

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_OWNER FOREIGN KEY (BOARD_OWNER_ASSOC_ID) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_CREATED FOREIGN KEY (CREATED_BY) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);	

ALTER TABLE HOMEPAGE.BOARD 
	ADD CONSTRAINT FK_BRD_LASTUPDATE FOREIGN KEY (LASTUPDATE_BY) 
	REFERENCES HOMEPAGE.PERSON (PERSON_ID);

CREATE UNIQUE INDEX HOMEPAGE.BOARD_OWNER_ASSOC_UIDX 
	ON HOMEPAGE.BOARD (BOARD_OWNER_ASSOC_ID ASC, BOARD_TYPE ASC) TABLESPACE "BOARDINDEXTABSPACE";

ALTER TABLE HOMEPAGE.BOARD
	ADD CONSTRAINT CONTAINER_ID_UNQ UNIQUE (BOARD_CONTAINER_ID);
	
--CREATE UNIQUE INDEX HOMEPAGE.BRD_CONTAINER_ID_UIDX 
--	ON HOMEPAGE.BOARD (BOARD_CONTAINER_ID)  TABLESPACE "BOARDINDEXTABSPACE";
	
COMMIT;

-------------------------------------------------------
-- 2) Adding fk to the existing BOARD_ENTRIES
-------------------------------------------------------

--CLEAR BOARD_* tables before applying CONTAINER_ID FK
DELETE FROM HOMEPAGE.BOARD_OBJECT_REFERENCE;
DELETE FROM HOMEPAGE.BOARD_CURRENT_STATUS;
DELETE FROM HOMEPAGE.BOARD_RECOMMENDATIONS;
DELETE FROM HOMEPAGE.BOARD_COMMENTS;
DELETE FROM HOMEPAGE.BOARD_ENTRIES;

COMMIT;

ALTER TABLE HOMEPAGE.BOARD_ENTRIES ENABLE ROW MOVEMENT;

ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD CONSTRAINT FK_CONTAINER_ID FOREIGN KEY (CONTAINER_ID) 
	REFERENCES HOMEPAGE.BOARD (BOARD_CONTAINER_ID);

CREATE INDEX HOMEPAGE.BRD_E_CONTAINER_ID_UIDX 
	ON HOMEPAGE.BOARD_ENTRIES (CONTAINER_ID) TABLESPACE "BOARDINDEXTABSPACE";


COMMIT;
--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------

------------------------
-- BUG TYPO FIXING
------------------------
-- RENAME FROM:  N_RECCOMANDATIONS to the correct: N_RECOMMENDATIONS 
ALTER TABLE HOMEPAGE.NR_ENTRIES_ACT RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_BLG RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_COM RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_DGR RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_EXTERNAL RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_FILE RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_FRM RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_HP RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_PRF RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;
ALTER TABLE HOMEPAGE.NR_ENTRIES_WIK RENAME COLUMN N_RECCOMANDATIONS TO N_RECOMMANDATIONS;
commit;

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[START] DISCOVERY MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------


-- 1 ACTIVITIES
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_ACT
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_ACT.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;
	
TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 2 BLOGS
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_BLG NR_SRC_STORIES_BLG
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_BLG.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;
	

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 3 COMMUNITIES
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_COM NR_SRC_STORIES_COM
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_COM.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 4 WIKIS
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_WIK NR_SRC_STORIES_WIK
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_WIK.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;	

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 5 PROFILES
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_PRF NR_SRC_STORIES_PRF
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_PRF.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;	

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 6 HOMEPAGE
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_HP NR_SRC_STORIES_HP
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_HP.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;	

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 7 DOGEAR
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_DGR NR_SRC_STORIES_DGR
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_DGR.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;
	
TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 8  FILES
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_ACT NR_SRC_STORIES_FILE
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_FILE.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;
	
TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;

-- 9  FORUMS
CREATE VIEW HOMEPAGE.DISCOVERY AS (
	SELECT 	NR_NEWS_DISCOVERY.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			'00000000-0000-0000-0000-000000000001'			READER_ID,
			17										CATEGORY_TYPE,
			NR_NEWS_DISCOVERY.SOURCE						SOURCE,
			NR_NEWS_DISCOVERY.CONTAINER_ID				CONTAINER_ID,
			NR_NEWS_DISCOVERY.ITEM_ID					ITEM_ID,
			NULL										ROLLUP_ENTRY_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_DISCOVERY.CREATION_DATE				CREATION_DATE,
			NR_NEWS_DISCOVERY.NEWS_STORY_ID				STORY_ID,
			NR_NEWS_DISCOVERY.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_DISCOVERY.CREATION_DATE				EVENT_TIME,
			NR_NEWS_DISCOVERY.IS_COMMUNITY_STORY			IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID					
	FROM 	HOMEPAGE.NR_NEWS_DISCOVERY NR_NEWS_DISCOVERY,  
			HOMEPAGE.NR_SRC_STORIES_FRM NR_SRC_STORIES_FRM
	WHERE 	NR_NEWS_DISCOVERY.NEWS_STORY_ID =  NR_SRC_STORIES_FRM.STORY_ID
);

commit;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.DISCOVERY;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_DISCOVERY_VIEW VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.DISCOVERY;

COMMIT;


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[END] DISCOVERY MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[START] SAVED MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

-- A) INSERT ENTRIES
-- B) INSERT STORIES
-- C) INSERT ACTIONABLE

-- 1) ACT ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 1
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_ACT
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_ACT VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 2) BLG ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 2
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_BLG
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_BLG VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 3) COM ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 3
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_COM
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_COM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 4) WIK ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 4
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_WIK
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_WIK VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 5 PRF ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 5
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_PRF
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_PRF VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 6) HP ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 6
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_HP
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_HP VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 7) DGR ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 7
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_DGR
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_DGR VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 8) FILES ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 8
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FILE
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_FILE VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

-- 9) FRM ENTRIES
CREATE VIEW HOMEPAGE.TMP_ENTRIES AS (
	SELECT 
		ENTRY_ID, SOURCE, SOURCE_TYPE, CONTAINER_ID, CONTAINER_NAME, CONTAINER_URL, ITEM_ID,     
		ITEM_NAME,  ITEM_URL, CREATION_DATE, UPDATE_DATE, TAGS, N_COMMENTS, N_RECOMMANDATIONS, N_ATTACHMENTS, BRIEF_DESC,  
		LAST_RECOMMENDER_ID, LAST_DATE_RECOMMENDER_ID, PREV_RECOMMENDER_ID, PREV_DATE_RECOMMENDER_ID,  LAST_COMMENT_ID, 
		LAST_DATE_COMMENT, LAST_DESC_COMMENT,  LAST_AUTHOR_COMMENT, PREV_COMMENT_ID,  PREV_DATE_COMMENT,  PREV_DESC_COMMENT,  
		PREV_AUTHOR_COMMENT, TARGET_SUBJECT_ID,  ITEM_ATOM_URL,  MESSAGE,   PREVIEW_IMAGE_URL,  JSON_META_DATA, EVENT_TIME, SCOPE
	FROM (
		SELECT 	NR_NEWS_SAVED.ITEM_ID ENTRY_ID,
				NR_NEWS_SAVED.SOURCE,
				NR_NEWS_SAVED.SOURCE_TYPE,
				NR_NEWS_SAVED.CONTAINER_ID,
				NR_NEWS_SAVED.CONTAINER_NAME,
				NR_NEWS_SAVED.CONTAINER_URL,
				NR_NEWS_SAVED.ITEM_ID,
				NR_NEWS_SAVED.ENTRY_NAME	ITEM_NAME,
				NR_NEWS_SAVED.ENTRY_URL ITEM_URL,			
				NR_NEWS_SAVED.CREATION_DATE,
				NR_NEWS_SAVED.CREATION_DATE UPDATE_DATE,
				NR_NEWS_SAVED.TAGS,
				NR_NEWS_SAVED.N_COMMENTS,
				NR_NEWS_SAVED.N_RECOMMANDATIONS,
				0 N_ATTACHMENTS, -- N_ATTACHMENTS
				NR_NEWS_SAVED.BRIEF_DESC,
				NULL	LAST_RECOMMENDER_ID,
				NULL	LAST_DATE_RECOMMENDER_ID,
				NULL  PREV_RECOMMENDER_ID,
				NULL PREV_DATE_RECOMMENDER_ID,
				NULL  LAST_COMMENT_ID,
				NULL LAST_DATE_COMMENT,
				NULL  LAST_DESC_COMMENT,
				NULL  LAST_AUTHOR_COMMENT,
				NULL  PREV_COMMENT_ID,
				NULL PREV_DATE_COMMENT,
				NULL  PREV_DESC_COMMENT,
				NULL  PREV_AUTHOR_COMMENT,
				NULL  TARGET_SUBJECT_ID,
				NR_NEWS_SAVED.ENTRY_ATOM_URL	ITEM_ATOM_URL,
				NULL  MESSAGE,
				NULL  PREVIEW_IMAGE_URL,
				NULL  JSON_META_DATA,
				NULL EVENT_TIME,
				0 SCOPE
		FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED,
			(
				SELECT 	ITEM_ID, MAX(NEWS_STORY_ID) STORY_ID
				FROM 	HOMEPAGE.NR_NEWS_SAVED
				WHERE 	ITEM_ID IS NOT NULL AND SOURCE_TYPE = 9
				GROUP	BY ITEM_ID
			) TEMP
		WHERE NR_NEWS_SAVED.NEWS_STORY_ID = TEMP.STORY_ID
		) TEMP_STORIES 
	WHERE TEMP_STORIES.ENTRY_ID NOT IN (	
									SELECT 	ENTRY_ID
									FROM 	HOMEPAGE.NR_ENTRIES_FRM
								)
);

COMMIT;

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.TMP_ENTRIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ENTRIES_FRM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

DROP VIEW HOMEPAGE.TMP_ENTRIES;

COMMIT;

----------------------------------------------------
----- STORIES
----------------------------------------------------

-- 1 ACT STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 1 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_ACT
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_ACT VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 2 BLG STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 2 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_BLG
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_BLG VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 3 COM STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 3 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_COM
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_COM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 4 WIK STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 4 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_WIK
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_WIK VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 5 PRF STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 5 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_PRF
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_PRF VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 6 HP STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 6 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_HP
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_HP VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 7 DGR STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 7 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_DGR
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_DGR VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 8 FILE STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 8 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_FILE
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FILE VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

-- 9 FRM STORIES
CREATE VIEW HOMEPAGE.STORIES AS (
	SELECT 		NEWS_STORY_ID		STORY_ID,
				EVENT_NAME			EVENT_NAME,
				SOURCE				SOURCE,
				CONTAINER_ID		CONTAINER_ID,
				CONTAINER_NAME		CONTAINER_NAME,
				CONTAINER_URL		CONTAINER_URL,
				ENTRY_ATOM_URL		ITEM_ATOM_URL,
				ITEM_CORRELATION_ID	ITEM_CORRELATION_ID,
				CREATION_DATE		CREATION_DATE,
				BRIEF_DESC			BRIEF_DESC,
				ACTOR_UUID			ACTOR_UUID,
				EVENT_RECORD_UUID	EVENT_RECORD_UUID,
				TAGS				TAGS,
				META_TEMPLATE		META_TEMPLATE,
				TEXT_META_TEMPLATE	TEXT_META_TEMPLATE,
				NULL					R_META_TEMPLATE,
				NULL					R_TEXT_META_TEMPLATE,
				IS_COMMUNITY_STORY	IS_COMMUNITY_STORY,
				NULL					ITEM_CORRELATION_NAME,
				SOURCE_TYPE			SOURCE_TYPE,
				0					HAS_ATTACHMENT,			
				ITEM_ID				ENTRY_ID,
				NULL					MESSAGE,
				CREATION_DATE		EVENT_TIME,
				NULL					VERB,
				NULL				ACTIVITY_META_DATA_1,
				NULL				ACTIVITY_META_DATA_2,
				0					IS_META_DATA_TRUNCATED
		FROM HOMEPAGE.NR_NEWS_SAVED
		WHERE SOURCE_TYPE = 9 AND NEWS_STORY_ID NOT IN 	(	SELECT STORY_ID
												 			FROM HOMEPAGE.NR_SRC_STORIES_FRM
												)
);

DECLARE  CURSOR s_cur IS SELECT * FROM HOMEPAGE.STORIES;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_SRC_STORIES_FRM VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/
	
COMMIT;

DROP VIEW HOMEPAGE.STORIES;

COMMIT;

--------------------------------------------------------------------------
-- READERS
--------------------------------------------------------------------------

-- 1 READERS
DECLARE  CURSOR s_cur IS 
	SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
			13										CATEGORY_TYPE,
			NR_NEWS_SAVED.SOURCE						SOURCE,
			NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
			NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
			0										RESOURCE_TYPE,
			NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
			NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
			NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
			0										USE_IN_ROLLUP,				
			0										IS_NETWORK,
			0										IS_FOLLOWER,
			NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
			NULL										NOTE_TEXT,
			NULL 						NOTE_UPDATE_DATE,
			NULL										ROLLUP_ENTRY_ID,
			NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
			NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
			0										IS_BROADCAST,
			NULL										ORGANIZATION_ID
	FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
	WHERE 	SOURCE_TYPE = 1;		

	
TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 2 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 2;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 3 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 3;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 4 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 4;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 5 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 5;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 6 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 6;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 7 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 7;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 8 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 8;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

-- 9 READERS
DECLARE  CURSOR s_cur IS
SELECT 	NR_NEWS_SAVED.READER_ID						READER_ID,
		13										CATEGORY_TYPE,
		NR_NEWS_SAVED.SOURCE						SOURCE,
		NR_NEWS_SAVED.CONTAINER_ID					CONTAINER_ID,
		NR_NEWS_SAVED.ITEM_ID						ITEM_ID,
		0										RESOURCE_TYPE,
		NR_NEWS_SAVED.CREATION_DATE					CREATION_DATE,
		NR_NEWS_SAVED.NEWS_STORY_ID					STORY_ID,
		NR_NEWS_SAVED.SOURCE_TYPE					SOURCE_TYPE,
		0										USE_IN_ROLLUP,				
		0										IS_NETWORK,
		0										IS_FOLLOWER,
		NR_NEWS_SAVED.CREATION_DATE					EVENT_TIME,
		NULL										NOTE_TEXT,
		NULL 						NOTE_UPDATE_DATE,
		NULL										ROLLUP_ENTRY_ID,
		NR_NEWS_SAVED.NEWS_RECORDS_ID 				CATEGORY_READER_ID,
		NR_NEWS_SAVED.IS_COMMUNITY_STORY				IS_STORY_COMM,
		0										IS_BROADCAST,
		NULL										ORGANIZATION_ID					
FROM 	HOMEPAGE.NR_NEWS_SAVED NR_NEWS_SAVED
WHERE 	SOURCE_TYPE = 9;

TYPE fetch_array IS TABLE OF s_cur%ROWTYPE;
s_array fetch_array;
BEGIN
  	OPEN s_cur;
  	LOOP
    	FETCH s_cur BULK COLLECT INTO s_array LIMIT 1000;
    	FORALL i IN 1..s_array.COUNT
    	INSERT INTO HOMEPAGE.NR_ACTIONABLE_READERS VALUES s_array(i);
		COMMIT;
    	
		EXIT WHEN s_cur%NOTFOUND;
  	END LOOP;
  	CLOSE s_cur;
  	COMMIT;
END;
/

COMMIT;

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--	[END] SAVED MIGRATION
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

DROP VIEW HOMEPAGE.NR_CATEGORIES_READERS;

COMMIT;

ALTER TABLE HOMEPAGE.NR_RESPONSES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_PROFILES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_COMMUNITIES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_ACTIVITIES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_BLOGS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_BOOKMARKS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_FILES_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_FORUMS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_WIKIS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_TAGS_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_STATUS_UPDATE_READERS  		ENABLE ROW MOVEMENT;
ALTER TABLE HOMEPAGE.NR_EXTERNAL_READERS  		ENABLE ROW MOVEMENT;

COMMIT;
    
--------------------------------------------------------------------------------------------------------------
-- CREATE THE VIEW FOR ALL THE STORIES
--------------------------------------------------------------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_CATEGORIES_READERS AS (
    SELECT * FROM HOMEPAGE.NR_RESPONSES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_PROFILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_COMMUNITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ACTIVITIES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BLOGS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_BOOKMARKS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FILES_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_FORUMS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_WIKIS_READERS
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_TAGS_READERS
    	UNION ALL
    SELECT * FROM HOMEPAGE.NR_STATUS_UPDATE_READERS
    	UNION ALL
	SELECT * FROM HOMEPAGE.NR_EXTERNAL_READERS    	
);

COMMIT;



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE UPGRADE35 FOR SEARCH 
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 84
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 34215: Implement and unit test changes to DAO layer for per-document seedlist retrieval

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS ADD ATOM_ID VARCHAR2(256) NULL;

CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_ACT_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(ACTION) TABLESPACE "HOMEPAGEINDEXTABSPACE";
	
CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_ACS_IDX
	ON HOMEPAGE.SR_INDEX_DOCS(SERVICE,ATOM_ID,CRAWLING_VERSION) TABLESPACE "HOMEPAGEINDEXTABSPACE";

ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT "ID_ACT_CHECK"
	CHECK (ACTION >=0 AND ACTION < 4);	
	
ALTER TABLE HOMEPAGE.SR_INDEX_DOCS 
	ADD CONSTRAINT "IGNORE_ACT_CHECK"
	CHECK (ACTION <> 3 OR RESUME_POINT IS NULL); 

--END  34215: Implement and unit test changes to DAO layer for per-document seedlist retrieval

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 87
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

----------------------------------------
--  SR_GLOBAL_SAND_PROPS
----------------------------------------

CREATE TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS(
	GSP_ID			VARCHAR2(36) NOT NULL,
	GSP_NAME		VARCHAR2(36) NOT NULL,
	GSP_VALUE		VARCHAR2(36) NOT NULL,
	GSP_TYPE        NUMBER(5,0) NOT NULL
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
	 ADD (CONSTRAINT "PK_GSP_ID" PRIMARY KEY ("GSP_ID")
	 USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE");

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS
    ADD CONSTRAINT UNIQUE_GSP_NAME UNIQUE ("GSP_NAME");

ALTER TABLE HOMEPAGE.SR_GLOBAL_SAND_PROPS		
	ADD CONSTRAINT GSP_TYPE_CHECK
	CHECK (GSP_TYPE >=0 AND GSP_TYPE < 4);

ALTER TABLE "HOMEPAGE"."SR_GLOBAL_SAND_PROPS" ENABLE ROW MOVEMENT;

--END 38374: DAO Layer Changes for Dynamic Global Properties for SAND 

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 89
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 40252: SPR#WDWU8AAA3P : search cluster nodes will insert dup scheduler task when scheduler table is empty

----------------------------------------
--  HOMEPAGE.LOTUSCONNECTIONSTASK
----------------------------------------

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;

ALTER TABLE HOMEPAGE.LOTUSCONNECTIONSTASK ADD CONSTRAINT UNIQUE_LCT_NAME UNIQUE ("NAME");

--END 40252: SPR#WDWU8AAA3P : search cluster nodes will insert dup scheduler task when scheduler table is empty


--START 40269: PERF, homepage db,  this read sql needs index on sr_index_docs

----------------------------------------
--  HOMEPAGE.SR_INDEX_DOCS
----------------------------------------

CREATE INDEX HOMEPAGE.SR_INDEX_DOCS_LLT4_IDX ON HOMEPAGE.SR_INDEX_DOCS(UPDATE_TIME ASC,ACTION DESC,CRAWLING_VERSION,SERVICE) TABLESPACE "HOMEPAGEINDEXTABSPACE";

--END  40269: PERF, homepage db,  this read sql needs index on sr_index_docs


---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start SEARCH FIXUP 91
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD

DELETE FROM HOMEPAGE.SR_FILESCONTENT;

DELETE FROM HOMEPAGE.SR_FACET_DOCS;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD FS_LOCAL_PATH VARCHAR2(256) NOT NULL;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD PROCESSOR VARCHAR2(36);
	
ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD PROCESSOR_STATE BLOB;
	
ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD CONTENT_LOCATION VARCHAR2(256) NOT NULL;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD IS_READY NUMBER(5,0) DEFAULT 0 NOT NULL ;


	
--END 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD  
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 92
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 92 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 59;

--------------------------------------
-- COMMIT
--------------------------------------

COMMIT;
--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;