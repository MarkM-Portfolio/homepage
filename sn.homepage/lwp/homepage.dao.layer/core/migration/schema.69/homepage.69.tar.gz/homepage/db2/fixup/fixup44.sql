-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 44 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- HOMEPAGE.MT_METRICS 
----------------------------------------------------------------------

CREATE TABLE HOMEPAGE.MT_METRIC_STAT  (
      METRIC_STAT_ID VARCHAR(36) NOT NULL,
      RECORDED_ON TIMESTAMP NOT NULL,
      METRIC_TYPE SMALLINT NOT NULL,
      METRIC_DESC VARCHAR(36) NOT NULL,
      RES_BUNDLE_KEY VARCHAR(144) NOT NULL,
      COUNT_LAST_24_H BIGINT,
      COUNT_LAST_7_D BIGINT,
      COUNT_LAST_1_M BIGINT,
      TOP_STATS VARCHAR(512),
      TOT_STAT BIGINT,
      AVG_TOT_STAT BIGINT
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.MT_METRIC_STAT 
    ADD CONSTRAINT PK_METRIC_STAT_ID PRIMARY KEY(METRIC_STAT_ID);

CREATE INDEX HOMEPAGE.MT_METRICS_IDX
    ON HOMEPAGE.MT_METRIC_STAT (RECORDED_ON ASC, METRIC_TYPE);
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.MT_METRIC_STAT TO USER LCUSER;


-------------------------------------------------
-- FIXING NT_NOTIFICATION TABLE
-------------------------------------------------

-- 1 NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID
------------------------------------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT WHERE RECIPIENT_ID IS NULL;
------------------------------------------------------------------------------------------------------------
DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) <= '30' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '30' AND (HEX(SUBSTR(ID,1,1))) <= '34' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '34' AND (HEX(SUBSTR(ID,1,1))) <= '39' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '39' AND (HEX(SUBSTR(ID,1,1))) <= '61' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '61' AND (HEX(SUBSTR(ID,1,1))) <= '64' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '64' AND (HEX(SUBSTR(ID,1,1))) <= '66' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT 
WHERE (HEX(SUBSTR(ID,1,1))) > '66' AND RECIPIENT_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT
WHERE RECIPIENT_ID IS NULL;

COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
	ALTER COLUMN RECIPIENT_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNT16TMPTABSPACE;

COMMIT;

-- 2 NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID
-----------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE FIRST_RECIPIENT_ID IS NULL;
----------------------------------------------------------------------------------- 
DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '30' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '30' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '34' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '34' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '39' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '39' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '61' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '61' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '64' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '64' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '66' AND FIRST_RECIPIENT_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '66' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE FIRST_RECIPIENT_ID IS NULL;

COMMIT;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ALTER COLUMN FIRST_RECIPIENT_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;
	
-- 3 NT_NOTIFICATION WHERE SENDER_ID
-----------------------------------------------------------------------------------
-- DELETE FROM HOMEPAGE.NT_NOTIFICATION WHERE SENDER_ID IS NULL;
-----------------------------------------------------------------------------------
DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '30' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '30' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '34' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '34' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '39' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '39' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '61' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '61' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '64' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '64' AND (HEX(SUBSTR(NOTIFICATION_ID,1,1))) <= '66' AND SENDER_ID IS NULL;

COMMIT;

DELETE
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE (HEX(SUBSTR(NOTIFICATION_ID,1,1))) > '66' AND NOTIFICATION_ID IS NULL;

COMMIT;

DELETE 
FROM HOMEPAGE.NT_NOTIFICATION 
WHERE SENDER_ID IS NULL;

COMMIT;
	
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
	ALTER COLUMN SENDER_ID SET NOT NULL;

reorg table HOMEPAGE.NT_NOTIFICATION use HPNT16TMPTABSPACE;

COMMIT;	





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 44 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------
-- FIXING DB INCONSISTENCES
--------------------------------------------------------------

-- 1) NR_STORIES
ALTER TABLE HOMEPAGE.NR_STORIES
    ALTER COLUMN R_META_TEMPLATE DROP NOT NULL;
    
reorg table HOMEPAGE.NR_STORIES use NEWS32TMPTABSPACE;

-- 2) EMD_EMAIL_PREFS
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS
    ALTER COLUMN EMAIL_ADDRESS DROP NOT NULL;

reorg table HOMEPAGE.EMD_EMAIL_PREFS use NEWS4TMPTABSPACE;

-- 3) NR_STORIES_CONTENT
ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    ALTER COLUMN CONTENT DROP NOT NULL;

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
    ADD COLUMN STORY_ID VARCHAR(36);
    
reorg table HOMEPAGE.NR_STORIES_CONTENT use NEWS4TMPTABSPACE;

-- 4) NR_NEWS_DISCOVERY
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
    ADD COLUMN IS_COMMUNITY_STORY SMALLINT DEFAULT 0;

UPDATE HOMEPAGE.NR_NEWS_DISCOVERY SET IS_COMMUNITY_STORY = 0;

------------------------------------------------------------------
-- FIXING TEMPLATE ISSUES
------------------------------------------------------------------
UPDATE HOMEPAGE.NR_TEMPLATE SET DATA_SOURCE_STRING = 'itemName;itemHtmlPath' 
WHERE TEMPLATE_ID = 'actEntComm-WEJHX1TBvSCW0PS8ayfbPlZ1k';

INSERT INTO HOMEPAGE.NR_TEMPLATE values ('blogCorrName-2G3abCWRYNRpLhSawJXF6Qd', 'blogCorrelationName', 'link', 'correlationName;correlationHtmlPath', 1);

-----------------------------------------------------------------
-- ADDING TABLES TO SUPPORT THE NEWS FFED
-----------------------------------------------------------------

------------------------------
-- NR_COMM_PERSON_FOLLOW
------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW (
	COMM_PERSON_FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	PERSON_COMMUNITY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT "PK_COMM_PER_ID" PRIMARY KEY("COMM_PERSON_FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_FOLLOW
    ADD CONSTRAINT "FK_COMM_PER_PER_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON ("PERSON_ID");

CREATE INDEX HOMEPAGE.NR_COMM_PER_FOLLOW_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_ID);

CREATE INDEX HOMEPAGE.NR_COMM_FOLLOW_COM_PER_ID
    ON HOMEPAGE.NR_COMM_PERSON_FOLLOW (PERSON_COMMUNITY_ID);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_FOLLOW TO USER LCUSER;


----------------------------------------------------------------------
-- HOMEPAGE.NR_COMM_PERSON_STORIES 
----------------------------------------------------------------------
CREATE TABLE HOMEPAGE.NR_COMM_PERSON_STORIES (
	COMM_PER_STORY_ID VARCHAR(36) NOT NULL,
	COMM_PER_READER_ID VARCHAR(36) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	ITEM_ID VARCHAR(36),
	RESOURCE_TYPE SMALLINT NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL,
	CREATION_DATE TIMESTAMP NOT NULL,
	SOURCE VARCHAR(36) NOT NULL,
	STORY_ID VARCHAR(36) NOT NULL
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT "PK_COMPER_STORY_ID" PRIMARY KEY("COMM_PER_STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_PERSON_STORIES
    ADD CONSTRAINT "FK_FCP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_READER
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC, COMM_PER_READER_ID);

CREATE INDEX HOMEPAGE.NR_COM_PER_STORIES_STORY_ID
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (STORY_ID);  

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_COMM_PERSON_STORIES TO USER LCUSER;

 
      
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 44 FOR SEARCH
------------------------------------------------

--{include.search-fixup44.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 44
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 44 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 43;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 44
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
