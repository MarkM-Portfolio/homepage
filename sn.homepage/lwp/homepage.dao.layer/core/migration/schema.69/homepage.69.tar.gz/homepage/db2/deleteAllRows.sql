-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- REMOVING RECORDS -----------------
CONNECT TO HOMEPAGE;

-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE 
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- REMOVING RECORDS -----------------

-- OH deletion

DELETE FROM HOMEPAGE.OH_PROVIDER;
DELETE FROM HOMEPAGE.OH_CLIENT;
DELETE FROM HOMEPAGE.OH_CONTEXT;
DELETE FROM HOMEPAGE.OH_APPLICATION;
DELETE FROM HOMEPAGE.OH_OAUTHACL;
DELETE FROM HOMEPAGE.OH_TOKEN;

commit;



DELETE FROM HOMEPAGE.HOMEPAGE_SCHEMA;

DELETE FROM HOMEPAGE.LOGINNAME;

DELETE FROM HOMEPAGE.HP_WIDGET_INST;

DELETE FROM HOMEPAGE.HP_TAB_INST;

DELETE FROM HOMEPAGE.HP_WIDGET_TAB; 

DELETE FROM HOMEPAGE.HP_UI;

DELETE FROM HOMEPAGE.HP_TAB;

DELETE FROM HOMEPAGE.PREREQ;

DELETE FROM HOMEPAGE.WIDGET;

DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

DELETE FROM HOMEPAGE.NT_NOTIFICATION;



DELETE FROM HOMEPAGE.PERSON;

DELETE FROM HOMEPAGE.MT_METRIC_STAT;


DELETE FROM HOMEPAGE.NT_REPLYTO_RECIPIENT;

DELETE FROM HOMEPAGE.NT_REPLYTO;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DELETE FROM HOMEPAGE.NR_COMM_SETTINGS;

DELETE FROM HOMEPAGE.DELETED_STORIES_QUEUE;

-- News delete entries tables
DELETE FROM HOMEPAGE.NR_ENTRIES_ACT;
DELETE FROM HOMEPAGE.NR_ENTRIES_BLG;
DELETE FROM HOMEPAGE.NR_ENTRIES_COM;
DELETE FROM HOMEPAGE.NR_ENTRIES_WIK;
DELETE FROM HOMEPAGE.NR_ENTRIES_PRF;
DELETE FROM HOMEPAGE.NR_ENTRIES_HP;
DELETE FROM HOMEPAGE.NR_ENTRIES_DGR;
DELETE FROM HOMEPAGE.NR_ENTRIES_FILE;
DELETE FROM HOMEPAGE.NR_ENTRIES_FRM;
DELETE FROM HOMEPAGE.NR_ENTRIES_EXTERNAL;

-- News delete board tables
DELETE FROM HOMEPAGE.BOARD_CURRENT_STATUS;
DELETE FROM HOMEPAGE.BOARD_RECOMMENDATIONS;
DELETE FROM HOMEPAGE.BOARD_OBJECT_REFERENCE;
DELETE FROM HOMEPAGE.BOARD_COMMENTS;
DELETE FROM HOMEPAGE.BOARD_READERS;
DELETE FROM HOMEPAGE.BOARD_ENTRIES;

-- New delete source stories
DELETE FROM HOMEPAGE.NR_SRC_STORIES_ACT;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_BLG;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_COM;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_WIK;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_PRF;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_HP;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_DGR;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_FILE;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_FRM;
DELETE FROM HOMEPAGE.NR_SRC_STORIES_EXTERNAL;


-- New delete categories stories
DELETE FROM HOMEPAGE.NR_RESPONSES_READERS;
DELETE FROM HOMEPAGE.NR_PROFILES_READERS;
DELETE FROM HOMEPAGE.NR_COMMUNITIES_READERS;
DELETE FROM HOMEPAGE.NR_ACTIVITIES_READERS;
DELETE FROM HOMEPAGE.NR_BLOGS_READERS;
DELETE FROM HOMEPAGE.NR_BOOKMARKS_READERS;
DELETE FROM HOMEPAGE.NR_FILES_READERS;
DELETE FROM HOMEPAGE.NR_FORUMS_READERS;
DELETE FROM HOMEPAGE.NR_WIKIS_READERS;
DELETE FROM HOMEPAGE.NR_TAGS_READERS;
DELETE FROM HOMEPAGE.NR_STATUS_UPDATE_READERS;

COMMIT;

-- NEWS deletion
DELETE FROM HOMEPAGE.NR_NEWS_RECORDS;
DELETE FROM HOMEPAGE.NR_SUBSCRIPTION;
DELETE FROM HOMEPAGE.NR_SOURCE;
DELETE FROM HOMEPAGE.NR_TEMPLATE;

DELETE FROM HOMEPAGE.NR_CATEGORY_TYPE;
DELETE FROM HOMEPAGE.NR_NEWS_SAVED;
DELETE FROM HOMEPAGE.NR_NEWS_DISCOVERY;

DELETE FROM HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
DELETE FROM HOMEPAGE.NR_NEWS_STATUS_CONTENT;
DELETE FROM HOMEPAGE.NR_NEWS_STATUS_COMMENT;
DELETE FROM HOMEPAGE.NR_NEWS_STATUS_NETWORK;

DELETE FROM HOMEPAGE.NR_AGGREGATED_READERS;
DELETE FROM HOMEPAGE.NR_COMM_PERSON_FOLLOW;
DELETE FROM HOMEPAGE.NR_NETWORK;
DELETE FROM HOMEPAGE.NR_STORIES_CONTENT;
DELETE FROM HOMEPAGE.NR_ORGPERSON_STORIES;
DELETE FROM HOMEPAGE.NR_COMM_STORIES;

DELETE FROM HOMEPAGE.NR_ORGPERSON_FOLLOW;
DELETE FROM HOMEPAGE.NR_COMM_FOLLOW;
DELETE FROM HOMEPAGE.NR_FOLLOWS;	
DELETE FROM HOMEPAGE.NR_RESOURCE;
DELETE FROM HOMEPAGE.NR_RESOURCE_TYPE;

-- EMail Digest deletion
DELETE FROM HOMEPAGE.EMD_EMAIL_PREFS;
DELETE FROM HOMEPAGE.EMD_TRANCHE_INFO;
DELETE FROM HOMEPAGE.EMD_TRANCHE;
DELETE FROM HOMEPAGE.EMD_RESOURCE_PREF;
DELETE FROM HOMEPAGE.EMD_FREQUENCY_TYPE;

-- Delete notifications NT_NOTIFICATIONs
DELETE FROM HOMEPAGE.NT_NOTIFICATION_RECIPIENT;
DELETE FROM HOMEPAGE.NT_NOTIFICATION;

DELETE FROM HOMEPAGE.NR_SOURCE_TYPE;

DELETE FROM HOMEPAGE.NR_RECOMMENDATION;
DELETE FROM HOMEPAGE.NR_ATTACHMENT;    

-- Delete actionable stories
DELETE FROM HOMEPAGE.NR_ACTIONABLE_READERS;
DELETE FROM HOMEPAGE.NR_DISCOVERY_VIEW;






-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-- REMOVING RECORDS -----------------

DELETE FROM HOMEPAGE.SR_FILECONTENTTASKDEF;

DELETE FROM HOMEPAGE.SR_SANDTASKDEF;

DELETE FROM HOMEPAGE.SR_BACKUPTASKDEF;

DELETE FROM HOMEPAGE.SR_INDEXINGTASKDEF;

DELETE FROM HOMEPAGE.SR_OPTIMIZETASKDEF;

DELETE FROM HOMEPAGE.SR_TASKDEF;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;

DELETE FROM HOMEPAGE.SR_MIGTASKDEFINFO;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;

DELETE FROM HOMEPAGE.SR_FACET_DOCS;

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMGR;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSLMPR;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTASK;

DELETE FROM HOMEPAGE.LOTUSCONNECTIONSTREG;

DELETE FROM HOMEPAGE.SR_FEEDBACK;

DELETE FROM HOMEPAGE.SR_FEEDBACK_CONTEXT;

DELETE FROM HOMEPAGE.SR_FEEDBACK_PARAMETERS;

DELETE FROM HOMEPAGE.SR_STATS;

DELETE FROM HOMEPAGE.SR_STRING_STATS;

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;

DELETE FROM HOMEPAGE.SR_TIMER_STATS;

DELETE FROM HOMEPAGE.SR_GLOBAL_SAND_PROPS; 





-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------


COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 
