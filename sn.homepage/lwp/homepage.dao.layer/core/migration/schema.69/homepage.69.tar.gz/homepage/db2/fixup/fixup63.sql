-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 63
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 63 FOR HP
------------------------------------------------

--{include.hp-fixup63.sql}

------------------------------------------------
-- INCLUDE FIX UP 63 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--------------------------------------------------------------------------------------
-- START: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------
--#ATOE8F3GSL

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD COLUMN TMP_DOMAIN_AFFINITY CLOB;

COMMIT;

reorg table HOMEPAGE.EMD_TRANCHE_INFO;
COMMIT;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET TMP_DOMAIN_AFFINITY = DOMAIN_AFFINITY;
COMMIT;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN DOMAIN_AFFINITY;

COMMIT;

reorg table HOMEPAGE.EMD_TRANCHE_INFO;
COMMIT;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
ADD COLUMN DOMAIN_AFFINITY CLOB;

COMMIT;

reorg table HOMEPAGE.EMD_TRANCHE_INFO;
COMMIT;

UPDATE HOMEPAGE.EMD_TRANCHE_INFO SET DOMAIN_AFFINITY = TMP_DOMAIN_AFFINITY;
COMMIT;

reorg table HOMEPAGE.EMD_TRANCHE_INFO;
COMMIT;

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
DROP COLUMN TMP_DOMAIN_AFFINITY;

COMMIT;

reorg table HOMEPAGE.EMD_TRANCHE_INFO;
COMMIT;

--------------------------------------------------------------------------------------
-- END: EMD FIX: changing the DOMAIN_AFFINITY VARCHAR TO BE CLOB 
--------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
-- START: ADDING ENTRY_ID
--------------------------------------------------------------------------------------

-- 1
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
	ADD COLUMN ENTRY_ID VARCHAR(36);

CREATE INDEX HOMEPAGE.NR_SRC_STORIES_ACT_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_ACT (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_ACT
  	ADD CONSTRAINT FK_ENTRY_ID_ACT FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_ACT (ENTRY_ID);      

COMMIT;

-- 2
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_BLG_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_BLG (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_BLG
  	ADD CONSTRAINT FK_ENTRY_ID_BLG FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_BLG (ENTRY_ID);     

COMMIT;

-- 3
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_COM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_COM (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_COM
  	ADD CONSTRAINT FK_ENTRY_ID_COM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_COM (ENTRY_ID);    

COMMIT;

-- 4
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_WIK_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_WIK (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_WIK
  	ADD CONSTRAINT FK_ENTRY_ID_WIK FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_WIK (ENTRY_ID);     

COMMIT;

-- 5
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_PRF_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_PRF (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_PRF
  	ADD CONSTRAINT FK_ENTRY_ID_PRF FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_PRF (ENTRY_ID);     

COMMIT;

-- 6
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_HP_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_HP (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_HP
  	ADD CONSTRAINT FK_ENTRY_ID_HP FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_HP (ENTRY_ID);    

COMMIT;

-- 7
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_DGR_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_DGR (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_DGR
  	ADD CONSTRAINT FK_ENTRY_ID_DGR FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_DGR (ENTRY_ID);     

COMMIT;
    
-- 8
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FILE_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FILE (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FILE
  	ADD CONSTRAINT FK_ENTRY_ID_FILE FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FILE (ENTRY_ID);     

COMMIT;

-- 9
ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
	ADD COLUMN ENTRY_ID VARCHAR(36);
	
CREATE INDEX HOMEPAGE.NR_SRC_STORIES_FRM_EIDX
    ON HOMEPAGE.NR_SRC_STORIES_FRM (ENTRY_ID);

ALTER TABLE HOMEPAGE.NR_SRC_STORIES_FRM
  	ADD CONSTRAINT FK_ENTRY_ID_FRM FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.NR_ENTRIES_FRM (ENTRY_ID);     

COMMIT;

reorg table HOMEPAGE.NR_SRC_STORIES_ACT use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_ACT;

reorg table HOMEPAGE.NR_SRC_STORIES_BLG use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_BLG;

reorg table HOMEPAGE.NR_SRC_STORIES_COM use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_COM;

reorg table HOMEPAGE.NR_SRC_STORIES_WIK use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_WIK;

reorg table HOMEPAGE.NR_SRC_STORIES_PRF use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_PRF;

reorg table HOMEPAGE.NR_SRC_STORIES_HP use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_HP;

reorg table HOMEPAGE.NR_SRC_STORIES_DGR use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_DGR;

reorg table HOMEPAGE.NR_SRC_STORIES_FILE use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_FILE;

reorg table HOMEPAGE.NR_SRC_STORIES_FRM use NEWS32TMPTABSPACE;
reorg indexes all for table HOMEPAGE.NR_SRC_STORIES_FRM;

COMMIT;

--------------------------------------------------------------------------------------
-- END: ADDING ENTRY_ID
--------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------
-- FIXING BOARD TABLES
--------------------------------------------------------------------------------------
DROP TABLE HOMEPAGE.BOARD_RECOMMENDATIONS;

DROP TABLE HOMEPAGE.BOARD_ATTACHMENTS;

DROP TABLE HOMEPAGE.BOARD_COMMENTS;

DROP TABLE HOMEPAGE.BOARD_READERS;

DROP TABLE HOMEPAGE.BOARD_ENTRIES;

COMMIT;

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ENTRIES  (
	ENTRY_ID VARCHAR(47) NOT NULL, -- the format will include in the pk also the creation time
	ENTRY_TYPE SMALLINT,
	CATEGORY_TYPE SMALLINT,
	SOURCE VARCHAR(36),
	SOURCE_TYPE SMALLINT,
	ITEM_ID VARCHAR(36) NOT NULL,
	ITEM_URL VARCHAR(2048) NOT NULL,
	CONTAINER_ID VARCHAR(256),
	CONTAINER_NAME VARCHAR(256),
	CREATION_DATE TIMESTAMP NOT NULL, -- used also by the seedlist, when something is created the update is equal to is created
	UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used and queried from the the seedlist for initial and incremental index
	ACTOR_UUID VARCHAR(36),
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0,
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0,
	IS_COMMUNITY_STORY SMALLINT DEFAULT 0,
	HAS_ATTACHMENT SMALLINT DEFAULT 0,
	TARGET_SUBJECT_ID VARCHAR(256),
	TAGS VARCHAR(1024),
	SL_IS_UPDATED SMALLINT NOT NULL DEFAULT 0, -- this field is used by the seedlist
	SL_IS_DELETED SMALLINT NOT NULL DEFAULT 0, -- this field is used by the seedlist
	SL_UPDATE_DATE TIMESTAMP NOT NULL, -- this field is used by the seedlist
	CONTENT BLOB NOT NULL
)
IN BOARD16TABSPACE;

ALTER TABLE HOMEPAGE.BOARD_ENTRIES 
    ADD CONSTRAINT PK_BRD_ENTRIES PRIMARY KEY(ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (UPDATE_DATE ASC);
  
CREATE INDEX HOMEPAGE.NEWS_BRD_SL_UPDATE
    ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC);

CREATE UNIQUE INDEX HOMEPAGE.NEWS_BRD_ITEM
    ON HOMEPAGE.BOARD_ENTRIES (ITEM_ID);    

COMMIT;

--------------------------------------
-- HOMEPAGE.BOARD_READERS to store the relationship between a reader and a status update
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_READERS  (
	READER_ENTRY_ID VARCHAR(47) NOT NULL, -- the format will include in the pk also the creation time
	READER_ID VARCHAR(36) NOT NULL,
	IS_READER_COMM SMALLINT NOT NULL DEFAULT 0,
	ENTRY_ID VARCHAR(47) NOT NULL,
	IS_NETWORK_NEWS SMALLINT NOT NULL DEFAULT 0,
	IS_FOLLOW_NEWS SMALLINT NOT NULL DEFAULT 0
)
IN BOARD16TABSPACE;

ALTER TABLE HOMEPAGE.BOARD_READERS 
    ADD CONSTRAINT PK_BRD_READERS PRIMARY KEY(READER_ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_PERSON_ID FOREIGN KEY (READER_ID)
	REFERENCES HOMEPAGE.PERSON(PERSON_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT FK_BRD_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);	    

CREATE INDEX HOMEPAGE.NEWS_BRD_READER_ID
    ON HOMEPAGE.BOARD_READERS  (READER_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_ID
    ON HOMEPAGE.BOARD_READERS  (ENTRY_ID);

ALTER TABLE HOMEPAGE.BOARD_READERS
	ADD CONSTRAINT NEWS_BRD_UNIQUE UNIQUE(READER_ID, ENTRY_ID);

COMMIT;

--------------------------------------
-- HOMEPAGE.BOARD_ATTACHMENTS to store the comments
--------------------------------------
CREATE TABLE HOMEPAGE.BOARD_COMMENTS  (
	COMMENT_ID VARCHAR(47) NOT NULL, -- the format will include in the pk also the creation time
	ACTOR_UUID VARCHAR(36),
	CREATION_DATE TIMESTAMP NOT NULL,
	ITEM_ID VARCHAR(47),
	ITEM_CORRELATION_ID VARCHAR(47),
	ITEM_URL VARCHAR(2048),	
	CONTENT BLOB(1M)
)
IN BOARD16TABSPACE;

ALTER TABLE HOMEPAGE.BOARD_COMMENTS 
    ADD CONSTRAINT PK_BRD_COMMENT_ID PRIMARY KEY(COMMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD CONSTRAINT FK_BRD_ITEM_COR_ID FOREIGN KEY (ITEM_CORRELATION_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ITEM_CORR_ID
    ON HOMEPAGE.BOARD_COMMENTS  (ITEM_CORRELATION_ID);   

COMMIT;

----------------------------------------------------------------
-- ADDING NR_STATUS_ATTACHMENT
----------------------------------------------------------------
CREATE TABLE HOMEPAGE.BOARD_ATTACHMENTS (
	ATTACHMENT_ID VARCHAR(47) NOT NULL,
	ENTRY_ID VARCHAR(47) NOT NULL, -- 47
	SOURCE_TYPE SMALLINT NOT NULL,
	ATTACHMENT_TYPE SMALLINT,
	CREATION_DATE TIMESTAMP,
	NAME VARCHAR(2048),
	DESCRIPTION VARCHAR(4000),	
	TARGET_ID  VARCHAR(256),
	TARGET_URL VARCHAR(2048),
	META_DATA VARCHAR(4000)
)
IN BOARD16TABSPACE;

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS 
    ADD CONSTRAINT PK_BRD_ATTACH_ID PRIMARY KEY(ATTACHMENT_ID);

ALTER TABLE HOMEPAGE.BOARD_ATTACHMENTS
	ADD CONSTRAINT FK_BRD_AT_ENTRY_ID FOREIGN KEY (ENTRY_ID)
	REFERENCES HOMEPAGE.BOARD_ENTRIES (ENTRY_ID);

CREATE INDEX HOMEPAGE.NEWS_BRD_ENTRY_IDX
    ON HOMEPAGE.BOARD_ATTACHMENTS (ENTRY_ID);     
	
COMMIT;

--------------------------------------
-- HOMEPAGE.BOARD_RECOMMANDATIONS to store the relationship between a board entries and something which has been recommended
---------------------------------------
CREATE TABLE HOMEPAGE.BOARD_RECOMMENDATIONS  (
	RECOMMENDATION_ID VARCHAR(47) NOT NULL, --primary key
	RECOMMENDER_ID VARCHAR(36) NOT NULL, -- PERSON_ID of the recommender, FK to PERSON table
	ENTRY_ID VARCHAR(47) NOT NULL,
	SOURCE_TYPE SMALLINT NOT NULL, 
	CREATION_DATE TIMESTAMP
)
IN BOARD16TABSPACE;

ALTER TABLE HOMEPAGE.BOARD_RECOMMENDATIONS 
    ADD CONSTRAINT PK_BRD_RECOMM_ID PRIMARY KEY(RECOMMENDATION_ID);

CREATE INDEX HOMEPAGE.BRD_REC_STORY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (ENTRY_ID);
    
CREATE UNIQUE INDEX HOMEPAGE.BRD_RECOM_ENTRY_ID
    ON HOMEPAGE.BOARD_RECOMMENDATIONS (RECOMMENDER_ID, ENTRY_ID);

COMMIT;

------------------------------------------------------
-- CREATE VIEW NR_ENTRIES
------------------------------------------------------
CREATE VIEW HOMEPAGE.NR_ENTRIES AS (
    SELECT * FROM HOMEPAGE.NR_ENTRIES_ACT
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_BLG
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_COM
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_WIK
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_PRF
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_HP
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_DGR
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FILE
        UNION ALL
    SELECT * FROM HOMEPAGE.NR_ENTRIES_FRM
);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_ENTRIES TO USER LCUSER;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 60 FOR SEARCH
------------------------------------------------

--{include.search-fixup63.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 63
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 63 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 62;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 60
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
