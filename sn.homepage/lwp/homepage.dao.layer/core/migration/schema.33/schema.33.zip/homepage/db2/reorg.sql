-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- to create a new baseline
connect to HOMEPAGE;

-----------------------------------------------------------------------------------------------------------
-- START HOMEPAGE 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- to create a new baseline

reorg table HOMEPAGE.HOMEPAGE_SCHEMA use TEMPSPACE1;
reorg table HOMEPAGE.PERSON use TEMPSPACE1;
reorg table HOMEPAGE.LOGINNAME use TEMPSPACE1;
reorg table HOMEPAGE.PREREQ use TEMPSPACE1;
reorg table HOMEPAGE.WIDGET use TEMPSPACE1;

reorg table HOMEPAGE.HP_UI use TEMPSPACE1;
reorg table HOMEPAGE.HP_TAB use TEMPSPACE1;
reorg table HOMEPAGE.HP_TAB_INST use TEMPSPACE1;
reorg table HOMEPAGE.HP_WIDGET_INST use TEMPSPACE1;
reorg table HOMEPAGE.HP_WIDGET_TAB use TEMPSPACE1;





-------------------------------------------------------


reorg indexes all for table HOMEPAGE.NT_NOTIFICATION;
reorg indexes all for table HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

reorg indexes all for table HOMEPAGE.HOMEPAGE_SCHEMA;
reorg indexes all for table HOMEPAGE.PERSON;
reorg indexes all for table HOMEPAGE.LOGINNAME;
reorg indexes all for table HOMEPAGE.PREREQ;
reorg indexes all for table HOMEPAGE.WIDGET;

reorg indexes all for table HOMEPAGE.HP_UI;
reorg indexes all for table HOMEPAGE.HP_TAB;
reorg indexes all for table HOMEPAGE.HP_TAB_INST;
reorg indexes all for table HOMEPAGE.HP_WIDGET_INST;
reorg indexes all for table HOMEPAGE.HP_WIDGET_TAB;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE 
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START NEWS 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--NEWS

-- to create a new baseline


reorg table HOMEPAGE.NT_NOTIFICATION use HPNTTMPTABSPACE;
reorg table HOMEPAGE.NT_NOTIFICATION_RECIPIENT use HPNTTMPTABSPACE;

reorg table HOMEPAGE.NR_SOURCE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SUBSCRIPTION use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_RECORDS use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_TEMPLATE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_EVENT_RECORDS use NEWSTMPTABSPACE;

reorg table HOMEPAGE.EMD_JOBS use NEWSTMPTABSPACE;
reorg table HOMEPAGE.EMD_JOBS_STATS use NEWSTMPTABSPACE;
reorg table HOMEPAGE.EMD_RECIPIENTS use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_SCHEDULER_LMGR use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_LMPR use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_TASK use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_SCHEDULER_TREG use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_GROUP_TYPE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_GROUP use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_PERSON_SOURCE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_GROUP_SOURCE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_CATEGORY_TYPE use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_FOLLOW use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_TOP_UPDATES use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_SAVED use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_DISCOVERY use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_WATCHLIST use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STORY use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_COMMENT use NEWSTMPTABSPACE;

reorg table HOMEPAGE.NR_NEWS_COMMENT_CONTENT use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_CONTENT use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_COMMENT use NEWSTMPTABSPACE;
reorg table HOMEPAGE.NR_NEWS_STATUS_NETWORK use NEWSTMPTABSPACE;

-------------------------------------------------------



reorg indexes all for table HOMEPAGE.NR_SOURCE;
reorg indexes all for table HOMEPAGE.NR_SUBSCRIPTION;
reorg indexes all for table HOMEPAGE.NR_NEWS_RECORDS;
reorg indexes all for table HOMEPAGE.NR_TEMPLATE;
reorg indexes all for table HOMEPAGE.NR_EVENT_RECORDS;

reorg indexes all for table HOMEPAGE.EMD_JOBS;
reorg indexes all for table HOMEPAGE.EMD_JOBS_STATS;
reorg indexes all for table HOMEPAGE.EMD_RECIPIENTS;

reorg indexes all for table HOMEPAGE.NR_SCHEDULER_LMGR;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_LMPR;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_TASK;
reorg indexes all for table HOMEPAGE.NR_SCHEDULER_TREG;

reorg indexes all for table HOMEPAGE.NR_GROUP_TYPE;
reorg indexes all for table HOMEPAGE.NR_GROUP;
reorg indexes all for table HOMEPAGE.NR_PERSON_SOURCE;
reorg indexes all for table HOMEPAGE.NR_GROUP_SOURCE;
reorg indexes all for table HOMEPAGE.NR_CATEGORY_TYPE;
reorg indexes all for table HOMEPAGE.NR_FOLLOW;
reorg indexes all for table HOMEPAGE.NR_NEWS_TOP_UPDATES;
reorg indexes all for table HOMEPAGE.NR_NEWS_SAVED;
reorg indexes all for table HOMEPAGE.NR_NEWS_DISCOVERY;
reorg indexes all for table HOMEPAGE.NR_NEWS_WATCHLIST;
reorg indexes all for table HOMEPAGE.NR_NEWS_STORY;
reorg indexes all for table HOMEPAGE.NR_NEWS_COMMENT;

reorg indexes all for table HOMEPAGE.NR_NEWS_COMMENT_CONTENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_CONTENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_COMMENT;
reorg indexes all for table HOMEPAGE.NR_NEWS_STATUS_NETWORK;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END NEWS 
-----------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------
-- START SEARCH 
-----------------------------------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- to create a new baseline

-- SEARCH
reorg table HOMEPAGE.SR_INDEXINGTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_OPTIMIZETASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_TASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_FILESCONTENT use TEMPSPACE1;
reorg table HOMEPAGE.SR_MIGTASKDEFINFO use TEMPSPACE1;
reorg table HOMEPAGE.SR_FILECONTENTTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_INDEX_DOCS use TEMPSPACE1;
reorg table HOMEPAGE.SR_FACET_DOCS use TEMPSPACE1;
reorg table HOMEPAGE.SR_RESUME_TOKENS use TEMPSPACE1;
reorg table HOMEPAGE.SR_BACKUPTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_INDEX_MANAGEMENT use TEMPSPACE1;
reorg table HOMEPAGE.SR_SANDTASKDEF use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK_CONTEXT use TEMPSPACE1;
reorg table HOMEPAGE.SR_FEEDBACK_PARAMETERS use TEMPSPACE1;
reorg table HOMEPAGE.SR_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_STRING_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_NUMBER_STATS use TEMPSPACE1;
reorg table HOMEPAGE.SR_TIMER_STATS use TEMPSPACE1;


reorg table HOMEPAGE.LOTUSCONNECTIONSLMGR use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSLMPR use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSTASK use TEMPSPACE1;
reorg table HOMEPAGE.LOTUSCONNECTIONSTREG use TEMPSPACE1;

-------------------------------------------------------


-- SEARCH
reorg indexes all for table HOMEPAGE.SR_INDEXINGTASKDEF;
reorg indexes all for table HOMEPAGE.SR_OPTIMIZETASKDEF;
reorg indexes all for table HOMEPAGE.SR_TASKDEF;
reorg indexes all for table HOMEPAGE.SR_FILESCONTENT;
reorg indexes all for table HOMEPAGE.SR_MIGTASKDEFINFO;
reorg indexes all for table HOMEPAGE.SR_FILECONTENTTASKDEF;
reorg indexes all for table HOMEPAGE.SR_INDEX_DOCS;
reorg indexes all for table HOMEPAGE.SR_FACET_DOCS;
reorg indexes all for table HOMEPAGE.SR_RESUME_TOKENS;
reorg indexes all for table HOMEPAGE.SR_BACKUPTASKDEF;
reorg indexes all for table HOMEPAGE.SR_INDEX_MANAGEMENT;
reorg indexes all for table HOMEPAGE.SR_SANDTASKDEF;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK_CONTEXT;
reorg indexes all for table HOMEPAGE.SR_FEEDBACK_PARAMETERS;
reorg indexes all for table HOMEPAGE.SR_STATS;
reorg indexes all for table HOMEPAGE.SR_STRING_STATS;
reorg indexes all for table HOMEPAGE.SR_NUMBER_STATS;
reorg indexes all for table HOMEPAGE.SR_TIMER_STATS;

reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSLMGR;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSLMPR;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSTASK;
reorg indexes all for table HOMEPAGE.LOTUSCONNECTIONSTREG;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END HOMEPAGE 
-----------------------------------------------------------------------------------------------------------


COMMIT;
	
--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate; 
