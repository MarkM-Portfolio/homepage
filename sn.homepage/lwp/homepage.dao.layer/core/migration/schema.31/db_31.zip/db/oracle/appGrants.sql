-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 


------------------------------------------------
-- INCLUDE GRANTS FOR NEWS HP
------------------------------------------------

{include.newshp-appgrants.sql}


------------------------------------------------
-- INCLUDE GRANTS FOR SEARCH
------------------------------------------------

{include.search-appgrants.sql}


GRANT ALTER SESSION TO HOMEPAGEUSER_ROLE;
GRANT CREATE SESSION TO HOMEPAGEUSER_ROLE;
GRANT CREATE SYNONYM TO HOMEPAGEUSER_ROLE;
GRANT SELECT_CATALOG_ROLE, HOMEPAGEUSER_ROLE TO HOMEPAGEUSER;


COMMIT;

------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------
-- END THE DEFINITION FOR THE SEARCH DATABASE
------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;