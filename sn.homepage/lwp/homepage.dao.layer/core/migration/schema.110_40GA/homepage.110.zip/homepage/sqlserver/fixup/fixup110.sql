-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 110
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 110 FOR HP
------------------------------------------------

--{include.hp-fixup110.sql}

------------------------------------------------
-- INCLUDE FIX UP 110 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 110 -----------------------------------
---------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.OH2P_CACHE 
	ALTER COLUMN USERNAME nvarchar(256);
GO

CREATE INDEX OH2P_CACHE_CNT 
	ON HOMEPAGE.OH2P_CACHE (USERNAME, CLIENTID) INCLUDE (COMPONENTID);
GO


--https://swgjazz.ibm.com:8001/jazz/resource/itemName/com.ibm.team.workitem.WorkItem/76700
-- This is just for SQLServer
ALTER TABLE HOMEPAGE.NR_AS_COLLECTION_CONFIG 
	ALTER COLUMN XML_DATA NVARCHAR(MAX) NOT NULL;
GO

ALTER TABLE HOMEPAGE.NR_AS_CRAWLER_STATUS 
	ALTER COLUMN XML_DATA  NVARCHAR(MAX) NOT NULL;
GO

-- 76830: Missing index on CREATION_DATE column in HOMEPAGE.NR_AS_SEEDLIST
CREATE INDEX NR_SL_CD_DELETED
	ON HOMEPAGE.NR_AS_SEEDLIST (CREATION_DATE DESC);
GO

---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 110 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 102 FOR SEARCH
------------------------------------------------

--{include.search-fixup110.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 110
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 110 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 109;
------------------------------------------------------------------------------------------------

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 110
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

COMMIT
