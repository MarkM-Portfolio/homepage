-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 91
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 91 FOR HP
------------------------------------------------

--{include.hp-fixup91.sql}

------------------------------------------------
-- INCLUDE FIX UP 91 FOR NEWS HP
------------------------------------------------

--{include.news-fixup91.sql}

------------------------------------------------
-- INCLUDE FIX UP 91 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--START 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD

DELETE FROM HOMEPAGE.SR_FILESCONTENT;

DELETE FROM HOMEPAGE.SR_FACET_DOCS;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD FS_LOCAL_PATH VARCHAR2(256) NOT NULL;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD PROCESSOR VARCHAR2(36);
	
ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD PROCESSOR_STATE BLOB;
	
ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD CONTENT_LOCATION VARCHAR2(256) NOT NULL;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT
	ADD IS_READY NUMBER(5,0) DEFAULT 0 NOT NULL ;


	
--END 36202: Modify the indexing and text extraction processes in accordance with designs in Search CDD  
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 91
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 91 , RELEASEVER = '3.5.0.0'
WHERE   DBSCHEMAVER = 90 ;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 91
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
