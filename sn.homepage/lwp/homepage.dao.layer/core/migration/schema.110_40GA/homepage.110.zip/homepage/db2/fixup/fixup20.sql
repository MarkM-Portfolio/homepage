-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

connect to HOMEPAGE;

-- 1) refactoring NR_READER_IS_TOP_STORY_IDX
DROP INDEX HOMEPAGE.NR_READER_IS_TOP_STORY_IDX;

CREATE INDEX HOMEPAGE.NR_READER_IS_TOP_STORY_IDX 
	ON HOMEPAGE.NR_NEWS_RECORDS (CREATION_DATE DESC, NEWS_RECORDS_ID, READER_ID, IS_TOP_STORY);

-- 2) new: NR_READER_TOPSTORY_SRC_IDX  (this is the most important and it improves several queries)
CREATE INDEX HOMEPAGE.NR_READER_TOPSTORY_SRC_IDX 
	ON HOMEPAGE.NR_NEWS_RECORDS (CREATION_DATE DESC, NEWS_RECORDS_ID, READER_ID, IS_TOP_STORY, SOURCE);

-- 3) refactoring: very important too
DROP INDEX HOMEPAGE.NR_NEWS_RECORDS_SOURCE_IDX;

CREATE INDEX HOMEPAGE.NR_NEWS_RECORDS_SOURCE_IDX 
	ON HOMEPAGE.NR_NEWS_RECORDS (CREATION_DATE DESC, NEWS_RECORDS_ID, READER_ID, IS_CONTAINER, IS_PUBLIC, SOURCE);

-- 4) important to retrieve saved story
DROP INDEX HOMEPAGE.NR_READER_IS_SAVED_IDX;

CREATE INDEX HOMEPAGE.NR_READER_IS_SAVED_IDX 
	ON HOMEPAGE.NR_NEWS_RECORDS(CREATION_DATE DESC, READER_ID, IS_SAVED);

-------------------------------------------------------------------------------
-- Updating the schema version from 19 to 20
-------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 20
WHERE   DBSCHEMAVER = 19;

--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;

--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;