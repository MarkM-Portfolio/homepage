-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2008, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

-- DB2   			ORACLE 
-- CHAR 		-> CHAR   
-- VARCHAR		-> VARCHAR2 
-- SMALLINT		-> NUMBER(5,0)
-- INTEGER		-> NUMBER(10 ,0)
-- BIGINT		-> NUMBER(19 ,0)
-- CLOB(max)	-> CLOB
-- BLOB(max)	-> BLOB
-- TIMESTAMP	-> TIMESTAMP   
  
--------------------------------------
-- CREATE THE TABLESPACE  
--------------------------------------   
 
-- HOMEPAGE TABLESPACE 
CREATE SMALLFILE TABLESPACE "HOMEPAGEREGTABSPACE"
	DATAFILE 'HOMEPAGEREGTABSPACE' 
	SIZE 100M REUSE AUTOEXTEND ON 
	NEXT 20M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;
	
CREATE SMALLFILE TABLESPACE "HOMEPAGEINDEXTABSPACE" 
	DATAFILE 'HOMEPAGEINDEXTABSPACE' 
	SIZE 100M REUSE AUTOEXTEND ON 
	NEXT 20M MAXSIZE UNLIMITED 
	LOGGING EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;

-- HOMEPAGE NOTIFICATION TABLETABLESPACE
CREATE TEMPORARY TABLESPACE "HPNTTMPTABSPACE"
	TEMPFILE 'HPNTTMPTABSPACE'
	SIZE 100M REUSE AUTOEXTEND ON;
	
CREATE SMALLFILE TABLESPACE "HPNTREGTABSPACE"
	DATAFILE 'HPNTREGTABSPACE'
	SIZE 100M REUSE AUTOEXTEND ON 
	NEXT 20M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;

CREATE SMALLFILE TABLESPACE "HPNTINDEXTABSPACE"
	DATAFILE 'HPNTINDEXTABSPACE'
	SIZE 100M REUSE AUTOEXTEND ON 
	NEXT 20M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;

-- HOMEPAGE NEWS TABLETABLESPACE
CREATE TEMPORARY TABLESPACE "NEWSTMPTABSPACE"
	TEMPFILE 'NEWSTMPTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON;
	
CREATE SMALLFILE TABLESPACE "NEWSREGTABSPACE"
	DATAFILE 'NEWSREGTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON 
	NEXT 40M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;
	
CREATE SMALLFILE TABLESPACE "NEWSINDEXTABSPACE"
	DATAFILE 'NEWSINDEXTABSPACE'
	SIZE 200M REUSE AUTOEXTEND ON 
	NEXT 40M MAXSIZE UNLIMITED LOGGING 
	EXTENT MANAGEMENT LOCAL 
	SEGMENT SPACE MANAGEMENT AUTO;

CREATE 	TABLESPACE "NEWSLOBTABSPACE"
        DATAFILE 'NEWSLOBTABSPACE'
        SIZE 400M REUSE AUTOEXTEND ON
        NEXT 40M MAXSIZE UNLIMITED;	

--------------------------------------
-- CREATE THE USER\SCHEMA
--------------------------------------
CREATE ROLE HOMEPAGEUSER_ROLE;
CREATE USER "HOMEPAGEUSER" PROFILE "DEFAULT" IDENTIFIED BY "&1" DEFAULT TABLESPACE "HOMEPAGEREGTABSPACE" TEMPORARY TABLESPACE "TEMP" ACCOUNT UNLOCK;
CREATE USER "HOMEPAGE" PROFILE "DEFAULT" IDENTIFIED BY "&1" DEFAULT TABLESPACE "HOMEPAGEREGTABSPACE" TEMPORARY TABLESPACE "TEMP" ACCOUNT UNLOCK;
COMMIT;

-------------------------------------
-- ALTER HOMEPAGE USER, assumes already created
-------------------------------------
GRANT "CONNECT" TO "HOMEPAGE";
ALTER USER "HOMEPAGE" DEFAULT ROLE ALL;
GRANT ALTER TABLESPACE TO "HOMEPAGE";
GRANT UNLIMITED TABLESPACE TO "HOMEPAGE";

--------------------------------------
-- CREATE THE TABLES
--------------------------------------
CREATE TABLE HOMEPAGE.HOMEPAGE_SCHEMA ( 
	COMPKEY VARCHAR2(36) NOT NULL,
	DBSCHEMAVER NUMBER(5, 0) NOT NULL,
	RELEASEVER VARCHAR2(32) DEFAULT ' ' NOT NULL
) 
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE "HOMEPAGE"."HOMEPAGE_SCHEMA" ENABLE ROW MOVEMENT;

--------------------------------------
-- STARTING HOMEPAGE TABLES DEFINITIONS
--------------------------------------
{include.hp-createDb.sql}
--------------------------------------
-- END HOMEPAGE TABLES DEFINITIONS
--------------------------------------

--------------------------------------
-- STARTING NEWS TABLES DEFINITIONS
--------------------------------------
{include.news-createDb.sql}
--------------------------------------
-- END NEWS TABLES DEFINITIONS
--------------------------------------

--------------------------------------
-- STARTING SEARCH TABLES DEFINITIONS
--------------------------------------
{include.search-createDb.sql}
--------------------------------------
-- END SEARCH TABLES DEFINITIONS
--------------------------------------

--------------------------------------
-- INSERT THE SCHEMA VERSION
--------------------------------------
INSERT INTO HOMEPAGE.HOMEPAGE_SCHEMA (COMPKEY, DBSCHEMAVER, RELEASEVER) 
VALUES ('HOMEPAGE', 56, '3.0.0.0');

COMMIT;

--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
