-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 109 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DROP TABLE HOMEPAGE.OH2P_CLIENTCFG;

CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID VARCHAR2(128) NOT NULL, 
	CLIENTID VARCHAR2(256) NOT NULL, 
	CLIENTSECRET VARCHAR2(256), 
	DISPLAYNAME VARCHAR2(256) NOT NULL, 
	REDIRECTURI VARCHAR2(2048), 
	ENABLED NUMBER(5)
)
TABLESPACE "HOMEPAGEREGTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID) USING INDEX TABLESPACE "HOMEPAGEINDEXTABSPACE";

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG ENABLE ROW MOVEMENT;

COMMIT;
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 109 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 109 -----------------------------------
---------------------------------------------------------------------------------

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_ACT_CD_VIS_IDX  
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ACTOR_UUID, CREATION_DATE DESC, IS_VISIBLE) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

DROP INDEX HOMEPAGE.STORIES_CONTAINER_URL_IDX;
COMMIT;

-------------------------------------------------------------------------
--75925: Duplicate entries in mobile/homepage/StatusUpdates
-------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_STATUS_NETWORK MODIFY (BRIEF_DESC VARCHAR2(4000));
COMMIT;

CREATE INDEX HOMEPAGE.NR_STATUS_UPDATE_IX
	ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (READER_ID, UPDATE_DATE ASC, CREATION_DATE ASC, ITEM_ID, ACTOR_UUID) TABLESPACE  NEWSINDEXTABSPACE;
COMMIT;


--76074: Fixup109.sql - add indexes based on performance and dev activities
DROP INDEX HOMEPAGE.NR_SL_UD_DELTED_IX;
COMMIT;

DROP INDEX HOMEPAGE.NR_SL_UD_VISIBLE_IX;
COMMIT;

DROP INDEX HOMEPAGE.NR_AS_SEEDLIST_IDX;
COMMIT;

CREATE INDEX HOMEPAGE.NR_SL_UD_STR
	ON HOMEPAGE.NR_AS_SEEDLIST (UPDATE_DATE ASC, STORY_ID) TABLESPACE  NEWSINDEXTABSPACE;
COMMIT;

-- Index for deletion service
DROP INDEX HOMEPAGE.COMM_READERS_DEL_SERV_IX;
COMMIT;

DROP INDEX HOMEPAGE.DISCOVERY_VIEW_DEL_SERV_IX;
COMMIT;

DROP INDEX HOMEPAGE.PROFILES_VIEW_DEL_SERV_IX;
COMMIT;

CREATE  INDEX HOMEPAGE.COMM_READERS_DEL_SERV_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (CREATION_DATE DESC, IS_BROADCAST) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (CREATION_DATE DESC, IS_BROADCAST) TABLESPACE  NEWSINDEXTABSPACE;  
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_VIEW_DEL_SERV_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (CREATION_DATE DESC, IS_BROADCAST) TABLESPACE  NEWSINDEXTABSPACE; 
COMMIT;

-------------------------------------------------------------------------
    
---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 109 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 109 FOR SEARCH
------------------------------------------------

--{include.search-fixup109.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 109
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 109 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 108;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 109
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- DISCONNECT
--------------------------------------
DISCONNECT ALL;

QUIT;
