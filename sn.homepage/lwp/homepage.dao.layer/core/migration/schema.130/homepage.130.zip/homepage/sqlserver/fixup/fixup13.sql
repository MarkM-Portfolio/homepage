-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 


USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO 

-----------------------------------------------------------------------------------------------------------
--  1 Adding the LOCALE and DISPLAYNAME attribute to the EMD_RECIPIENTS
-----------------------------------------------------------------------------------------------------------
ALTER TABLE HOMEPAGE.EMD_RECIPIENTS
	ADD LOCALE nvarchar(5)
GO

ALTER TABLE HOMEPAGE.EMD_RECIPIENTS
	ADD DISPLAYNAME nvarchar(256)
GO

-----------------------------------------------------------------------------------------------------------
--  2 Adding the TEXT_META_TEMPLATE an empty space
-----------------------------------------------------------------------------------------------------------
UPDATE HOMEPAGE.NR_NEWS_RECORDS SET TEXT_META_TEMPLATE = ' '
GO

-----------------------------------------------------------------------------------------------------------
--  3 Adding the default value to 0 for IS_PRIVATE in the table HOMEPAGE.NR_SOURCE
-----------------------------------------------------------------------------------------------------------
UPDATE HOMEPAGE.NR_SOURCE SET IS_PRIVATE = 0
GO

-----------------------------------------------------------------------------------------------------------
--  4 Upgrade fixup number to 13
-----------------------------------------------------------------------------------------------------------

-- Updating the schema version from 12 to 13
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 13
WHERE   DBSCHEMAVER = 12
GO





COMMIT;