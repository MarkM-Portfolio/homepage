-- ***************************************************************** 
--                                                                   
-- Licensed Materials - Property of IBM                                                  
--                                                                   
-- 5724_S68                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2011 All Rights Reserved.                                    
--                                                                   
-- US Government Users Restricted Rights - Use, duplication or    
-- disclosure restricted by GSA ADP Schedule Contract with      
-- IBM Corp.                         
--                                                                   
-- ***************************************************************** 

USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 103
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 103 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START HP FIXUP 103 -------------------------------------
---------------------------------------------------------------------------------


UPDATE HOMEPAGE.WIDGET 
 	SET WIDGET_TITLE = '%widget.connshare.microblog.name', 
 	 WIDGET_TEXT = '%widget.connshare.microblog.desc', 
 	 WIDGET_URL = '${COMMON_CONTEXT_ROOT}/web/lconn.news.microblogging.sharebox/globalMicrobloggingForm.xml', 
 	 WIDGET_ICON = NULL, 
 	 WIDGET_ENABLED = 1 , 
 	 WIDGET_SYSTEM = 1 , 
 	 WIDGET_HOMEPAGE_SPECIFIC = 0, 
 	 WIDGET_PREVIEW_IMAGE  = NULL, 
 	 WIDGET_CATEGORY  = 'CONNECTIONSSHARE', 
 	 WIDGET_IS_DEFAULT_OPENED  = 0, 
 	 WIDGET_MARKED_CACHABLE  = 0,
	 WIDGET_MULTIPLE_INSTANCES  = 0,
	 WIDGET_SECURE_URL  = '${COMMON_CONTEXT_ROOT}/web/lconn.news.microblogging.sharebox/globalMicrobloggingForm.xml',
	 WIDGET_SECURE_ICON  = NULL ,
	 IS_GADGET  = 1,
	 WIDGET_POLICY_FLAGS = 55, 
	 PROXY_POLICY  = 'intranet_access',
	 SHARE_ORDER = 0
WHERE WIDGET_ID = '826e0a39-d231-49bd-a1fa-b1e6e787aaa1';

GO


UPDATE HOMEPAGE.WIDGET 
 	SET WIDGET_TITLE = '%widget.communities.event.name', 
 	 WIDGET_TEXT = '%widget.communities.event.desc', 
 	 WIDGET_URL = '${COMMON_CONTEXT_ROOT}/web/lconn.calendar/CalendarGadget.xml', 
 	 WIDGET_ICON = '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png', 
 	 WIDGET_ENABLED = 1 , 
 	 WIDGET_SYSTEM = 1 , 
 	 WIDGET_HOMEPAGE_SPECIFIC = 1, 
 	 WIDGET_PREVIEW_IMAGE  = '${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg', 
 	 WIDGET_CATEGORY  = 'COMMUNITIES', 
 	 WIDGET_IS_DEFAULT_OPENED  = 1, 
 	 WIDGET_MARKED_CACHABLE  = 0,
	 WIDGET_MULTIPLE_INSTANCES  = 0,
	 WIDGET_SECURE_URL  = '${COMMON_CONTEXT_ROOT}/web/lconn.calendar/CalendarGadget.xml',
	 WIDGET_SECURE_ICON  = '${COMMON_CONTEXT_ROOT}/web/com.ibm.lconn.core.styles/images/iconCommunities16.png' ,
	 IS_GADGET  = 1,
	 WIDGET_POLICY_FLAGS = 39, 
	 PROXY_POLICY  = 'intranet_access',
	 SHARE_ORDER = -1
WHERE WIDGET_ID = 'commuevtxe7c4x4e08xab54x80e7a4eb8933';

GO

INSERT INTO HOMEPAGE.HP_WIDGET_TAB 
            (WIDGET_TAB_ID, WIDGET_ID, TAB_ID, TYPE)
VALUES      ('61532c5f-664f-40c0-bd09-abf337b43312','commuevtxe7c4x4e08xab54x80e7a4eb8933','_noui.gadgetpanx11e1b0c40800200c9a66','primary');

GO


CREATE INDEX HP_WIDGET_IDX 
	ON HOMEPAGE.HP_WIDGET_INST (WIDGET_ID);	
	
CREATE INDEX PERSON_SND_SR 
	ON HOMEPAGE.PERSON (MEMBER_TYPE, SAND_OPT, SAND_LAST_UPDATE ASC);	
	
	
--
DROP TABLE HOMEPAGE.MTCONFIG;

CREATE TABLE HOMEPAGE.MTCONFIG (
	UUID			nvarchar(36) NOT NULL,
	SCOPE 			nvarchar(36) NOT NULL,
	ID 				nvarchar(128) NOT NULL,
	CONFIG_VALUE 	nvarchar(1024),
	SERVICE 		nvarchar(256),
	NAME	 		nvarchar(64),
	DESCRIPTION		nvarchar(64),
	OVERRIDABLE 	NUMERIC(5,0) DEFAULT 1 NOT NULL,
	ISPOLICY		NUMERIC(5,0) DEFAULT 0 NOT NULL,
	ADMIN_VIS		NUMERIC(5,0) DEFAULT 1 NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE HOMEPAGE.MTCONFIG
	 ADD CONSTRAINT PK_ID PRIMARY KEY (UUID);
	 
ALTER TABLE HOMEPAGE.MTCONFIG
	ADD CONSTRAINT UNIQUE_ID UNIQUE (SCOPE,ID);

CREATE INDEX SETTINGS_BY_ID
    ON HOMEPAGE.MTCONFIG (ID);	

-- search indexes    
CREATE INDEX PERSON_SAND_OPT_IDX
    ON HOMEPAGE.PERSON(SAND_OPT, SAND_LAST_UPDATE ASC)
GO

CREATE INDEX PERSON_STATE_IDX
  ON HOMEPAGE.PERSON(STATE, LAST_UPDATE ASC)
GO
    

---------------------------------------------------------------------------------
------------------------ END HP FIXUP 103 ---------------------------------------
---------------------------------------------------------------------------------
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 103 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 103 -----------------------------------
---------------------------------------------------------------------------------

-- 68544: Adding to AS table an unique column where the timestamp is auto generated 
ALTER TABLE HOMEPAGE.NR_AS_SEEDLIST
	ADD CONSTRAINT NR_AS_SEEDLIST_UPDATE_DATE_DEFAULT DEFAULT (getdate()) FOR UPDATE_DATE;
GO	
	
--68754: expensive comments query, tablescan on BOARD_COMMENTS
CREATE INDEX SEEDLIST_BRD_IDX 
	ON HOMEPAGE.BOARD_ENTRIES (SL_UPDATE_DATE ASC, ENTRY_ID);


ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT 
	ALTER COLUMN ACTIVITY_META_DATA NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT 
	ALTER COLUMN ITEM_CONTENT NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT 
	ALTER COLUMN ITEM_CORRELATION_CONTENT NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.EMD_TRANCHE_INFO
	ALTER COLUMN DOMAIN_AFFINITY NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.BOARD_OBJECT_REFERENCE
	ALTER COLUMN FULL_OBJECT_META_DATA NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.NR_AS_COLLECTION_CONFIG 
	ALTER COLUMN XML_DATA NVARCHAR(MAX);

GO

ALTER TABLE HOMEPAGE.NR_AS_CRAWLER_STATUS 
	ALTER COLUMN XML_DATA  NVARCHAR(MAX);

GO

------------

-- 67826
DROP INDEX NR_STORIES_ER_UUID ON HOMEPAGE.NR_STORIES;
GO

CREATE INDEX  NR_STORIES_ER_UUID 
	ON HOMEPAGE.NR_STORIES (EVENT_RECORD_UUID, STORY_ID);
GO

-- 68050: Discovery view for communities is very slow. Index needed
CREATE INDEX DISCOVERY_VIEW_COM 
	ON HOMEPAGE.NR_DISCOVERY_VIEW (IS_STORY_COMM, USE_IN_ROLLUP);
GO

--68097: Remove WIDGET_ID column from BOARD table in next fixup
ALTER TABLE HOMEPAGE.BOARD DROP COLUMN WIDGET_ID;
GO

--59735: Exception in the logs on News startup in SourceTypeSyncServiceImpl
UPDATE HOMEPAGE.NR_SOURCE_TYPE 	SET  	IMAGE_URL = '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconCommunities16.png',
										IMAGE_URL_SSL = '${connections}/resources/web/com.ibm.lconn.core.styles/images/iconCommunities16.png'
								WHERE 	SOURCE = 'communities';
GO

--68088: [fixup 103] Add 2 columns in BOARD_ENTRIES and BOARD_COMMENTS
--57636: Issue with hashtags keeping the capitals characters when added
--TAGS_LOWER columns in BOARD_ENTRIES and BOARD_COMMENTS
ALTER TABLE HOMEPAGE.BOARD_ENTRIES
	ADD HTML_CONTENT 	NVARCHAR(MAX);

GO
	
ALTER TABLE HOMEPAGE.BOARD_COMMENTS
	ADD HTML_CONTENT 	NVARCHAR(MAX);


GO

-------------------------------------------------------------------------------------------------------------
-- Drop 2 indexes: AUT_IX, RLL_IX; Create a new index
-------------------------------------------------------------------------------------------------------------






--  [start indexes] NR_AGGREGATED_READERS
DROP  INDEX AGGREGATED_READERS_AUT_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS;
GO

DROP  INDEX AGGREGATED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS;
GO

--  [end indexes] NR_AGGREGATED_READERS






--  [start indexes] NR_RESPONSES_READERS
DROP  INDEX RESPONSES_READERS_AUT_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS;
GO

DROP  INDEX RESPONSES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS;
GO

--  [end indexes] NR_RESPONSES_READERS






--  [start indexes] NR_PROFILES_READERS
DROP  INDEX PROFILES_READERS_AUT_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS;
GO

DROP  INDEX PROFILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS;
GO

--  [end indexes] NR_PROFILES_READERS






--  [start indexes] NR_COMMUNITIES_READERS
DROP  INDEX COMM_READERS_AUT_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS;
GO

DROP  INDEX COMM_READERS_RLL_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS;
GO

--  [end indexes] NR_COMMUNITIES_READERS






--  [start indexes] NR_ACTIVITIES_READERS
DROP  INDEX ACTIVITIES_READERS_AUT_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS;
GO

DROP  INDEX ACTIVITIES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS;
GO

--  [end indexes] NR_ACTIVITIES_READERS






--  [start indexes] NR_BLOGS_READERS
DROP  INDEX BLOGS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS;
GO

DROP  INDEX BLOGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS;
GO

--  [end indexes] NR_BLOGS_READERS






--  [start indexes] NR_BOOKMARKS_READERS
DROP  INDEX BOOKMARKS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS;
GO

DROP  INDEX BOOKMARKS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS;
GO

--  [end indexes] NR_BOOKMARKS_READERS






--  [start indexes] NR_FILES_READERS
DROP  INDEX FILES_READERS_AUT_IX 
 	ON HOMEPAGE.NR_FILES_READERS;
GO

DROP  INDEX FILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FILES_READERS;
GO

--  [end indexes] NR_FILES_READERS






--  [start indexes] NR_FORUMS_READERS
DROP  INDEX FORUMS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS;
GO

DROP  INDEX FORUMS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS;
GO

--  [end indexes] NR_FORUMS_READERS






--  [start indexes] NR_WIKIS_READERS
DROP  INDEX WIKIS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS;
GO

DROP  INDEX WIKIS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS;
GO

--  [end indexes] NR_WIKIS_READERS






--  [start indexes] NR_TAGS_READERS
DROP  INDEX TAGS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_TAGS_READERS;
GO

DROP  INDEX TAGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_TAGS_READERS;
GO

--  [end indexes] NR_TAGS_READERS






--  [start indexes] NR_STATUS_UPDATE_READERS
DROP  INDEX STATUS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
GO

DROP  INDEX STATUS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS;
GO

--  [end indexes] NR_STATUS_UPDATE_READERS






--  [start indexes] NR_EXTERNAL_READERS
DROP  INDEX EXTERNAL_READERS_AUT_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS;
GO

DROP  INDEX EXTERNAL_READERS_RLL_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS;
GO

--  [end indexes] NR_EXTERNAL_READERS






--  [start indexes] NR_ACTIONABLE_READERS
DROP  INDEX ACTIONABLE_READERS_AUT_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS;
GO

DROP  INDEX ACTIONABLE_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS;
GO

--  [end indexes] NR_ACTIONABLE_READERS






--  [start indexes] NR_DISCOVERY_VIEW
DROP  INDEX DISCOVERY_VIEW_AUT_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW;
GO

DROP  INDEX DISCOVERY_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW;
GO

--  [end indexes] NR_DISCOVERY_VIEW






--  [start indexes] NR_PROFILES_VIEW
DROP  INDEX PROFILES_VIEW_AUT_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW;
GO

DROP  INDEX PROFILES_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW;
GO

--  [end indexes] NR_PROFILES_VIEW






--  [start indexes] NR_NOTIFICATION_SENT_READERS
DROP  INDEX NOTIFICA_READERS_AUT_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
GO

DROP  INDEX NOTIFICA_READERS_RLL_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS;
GO

--  [end indexes] NR_NOTIFICATION_SENT_READERS






--  [start indexes] NR_NOTIFICATION_RECEIV_READERS
DROP  INDEX NOT_REC_READERS_AUT_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS;
GO

DROP  INDEX NOT_REC_READERS_RLL_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS;
GO

--  [end indexes] NR_NOTIFICATION_RECEIV_READERS






--  [start indexes] NR_SAVED_READERS
DROP  INDEX SAVED_READERS_AUT_IX 
 	ON HOMEPAGE.NR_SAVED_READERS;
GO

DROP  INDEX SAVED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_SAVED_READERS;
GO

--  [end indexes] NR_SAVED_READERS






--  [start indexes] NR_TOPICS_READERS
DROP  INDEX TOPICS_READERS_AUT_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS;
GO

DROP  INDEX TOPICS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS;
GO

--  [end indexes] NR_TOPICS_READERS







--  [start indexes] NR_AGGREGATED_READERS
CREATE  INDEX AGGREGATED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_AGGREGATED_READERS





--  [start indexes] NR_RESPONSES_READERS
CREATE  INDEX RESPONSES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_RESPONSES_READERS





--  [start indexes] NR_PROFILES_READERS
CREATE  INDEX PROFILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_PROFILES_READERS





--  [start indexes] NR_COMMUNITIES_READERS
CREATE  INDEX COMM_READERS_RLL_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_COMMUNITIES_READERS





--  [start indexes] NR_ACTIVITIES_READERS
CREATE  INDEX ACTIVITIES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_ACTIVITIES_READERS





--  [start indexes] NR_BLOGS_READERS
CREATE  INDEX BLOGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_BLOGS_READERS





--  [start indexes] NR_BOOKMARKS_READERS
CREATE  INDEX BOOKMARKS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_BOOKMARKS_READERS





--  [start indexes] NR_FILES_READERS
CREATE  INDEX FILES_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FILES_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_FILES_READERS





--  [start indexes] NR_FORUMS_READERS
CREATE  INDEX FORUMS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_FORUMS_READERS





--  [start indexes] NR_WIKIS_READERS
CREATE  INDEX WIKIS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_WIKIS_READERS





--  [start indexes] NR_TAGS_READERS
CREATE  INDEX TAGS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_TAGS_READERS





--  [start indexes] NR_STATUS_UPDATE_READERS
CREATE  INDEX STATUS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_STATUS_UPDATE_READERS





--  [start indexes] NR_EXTERNAL_READERS
CREATE  INDEX EXTERNAL_READERS_RLL_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_EXTERNAL_READERS





--  [start indexes] NR_ACTIONABLE_READERS
CREATE  INDEX ACTIONABLE_READERS_RLL_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_ACTIONABLE_READERS





--  [start indexes] NR_DISCOVERY_VIEW
CREATE  INDEX DISCOVERY_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_DISCOVERY_VIEW





--  [start indexes] NR_PROFILES_VIEW
CREATE  INDEX PROFILES_VIEW_RLL_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_PROFILES_VIEW





--  [start indexes] NR_NOTIFICATION_SENT_READERS
CREATE  INDEX NOTIFICA_READERS_RLL_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_NOTIFICATION_SENT_READERS





--  [start indexes] NR_NOTIFICATION_RECEIV_READERS
CREATE  INDEX NOT_REC_READERS_RLL_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_NOTIFICATION_RECEIV_READERS





--  [start indexes] NR_SAVED_READERS
CREATE  INDEX SAVED_READERS_RLL_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_SAVED_READERS





--  [start indexes] NR_TOPICS_READERS
CREATE  INDEX TOPICS_READERS_RLL_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS (READER_ID, IS_VISIBLE, USE_IN_ROLLUP);
GO

--  [end indexes] NR_TOPICS_READERS



---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 103 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 102 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH 103 									------ 
---------------------------------------------------------------------------------

--[START search]
DROP INDEX SR_FEEDBACK_CLIENT_IDX ON HOMEPAGE.SR_FEEDBACK;
GO

--
ALTER TABLE HOMEPAGE.SR_FEEDBACK 
	ALTER COLUMN CLIENT_ID  NVARCHAR(256) NOT NULL;
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK 
	ALTER COLUMN ACTION  NVARCHAR(256) NOT NULL;
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK 
	ALTER COLUMN ITEM_ID  NVARCHAR(256) NOT NULL;
GO	

ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT  
	ALTER COLUMN TYPE  NVARCHAR(256) NOT NULL;
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT  
	ALTER COLUMN TYPE_VALUE  NVARCHAR(256) NOT NULL;
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_CONTEXT  
	ALTER COLUMN WEIGHT  NVARCHAR(256) NOT NULL;
GO

ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS  
	ALTER COLUMN PARAM  NVARCHAR(256) NOT NULL;
GO
	
ALTER TABLE HOMEPAGE.SR_FEEDBACK_PARAMETERS  
	ALTER COLUMN PARAM_VALUE  NVARCHAR(256) NOT NULL;
GO


CREATE INDEX SR_FEEDBACK_CLIENT_IDX
		ON HOMEPAGE.SR_FEEDBACK (CLIENT_ID);
GO	
--[END search]

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 100
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 103 , RELEASEVER = '4.0.0.0'
WHERE   DBSCHEMAVER = 102;
------------------------------------------------------------------------------------------------

GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 102
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++

COMMIT
