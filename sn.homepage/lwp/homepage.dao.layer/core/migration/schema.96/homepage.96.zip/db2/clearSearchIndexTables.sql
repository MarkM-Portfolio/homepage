-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2001, 2009                                    
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-----------------------------------------------------------------------------------------------------------
-- START SEARCH
-----------------------------------------------------------------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- SEARCH

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_RESUME_TOKENS;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_DOCS;
COMMIT;

DELETE FROM HOMEPAGE.SR_FILESCONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_STRING_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_NUMBER_STATS;
COMMIT;

DELETE FROM HOMEPAGE.SR_TIMER_STATS;
COMMIT;


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


-----------------------------------------------------------------------------------------------------------
-- END SEARCH
-----------------------------------------------------------------------------------------------------------


CONNECT RESET;
