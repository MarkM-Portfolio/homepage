-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 100 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START HP FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------


CREATE TABLE HOMEPAGE.OH2P_CACHE (
	LOOKUPKEY VARCHAR(256) NOT NULL, 
	UNIQUEID VARCHAR(128) NOT NULL, 
	COMPONENTID VARCHAR(256) NOT NULL, 
	TYPE VARCHAR(64) NOT NULL, 
	SUBTYPE VARCHAR(64), 
	CREATEDAT BIGINT, 
	LIFETIME INTEGER, 
	EXPIRES BIGINT, 
	TOKENSTRING VARCHAR(2048) NOT NULL, 
	CLIENTID VARCHAR(64) NOT NULL, 
	USERNAME VARCHAR(64) NOT NULL, 
	SCOPE VARCHAR(512) NOT NULL, 
	REDIRECTURI VARCHAR(2048), 
	STATEID VARCHAR(64) NOT NULL
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.OH2P_CACHE 
	ADD CONSTRAINT PK_LOOKUPKEY PRIMARY KEY (LOOKUPKEY);

CREATE INDEX OH2P_CACHE_EXPIRES ON HOMEPAGE.OH2P_CACHE (EXPIRES ASC);


COMMIT;



CREATE TABLE HOMEPAGE.OH2P_CLIENTCFG (
	COMPONENTID VARCHAR(256) NOT NULL, 
	CLIENTID VARCHAR(256) NOT NULL, 
	CLIENTSECRET VARCHAR(256), 
	DISPLAYNAME VARCHAR(256) NOT NULL, 
	REDIRECTURI VARCHAR(2048), 
	ENABLED SMALLINT
)
IN HPNT16TABSPACE;

ALTER TABLE HOMEPAGE.OH2P_CLIENTCFG 
	ADD CONSTRAINT PK_COMPIDCLIENTID PRIMARY KEY (COMPONENTID,CLIENTID);

COMMIT;



ALTER TABLE HOMEPAGE.HP_UI ADD COLUMN WELCOME_NOTE SMALLINT DEFAULT 1;

COMMIT;

reorg table HOMEPAGE.HP_UI;

COMMIT;


-- Update Dogear widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/dogear.xml'
WHERE WIDGET_ID='dogear46x0a77x4a43x82aaxb00187218631';

-- Update My Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/personal/mybookmarks.xml'
WHERE WIDGET_ID='dembk46x0a77x4a43x82aaxb00187218631';

-- Update Popular Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/popular/popularbookmarks.xml'
WHERE WIDGET_ID='depbk46x0a77x4a43x82aaxb00187218631';

-- Update Recent Bookmarks widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/recent/recentbookmarks.xml'
WHERE WIDGET_ID='derbk46x0a77x4a43x82aaxb00187218631';

-- Update Watchlist widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/bookmarks/watching/watchlist.xml'
WHERE WIDGET_ID='dewl46x0a77x4a43x82aaxb00187218631';

-- Update Activities Original widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activities.xml'
WHERE WIDGET_ID='activitixa187x491dxa4bfx2e1261d0b6ec';

-- Update MyActivities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/personal/myactivities.xml'
WHERE WIDGET_ID='myactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Public Activities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/pub/publicactivities.xml'
WHERE WIDGET_ID='pubactxa187x491dxa4bfx2e1261d0b6ec';

-- Update Sidebar Activities ToDo Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/activities/activitiesTodoList.xml'
WHERE WIDGET_ID='activities-sidebar7x4229x8';

-- Update Communities Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/communities.xml'
WHERE WIDGET_ID='communitxe7c4x4e08xab54x80e7a4eb8933';

-- Update MyCommunities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/personal/mycommunities.xml'
WHERE WIDGET_ID='mycommunxe7c4x4e08xab54x80e7a4eb8933';

-- Update Public Communities Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/communities/pub/publiccommunities.xml'
WHERE WIDGET_ID='pubcommuxe7c4x4e08xab54x80e7a4eb8933';

-- Update Blogs widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/blogs/blogs.xml'
WHERE WIDGET_ID='blogs448xcd34x4565x9469x9c34fcefe48c';

-- Update Profiles Original Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/profiles.xml'
WHERE WIDGET_ID='profilesxaac7x4229x87bbx9a1c3551c591';

-- Update MyProfile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/personal/myprofile.xml'
WHERE WIDGET_ID='myprofisxaac7x4229x87bbx9a1c3551c591';

-- Update Colleague Profile widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/profiles/colleagues/colleagueprofile.xml'
WHERE WIDGET_ID='colprofsxaac7x4229x87bbx9a1c3551c591';

-- Update MyWiki widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/mywiki.xml'
WHERE WIDGET_ID='mywikiz1xaac7x4229x87BBx91ac3551c591';

-- Update Popular Wiki Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/popularwiki.xml'
WHERE WIDGET_ID='pop-wiki1xaac7x4229x87BBx91ac3551c5';

-- Update Latest Wiki Widget 
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/wikis/latestwiki.xml'
WHERE WIDGET_ID='latest-wiki5jz1xaac7x4229x87BBx91ac';

-- Update MyFiles widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/files.xml'
WHERE WIDGET_ID='myFilesPb86locI7vRV4yY1KKawZvE8Qul88';

-- Update Files shared with me Widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/files/sharedFiles.xml'
WHERE WIDGET_ID='sharedFilesV4fv72LD5NAcGv2nbrex0ExEq';

-- Update Sand widget
UPDATE HOMEPAGE.WIDGET
SET WIDGET_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml',
    WIDGET_SECURE_URL='${COMMON_CONTEXT_ROOT}/web/lconn.homepage/widgets/sand/recommend.xml'
WHERE WIDGET_ID='recommend7x4f6hd93kd9';

COMMIT;

---------------------------------------------------------------------------------
------------------------ END HP FIXUP 100 ---------------------------------------
---------------------------------------------------------------------------------
  
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START NEWS FIXUP 100 -----------------------------------
---------------------------------------------------------------------------------


------------------------------------------------------------------------------
-- INSERT DATA INTO NR_TEMPLATE TABLE
------------------------------------------------------------------------------

INSERT INTO HOMEPAGE.NR_TEMPLATE
		(TEMPLATE_ID, NAME, DATA_SOURCE_STRING, FORMAT, NO_VALUES)
VALUES	('repostIcon-oPldKwZTaR7aAiPFw4L08CyRW','repostIcon', 'asRepostIcon', 'repostIcon', 1); 

COMMIT;



------------------------------------------------------------------------------
-- ADD INDEXES TO NR_STORIES TABLE
------------------------------------------------------------------------------

CREATE INDEX HOMEPAGE.STORIES_CONTAINER_URL_IDX ON 
	HOMEPAGE.NR_STORIES (CONTAINER_URL ASC);

CREATE INDEX HOMEPAGE.STORIES_EVENT_ITEM_ACTOR_IDX ON
	HOMEPAGE.NR_STORIES (EVENT_NAME, ITEM_ID, ACTOR_UUID);
COMMIT;

------------------------------------------------------------------------------------------------
-- [START] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------

--------------------------------------------------------------
-- Make the existing index on ITEM_CORRELATION_ID to a clustered index
--------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_NEWS_SC_ITEM_COR;
COMMIT;
 
CREATE INDEX HOMEPAGE.CL_STATUS_COMMENT_IDX
ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (ITEM_CORRELATION_ID) CLUSTER;
COMMIT;


-----------------------------------------------------------------------------
-- DROP AND RECREATE THE INDEXES USING UPDATE_DATE INSTEAD OF CREATION_DATE
-----------------------------------------------------------------------------
DROP INDEX HOMEPAGE.NR_NEWS_SN_READER_FOLL;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_FOLL
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_FOLLOW_NEWS);
COMMIT;

DROP INDEX HOMEPAGE.NR_NEWS_SN_READER_NETW;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_SN_READER_NETW
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID, IS_NETWORK_NEWS);
COMMIT;

DROP INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER;
COMMIT;

CREATE INDEX HOMEPAGE.NR_NEWS_STATUS_NETWORK_READER
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE DESC, READER_ID);
COMMIT;

DROP INDEX HOMEPAGE.NR_STATUS_NETWORK_DATE;
COMMIT;

CREATE INDEX HOMEPAGE.NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (UPDATE_DATE ASC);
COMMIT;

------------------------------------------------------------------------------------------------
-- [END] UPDATING SET OF INDEXES FOR NR_NEWS_STATUS_NETWORK AND NR_NEWS_STATUS_COMMENT TABLES
------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------
-- ADD WIDGET_ID to the BOARD table
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.BOARD ADD COLUMN WIDGET_ID VARCHAR(36);

COMMIT;

reorg table HOMEPAGE.BOARD;

COMMIT;


------------------------------------------------------------------------------
-- ADD MODERATION FLAGS TO THE ENTRIES TABLE
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_ENTRIES 
	ADD COLUMN IS_LAST_COMMENT_VISIBLE SMALLINT DEFAULT 1
	ADD COLUMN IS_PREV_COMMENT_VISIBLE SMALLINT DEFAULT 1;

COMMIT;

reorg table HOMEPAGE.NR_ENTRIES;

COMMIT;

ALTER TABLE HOMEPAGE.NR_ENTRIES_ARCHIVE 
	ADD COLUMN IS_LAST_COMMENT_VISIBLE SMALLINT DEFAULT 1
	ADD COLUMN IS_PREV_COMMENT_VISIBLE SMALLINT DEFAULT 1;

COMMIT;

reorg table HOMEPAGE.NR_ENTRIES_ARCHIVE;

COMMIT;


------------------------------------------------------------------------------
-- MOVE COLUMNS BETWEEN NR_STORY AND NR_STORIES_CONTENT TABLES
------------------------------------------------------------------------------

DROP INDEX HOMEPAGE.STORIES_CONTENT_STORY;
DROP INDEX HOMEPAGE.NR_STORIES_CONTENT_DATE;
RENAME TABLE HOMEPAGE.NR_STORIES_CONTENT TO NR_STORIES_CONTENT_OLD;


CREATE TABLE HOMEPAGE.NR_STORIES_CONTENT (
	STORY_CONTENT_ID VARCHAR(36) NOT NULL,
	CONTENT BLOB(1M),
	CREATION_DATE TIMESTAMP NOT NULL,
	STORY_ID VARCHAR(36),
	SOURCE_TYPE SMALLINT,
	ACTIVITY_META_DATA CLOB,
	ITEM_CONTENT CLOB,
	ITEM_CORRELATION_CONTENT CLOB,
	CONTENT_FORMAT SMALLINT,
	ITEM_CONTENT_FORMAT SMALLINT,
	ITEM_CORRELATION_FORMAT SMALLINT,
	ACTIVITY_META_DATA_1 VARCHAR(4000) for bit data,
	ACTIVITY_META_DATA_2 VARCHAR(4000) for bit data,
	IS_META_DATA_TRUNCATED SMALLINT,
	ITEM_BRIEF_DESC VARCHAR(4000),
	ITEM_CORRELATION_BRIEF_DESC VARCHAR(4000)
)
IN NEWS32TABSPACE;

COMMIT;

--------------------------------------------------------------
-- MIGRATE DATA
--------------------------------------------------------------
reorg table HOMEPAGE.NR_STORIES_CONTENT;
commit; 

EXPORT TO data.tmp.ixf OF IXF METHOD N ( 
	STORY_CONTENT_ID,CONTENT,CREATION_DATE,STORY_ID,SOURCE_TYPE,
	ACTIVITY_META_DATA,ITEM_CONTENT,ITEM_CORRELATION_CONTENT,
	CONTENT_FORMAT,ITEM_CONTENT_FORMAT,ITEM_CORRELATION_FORMAT,
	ACTIVITY_META_DATA_1,ACTIVITY_META_DATA_2,IS_META_DATA_TRUNCATED,
	ITEM_BRIEF_DESC,ITEM_CORRELATION_BRIEF_DESC
)
 SELECT 
	STORY_CONTENT_ID,CONTENT,CREATION_DATE,STORY_ID,SOURCE_TYPE,
	ACTIVITY_META_DATA,ITEM_CONTENT,ITEM_CORRELATION_CONTENT,
	CONTENT_FORMAT,ITEM_CONTENT_FORMAT,ITEM_CORRELATION_FORMAT,
	' '  ACTIVITY_META_DATA_1, ' '  ACTIVITY_META_DATA_2, 0 IS_META_DATA_TRUNCATED,
	' ' ITEM_BRIEF_DESC, ' '  ITEM_CORRELATION_BRIEF_DESC
 FROM HOMEPAGE.NR_STORIES_CONTENT_OLD ;



IMPORT FROM data.tmp.ixf OF IXF METHOD N ( 
	STORY_CONTENT_ID,CONTENT,CREATION_DATE,STORY_ID,SOURCE_TYPE,
	ACTIVITY_META_DATA,ITEM_CONTENT,ITEM_CORRELATION_CONTENT,
	CONTENT_FORMAT,ITEM_CONTENT_FORMAT,ITEM_CORRELATION_FORMAT,
	ACTIVITY_META_DATA_1,ACTIVITY_META_DATA_2,IS_META_DATA_TRUNCATED,
	ITEM_BRIEF_DESC,ITEM_CORRELATION_BRIEF_DESC
) COMMITCOUNT 1000 
INSERT INTO HOMEPAGE.NR_STORIES_CONTENT ( 
	STORY_CONTENT_ID,CONTENT,CREATION_DATE,STORY_ID,SOURCE_TYPE,
	ACTIVITY_META_DATA,ITEM_CONTENT,ITEM_CORRELATION_CONTENT,
	CONTENT_FORMAT,ITEM_CONTENT_FORMAT,ITEM_CORRELATION_FORMAT,
	ACTIVITY_META_DATA_1,ACTIVITY_META_DATA_2,IS_META_DATA_TRUNCATED,
	ITEM_BRIEF_DESC,ITEM_CORRELATION_BRIEF_DESC
); 
COMMIT; 

reorg table HOMEPAGE.NR_STORIES_CONTENT;
COMMIT; 

DROP TABLE HOMEPAGE.NR_STORIES_CONTENT_OLD;


ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
  	ADD CONSTRAINT "PK_STORY_CONT_ID" PRIMARY KEY("STORY_CONTENT_ID");

CREATE INDEX HOMEPAGE.STORIES_CONTENT_STORY
    ON HOMEPAGE.NR_STORIES_CONTENT (STORY_ID);

CREATE INDEX HOMEPAGE.NR_STORIES_CONTENT_DATE
    ON HOMEPAGE.NR_STORIES_CONTENT (CREATION_DATE ASC);    	

COMMIT;


ALTER TABLE HOMEPAGE.NR_STORIES 
	DROP COLUMN ACTIVITY_META_DATA_1
	DROP COLUMN ACTIVITY_META_DATA_2
	DROP COLUMN IS_META_DATA_TRUNCATED;

ALTER TABLE HOMEPAGE.NR_STORIES 
	ADD COLUMN RELATED_COMMUNITY_ID VARCHAR(36);

COMMIT;

reorg table HOMEPAGE.NR_STORIES;

COMMIT;



------------------------------------------------------------------------------
-- ADD INDEX ON ROLLUP_ENTRY_ID TO ALL READER TABLES
------------------------------------------------------------------------------

CREATE  INDEX HOMEPAGE.AGGREGATED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_AGGREGATED_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.RESPONSES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_RESPONSES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.COMM_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_COMMUNITIES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.ACTIVITIES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIVITIES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.BLOGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BLOGS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.BOOKMARKS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_BOOKMARKS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.FILES_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FILES_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.FORUMS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_FORUMS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.WIKIS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_WIKIS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.TAGS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TAGS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.STATUS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_STATUS_UPDATE_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.EXTERNAL_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_EXTERNAL_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.ACTIONABLE_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_ACTIONABLE_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.DISCOVERY_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_DISCOVERY_VIEW (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.PROFILES_VIEW_ROLLUP_IX 
 	ON HOMEPAGE.NR_PROFILES_VIEW (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.NOTIFICA_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_SENT_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.NOT_REC_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_NOTIFICATION_RECEIV_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.SAVED_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_SAVED_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

CREATE  INDEX HOMEPAGE.TOPICS_READERS_ROLLUP_IX 
 	ON HOMEPAGE.NR_TOPICS_READERS (ROLLUP_ENTRY_ID, READER_ID); 
COMMIT;

------------------------------------------------------------------------------
-- ADD NR_AS_CONTENT_INDEX_STATS TABLE
------------------------------------------------------------------------------

CREATE TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS (
	STAT_ID VARCHAR(36) NOT NULL,
	STAT_NAME VARCHAR(2048),
	STAT_VALUE BLOB(100M)
)
IN NEWS4TABSPACE;

ALTER TABLE HOMEPAGE.NR_AS_CONTENT_INDEX_STATS
  	ADD CONSTRAINT NR_CONTENTSTATS_PK PRIMARY KEY(STAT_ID);

COMMIT;

------------------------------------------------------------------------------
-- DB schema consistency with event model [START]
------------------------------------------------------------------------------

ALTER TABLE HOMEPAGE.NR_STORIES_CONTENT
	ADD COLUMN ITEM_TAGS VARCHAR(1024)
	ADD COLUMN ITEM_CORRELATION_TAGS VARCHAR(1024);

COMMIT;

reorg table HOMEPAGE.NR_STORIES_CONTENT;

COMMIT; 

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [start]

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID < '0..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '0..f' AND STORY_ID < '1..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '1..f' AND STORY_ID < '2..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '2..f' AND STORY_ID < '3..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '3..f' AND STORY_ID < '4..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '4..f' AND STORY_ID < '5..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '5..f' AND STORY_ID < '6..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '6..f' AND STORY_ID < '7..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '7..f' AND STORY_ID < '8..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '8..f' AND STORY_ID < '9..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= '9..f' AND STORY_ID < 'a..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'a..f' AND STORY_ID < 'b..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'b..f' AND STORY_ID < 'c..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'c..f' AND STORY_ID < 'd..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'd..f' AND STORY_ID < 'e..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'e..f' AND STORY_ID < 'f..f';

COMMIT;

UPDATE HOMEPAGE.NR_STORIES_CONTENT STORIES_CONTENT SET
ITEM_TAGS = (SELECT ITEM_TAGS FROM HOMEPAGE.NR_STORIES STORIES WHERE STORIES.STORY_ID = STORIES_CONTENT.STORY_ID)
WHERE STORY_ID >= 'f..f';

COMMIT;

-- Copy ITEM_TAGS data from NR_STORIES to NR_STORIES_CONTENT [end]


ALTER TABLE HOMEPAGE.NR_STORIES
	DROP COLUMN ITEM_TAGS
	DROP COLUMN ITEM_AUTHOR_DISPLAYNAME;
COMMIT;

ALTER TABLE HOMEPAGE.NR_STORIES
	ADD COLUMN ITEM_CORRELATION_SCOPE SMALLINT
	ADD COLUMN ITEM_CORRELATION_UPDATE_DATE TIMESTAMP
	ADD COLUMN ITEM_CORRELATION_URL VARCHAR(2048);
COMMIT;

reorg table HOMEPAGE.NR_STORIES;

COMMIT; 

------------------------------------------------------------------------------
-- DB schema consistency with event model [END]
------------------------------------------------------------------------------



---------------------------------------------------------------------------------
------------------------ END NEWS FIXUP 100 -------------------------------------
---------------------------------------------------------------------------------
 

  
  
  
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 100 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

CREATE INDEX HOMEPAGE.SR_FEEDBACK_PERSON_ID_IDX ON HOMEPAGE.SR_FEEDBACK (PERSON_ID);
COMMIT;

ALTER TABLE HOMEPAGE.SR_FILESCONTENT 
DROP COLUMN CONTENT;
COMMIT;

DELETE FROM HOMEPAGE.SR_INDEX_MANAGEMENT;
COMMIT;

ALTER TABLE HOMEPAGE.SR_INDEX_MANAGEMENT
ADD COLUMN OUT_OF_SYNC SMALLINT NOT NULL DEFAULT 0;
COMMIT;

reorg table HOMEPAGE.SR_FILESCONTENT use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_FILESCONTENT;

reorg table HOMEPAGE.SR_INDEX_MANAGEMENT use TEMPSPACE1;
reorg indexes all for table HOMEPAGE.SR_INDEX_MANAGEMENT;

RUNSTATS ON TABLE "HOMEPAGE"."SR_FILESCONTENT";
RUNSTATS ON TABLE "HOMEPAGE"."SR_FILESCONTENT" FOR INDEXES ALL;

RUNSTATS ON TABLE "HOMEPAGE"."SR_INDEX_MANAGEMENT";
RUNSTATS ON TABLE "HOMEPAGE"."SR_INDEX_MANAGEMENT" FOR INDEXES ALL;

---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 100
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 100, RELEASEVER = '4.0.0.0' 
WHERE   DBSCHEMAVER = 99; 

------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 100
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
