-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2010                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 
USE HOMEPAGE;
GO

BEGIN TRANSACTION
GO

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 54
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 54 FOR HP
------------------------------------------------

-- {include.hp-fixup54.sql}

------------------------------------------------
-- INCLUDE FIX UP 54 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-- STATUS_UPDATES tables

-- HOMEPAGE.NR_NEWS_STATUS_NETWORK
-- HOMEPAGE.NR_NEWS_STATUS_COMMENT
-- HOMEPAGE.NR_NEWS_STATUS_CONTENT

CREATE INDEX NR_STATUS_NETWORK_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_NETWORK (CREATION_DATE ASC);
   
GO

CREATE INDEX NR_STATUS_COMMENT_DATE
    ON HOMEPAGE.NR_NEWS_STATUS_COMMENT (CREATION_DATE ASC);

GO

-- NR_STORIES_CONTENT table
CREATE INDEX NR_STORIES_CONTENT_DATE
    ON HOMEPAGE.NR_STORIES_CONTENT (CREATION_DATE ASC);

GO

-- FOLLOWED STORIES tableS

--HOMEPAGE.NR_RESPONSES_STORIES 
--HOMEPAGE.NR_PROFILES_STORIES
--HOMEPAGE.NR_COMMUNITIES_STORIES
--HOMEPAGE.NR_ACTIVITIES_STORIES
--HOMEPAGE.NR_BLOGS_STORIES
--HOMEPAGE.NR_BOOKMARKS_STORIES
--HOMEPAGE.NR_FILES_STORIES
--HOMEPAGE.NR_FORUMS_STORIES
--HOMEPAGE.NR_WIKIS_STORIES
--HOMEPAGE.NR_TAGS_STORIES

CREATE INDEX NR_RESPONSES_STORIES_DATE
    ON HOMEPAGE.NR_RESPONSES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_PROFILES_STORIES_DATE
    ON HOMEPAGE.NR_PROFILES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_COMMUNITIES_STORIES_DATE
    ON HOMEPAGE.NR_COMMUNITIES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_ACTIVITIES_STORIES_DATE
    ON HOMEPAGE.NR_ACTIVITIES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_BLOGS_STORIES_DATE
    ON HOMEPAGE.NR_BLOGS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_BOOKMARKS_STORIES_DATE
    ON HOMEPAGE.NR_BOOKMARKS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_FILES_STORIES_DATE
    ON HOMEPAGE.NR_FILES_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_FORUMS_STORIES_DATE
    ON HOMEPAGE.NR_FORUMS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_WIKIS_STORIES_DATE
    ON HOMEPAGE.NR_WIKIS_STORIES (CREATION_DATE ASC);

GO

CREATE INDEX NR_TAGS_STORIES_DATE
    ON HOMEPAGE.NR_TAGS_STORIES (CREATION_DATE ASC);

GO

-- HOMEPAGE.NR_COMM_PERSON_STORIES
CREATE INDEX NR_COMM_PERSON_STORIES_DATE
    ON HOMEPAGE.NR_COMM_PERSON_STORIES (CREATION_DATE ASC);

GO

-- HOMEPAGE.NR_COMM_STORIES
CREATE INDEX NR_COMM_STORIES_DATE
    ON HOMEPAGE.NR_COMM_STORIES (CREATION_DATE ASC);

GO    


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 54 FOR SEARCH
------------------------------------------------

--{include.search-fixup54.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 54
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 54 , RELEASEVER = '3.0.0.0'
WHERE   DBSCHEMAVER = 53;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 54
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
