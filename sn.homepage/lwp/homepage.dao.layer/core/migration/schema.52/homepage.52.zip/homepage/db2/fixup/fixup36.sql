-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 36 FOR HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
----------------------------------------------------------------------
-- 1) ADDING the new widget - UPDATE activities to do list (review) 
----------------------------------------------------------------------
UPDATE 	HOMEPAGE.WIDGET 
SET 	WIDGET_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml', WIDGET_SECURE_URL='web/widgets/activitiesTodoList/activitiesTodoList.xml'
WHERE 	WIDGET_ID='activities-sidebar7x4229x8';

INSERT INTO HOMEPAGE.WIDGET (WIDGET_ID,WIDGET_TITLE,WIDGET_TEXT,WIDGET_URL,WIDGET_ICON,WIDGET_ENABLED,WIDGET_SYSTEM,WIDGET_HOMEPAGE_SPECIFIC,WIDGET_PREVIEW_IMAGE,WIDGET_CATEGORY,WIDGET_IS_DEFAULT_OPENED,WIDGET_MULTIPLE_INSTANCES,WIDGET_MARKED_CACHABLE,WIDGET_SECURE_URL,WIDGET_SECURE_ICON) VALUES ('recommend7x4f6hd93kd9','%widget.sand.recommend.name','%widget.sand.recommend.desc','web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png',1,0,1,'${HOMEPAGE_CONTEXT_ROOT}/web/jsp/palette/images/profiles_my_colleagues.jpg','SAND',1,0,0,'web/widgets/sand/recommend.xml','${HOMEPAGE_CONTEXT_ROOT}/images/default_buttons/png/iconRecommend16.png');

INSERT INTO HOMEPAGE.HP_WIDGET_TAB (WIDGET_TAB_ID,WIDGET_ID,TAB_ID,TYPE) VALUES ('UPDATES_recommend-sidebar','recommend7x4f6hd93kd9','_panel.updatex4a43x82aaxb00187218631','primary');

INSERT INTO HOMEPAGE.PREREQ 
			(PREREQ_ID,APP_ID,WIDGET_ID) 
VALUES 		('9t1a20f1xc4cax6cc4x8b0bx51af2ddef2cd','sand','recommend7x4f6hd93kd9');

----------------------------------------------------------------------
-- 2) ADDING TO THE PERSON TABLE A LAST_UPDATE ATTRIBUTE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.PERSON
	ADD LAST_UPDATE TIMESTAMP;

----------------------------------------------------------------------
-- 3) REFACTORING OF THE NOTIFICATIONS tables 
--		DB script update to store internal IDs for users in notification tables
----------------------------------------------------------------------
------------------------------------  NT_NOTIFICATION -------------------------------------
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD SENDER_ID VARCHAR(36);

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
ADD FIRST_RECIPIENT_ID VARCHAR(36);

-- add index (ADDED) - it is new index (we need to remove it after) FIX
CREATE INDEX HOMEPAGE.NT_NOTIFICATION_FP_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(FIRST_RECIPIENT_EXID);	

RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

-- sender_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET SENDER_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.SENDER_EXID);

COMMIT;        

-- first_recipient_id
UPDATE HOMEPAGE.NT_NOTIFICATION    	
SET FIRST_RECIPIENT_ID = (   SELECT  HOMEPAGE.PERSON.PERSON_ID
                    FROM    HOMEPAGE.PERSON
                    WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION.FIRST_RECIPIENT_EXID);

COMMIT;

-- drop (REMOVE) the temp index FIX
DROP INDEX HOMEPAGE.NT_NOTIFICATION_FP_INDEX;       

-- sender
DROP INDEX HOMEPAGE.NT_NOTIFICATION_EXID_INDEX;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN SENDER_EXID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT "FK_SENDER_ID" FOREIGN KEY ("SENDER_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");
	
-- recipient
ALTER TABLE HOMEPAGE.NT_NOTIFICATION
DROP COLUMN FIRST_RECIPIENT_EXID;

ALTER TABLE HOMEPAGE.NT_NOTIFICATION
    ADD CONSTRAINT "FK_F_RECIPIENT_ID" FOREIGN KEY ("FIRST_RECIPIENT_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

-- add index
CREATE INDEX HOMEPAGE.NT_NOTIFICATION_EXID_INDEX
	ON HOMEPAGE.NT_NOTIFICATION(SENDER_ID);

--REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;

 
------------------ NT_NOTIFICATION_RECIPIENT --------------
-- to remove LOLLO
RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;	
	
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
ADD RECIPIENT_ID VARCHAR(36);

UPDATE HOMEPAGE.NT_NOTIFICATION_RECIPIENT    	
SET RECIPIENT_ID = (    SELECT  HOMEPAGE.PERSON.PERSON_ID
                        FROM    HOMEPAGE.PERSON
                        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID)
WHERE EXISTS
  (     SELECT  HOMEPAGE.PERSON.PERSON_ID
        FROM    HOMEPAGE.PERSON
        WHERE   HOMEPAGE.PERSON.EXID = HOMEPAGE.NT_NOTIFICATION_RECIPIENT.RECIPIENT_EXID);

COMMIT;        
        
DROP INDEX HOMEPAGE.NT_NOTIF_RECT_EXID_INDEX;        

ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
DROP COLUMN RECIPIENT_EXID;

--REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT; 
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;


-- add fk
ALTER TABLE HOMEPAGE.NT_NOTIFICATION_RECIPIENT
    ADD CONSTRAINT "FK_RECIPIENT_ID" FOREIGN KEY ("RECIPIENT_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;

-- add index
CREATE INDEX HOMEPAGE.NT_NOT_RECIPIENT_INDEX
	ON HOMEPAGE.NT_NOTIFICATION_RECIPIENT(RECIPIENT_ID);

--REORG TABLE	HOMEPAGE.NT_NOTIFICATION;
--REORG TABLE	HOMEPAGE.NT_NOTIFICATION_RECIPIENT;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION_RECIPIENT" FOR INDEXES ALL;
--RUNSTATS ON TABLE "HOMEPAGE"."NT_NOTIFICATION" FOR INDEXES ALL;
    
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 36 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
----------------------------------------------------------------------
-- 4) ADDING A UNIQUE CONSTRAINT on EMD_EMAIL_PREFES - PERSON ID
---------------------------------------------------------------------
ALTER TABLE HOMEPAGE.EMD_EMAIL_PREFS 
	ADD CONSTRAINT UNIQUE_PREFS UNIQUE ("PERSON_ID");

----------------------------------------------------------------------
-- 5) REMOVE NR_NEWS_COMMENT table
----------------------------------------------------------------------
DROP TABLE HOMEPAGE.NR_NEWS_COMMENT;

----------------------------------------------------------------------
-- 6) SET HP_UI.WELCOME MODE  to 1 for all the users 
----------------------------------------------------------------------
UPDATE HOMEPAGE.HP_UI SET WELCOME_MODE = 1;

----------------------------------------------------------------------
-- 7) DROP NOT NULL on NR_STORIES for column R_META_TEMPLATE 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES DROP FOREIGN KEY "FK_F_STORY_ID";
ALTER TABLE HOMEPAGE.NR_COMM_STORIES DROP FOREIGN KEY "FK_COMM_STORY_ID";
ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES  DROP FOREIGN KEY "FK_ORGP_STORY_ID";

DROP TABLE HOMEPAGE.NR_STORIES;

CREATE TABLE HOMEPAGE.NR_STORIES (
	STORY_ID VARCHAR(36) NOT NULL,
	EVENT_NAME VARCHAR(256) NOT NULL,
	SOURCE VARCHAR(36),
	CONTAINER_ID VARCHAR(36),	
	CONTAINER_NAME VARCHAR(256),
	CONTAINER_URL VARCHAR(2048),
	ITEM_NAME VARCHAR(256),
	ITEM_URL VARCHAR(2048),
	ITEM_ATOM_URL VARCHAR(2048),
	ITEM_ID VARCHAR(36), -- NEW
	ITEM_CORRELATION_ID VARCHAR(36), -- NEW	
	CREATION_DATE TIMESTAMP NOT NULL,
	BRIEF_DESC VARCHAR(512),
	ACTOR_UUID VARCHAR(36),
	EVENT_RECORD_UUID VARCHAR(36) NOT NULL,
	TAGS VARCHAR(1024),
	META_TEMPLATE VARCHAR(4096) DEFAULT '' NOT NULL,
	TEXT_META_TEMPLATE VARCHAR(1024),
	R_META_TEMPLATE VARCHAR(4096),
	R_TEXT_META_TEMPLATE VARCHAR(1024),
	N_COMMENTS SMALLINT NOT NULL DEFAULT 0, -- NEW
	N_RECOMMANDATIONS SMALLINT NOT NULL DEFAULT 0 -- NEW
)
IN NEWS32TABSPACE;

ALTER TABLE HOMEPAGE.NR_STORIES
    ADD CONSTRAINT "PK_STORY_ID" PRIMARY KEY("STORY_ID");
    
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_STORIES  TO USER LCUSER;  

ALTER TABLE HOMEPAGE.NR_FOLLOWED_STORIES
    ADD CONSTRAINT "FK_F_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

ALTER TABLE HOMEPAGE.NR_COMM_STORIES
    ADD CONSTRAINT "FK_COMM_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");

ALTER TABLE HOMEPAGE.NR_ORGPERSON_STORIES
    ADD CONSTRAINT "FK_ORGP_STORY_ID" FOREIGN KEY ("STORY_ID")
	REFERENCES HOMEPAGE.NR_STORIES ("STORY_ID");    

----------------------------------------------------------------------
-- 8) REMOVE RELATED COMMUNITY COLUMNS FROM DISCOVERY TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_DISCOVERY
DROP COLUMN RELATED_COMM_NAME;

----------------------------------------------------------------------
-- 9) REMOVE RELATED COMMUNITY COLUMNS FROM NR_NEWS_SAVED TABLES 
----------------------------------------------------------------------
ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_UUID;

ALTER TABLE HOMEPAGE.NR_NEWS_SAVED
DROP COLUMN RELATED_COMM_NAME;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 36 FOR SEARCH
------------------------------------------------

--{include.search-fixup36.sql}



------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 36
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 36 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 35;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 36
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
