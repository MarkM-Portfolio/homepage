-- ***************************************************************** 
--                                                                   
-- IBM Confidential                                                  
--                                                                   
-- OCO Source Materials                                              
--                                                                   
-- Copyright IBM Corp. 2009                                          
--                                                                   
-- The source code for this program is not published or otherwise    
-- divested of its trade secrets, irrespective of what has been      
-- deposited with the U.S. Copyright Office.                         
--                                                                   
-- ***************************************************************** 

CONNECT TO HOMEPAGE;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					start	FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


------------------------------------------------
-- INCLUDE FIX UP 32 FOR HP
------------------------------------------------

--{include.hp-fixup32.sql}

------------------------------------------------
-- INCLUDE FIX UP 32 FOR NEWS HP
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- Missing fk for NR_NEWS_WATCHLIST
ALTER TABLE HOMEPAGE.NR_NEWS_WATCHLIST
	ADD CONSTRAINT "FK_F_WSOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");
	
-- REMOVING NR_FOLLOW_GROUP table
DROP TABLE HOMEPAGE.NR_FOLLOW_GROUP;

-- REFACTORING THE NR_FOLLOW table; 
DROP TABLE HOMEPAGE.NR_FOLLOW;

-- REMOVING NR_CATEGORY table
DROP TABLE HOMEPAGE.NR_CATEGORY;

------------------------------------------------
-- NR_FOLLOW
------------------------------------------------
CREATE TABLE HOMEPAGE.NR_FOLLOW (
	FOLLOW_ID VARCHAR(36) NOT NULL,
	PERSON_ID VARCHAR(36) NOT NULL,
	SOURCE_ID VARCHAR(36) NOT NULL,
	CATEGORY_TYPE SMALLINT NOT NULL
)
IN NEWSTABSPACE;

ALTER TABLE HOMEPAGE.NR_FOLLOW 
    ADD CONSTRAINT "PK_FOLLOW_ID" PRIMARY KEY("FOLLOW_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_PERSON_ID" FOREIGN KEY ("PERSON_ID")
	REFERENCES HOMEPAGE.PERSON("PERSON_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_F_SOURCE_ID" FOREIGN KEY ("SOURCE_ID")
	REFERENCES HOMEPAGE.NR_SOURCE_WATCHED("SOURCE_ID");

ALTER TABLE HOMEPAGE.NR_FOLLOW
	ADD CONSTRAINT "FK_CATEGORY_TYPE" FOREIGN KEY ("CATEGORY_TYPE")
	REFERENCES HOMEPAGE.NR_CATEGORY_TYPE("CATEGORY_TYPE");

runstats on table HOMEPAGE.NR_FOLLOW with distribution and detailed indexes all allow write access;
GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.NR_FOLLOW TO USER LCUSER;

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR PROFILES SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		1
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 1 AND -- 1 is profile
        NR_SOURCE.SOURCE = 'profiles';

-- MIGRATE DATA TO THE FOLLOW TABLE
-- CREATE THE RELETIONSHIP FOR TAG SOURCE INTO THE FOLLOW TABLE
INSERT INTO HOMEPAGE.NR_FOLLOW (
    FOLLOW_ID,
    PERSON_ID,
    SOURCE_ID,
    CATEGORY_TYPE    
)
SELECT  SUBSTR(NR_SUBSCRIPTION.PERSON_ID,1,10) || 
        SUBSTR(NR_SOURCE.SOURCE_ID,1,10) ||  
        SUBSTR((SUBSTR((NR_CATEGORY_TYPE.CATEGORY_TYPE_NAME || NR_SUBSCRIPTION.PERSON_ID),2,36)),1,14),
        NR_SUBSCRIPTION.PERSON_ID,
        NR_SOURCE.SOURCE_ID,
		2
FROM    HOMEPAGE.NR_SUBSCRIPTION NR_SUBSCRIPTION, 
        HOMEPAGE.NR_SOURCE NR_SOURCE, 
        HOMEPAGE.NR_CATEGORY_TYPE NR_CATEGORY_TYPE        
WHERE   NR_SUBSCRIPTION.SOURCE_ID = NR_SOURCE.SOURCE_ID  AND 
        NR_SUBSCRIPTION.IS_EXPLICIT = 1 AND
        NR_SUBSCRIPTION.IS_ACTIVE = 1 AND
        NR_CATEGORY_TYPE.CATEGORY_TYPE = 2 AND -- 2 is tags
        NR_SOURCE.SOURCE = 'tag';        

COMMIT;

-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END NewsHp Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


------------------------------------------------
-- INCLUDE FIX UP 32 FOR SEARCH
------------------------------------------------


-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- START: Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
---------------------------------------------------------------------------------
------------------------ START SEARCH -------------------------------------------
---------------------------------------------------------------------------------

--SPR #JJOL82AEP2
DELETE FROM HOMEPAGE.SR_FACET_DOCS WHERE DOCUMENT_ID NOT IN (SELECT DOCUMENT_ID FROM HOMEPAGE.SR_INDEX_DOCS);

ALTER TABLE HOMEPAGE.SR_FACET_DOCS
	ADD CONSTRAINT "FK_IDX_DOC_ID" FOREIGN KEY ("DOCUMENT_ID") 
	REFERENCES  HOMEPAGE.SR_INDEX_DOCS("DOCUMENT_ID") ON DELETE CASCADE;	

----------------------------------------
--  SR_SANDTASKDEF
----------------------------------------

CREATE TABLE HOMEPAGE.SR_SANDTASKDEF (
    SAND_TASK_ID VARCHAR(36) NOT NULL,
    TASK_ID VARCHAR(36) NOT NULL,
	SAND_TASK_SERVICES VARCHAR(256) NOT NULL
)
IN HOMEPAGETABSPACE;

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "PK_ST_TASK_ID" PRIMARY KEY ("SAND_TASK_ID");

ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "UNIQUE_TASK_ID_ST" UNIQUE ("TASK_ID");
	
ALTER TABLE HOMEPAGE.SR_SANDTASKDEF
	ADD CONSTRAINT "FK_ST_TASK_ID" FOREIGN KEY ("TASK_ID") 
	REFERENCES  HOMEPAGE.SR_TASKDEF("TASK_ID") ON DELETE CASCADE;

INSERT INTO HOMEPAGE.SR_TASKDEF(TASK_ID,TASK_NAME,STARTBY,INTERVAL,TASK_TYPE,ENABLED) VALUES('ea789e87-c262-484b-92f4-d60af4bef3d4','nightly-sand-task','0 15 1 * * ?','0 0 1 * * ?','SaNDTask',1);

INSERT INTO HOMEPAGE.SR_SANDTASKDEF(SAND_TASK_ID,TASK_ID,SAND_TASK_SERVICES) VALUES('fd44131a-5075-4bcb-85a9-9e501bd010fb','ea789e87-c262-484b-92f4-d60af4bef3d4','evidence-graph-manageremployees-tags-taggedby');

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_SANDTASKDEF TO USER LCUSER;


----------------------------------------
--  SR_ALLTASKSDEF
----------------------------------------

DROP VIEW HOMEPAGE.SR_ALLTASKSDEF;

CREATE VIEW HOMEPAGE.SR_ALLTASKSDEF AS
(
	SELECT 	T1.TASK_ID  		AS	PARENT_TASK_ID,
	T1.TASK_NAME 				AS	PARENT_TASK_NAME,
	T1.INTERVAL 				AS	PARENT_TASK_INTERVAL,
	T1.STARTBY	 				AS	PARENT_TASK_STARTBY,
	T1.TASK_TYPE 				AS	PARENT_TASK_TYPE,
	T1.ENABLED					AS  	PARENT_TASK_ENABLED,
	T2.INDEXING_TASK_SERVICES	AS	INDEXING_TASK_SERVICES,
	T2.INDEXING_TASK_OPTIMIZE	AS	INDEXING_TASK_OPTIMIZE,
	T2.INDEXING_TASK_ID			AS	INDEXING_TASK_ID,
	''							AS	OPTIMIZE_TASK_ID,
	'' 							AS 	FILECONTENT_TASK_ID,
	''							AS				FILE_CONTENT_TASK_SERVICES,
	0							AS 	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''			AS	SAND_TASK_SERVICES,
	'' 							AS 	BACKUP_TASK_ID,
	''							AS	BACKUP_TASK_TYPE,
	''							AS	BACKUP_TASK_SCRIPT,
	T2.INDEXING_TASK_ID			AS	CHILDTASK_PK	
	FROM    HOMEPAGE.SR_TASKDEF T1,HOMEPAGE.SR_INDEXINGTASKDEF T2 
	WHERE T1.TASK_ID=T2.TASK_ID
) 
UNION 
(
	SELECT T3.TASK_ID		AS 	PARENT_TASK_ID,
	T3.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T3.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T3.STARTBY 				AS	PARENT_TASK_STARTBY,
	T3.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T3.ENABLED 				AS  	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	T4.OPTIMIZE_TASK_ID 	AS	OPTIMIZE_TASK_ID,
	'' 						AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
        ''                 AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 						AS 	BACKUP_TASK_ID,
	''						AS	BACKUP_TASK_TYPE,
	''						AS	BACKUP_TASK_SCRIPT,
	T4.OPTIMIZE_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T3,HOMEPAGE.SR_OPTIMIZETASKDEF T4
	WHERE  T3.TASK_ID=T4.TASK_ID
)
UNION 
(
	SELECT T5.TASK_ID				AS	PARENT_TASK_ID,
	T5.TASK_NAME 					AS	PARENT_TASK_NAME,
	T5.INTERVAL						AS	PARENT_TASK_INTERVAL,
	T5.STARTBY 						AS	PARENT_TASK_STARTBY,
	T5.TASK_TYPE 					AS	PARENT_TASK_TYPE,
 	T5.ENABLED 						AS	PARENT_TASK_ENABLED,
	''								AS	INDEXING_TASK_SERVICES,
	0								AS	INDEXING_TASK_OPTIMIZE,
	''								AS	INDEXING_TASK_ID,
	''								AS	OPTIMIZE_TASK_ID,
	T6.FILECONTENT_TASK_ID 			AS	FILECONTENT_TASK_ID,
	T6.FILE_CONTENT_TASK_SERVICES	AS	FILE_CONTENT_TASK_SERVICES,
	T6.CONTENT_FAILURES_ONLY		AS	CONTENT_FAILURES_ONLY,
        ''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	'' 								AS 	BACKUP_TASK_ID,
	''								AS	BACKUP_TASK_TYPE,
	''								AS	BACKUP_TASK_SCRIPT,
	T6.FILECONTENT_TASK_ID			AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T5,HOMEPAGE.SR_FILECONTENTTASKDEF T6
	WHERE  T5.TASK_ID=T6.TASK_ID
)
UNION 
(
	SELECT T7.TASK_ID		AS 	PARENT_TASK_ID,
	T7.TASK_NAME 			AS 	PARENT_TASK_NAME,
	T7.INTERVAL				AS 	PARENT_TASK_INTERVAL,
	T7.STARTBY 				AS	PARENT_TASK_STARTBY,
	T7.TASK_TYPE 			AS 	PARENT_TASK_TYPE,
 	T7.ENABLED 				AS	PARENT_TASK_ENABLED,
	''						AS 	INDEXING_TASK_SERVICES,
	0						AS	INDEXING_TASK_OPTIMIZE,
	''						AS	INDEXING_TASK_ID,
	''						AS	OPTIMIZE_TASK_ID,
	''		 				AS 	FILECONTENT_TASK_ID,
	''						AS	FILE_CONTENT_TASK_SERVICES,
	0						AS	CONTENT_FAILURES_ONLY,
	''                  AS      SAND_TASK_ID,
	''                      AS      SAND_TASK_SERVICES,
	T8.BACKUP_TASK_ID		AS 	BACKUP_TASK_ID,
	T8.TYPE					AS	BACKUP_TASK_TYPE,
	T8.SCRIPT				AS	BACKUP_TASK_SCRIPT,
	T8.BACKUP_TASK_ID		AS	CHILDTASK_PK
	FROM   HOMEPAGE.SR_TASKDEF T7,HOMEPAGE.SR_BACKUPTASKDEF T8
	WHERE  T7.TASK_ID=T8.TASK_ID
)
UNION
(
        SELECT T9.TASK_ID                               AS      PARENT_TASK_ID,
        T9.TASK_NAME                                    AS      PARENT_TASK_NAME,
        T9.INTERVAL                                             AS      PARENT_TASK_INTERVAL,
        T9.STARTBY                                              AS      PARENT_TASK_STARTBY,
        T9.TASK_TYPE                                    AS      PARENT_TASK_TYPE,
        T9.ENABLED                                              AS      PARENT_TASK_ENABLED,
        ''                                                              AS      INDEXING_TASK_SERVICES,
        0                                                               AS      INDEXING_TASK_OPTIMIZE,
        ''                                                              AS      INDEXING_TASK_ID,
        ''                                                              AS      OPTIMIZE_TASK_ID,
        ''                                              AS      FILECONTENT_TASK_ID,
        ''                                              AS      FILE_CONTENT_TASK_SERVICES,
        0                                               AS      CONTENT_FAILURES_ONLY,
        T10.SAND_TASK_ID                  AS      SAND_TASK_ID,
	T10.SAND_TASK_SERVICES			AS	SAND_TASK_SERVICES,
        ''                                                              AS      BACKUP_TASK_ID,
        ''                                                              AS      BACKUP_TASK_TYPE,
        ''                                                              AS      BACKUP_TASK_SCRIPT,
        T10.SAND_TASK_ID                  AS      CHILDTASK_PK
        FROM   HOMEPAGE.SR_TASKDEF T9,HOMEPAGE.SR_SANDTASKDEF T10
        WHERE  T9.TASK_ID=T10.TASK_ID
);

GRANT DELETE,INSERT,SELECT,UPDATE ON HOMEPAGE.SR_ALLTASKSDEF TO USER LCUSER;

	
---------------------------------------------------------------------------------
------------------------ END SEARCH ---------------------------------------------
---------------------------------------------------------------------------------
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
-- END Search Schema
-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




------------------------------------------------------------------------------------------------
-- UPDATE SCHEMA VERSION AND RELEASE VERSION to 32
------------------------------------------------------------------------------------------------
UPDATE  HOMEPAGE.HOMEPAGE_SCHEMA SET DBSCHEMAVER = 32 , RELEASEVER = '3.0.0'
WHERE   DBSCHEMAVER = 31;
------------------------------------------------------------------------------------------------

COMMIT;

-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++
--					end	FIXUP 32
-- +++++++++++++++++++++++++++++++++++++++++++++
-- +++++++++++++++++++++++++++++++++++++++++++++


--------------------------------------
-- FLUSH
--------------------------------------
FLUSH PACKAGE CACHE DYNAMIC;


--------------------------------------
-- TERMINATE
--------------------------------------
connect reset;
terminate;
